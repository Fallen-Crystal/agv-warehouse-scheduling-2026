"""核验固定版本原始数据，导出每日统计与本次实验窗口；不更改实验输入。"""
import csv
import hashlib
import json
import shutil
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'deliverables/wepa_real_data'


def write_csv(path, rows, fields):
    # UTF-8 BOM便于中文Windows上的表格软件直接打开。
    with path.open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main():
    selection = json.loads((ROOT/'data/input-selection.json').read_text(encoding='utf-8'))
    for name, key in [('2_orders.json', 'source_sha256'),
                      ('3_initial_fill_lvl.json', 'initial_stock_sha256')]:
        assert hashlib.sha256((OUT/'raw'/name).read_bytes()).hexdigest() == selection[key], name
    orders = json.loads((OUT/'raw/2_orders.json').read_text(encoding='utf-8'))
    groups = defaultdict(list)
    for row in orders:
        groups[int(row[2]//86400)].append(row)
    first = min(r[2] for r in orders)
    last = max(r[2] for r in orders)
    daily = []
    # 零订单日也列出；day是相对起点的整数索引，不是已知日历日期。
    for day in range(int(first//86400), int(last//86400)+1):
        rows = groups[day]
        times = [r[2]-day*86400 for r in rows]
        kinds = Counter(r[0] for r in rows)
        daily.append(dict(day_index=day, orders=len(rows), delivery=kinds['delivery'],
                          retrieval=kinds['retrieval'], calendar_minutes=1440,
                          active_order_minutes=len({int(t//60) for t in times}),
                          first_order_second=min(times) if times else '',
                          last_order_second=max(times) if times else '',
                          first_to_last_minutes=(max(times)-min(times))/60 if times else 0))
    write_csv(OUT/'daily_statistics.csv', daily, list(daily[0]))
    protocol = json.loads((ROOT/'data/protocol.json').read_text(encoding='utf-8'))
    windows, exported = [], []
    used = protocol['development'][:4]+protocol['validation'][:1]
    for case in protocol['cases']:
        if case['case'] not in used:
            continue
        phase = 'train' if case['case'] in protocol['development'][:4] else 'monitor'
        windows.append(dict(case=case['case'], phase=phase, day_index=case['source_day'],
                            start_minute_of_day=(case['start_seconds']%86400)/60,
                            window_minutes=(case['end_seconds']-case['start_seconds'])/60,
                            orders=len(case['tasks'])))
        for task in case['tasks']:
            raw = orders[task['source_row']]
            assert raw[:6] == [task[k] for k in ('kind','sku','source_time','source_dock','batch','week')]
            exported.append(dict(case=case['case'], phase=phase, **task))
    write_csv(OUT/'experiment_windows.csv', windows, list(windows[0]))
    write_csv(OUT/'experiment_orders.csv', exported, list(exported[0]))
    summary = dict(source_commit='da6280a8f8be1010eae64264c69a90258a288173',
                   total_orders=len(orders), first_second=first, last_second=last,
                   first_day_index=min(groups), last_day_index=max(groups),
                   calendar_day_indices=len(daily), days_with_orders=len(groups),
                   elapsed_first_to_last_days=(last-first)/86400,
                   daily_active_minutes_min=min(r['active_order_minutes'] for r in daily),
                   daily_active_minutes_max=max(r['active_order_minutes'] for r in daily),
                   experiment_unique_orders=len(exported), experiment_windows=windows,
                   original_hashes_verified=True, experiment_source_rows_verified=True)
    (OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    source='https://github.com/malerinc/slapstack/tree/'+summary['source_commit']
    text = f'''# WEPA真实订单数据交付说明

来源：{source}，许可见LICENSE。原始订单与初始库存SHA-256已与实验登记值核对。

## 完整原始数据

raw/2_orders.json保留原始字节，共{len(orders):,}条托盘级订单；字段依次为类型、SKU、绝对秒、码头、批次、周编号。
raw/3_initial_fill_lvl.json为起始库存；raw/1_layout.csv为来源仓库地图。本实验使用课程仿真地图，并未使用该原厂地图。

作者说明订单覆盖89天。按时间戳实算：首笔{first}秒，末笔{last}秒，跨越{(last-first)/86400:.6f}天；涉及day{min(groups)}至day{max(groups)}，共{len(daily)}个自然日索引，其中{len(groups)}天有订单。相对日索引不能直接换算成日历日期。

## 每天有多少分钟订单

每天时间桶为1440分钟，但订单是离散到达事件，不是每分钟都有一条。
daily_statistics.csv逐日列出订单量、入出库量、实际有订单的分钟数、首末订单时刻和首末跨度。
active_order_minutes统计当天至少出现一笔订单的不同分钟数；first_to_last_minutes包括中间无订单间隔，不表示连续繁忙时间。首末日可能只有部分时间范围；缺少订单不能单独证明停工或缺失记录。

## 本次DQN实际用量

本次只用了4个15分钟训练窗口和1个15分钟监测窗口：共75分钟不同时间片，其中训练60分钟，监测15分钟，合计{len(exported)}条不同源订单。
experiment_windows.csv列出窗口起点、日索引与订单数；experiment_orders.csv提供这些源订单的可读表。
每个seed将同样4个训练窗口重复6轮，不增加真实数据覆盖。3个seed也不代表3组新日期。
监测窗口被反复使用，属于探索性评估，不是未接触的最终测试集。

导出脚本：export_wepa_data.py。summary.json保存机器可读统计；所有实验窗口源行已逐项与原始订单核验。
'''
    (OUT/'README.md').write_text(text,encoding='utf-8')
    archive=shutil.make_archive(str(ROOT/'deliverables/WEPA_real_data'),'zip',OUT)
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    print(archive)


if __name__ == '__main__':
    main()
