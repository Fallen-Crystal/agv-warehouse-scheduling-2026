"""Freeze new windows on previously used days; do not claim fresh-day evidence."""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import re
from paths import ROOT, sha


def main():
    target = ROOT / 'data/protocol.json'
    protocol = json.loads(target.read_text(encoding='utf-8'))
    if protocol['validation']:
        raise ValueError('Selection already frozen')
    outputs = ROOT.parent.parent / 'outputs'
    raw = outputs / 'agv-simple-routing-20261024/data/raw'
    source = raw / '2_orders.json'
    if sha(source) != protocol['source_sha256']:
        raise ValueError('Raw source differs')
    used, manifests = set(), {}
    for p in sorted(outputs.rglob('protocol.json')):
        try:
            text = p.read_text(encoding='utf-8')
        except (UnicodeError, OSError):
            continue
        ids = re.findall(r'wepa-day\d+-bin\d+', text)
        if ids:
            used.update(ids)
            manifests[p.relative_to(outputs).as_posix()] = sha(p)
    used_days = {int(re.search(r'day(\d+)', c)[1]) for c in used}
    excluded_days = {int(re.search(r'day(\d+)', c)[1]) for c in protocol['development']}
    rows = json.loads(source.read_text(encoding='utf-8'))
    stock = Counter({int(k): v for k, v in json.loads(
        (raw / '3_initial_fill_lvl.json').read_text()).items()})
    bins = defaultdict(list)
    for i, row in enumerate(rows):
        bins[row[2] // 900].append((i, row))
    selected, selected_days = [], set()
    for bucket, entries in bins.items():
        day = bucket // 96
        kinds = Counter(r[0] for _, r in entries)
        skus = sorted({r[1] for _, r in entries})
        if (day not in excluded_days | selected_days and f'wepa-day{day}-bin{bucket}' not in used
            and 35 <= len(entries) <= 65
            and 2 <= len(skus) <= 5 and len(kinds) == 2 and min(kinds.values()) >= 5
            and 0 <= sum(stock[s] for s in skus) <= 900
            and all(stock[s] >= 0 for s in skus)):
            ledger = Counter({s: stock[s] for s in skus})
            for _, r in entries:
                ledger[r[1]] += 1 if r[0] == 'delivery' else -1
            if all(v >= 0 for v in ledger.values()):
                tasks = [dict(id=j, source_row=i, kind=r[0], sku=r[1],
                    release=r[2]-bucket*900, source_time=r[2], source_dock=r[3],
                    batch=r[4], week=r[5]) for j, (i, r) in enumerate(entries)]
                selected.append(dict(case=f'wepa-day{day}-bin{bucket}', source_day=day,
                    source_bin=bucket, start_seconds=bucket*900, end_seconds=(bucket+1)*900,
                    close_at=900, initial={str(s): stock[s] for s in skus}, tasks=tasks))
                selected_days.add(day)
                if len(selected) == 4:
                    break
        for _, r in entries:
            stock[r[1]] += 1 if r[0] == 'delivery' else -1
    if len(selected) != 4:
        raise ValueError('Insufficient eligible new windows outside development days')
    protocol['validation'] = [c['case'] for c in selected]
    protocol['cases'].extend(selected)
    protocol['treatments'] = ['gate', 'hungarian', 'hga']
    protocol['validation_seeds'] = [0, 1]
    protocol['selection'] = 'Three fixed arms: original joint GA, rolling F-aware Hungarian, Hungarian-seeded joint GA; rank development then freeze; validate on unused windows outside development dates; no validation retuning or fresh-date generalization claim.'
    protocol['validation_scope'] = 'Previously untested windows, but reused source dates; dates are the analysis clusters.'
    target.write_text(json.dumps(protocol, indent=2), encoding='utf-8')
    audit = dict(excluded_cases=sorted(used), excluded_days=sorted(excluded_days), prior_used_days=sorted(used_days),
        prior_protocols=manifests, source_sha256=sha(source),
        initial_stock_sha256=sha(raw/'3_initial_fill_lvl.json'),
        selected=protocol['validation'], selected_days=sorted(selected_days),
        rule_amendment='Original fresh-day rule found zero remaining eligible dates, before any algorithm execution; select unused windows instead.',
        fresh_day_generalization=False, read_performance=False, policy_executions_before_selection=0)
    (ROOT/'data/input-selection.json').write_text(json.dumps(audit, indent=2), encoding='utf-8')
    print(json.dumps(audit))


if __name__ == '__main__':
    main()
