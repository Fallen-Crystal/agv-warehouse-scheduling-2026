"""只用内存验证最终报告诚实门槛、真实自适应日志汇总及没有GA时的空范围。"""
import unittest
from unittest.mock import patch
from paths import ROOT  # 与训练入口一致，先初始化冻结基线依赖的模块路径。
from adaptive_hungarian_learning import ADAPTATION
import report_adaptive_hungarian_learning as report

class ReportTests(unittest.TestCase):
    def test_incomplete_creates_no_final_outputs(self):
        with patch.object(report,'read') as read,patch.object(report,'write') as write,patch.object(report.ROOT.__class__,'write_text') as text:
            self.assertFalse(report.publish(dict(complete=False)))
            read.assert_not_called(); write.assert_not_called(); text.assert_not_called()

    def test_stale_model_identity_creates_no_final_outputs(self):
        fixture=dict(complete=True,selection=dict(checkpoint_sha256='audited-model'))
        with patch.object(report,'sha',return_value='different-model'),patch.object(report,'read') as read,patch.object(report,'write') as write,patch.object(report.ROOT.__class__,'write_text') as text:
            with self.assertRaisesRegex(ValueError,'Model identity'): report.publish(fixture)
            read.assert_not_called(); write.assert_not_called(); text.assert_not_called()

    def test_actual_rate_ranges_and_average_claim(self):
        fixture=dict(complete=True,fit_complete=True,training_windows=60,training_decisions=8000,train_steps=31000,
            selection=dict(epoch=2,checkpoint_sha256='fixture-only'),validation_epochs=[dict(epoch=2,mean_ratios=dict(ga=.99,exact=.99,hungarian=.99))],test=[])
        for index in range(5):
            f=dict(dqn=1.01 if index==0 else 1.,ga=1. if index==0 else 1.01,exact=1. if index==0 else 1.01,hungarian=1. if index==0 else 1.01)
            fixture['test'].append(dict(day=200+index,case=f'fixture-{index}',minutes=30,orders=40,F=f,
                actions=dict(hungarian=40),improvement_percent={k:100*(1-f['dqn']/f[k]) for k in report.LABELS}))
        fixture['mean_paired_improvement_percent']={key:sum(t['improvement_percent'][key] for t in fixture['test'])/5 for key in report.LABELS}
        history=[dict(mutation_rate=.7,owner_mutation_rate=.8,crossover_rate=.9,crossover_attempts=10,crossovers=9,order_mutations=7,owner_mutations=8),
            dict(mutation_rate=.95,owner_mutation_rate=.95,crossover_rate=.55,crossover_attempts=10,crossovers=5,order_mutations=10,owner_mutations=9)]
        def read(path):
            if path.name=='adaptive_hungarian_learning_protocol.json': return dict(learning=dict(epochs=6),ga_adaptation=ADAPTATION)
            return dict(ga_searches=[dict(proxy_evaluations=40,mutation_history=history)] if path.name.endswith('_ga.json') else [])
        with patch.object(report,'read',side_effect=read),patch.object(report,'sha',return_value='fixture-only'),patch.object(report,'write') as write,\
             patch.object(report.ROOT.__class__,'exists',return_value=False),patch.object(report.ROOT.__class__,'write_text') as text:
            self.assertTrue(report.publish(fixture))
            result=write.call_args.args[1]
            self.assertTrue(result['average_goal_achieved']); self.assertFalse(result['all_date_pairs_improved'])
            self.assertEqual(result['paired_counts']['ga'],dict(better=4,equal=0,worse=1))
            ga=result['test_ga_adaptation']['ga']; dqn=result['test_ga_adaptation']['dqn']
            self.assertEqual(ga['crossover_range'],[.55,.9]); self.assertEqual(ga['mutation_range'],[.7,.95])
            self.assertEqual((ga['crossover_attempts'],ga['crossovers'],ga['total_proxy_evaluations']),(100,70,200))
            self.assertEqual(ga['crossover_trigger_fraction'],.7)
            self.assertEqual(dqn['searches'],0); self.assertIsNone(dqn['crossover_range']); self.assertIsNone(dqn['crossover_trigger_fraction'])
            document=[call.args[0] for call in text.call_args_list if call.args[0].startswith('# ')][0]
            self.assertIn('未调用GA',document)
            self.assertIn('GA动作次数不等于实际搜索次数',document)
            # 失败案例仍从正式F计算改善率，避免构造互相矛盾的报告输入。
            for t in fixture['test']:
                t['F']['hungarian']=t['F']['dqn']/1.001
                t['improvement_percent']['hungarian']=100*(1-t['F']['dqn']/t['F']['hungarian'])
            fixture['mean_paired_improvement_percent']['hungarian']=sum(
                t['improvement_percent']['hungarian'] for t in fixture['test'])/5
            self.assertTrue(report.publish(fixture))
            failed=write.call_args.args[1]
            self.assertFalse(failed['average_goal_achieved'])
            self.assertFalse(failed['all_date_pairs_improved'])
            self.assertEqual(failed['paired_counts']['hungarian'],dict(better=0,equal=0,worse=5))
            failed_document=[call.args[0] for call in text.call_args_list if call.args[0].startswith('# ')][-1]
            self.assertIn('本轮尚未达到平均改善目标',failed_document)
            self.assertIn('| 纯匈牙利 | -0.100000% | 0/0/5 |',failed_document)

if __name__=='__main__': unittest.main()
