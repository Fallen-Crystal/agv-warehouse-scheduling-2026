"""Continue a finished development batch through frozen selection and validation."""
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent


def main():
    commands=[
        ['analyze_boundary.py','--phase','development'],
        ['equivalence_boundary.py'],
        ['boundary_batch.py','--phase','validation'],
        ['analyze_boundary.py','--phase','validation'],
        ['audit_boundary.py'],
        ['mechanism_boundary.py'],
        ['report_boundary.py'],
        ['run_selected.py','--case','wepa-day45-bin4335','--output','boundary_results/recommended_demo.json'],
    ]
    for command in commands:
        print('STAGE '+' '.join(command),flush=True)
        subprocess.run([sys.executable,*command],cwd=ROOT,check=True)

if __name__=='__main__':
    main()
