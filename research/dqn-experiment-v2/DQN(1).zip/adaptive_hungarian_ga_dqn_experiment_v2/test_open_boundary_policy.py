"""检验开放流预测边界无未来泄露且真实闭流执行仍回库。"""
import unittest
import copy
from open_boundary_policy import execute_open_boundary
from run_search_headroom import PROTOCOL,read_json
from improved.profiles import PROFILES
from improved.forecast import snapshot, rollout
from wepa.data import build
from wepa.kernel import World


class BoundaryTests(unittest.TestCase):
    def test_snapshot_has_published_jobs_only_and_no_true_closure(self):
        case=dict(case='open-boundary-visibility',close_at=9999,initial={'1':3},tasks=[
            dict(id=0,sku=1,kind='retrieval',release=0,source_dock=1),
            dict(id=1,sku=1,kind='delivery',release=8000,source_dock=1)])
        world=World(build(case,vehicles=6))
        world.publish_and_complete()
        view=snapshot(world,terminal='standby')
        self.assertEqual(set(view.tasks),{0})
        self.assertFalse(view.observed_closed)
        self.assertFalse(view.closed)
        self.assertEqual(view.model['close_at'],float('inf'))
        again=snapshot(view)
        self.assertEqual(set(again.tasks),{0})
        self.assertFalse(again.observed_closed)
        self.assertEqual(again.forecast_terminal,'standby')

    def test_publicly_closed_forecast_finishes_only_at_all_homes(self):
        case=dict(case='closed-boundary-forecast',close_at=0,initial={'1':3},tasks=[
            dict(id=0,sku=1,kind='retrieval',release=0,source_dock=1)])
        world=World(build(case,vehicles=6))
        world.publish_and_complete()
        view=snapshot(world,terminal='standby')
        self.assertTrue(view.observed_closed)
        self.assertTrue(view.closed)
        prediction,usage=rollout(view)
        self.assertIsNotNone(prediction)
        self.assertEqual(usage['reason'],'complete')
        self.assertTrue(usage['observed_closed'])
        self.assertTrue(prediction.done)
        self.assertEqual([p[0] for p in prediction.plans],world.scene.homes[:6])

    def test_closed_real_episode_requires_final_return_and_keeps_budget(self):
        protocol=read_json(PROTOCOL)
        case=dict(case='open-boundary-synthetic',close_at=30,initial={'1':4},tasks=[
            dict(id=i,sku=1,kind=kind,release=release,source_dock=1)
            for i,(kind,release) in enumerate([
                ('retrieval',0),('delivery',4),('retrieval',12),('delivery',20)])])
        before=copy.deepcopy(PROFILES)
        row,result=execute_open_boundary(case,protocol)
        self.assertEqual(PROFILES,before)
        self.assertTrue(result['valid'])
        model=build(case,**protocol['configuration'])
        self.assertEqual([p[-1] for p in result['paths']],model['scene'].homes[:6])
        self.assertEqual(row['budget'],dict(proxy=192,generations=16,previews=6))
        self.assertAlmostEqual(row['reward_sum'],-row['F'])
        for entry in result['search_log']:
            if 'anchor_usage' in entry:
                self.assertEqual(entry['anchor_usage']['terminal'],'standby')


if __name__=='__main__':
    unittest.main()
