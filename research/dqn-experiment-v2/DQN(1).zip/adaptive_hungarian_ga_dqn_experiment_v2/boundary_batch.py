"""Resume-safe two-process experiment runner; logs failures without omission."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--phase',choices=['development','validation'],required=True)
    p.add_argument('--workers',type=int,default=None,
                   help='Optional resume-safe override for host CPU pressure')
    args = p.parse_args()
    protocol = json.loads((ROOT/'boundary_protocol.json').read_text(encoding='utf-8'))
    arms = list(protocol['arms'])
    if args.phase == 'validation':
        selected = json.loads((ROOT/'boundary_results/selection.json').read_text(encoding='utf-8'))['selected']
        arms = ['original','ga','matching',selected]
    cases = [c for c in protocol['cases'] if c['source_case'] in protocol[args.phase]]
    seeds = protocol[args.phase+'_seeds']
    out = ROOT/'boundary_results'/args.phase
    out.mkdir(parents=True,exist_ok=True)
    tasks = [(c['case'],arm,seed) for c in cases for seed in seeds for arm in arms]

    def worker(task):
        case, arm, seed = task
        stem = out/f'{case}__{arm}__s{seed}'
        target, status = stem.with_suffix('.json'), stem.with_suffix('.status.json')
        if status.exists():
            return json.loads(status.read_text(encoding='utf-8'))
        if target.exists():
            # A completed result can survive an interrupted parent.
            row = json.loads(target.read_text(encoding='utf-8'))['row']
            info = dict(case=case,arm=arm,seed=seed,status='ok' if row['valid'] else 'invalid',recovered=True)
        else:
            start = time.perf_counter()
            with stem.with_suffix('.log').open('x',encoding='utf-8') as log:
                try:
                    done = subprocess.run([sys.executable,str(ROOT/'boundary_trial.py'),
                        '--case',case,'--arm',arm,'--seed',str(seed),'--output',str(target)],
                        cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,
                        timeout=protocol['limits']['wall_seconds'])
                    info = dict(case=case,arm=arm,seed=seed,status='ok' if done.returncode==0 else 'failed',returncode=done.returncode)
                except subprocess.TimeoutExpired:
                    info = dict(case=case,arm=arm,seed=seed,status='timeout')
            info['wall'] = time.perf_counter()-start
        with status.open('x',encoding='utf-8') as f:
            json.dump(info,f,ensure_ascii=False)
        return info

    worker_count = args.workers or protocol['limits']['workers']
    with ThreadPoolExecutor(max_workers=worker_count) as pool:
        futures = [pool.submit(worker,t) for t in tasks]
        for index,future in enumerate(as_completed(futures),1):
            result = future.result()
            print(f'{args.phase} {index}/{len(tasks)} '+json.dumps(result),flush=True)

if __name__ == '__main__':
    main()
