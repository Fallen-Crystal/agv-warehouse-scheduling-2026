"""仅扫描原始输入以设计未见日期划分；不执行策略或读取成绩。"""
import json
from collections import Counter,defaultdict
from paths import ROOT,sha

def scan(seconds=3600, minimum=40, maximum=240):
    raw=ROOT/'deliverables/wepa_real_data/raw'
    provenance=json.loads((ROOT/'data/input-selection.json').read_text(encoding='utf-8'))
    assert sha(raw/'2_orders.json')==provenance['source_sha256']
    assert sha(raw/'3_initial_fill_lvl.json')==provenance['initial_stock_sha256']
    orders=json.loads((raw/'2_orders.json').read_text())
    stock=Counter({int(k):v for k,v in json.loads((raw/'3_initial_fill_lvl.json').read_text()).items()})
    bins=defaultdict(list)
    for i,r in enumerate(orders): bins[int(r[2]//seconds)].append((i,r))
    selected=[]
    for bucket,entries in sorted(bins.items()):
        initial={s:stock[s] for s in {r[1] for _,r in entries}}
        valid=(minimum<=len(entries)<=maximum and 1<=len(initial)<=5 and
               sum(initial.values())<=900 and len({r[0] for _,r in entries})==2)
        ledger=Counter(initial)
        for _,r in entries:
            ledger[r[1]]+=1 if r[0]=='delivery' else -1
            if not 0<=ledger[r[1]]<=initial[r[1]]+50: valid=False
        if valid:
            selected.append(dict(case=f'wepa-{seconds}s-day{bucket*seconds//86400}-bin{bucket}',source_day=bucket*seconds//86400,
                source_bin=bucket,start_seconds=bucket*seconds,end_seconds=(bucket+1)*seconds,close_at=seconds,
                initial={str(k):v for k,v in sorted(initial.items())},
                tasks=[dict(id=j,source_row=i,kind=r[0],sku=r[1],release=r[2]-bucket*seconds,
                            source_time=r[2],source_dock=r[3],batch=r[4],week=r[5]) for j,(i,r) in enumerate(entries)]))
        stock.update({})
        for _,r in entries: stock[r[1]]+=1 if r[0]=='delivery' else -1
    return selected

if __name__=='__main__':
    old=json.loads((ROOT/'data/input-selection.json').read_text())
    broad=json.loads((ROOT/'data/dqn_broad_protocol.json').read_text())
    used=set(old['prior_used_days'])|{c['source_day'] for c in broad['cases']}
    for seconds in (3600,7200,1800):
        candidates=scan(seconds)
        fresh=[c for c in candidates if c['source_day'] not in used]
        print(json.dumps(dict(seconds=seconds,windows=len(candidates),days=sorted({c['source_day'] for c in candidates}),
                             fresh_days=sorted({c['source_day'] for c in fresh}),fresh_windows=len(fresh)),ensure_ascii=False),flush=True)
