"""比对最终检查点独立冻结复验和训练期监测，不混入新训练。"""
import argparse
import json
from pathlib import Path
from paths import sha


def verify(root):
    root = Path(root)
    checked = []
    for seed in (0, 1, 2):
        folder = root / f's{seed}'
        manifest = json.loads((folder / 'manifest.json').read_text(encoding='utf-8'))
        final_epoch = manifest['config']['rounds']
        replay = json.loads((folder / 'final_replay.json').read_text(encoding='utf-8'))
        assert replay['seed'] == seed and replay['frozen_state_verified']
        assert replay['checkpoint_sha256'] == sha(folder / f'epoch{final_epoch}.npz')
        rows = [json.loads(line) for line in (folder / 'episodes.jsonl').read_text(encoding='utf-8').splitlines() if line]
        monitors = {r['case']: r for r in rows if r['phase'] == 'monitor' and r['epoch'] == final_epoch}
        assert set(monitors) == set(manifest['monitor'])
        assert len(replay['rows']) == len(monitors)
        assert {r['case'] for r in replay['rows']} == set(monitors)
        for actual in replay['rows']:
            expected = monitors[actual['case']]
            # 排除wall等非确定性计时，其余性能和学习状态必须精确复现。
            for field in ('valid', 'F', 'T', 'R', 'D', 'traffic_wait', 'actions',
                          'train_steps', 'replay_size', 'reward_sum', 'initial_cost',
                          'learning_reward_sum', 'observation_schema', 'transitions', 'losses'):
                assert actual[field] == expected[field], (seed, actual['case'], field)
            checked.append(dict(seed=seed, case=actual['case'], F=actual['F'],
                                checkpoint_sha256=replay['checkpoint_sha256'], exact_replay=True))
    return dict(complete=True, frozen_state_verified=True, rows=checked)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root')
    args = parser.parse_args()
    report = verify(args.root)
    target = Path(args.root) / 'replay_verification.json'
    if target.exists():
        target.read_text(encoding='utf-8')
    target.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
