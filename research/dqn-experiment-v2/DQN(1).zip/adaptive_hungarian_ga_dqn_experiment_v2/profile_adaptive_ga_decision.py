"""只剖析一个训练日期的首次GA派单；不跑完整窗口，不读取测试成绩。

强制GA仅用于性能诊断，不作为DQN自主选择或正式F改善的证据。
运行中实验不受本脚本影响；候选实现、种群与预览预算沿用正式入口。
"""
import cProfile
import json
import pstats
import time
from unittest.mock import patch
from paths import ROOT
from wepa.data import build
from wepa.kernel import World
from simple.routing import make_router
from objective import LinearObjective
from improved.hungarian import matching_hungarian
from adaptive_genetic import candidates
from adaptive_hungarian_learning import LearningPolicy,MultiStepAgent


def main():
    protocol=json.loads((ROOT/'data/adaptive_hungarian_learning_protocol.json').read_text(encoding='utf-8'))
    case=next(c for c in protocol['cases'] if c['case']==protocol['development'][0])
    world=World(build(case,**protocol['configuration']))
    world.route_kind,world.route_seed='sipp',0
    world.router=make_router(world.scene,'sipp',0)
    world.publish_and_complete()
    agent=MultiStepAgent(seed=0,state_dim=32,hidden=64,output_scale=.01)
    for parameter in agent.online.values(): parameter[:]=0
    agent.online['b2'][:]=[-1,1]
    policy=LearningPolicy(0,objective=LinearObjective(**protocol['objective']),agent=agent,training=False)
    searches=[]
    def traced_candidates(*args,**kwargs):
        kwargs.update(adaptive_mutation=True,adaptive_crossover=True,mutation_rate=.7,crossover_rate=.9)
        plans,meta=candidates(*args,**kwargs)
        searches.append(meta)
        return plans,meta
    profile=cProfile.Profile()
    start=time.perf_counter()
    with patch('improved.policy.matching',lambda w,scorer=None:matching_hungarian(w,policy.objective)[0]),\
         patch('improved.policy.candidates',traced_candidates):
        pairs=profile.runcall(policy.action,world)
    elapsed=time.perf_counter()-start
    assert pairs and policy.action_counts['ga']==1 and agent.train_steps==0
    stats=pstats.Stats(profile)
    def functions(sort_column):
        entries=sorted(stats.stats.items(),key=lambda item:item[1][sort_column],reverse=True)[:30]
        return [dict(file=filename,line=line,function=name,primitive_calls=value[0],calls=value[1],
            own_seconds=value[2],cumulative_seconds=value[3]) for (filename,line,name),value in entries]
    result=dict(diagnostic_only=True,forced_action='ga',source_group='development',source_case=case['case'],
        simulation_time=world.time,visible_orders=len(world.visible),initial_stock=len(world.stock),
        wall_seconds=elapsed,profile_total_seconds=stats.total_tt,pairs=pairs,route_stats=world.router.stats,
        ga_searches=searches,top_own_time=functions(2),top_cumulative_time=functions(3))
    folder=ROOT/'results'
    raw=folder/'adaptive_ga_first_decision.prof'
    output=folder/'adaptive_ga_first_decision_profile.json'
    # 诊断文件单独命名，不覆盖训练、验证、选模或正式测试记录。
    if output.exists(): raise FileExistsError(output)
    if raw.exists(): raise FileExistsError(raw)
    profile.dump_stats(raw)
    output.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(dict(source_case=case['case'],visible_orders=len(world.visible),wall_seconds=elapsed,
        route_stats=world.router.stats,searches=len(searches),top_own_time=result['top_own_time'][:6],
        top_cumulative_time=result['top_cumulative_time'][:6]),ensure_ascii=False,indent=2),flush=True)


if __name__=='__main__': main()
