"""冻结本轮训练/验证/未见测试协议；仅根据输入挑选日期。"""
import json
from paths import ROOT,sha,verify_baseline
from prepare_hungarian_learning import scan
from wepa.data import build

def main():
    verify_baseline()
    broad=json.loads((ROOT/'data/dqn_broad_protocol.json').read_text(encoding='utf-8'))
    provenance=json.loads((ROOT/'data/input-selection.json').read_text(encoding='utf-8'))
    used=set(provenance['prior_used_days'])|{c['source_day'] for c in broad['cases']}
    hourly=scan(3600)
    half=scan(1800)
    # 保留所有可用未使用日期；有合格整点小时就取小时，否则取完整半小时。
    # 不根据策略结果筛选，不截断批次，不扩大每SKU初始库存+50的储位限制。
    fresh_days=sorted({c['source_day'] for c in hourly+half}-used)
    test=[]
    for day in fresh_days:
        eligible=[c for c in hourly if c['source_day']==day] or [c for c in half if c['source_day']==day]
        test.append(min(eligible,key=lambda c:c['start_seconds']))
    assert fresh_days==[5,19,53,55,76]
    cases=broad['cases']+test
    for c in cases: build(c,**broad['configuration'])
    protocol=dict(version='hungarian-learning-v1',configuration=broad['configuration'],objective=broad['objective'],
        development=broad['development'],validation=broad['evaluation'],test=[c['case'] for c in test],cases=cases,
        previously_used_days=sorted(used),source_sha256=broad['source_sha256'],initial_stock_sha256=broad['initial_stock_sha256'],
        test_selection='Earliest feasible hour per unused day; otherwise earliest feasible half-hour. 40..240 complete orders; both types; 1..5 SKUs; initial<=900; prefix within initial+50. All five eligible fresh dates retained.',
        action_definition=['hungarian_f_surrogate','joint_ga'],ga_budget=dict(proxy=192,previews=6,generations=16,gate=False),
        learning=dict(seed=0,epochs=6,state_dim=32,hidden=64,learning_rate=.0003,gamma=1.,double_dqn=True,output_scale=.01,
            n_step=5,updates_per_decision=4,epsilon='max(0.05,0.40*0.72**(epoch-1))'),
        selection='Minimize worst of three mean paired F ratios on validation; best and latest saved. Never select by test. Test only after checkpoint selection.',
        limitations='Only input-feasible source subset with synthetic shelf mapping. Test includes four half-hours and one hour; compare paired ratios, report durations. Five previously unused source dates, not a plant deployment guarantee.')
    target=ROOT/'data/hungarian_learning_protocol.json'
    if target.exists(): assert json.loads(target.read_text(encoding='utf-8'))==protocol
    else: target.write_text(json.dumps(protocol,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(dict(protocol_sha256=sha(target),train_days=[c['source_day'] for c in cases if c['case'] in protocol['development']],
        validation_days=[c['source_day'] for c in cases if c['case'] in protocol['validation']],
        test=[dict(day=c['source_day'],orders=len(c['tasks']),minutes=c['close_at']//60) for c in test],
        train_orders=sum(len(c['tasks']) for c in cases if c['case'] in protocol['development'])),ensure_ascii=False),flush=True)

if __name__=='__main__': main()
