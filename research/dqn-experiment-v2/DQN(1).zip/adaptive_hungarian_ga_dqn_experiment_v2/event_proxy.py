"""事件驱动的代理排序消融；继承共享缓存/评估计数，不增加物理预览。

保留原锚点前驱和槽位，只改变未来车辆/bay预留的解释。它仍是近似代理，
不模拟SIPP碰撞或真实WMS变化，最终候选仍由原物理预览接受。
"""
from math import inf
import paths
from improved.proxy import MixedCosts, standby_distance


class EventCosts(MixedCosts):
    def _schedule(self, order, owners=None):
        w=self.world
        times=[]
        positions=[]
        flows=[r['end']-w.tasks[r['task']]['release'] for r in w.records]
        final_t=max((r['end'] for r in w.records),default=w.time)
        moves=w.past_moves
        for k,r in enumerate(w.active):
            if r is None:
                times.append(w.time)
                positions.append(w.plans[k][0])
            else:
                times.append(r['end'])
                positions.append(r['drop'])
                suffix=w.plans[k][:r['end']-w.time+1]
                moves+=sum(a!=b for a,b in zip(suffix,suffix[1:]))
        pending=list(order)
        locks=dict(w.locks)
        assignment={}
        clock=w.time
        while pending:
            selected=None
            for jid in pending:
                if self.predecessor.get(jid) in pending:
                    continue
                bay=self.slots[jid]['bay']
                if locks.get(bay,0)>clock:
                    continue
                choices=range(len(times)) if owners is None else [owners[jid]]
                options=[]
                for k in choices:
                    if times[k]>clock:
                        continue
                    self.details(k,positions[k],self.jobs[jid])
                    d,approach,pickup,drop,ps,ds=self.cache[k,tuple(positions[k]),jid]
                    options.append((clock+d+ps+ds,d,k,approach,drop,ps,ds))
                if options:
                    selected=(jid,min(options))
                    break
            if selected is None:
                events=[t for t in times if t>clock]+[t for t in locks.values() if t>clock]
                if not events:
                    return (inf,inf,inf),assignment
                clock=min(events)
                continue
            jid,(finish,d,k,approach,drop,ps,ds)=selected
            times[k],positions[k]=finish,drop
            bay=self.slots[jid]['bay']
            locks[bay]=finish if self.jobs[jid]['kind']=='delivery' else clock+approach+ps
            flows.append(finish-self.jobs[jid]['release'])
            moves+=d
            final_t=max(final_t,finish)
            pending.remove(jid)
            assignment[jid]=k
        open_boundary=getattr(w,'forecast_terminal','home')=='standby' and not w.observed_closed
        moves+=sum(standby_distance(w,p,k) if open_boundary else
                   w.router.distance(tuple(p),w.scene.homes[k],k) for k,p in enumerate(positions))
        return (final_t,sum(flows)/max(1,len(flows)),moves),assignment
