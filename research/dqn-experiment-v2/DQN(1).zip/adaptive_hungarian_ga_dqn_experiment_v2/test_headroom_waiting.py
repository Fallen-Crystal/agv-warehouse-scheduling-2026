"""Waiting-ledger tests: small synthetic physical run and crafted business states.
No real date or additional physical simulation is used by the ledger itself.
"""
import copy
import json
import unittest
from unittest.mock import patch

import paths
from wepa.data import build
from wepa.kernel import World
from improved.execute import run
from headroom_waiting import analyze_waiting, _replay_logic, CATEGORIES


def task(jid, kind='delivery', release=0):
    return dict(id=jid, kind=kind, release=release, sku=1)


def slot(sid, bay=0, level=1):
    return dict(id=sid, sku=1, bay=bay, level=level)


def record(jid, sid, assigned, pickup_end, end, vehicle=0):
    return dict(task=jid, slot=sid, vehicle=vehicle, assigned_at=assigned,
                pickup_end=pickup_end, end=end)


def crafted(tasks, slots, occupied, records, final_stock, vehicles=1, end=None):
    model = dict(case='crafted-business-only', tasks=tasks, slots=slots,
                 occupied=occupied, vehicles=vehicles, close_at=0)
    result = dict(records=records, completed=[j['id'] for j in tasks],
                  final_stock=final_stock,
                  time=end if end is not None else max((r['end'] for r in records), default=0))
    return model, result


class WaitingBusinessTests(unittest.TestCase):
    def test_same_tick_assignment_counts_other_ready_job_as_busy(self):
        model, result = crafted([task(0), task(1)], [slot(0), slot(1, bay=1)], [],
                                [record(0, 0, 0, 1, 3), record(1, 1, 5, 6, 8)], [0, 1])
        data = _replay_logic(model, result)
        self.assertEqual(data['tasks'][0]['pre_assignment'], 0)
        parts = data['tasks'][1]['partition']
        self.assertEqual(parts['ready_fleet_busy'], 3)
        self.assertEqual(parts['ready_with_idle_vehicle'], 2)
        self.assertEqual(sum(parts.values()), 5)
        self.assertEqual(data['tasks'][1]['intervals'], [
            dict(start=0, stop=3, category='ready_fleet_busy'),
            dict(start=3, stop=5, category='ready_with_idle_vehicle')])

    def test_delivery_layer_then_bay_lock_priority(self):
        model, result = crafted([task(0), task(1)], [slot(0), slot(1, level=2)], [],
                                [record(0, 0, 1, 2, 4), record(1, 1, 4, 5, 9)], [0, 1])
        data = _replay_logic(model, result)
        parts = data['tasks'][1]['partition']
        self.assertEqual(parts['layer_precedence'], 1)  # t=0, both jobs are bound.
        self.assertEqual(parts['bay_locked'], 3)        # t=1,2,3; also lower level reserved.
        self.assertEqual(sum(parts.values()), 4)
        self.assertEqual(data['aggregate']['pre_assignment_total'], 5)

    def test_retrieval_upper_level_then_bay_then_busy(self):
        model, result = crafted([task(0, 'retrieval'), task(1, 'retrieval')],
                                [slot(0), slot(1, level=2)], [0, 1],
                                [record(0, 1, 2, 6, 7), record(1, 0, 7, 9, 10)], [])
        data = _replay_logic(model, result)
        parts = data['tasks'][1]['partition']
        self.assertEqual(parts['layer_precedence'], 2)
        self.assertEqual(parts['bay_locked'], 4)
        self.assertEqual(parts['ready_fleet_busy'], 1)  # pickup released lock, car still active.
        self.assertEqual(sum(parts.values()), 7)

    def test_unbound_until_pickup_changes_stock_before_completion(self):
        model, result = crafted([task(0, 'retrieval'), task(1)], [slot(0)], [0],
                                [record(0, 0, 0, 2, 3), record(1, 0, 3, 4, 6)], [0])
        data = _replay_logic(model, result)
        parts = data['tasks'][1]['partition']
        self.assertEqual(parts['unbound_slot'], 2)
        self.assertEqual(parts['ready_fleet_busy'], 1)
        self.assertEqual(sum(parts.values()), 3)
        self.assertEqual(data['replay']['final_stock'], [0])

    def test_release_and_assignment_interval_is_half_open(self):
        model, result = crafted([task(0, release=3)], [slot(0)], [],
                                [record(0, 0, 5, 6, 8)], [0], end=12)
        data = _replay_logic(model, result)
        self.assertEqual(data['tasks'][0]['intervals'],
                         [dict(start=3, stop=5, category='ready_with_idle_vehicle')])
        self.assertEqual(data['aggregate']['pre_assignment_total'], 2)
        self.assertEqual(data['replay']['ticks'], 13)

    def test_reject_wrong_binding_nonready_busy_and_inventory(self):
        model, result = crafted([task(0), task(1)], [slot(0), slot(1, level=2)], [],
                                [record(0, 0, 1, 2, 4), record(1, 1, 4, 5, 9)], [0, 1])
        bad = copy.deepcopy(result)
        bad['records'][0]['slot'] = 1
        with self.assertRaisesRegex(ValueError, 'slot mismatch'):
            _replay_logic(model, bad)
        bad = copy.deepcopy(result)
        bad['records'][1]['assigned_at'] = 2
        with self.assertRaisesRegex(ValueError, 'nonready'):
            _replay_logic(model, bad)
        bad = copy.deepcopy(result)
        bad['final_stock'] = []
        with self.assertRaisesRegex(ValueError, 'inventory'):
            _replay_logic(model, bad)
        model, result = crafted([task(0), task(1)], [slot(0), slot(1, bay=1)], [],
                                [record(0, 0, 0, 1, 4), record(1, 1, 1, 2, 5)], [0, 1])
        with self.assertRaisesRegex(ValueError, 'busy/duplicate'):
            _replay_logic(model, result)

    def test_empty_business_replay(self):
        model, result = crafted([], [], [], [], [], end=2)
        data = _replay_logic(model, result)
        self.assertEqual(data['aggregate']['pre_assignment_total'], 0)
        self.assertEqual(data['aggregate']['mean_steps'], dict.fromkeys(CATEGORIES, 0.0))


class WaitingPhysicalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        case = dict(case='waiting-synthetic-four-orders', close_at=30, initial={'1': 4},
                    tasks=[dict(id=i, sku=1, kind=kind, release=release, source_dock=1)
                           for i, (kind, release) in enumerate([
                               ('retrieval', 0), ('delivery', 4),
                               ('retrieval', 12), ('delivery', 20)])])
        cls.model = build(case, vehicles=6)
        cls.result = run(cls.model, method='fcfs', seed=0)

    def test_full_synthetic_trace_exact_ledger_without_routing_or_simulation(self):
        before = copy.deepcopy(self.result)
        # Analyze the JSON-loaded representation as a real stored trace would be.
        restored = json.loads(json.dumps(self.result))
        with (patch.object(World, '__init__', side_effect=AssertionError('No new World')),
              patch.object(World, 'trip', side_effect=AssertionError('No routing')),
              patch.object(World, 'commit', side_effect=AssertionError('No physical commit')),
              patch.object(World, 'advance', side_effect=AssertionError('No new simulation'))):
            data = analyze_waiting(self.model, restored)
        expected = sum(r['assigned_at']-self.model['tasks'][r['task']]['release']
                       for r in self.result['records'])
        self.assertEqual(data['aggregate']['pre_assignment_total'], expected)
        self.assertEqual(sum(data['aggregate']['total_steps'].values()), expected)
        self.assertEqual(data['replay']['final_stock'], self.result['final_stock'])
        self.assertEqual(data['replay']['completed'], self.result['completed'])
        self.assertTrue(data['physical_validation']['valid'])
        self.assertEqual(self.result, before)
        json.dumps(data, allow_nan=False)

    def test_reject_incomplete_physical_trace(self):
        bad = dict(self.result, valid=False)
        with self.assertRaises(ValueError):
            analyze_waiting(self.model, bad)


if __name__ == '__main__':
    unittest.main()
