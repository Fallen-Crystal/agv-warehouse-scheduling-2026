"""反事实检查：只改未发布订单，保持可见订单、库存和物理状态完全相同。

仅执行当前一次决策，避免重跑完整训练/测试窗口；这是信息边界检查，
不把随机初始化网络或人为固定动作的结果当作性能证据。
"""
import copy
from unittest.mock import patch
import unittest
import numpy as np
from paths import ROOT  # 初始化冻结基线模块路径，与正式入口一致。
from wepa.data import build
from wepa.kernel import World
from simple.routing import make_router
from objective import LinearObjective
from improved.forecast import snapshot
from improved.hungarian import matching_hungarian
from rl_scheduler import observe as legacy_observe
from adaptive_genetic import candidates
from adaptive_hungarian_learning import LearningPolicy,MultiStepAgent,learning_observation


def make_world(variant):
    visible=[dict(id=k,kind='delivery',sku=101+k,release=0,source_dock=1) for k in range(2)]
    if variant==0:
        future=[dict(id=2,kind='retrieval',sku=101,release=600,source_dock=1)]
        close=1800
    else:
        # 数量、SKU、方向、时间和码头均改变，但全部在当前时刻之后。
        future=[dict(id=2+k,kind='delivery' if k%2==0 else 'retrieval',sku=101+(k//2)%2,
                     release=900+5*k,source_dock=2+k%3) for k in range(20)]
        close=3600
    case=dict(case='future-blindness-fixture',close_at=close,initial={'101':1,'102':1},tasks=visible+future)
    world=World(build(case,vehicles=6,layers=5,size='large'))
    world.route_kind,world.route_seed='sipp',0
    world.router=make_router(world.scene,'sipp',0)
    world.publish_and_complete()
    return world


def make_agent(seed=0):
    return MultiStepAgent(seed=seed,state_dim=32,hidden=8,capacity=32,warmup=8,batch_size=8,double_dqn=True,output_scale=.01)


class VisibilityTests(unittest.TestCase):
    def test_state_q_and_sanitized_forecast_ignore_unpublished_orders(self):
        worlds=[make_world(k) for k in range(2)]
        self.assertNotEqual(len(worlds[0].tasks),len(worlds[1].tasks))
        self.assertEqual(worlds[0].visible,worlds[1].visible)
        for seed in (0,1,17):
            agent=make_agent(seed)
            observations=[learning_observation(w,LearningPolicy(0,objective=LinearObjective(),agent=agent,training=False)) for w in worlds]
            self.assertEqual(len(observations[0]),32)
            np.testing.assert_array_equal(*observations)
            np.testing.assert_array_equal(agent._forward(np.asarray(observations[0]),agent.online)[0],agent._forward(np.asarray(observations[1]),agent.online)[0])
            self.assertEqual(agent.select(observations[0],training=False),agent.select(observations[1],training=False))
        views=[snapshot(w) for w in worlds]
        for view in views:
            self.assertEqual(set(view.tasks),{0,1})
            self.assertEqual(view.model['close_at'],view.time)
            self.assertFalse(view.observed_closed)
        self.assertEqual(views[0].model,views[1].model)

    def test_both_actual_algorithm_branches_ignore_unpublished_orders(self):
        for action in (0,1):
            outputs=[]; diagnostics=[]
            for variant in (0,1):
                world=make_world(variant); agent=make_agent()
                # 这里只强制遍历两个分支；正式推断仍由训练后网络自主选择。
                for weights in agent.online.values(): weights.fill(0)
                agent.online['b2'][:]=[1,-1] if action==0 else [-1,1]
                policy=LearningPolicy(0,objective=LinearObjective(),agent=agent,training=False)
                traces=[]
                def actual_candidates(*args,**kwargs):
                    result=candidates(*args,**kwargs)
                    traces.append(copy.deepcopy(result[1]))
                    return result
                # 与正式适配器相同：替换匹配实现，GA使用双自适应默认参数。
                contexts=[]
                def record_context(w):
                    state=legacy_observe(w)
                    contexts.append(state.__dict__.copy())
                    return state
                with patch('improved.policy.matching',lambda w,scorer=None:matching_hungarian(w,policy.objective)[0]),\
                     patch('improved.policy.candidates',actual_candidates),patch('improved.policy.observe_rl',record_context):
                    pairs=policy.action(world)
                self.assertTrue(pairs)
                self.assertEqual(set(policy.action_counts),{'hungarian' if action==0 else 'ga'})
                if action==1:
                    self.assertTrue(traces)
                    self.assertTrue(all(t['adaptive_crossover'] and t['adaptive_mutation'] for t in traces))
                # 旧bandit的日志inventory_risk除以完整订单数，但ActionAdapter
                # 完全忽略该State。保留差异证据，不把日志相等误作必要条件。
                diagnostics.append(contexts)
                operational_logs=[{k:v for k,v in event.items() if k!='rl_state'} for event in policy.logs]
                outputs.append((pairs,world.records,policy.plan,operational_logs,traces))
            self.assertEqual(outputs[0],outputs[1])
            self.assertNotEqual(diagnostics[0],diagnostics[1])


if __name__=='__main__': unittest.main()
