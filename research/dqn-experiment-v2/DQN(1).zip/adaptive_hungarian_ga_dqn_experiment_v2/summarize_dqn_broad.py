"""小时窗实验独立审计：允许训练中查看进度，仅完整配对后发布结果。"""
import json
import math
import statistics
from pathlib import Path
from paths import ROOT, sha, verify_baseline


def audit_row(row):
    assert row['valid'], 'Invalid trajectory'
    assert abs(row['F']-(.5*row['T']/900+.3*row['R']/900+.2*row['D']/5400))<1e-12
    assert abs(row['reward_sum']+row['F'])<1e-10
    assert abs(sum(row['initial_cost_terms'].values())-row['initial_cost'])<1e-10
    transitions=row['transitions']
    assert transitions and len(transitions)==sum(row['actions'].values())
    assert sum(bool(t['done']) for t in transitions)==1 and transitions[-1]['done']
    assert abs(sum(t['reward'] for t in transitions)-row['learning_reward_sum'])<1e-10
    assert abs(row['learning_reward_sum']-row['initial_cost']+row['F'])<1e-10
    for t in transitions:
        assert abs(sum(t['reward_terms'].values())-t['reward'])<1e-10
        assert t['duration']>=0 and t['action'] in (0,1)
    assert all(math.isfinite(x) for x in row['losses'])


def analyze():
    folder=ROOT/'results/dqn_broad_v1'
    protocol=json.loads((ROOT/'data/dqn_broad_protocol.json').read_text(encoding='utf-8'))
    manifest=json.loads((folder/'manifest.json').read_text())
    assert all(sha(ROOT/p)==digest for p,digest in manifest['hashes'].items()), 'Source drift'
    assert verify_baseline()==manifest['baseline_files']
    import random
    expected_order=list(protocol['development'])
    random.Random(0).shuffle(expected_order)
    training=[]
    previous_steps=previous_replay=0
    for index in range(len(protocol['development'])):
        path=folder/f'train_{index:02d}.json'
        if not path.exists():
            break
        row=json.loads(path.read_text(encoding='utf-8'))
        audit_row(row)
        assert row['phase']=='train' and row['case']==expected_order[index], 'Training order mismatch'
        assert row['train_steps']-previous_steps==len(row['losses'])
        assert row['replay_size']-previous_replay==len(row['transitions'])
        # 检查落盘记录与用于续跑的完整检查点一致，不只相信JSON计数。
        from dqn_agent import DQNAgent
        agent = DQNAgent.load(folder/f'train_{index:02d}.npz')
        assert (agent.train_steps,agent.replay_size)==(row['train_steps'],row['replay_size'])
        assert agent.state_dim==24 and agent.double_dqn and agent.output_scale==.01
        assert agent.gamma==1 and agent.epsilon==.3
        assert agent.replay.position==agent.replay_size  # 本轮总经验数未达到10000容量。
        previous_steps,previous_replay=row['train_steps'],row['replay_size']
        training.append(row)
    assert len({r['case'] for r in training})==len(training)
    pairs=[]
    final=folder/'final.npz'
    if final.exists():
        import numpy as np
        assert len(training)==10, 'Final checkpoint created before training finished'
        # npz容器字节可能不同；比较所有数组和JSON元数据，要求完整状态相同。
        with np.load(final,allow_pickle=False) as final_arrays, np.load(folder/'train_09.npz',allow_pickle=False) as last_arrays:
            assert set(final_arrays.files)==set(last_arrays.files)
            for key in final_arrays.files:
                np.testing.assert_array_equal(final_arrays[key],last_arrays[key])
    for index,name in enumerate(protocol['evaluation']):
        rows={}
        for strategy in ('dqn','fixed_ga'):
            path=folder/f'eval_{index:02d}_{strategy}.json'
            if not path.exists():
                continue
            row=json.loads(path.read_text(encoding='utf-8'))
            audit_row(row)
            assert row['case']==name and row['strategy']==strategy and row['phase']=='evaluation'
            assert not row['losses'] and row['seed']==protocol['seed']==0
            if strategy=='dqn':
                assert len(training)==10 and row['frozen_state_verified']
                assert row['checkpoint_sha256']==sha(final)
                assert (row['train_steps'],row['replay_size'])==(previous_steps,previous_replay)
            else:
                assert row['train_steps']==row['replay_size']==0
                assert row['checkpoint_sha256'] is None
                assert row['actions'].get('matching',0)==0
            rows[strategy]=row
        if len(rows)==2:
            dqn,ga=rows['dqn'],rows['fixed_ga']
            pairs.append(dict(case=name,dqn_F=dqn['F'],fixed_ga_F=ga['F'],
                              improvement_percent=100*(ga['F']-dqn['F'])/ga['F'],
                              dqn={k:dqn[k] for k in ('T','R','D','actions','traffic_wait')},
                              fixed_ga={k:ga[k] for k in ('T','R','D','actions','traffic_wait')}))
    complete=len(training)==10 and len(pairs)==4
    return dict(complete=complete,training_windows=len(training),paired_evaluation_windows=len(pairs),
                train_steps=previous_steps,replay_size=previous_replay,pairs=pairs,
                mean_paired_improvement_percent=statistics.mean(p['improvement_percent'] for p in pairs) if pairs else None,
                improved_dates=sum(p['improvement_percent']>0 for p in pairs))


def main():
    report=analyze()
    print(json.dumps(report,ensure_ascii=False,indent=2))
    # 未完成时只打印审计进度，不产生完整结果文件。
    if not report['complete']:
        return
    target=ROOT/'results/dqn_broad_v1/aggregate.json'
    if target.exists():
        target.read_text(encoding='utf-8')
    target.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')


if __name__=='__main__':
    main()
