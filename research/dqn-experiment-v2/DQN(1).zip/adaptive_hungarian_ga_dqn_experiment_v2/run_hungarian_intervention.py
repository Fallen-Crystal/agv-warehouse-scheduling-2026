"""单seed、4窗、两种匹配替换；复用最终DQN，冻结评估，不调参。

原4窗已用于评估，本次属于探索性诊断。每个变体每窗一次，逐条提交可续跑。
"""
import json
from unittest.mock import patch
from paths import ROOT,sha,verify_baseline
from objective import LinearObjective
from dqn_agent import DQNAgent
from run_dqn_broad_data import frozen
from hungarian_intervention import intervention
from summarize_dqn_broad import analyze,audit_row


def main():
    prior=analyze()
    assert prior['complete']
    protocol=json.loads((ROOT/'data/dqn_broad_protocol.json').read_text(encoding='utf-8'))
    cases={c['case']:c for c in protocol['cases']}
    folder=ROOT/'results/hungarian_intervention_v1'
    folder.mkdir(parents=True,exist_ok=True)
    checkpoint=ROOT/'results/dqn_broad_v1/final.npz'
    files=[ROOT/name for name in ('hungarian_intervention.py','run_hungarian_intervention.py',
           'dqn_policy.py','dqn_agent.py','train_dqn.py','data/dqn_broad_protocol.json')]
    files+=sorted((ROOT/'improved').glob('*.py'))
    identity={p.relative_to(ROOT).as_posix():sha(p) for p in files}
    manifest=dict(hashes=identity,checkpoint_sha256=sha(checkpoint),seed=0,training=False,
                  baseline_files=verify_baseline(),evaluation=protocol['evaluation'],
                  variants=['same_cost','f_surrogate'],
                  limitation='Exploratory reuse of previously evaluated dates; no retraining; changed action semantics.')
    path=folder/'manifest.json'
    if path.exists():
        assert json.loads(path.read_text(encoding='utf-8'))==manifest,'Source drift'
    else:
        path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    objective=LinearObjective(**protocol['objective'])
    for variant in manifest['variants']:
        for index,name in enumerate(protocol['evaluation']):
            output=folder/f'{variant}_{index:02d}.json'
            if output.exists():
                continue
            # 每窗重新加载同一最终状态，隔离任何非预期跨窗影响。
            agent=DQNAgent.load(checkpoint)
            with patch('improved.policy.matching',intervention(variant,objective)):
                row=frozen(agent,cases[name],protocol)
            audit_row(row)
            assert sha(checkpoint)==manifest['checkpoint_sha256']
            row.update(variant=variant,seed=0,checkpoint_sha256=manifest['checkpoint_sha256'])
            output.write_text(json.dumps(row,ensure_ascii=False),encoding='utf-8')
            print(json.dumps({k:v for k,v in row.items() if k not in ('transitions','losses')},ensure_ascii=False),flush=True)
    print('Completed eight exploratory intervention evaluations.',flush=True)


if __name__=='__main__':
    main()
