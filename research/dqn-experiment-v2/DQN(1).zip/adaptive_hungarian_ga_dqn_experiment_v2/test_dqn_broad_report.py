"""报告发布门槛测试：不运行仿真，不写实际结果。"""
import unittest
import json
import csv
import io
from unittest.mock import patch
import report_dqn_broad


class BroadReportTests(unittest.TestCase):
    def test_incomplete_cannot_publish(self):
        # 即使只有最后一组对照未完成，也不得调用文件读取/写入生成完整报告。
        with patch.object(report_dqn_broad, 'analyze', return_value={'complete': False}), \
             patch.object(report_dqn_broad, 'ROOT') as root:
            with self.assertRaisesRegex(AssertionError, 'Experiment incomplete'):
                report_dqn_broad.main()
            root.__truediv__.assert_not_called()

    def test_complete_report_in_memory(self):
        # 文件系统完全用内存替身，不把测试值写入正式结果。
        from paths import ROOT
        protocol=json.loads((ROOT/'data/dqn_broad_protocol.json').read_text(encoding='utf-8'))
        metrics=dict(T=3600,R=200,D=10000,actions={'matching':2,'ga':3},traffic_wait=0)
        pairs=[dict(case=name,dqn_F=2.4,fixed_ga_F=2.5,improvement_percent=4.,
                    dqn=metrics,fixed_ga=metrics) for name in protocol['evaluation']]
        report=dict(complete=True,pairs=pairs,train_steps=100,replay_size=163,
                    mean_paired_improvement_percent=4.,improved_dates=4)
        files={'data/dqn_broad_protocol.json':json.dumps(protocol)}
        class MemoryPath:
            def __init__(self,name=''):
                self.name=name
            def __truediv__(self,name):
                return MemoryPath(self.name+'/'+name if self.name else name)
            def exists(self):
                return self.name in files
            def read_text(self,**kwargs):
                return files[self.name]
            def write_text(self,text,**kwargs):
                files[self.name]=text
        with patch.object(report_dqn_broad,'ROOT',MemoryPath()), \
             patch.object(report_dqn_broad,'analyze',return_value=report), \
             patch('verify_dqn_broad_inputs.verify',return_value={'verified':True}), \
             patch('dqn_agent.DQNAgent.load') as load:
            import numpy as np
            load.return_value.replay.states=np.zeros((2,24))
            load.return_value.replay_size=2
            report_dqn_broad.main()
        text=files['docs/DQN扩大数据实验结果.md']
        self.assertIn('1327',text)
        self.assertIn('504',text)
        self.assertIn('不是全天',text)
        self.assertIn('4.000%',text)
        aggregate=json.loads(files['results/dqn_broad_v1/aggregate.json'])
        self.assertTrue(aggregate['input_verification']['verified'])
        rows=list(csv.DictReader(io.StringIO(files['results/dqn_broad_v1/paired_results.csv'])))
        self.assertEqual(len(rows),8)
        self.assertEqual({row['case'] for row in rows},set(protocol['evaluation']))
        self.assertEqual([row['method'] for row in rows],['DQN','固定GA']*4)
        self.assertEqual([float(row['F']) for row in rows],[2.4,2.5]*4)
        self.assertEqual(set(rows[0]),{'case','source_day','orders','method','F','T','R','D',
                                     'matching_actions','ga_actions','traffic_wait'})


if __name__ == '__main__':
    unittest.main()
