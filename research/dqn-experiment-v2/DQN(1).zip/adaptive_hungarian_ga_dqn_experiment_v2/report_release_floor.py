"""正式F的订单发布时间下限账本；不更换F或用于夸大收益。"""
from paths import ROOT
from objective import LinearObjective
from run_search_headroom import read_json,PROTOCOL,commit
from audit_search_headroom import audit_folder


def main():
    folder=ROOT/'results/search_headroom_v1'
    audit=audit_folder(folder)
    protocol=read_json(PROTOCOL)
    cases={c['case']:c for c in protocol['cases']}
    objective=LinearObjective(**protocol['objective'])
    rows=[]
    for r in audit['rows']:
        if r['budget_name']!='baseline':
            continue
        latest=max((j['release'] for j in cases[r['case']]['tasks']),default=0)
        release_F=objective.terms((latest,0,0))[0]
        rows.append(dict(case=r['case'],source_day=r['source_day'],F=r['F'],T=r['T'],
            latest_release=latest,T_after_last_release=r['T']-latest,
            mandatory_release_F=release_F,mandatory_release_fraction=release_F/r['F'],
            remaining_F=r['F']-release_F,
            formal_F_for_5pct_reduction=.05*r['F'],
            equivalent_T_only_reduction_seconds=.05*r['F']*objective.scales[0]/objective.weights[0],
            equivalent_R_only_reduction_seconds=.05*r['F']*objective.scales[1]/objective.weights[1],
            equivalent_D_only_reduction_cells=.05*r['F']*objective.scales[2]/objective.weights[2]))
    commit(folder,'release_floor.json',dict(rows=rows,
        qualification='Exact release floor accounting only. Remaining F includes compulsory service/travel; it is not avoidable cost. Formal F and percentage denominator remain unchanged.'))
    lines=['# 发布时间对正式F的约束', '',
           'T包含从时间零到最后任务完成的整个窗口。最后一项订单未发布前不可能完成全部任务，因此最后释放时刻贡献是所有策略共有的F下限之一。', '',
           '| 日期 | 正式F | T | 最后释放 | 最后释放后尾部秒 | 发布时间必然贡献 | 占正式F |',
           '|---|---:|---:|---:|---:|---:|---:|']
    for r in rows:
        lines.append(f"| {r['source_day']} | {r['F']:.6f} | {r['T']} | {r['latest_release']} | {r['T_after_last_release']} | {r['mandatory_release_F']:.6f} | {100*r['mandatory_release_fraction']:.2f}% |")
    lines+=['','该账本解释为什么长在线窗口的正式F改善率可能被发布时间压缩，但不能把小改善重新包装成大收益。正式F与改善分母保持不变。剩余成本还含必要移动、服务与真实约束，不能全部视作可优化损失。','',
            '## 正式F降低5%需要多大变化', '',
            '以下仅为保持其他两项不变时的代数等价值，并不表示实际可实现或各项能独立改变。', '',
            '| 日期 | 仅T需下降秒 | 仅R需下降秒/单 | 仅D需下降格 |',
            '|---|---:|---:|---:|']
    for r in rows:
        lines.append(f"| {r['source_day']} | {r['equivalent_T_only_reduction_seconds']:.2f} | {r['equivalent_R_only_reduction_seconds']:.2f} | {r['equivalent_D_only_reduction_cells']:.2f} |")
    (folder/'发布时间约束.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(rows,flush=True)


if __name__=='__main__':
    main()
