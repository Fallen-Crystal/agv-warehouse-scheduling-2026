"""Create a structured Chinese Word document for the frozen AGV study."""
from pathlib import Path
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "AGV仓库建模与调度算法说明.docx"
MAP = ROOT / "experiment_map_large.png"

def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)

def set_run_font(run, name="Microsoft YaHei", size=10.5, bold=False, color=None):
    run.font.name = name
    run._element.rPr.rFonts.set(qn("w:eastAsia"), name)
    run.font.size = Pt(size)
    run.bold = bold
    if color:
        run.font.color.rgb = RGBColor(*color)

def add_body(doc, text, bold_prefix=None):
    p = doc.add_paragraph(style="Normal")
    p.paragraph_format.space_after = Pt(5)
    p.paragraph_format.line_spacing = 1.15
    if bold_prefix and text.startswith(bold_prefix):
        r = p.add_run(bold_prefix)
        set_run_font(r, bold=True)
        r2 = p.add_run(text[len(bold_prefix):])
        set_run_font(r2)
    else:
        r = p.add_run(text)
        set_run_font(r)
    return p

def add_code(doc, text):
    p = doc.add_paragraph(style="No Spacing")
    p.paragraph_format.left_indent = Cm(0.7)
    p.paragraph_format.space_after = Pt(5)
    r = p.add_run(text)
    set_run_font(r, name="Consolas", size=9.5)
    return p

def add_bullet(doc, text, level=0):
    p = doc.add_paragraph(style="List Bullet" if level == 0 else "List Bullet 2")
    p.paragraph_format.space_after = Pt(3)
    r = p.add_run(text)
    set_run_font(r)
    return p

def add_table(doc, headers, rows, widths=None):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    for i, h in enumerate(headers):
        cell = table.rows[0].cells[i]
        cell.text = ""
        set_cell_shading(cell, "D9EAF7")
        r = cell.paragraphs[0].add_run(h)
        set_run_font(r, bold=True)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    for row in rows:
        cells = table.add_row().cells
        for i, value in enumerate(row):
            cells[i].text = ""
            r = cells[i].paragraphs[0].add_run(str(value))
            set_run_font(r, size=9.5)
            cells[i].vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    if widths:
        for row in table.rows:
            for i, width in enumerate(widths):
                row.cells[i].width = Cm(width)
    doc.add_paragraph().paragraph_format.space_after = Pt(1)
    return table

doc = Document()
sec = doc.sections[0]
sec.top_margin = Cm(2.0)
sec.bottom_margin = Cm(2.0)
sec.left_margin = Cm(2.2)
sec.right_margin = Cm(2.2)
styles = doc.styles
styles["Normal"].font.name = "Microsoft YaHei"
styles["Normal"]._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
styles["Normal"].font.size = Pt(10.5)
for style_name, size, color in [("Title", 20, (31, 78, 121)), ("Heading 1", 15, (31, 78, 121)), ("Heading 2", 12, (55, 96, 146)), ("Heading 3", 11, (55, 96, 146))]:
    st = styles[style_name]
    st.font.name = "Microsoft YaHei"
    st._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    st.font.size = Pt(size)
    st.font.color.rgb = RGBColor(*color)

p = doc.add_paragraph(style="Title")
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.add_run("现有AGV仓库实验的建模规则与调度算法说明")
sub = doc.add_paragraph()
sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = sub.add_run("冻结实验几何、库存约束、SIPP执行和自适应调度版本")
set_run_font(r, size=11, color=(90, 90, 90))
add_body(doc, "本文档记录当前仓库实验中实际执行的建模规则、数学目标、任务可执行条件、精确匹配、联合遗传算法以及RL自适应选择层。文档中的算法描述以现有源码和冻结协议为准，实验评价仍使用原有物理目标函数。")

# 1
h = doc.add_heading("一、实验范围与固定输入", level=1)
add_body(doc, "本轮研究使用固定的仓库几何、订单窗口、库存、任务发布时间、SIPP路由器和评价目标。算法只改变调度决策，不改变仓库物理规则或原始请求。")

doc.add_heading("1.1 冻结实验协议", level=2)
add_table(doc, ["项目", "当前设置"], [
    ("地图规格", "large，62 × 47 网格"),
    ("AGV数量", "6辆同构车辆"),
    ("货架层数", "5层"),
    ("仿真步长", "1秒/步"),
    ("请求窗口", "900秒"),
    ("速度", "1格/秒"),
    ("路径规划", "SIPP，四邻接网格"),
    ("正式目标", "F = 0.5T/900 + 0.3R/900 + 0.2D/5400"),
], [4.0, 10.0])
add_body(doc, "地图生成和任务输入分开处理：地图由固定的混合货架生成器生成，订单来自protocol.json中冻结的WEPA请求窗口。当前验证窗口示例为wepa-day40-bin3885；更换窗口只改变订单和库存输入，不改变地图几何。")

doc.add_heading("1.2 地图结构", level=2)
if MAP.exists():
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run().add_picture(str(MAP), width=Cm(15.5))
    cap = doc.add_paragraph("图1 现有大型实验地图（颜色说明见图上方图例）")
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for run in cap.runs: set_run_font(run, size=9, color=(90,90,90))
add_body(doc, "地图左侧是6个车辆home待命点：(0,2)、(0,8)、(0,14)、(0,20)、(0,26)、(0,32)。上边界设置3个入库口：(3,0)、(31,0)、(58,0)；下边界设置4个出库口：(3,46)、(21,46)、(40,46)、(58,46)。货架、设备区、立柱和通道均属于固定几何。车辆只能进入合法装卸点和可通行区域，其他车辆的home点对当前车辆是禁用位置。")

# 2
doc.add_heading("二、任务、货位与库存建模", level=1)
doc.add_heading("2.1 任务类型", level=2)
add_table(doc, ["类型", "物料流向", "车辆路径", "服务时间"], [
    ("delivery", "入库口 → 货架", "home → 入库口 → 货架点 → home", "入库口1；货架放置2l"),
    ("retrieval", "货架 → 出库口", "home → 货架点 → 出库口 → home", "货架取货2l；出库口1"),
], [3.0, 4.0, 6.0, 3.0])
add_body(doc, "其中l是货架层号。delivery在代码语义中表示从外部入库口把货物送入货架；retrieval才是从货架取货并送到出库口。每个任务发布后都有release时间，只有release不晚于当前仿真时刻的任务才进入visible集合。")

doc.add_heading("2.2 WMS货位绑定", level=2)
add_body(doc, "货位绑定由WMS规则确定，不由RL或GA随意改写。系统根据SKU、当前库存、已预约货位和货架结构，为已发布任务选择合法货位。绑定操作只写入任务与货位关系；真实库存只有在取货或放货完成相应阶段后才更新。")
add_bullet(doc, "retrieval必须绑定到当前确实有库存的货位。")
add_bullet(doc, "delivery必须绑定到当前空闲且没有冲突预约的货位。")
add_bullet(doc, "同一bay的占用和预约会形成锁，避免多个任务同时操作同一货架区域。")
add_bullet(doc, "货位绑定不等于任务已经派车；任务仍需通过ready规则和SIPP路径验证。")

doc.add_heading("2.3 可执行任务ready规则", level=2)
add_body(doc, "ready集合表示当前时刻真正可以派车的任务。它不是所有已经发布的任务，也不是简单的pending集合。任务需要同时满足：已经发布、已经完成货位绑定、尚未分配、货架bay未被锁定，并满足货架层序约束。")
add_body(doc, "对于retrieval，若同一bay中存在更高层且仍在库存中的货物，则当前低层货物不能先取：")
add_code(doc, "retrieval_ready(j) = 1，当且仅当不存在 q，使 bay(q)=bay(j)、level(q)>level(j)、q仍在库存。")
add_body(doc, "对于delivery，若同一bay中存在更低层的入库预约，则当前高层货物不能先放：")
add_code(doc, "delivery_ready(j) = 1，当且仅当不存在 q，使 bay(q)=bay(j)、level(q)<level(j)、q属于入库预约。")
add_body(doc, "这些规则保证车辆不会绕过物理货架层序直接访问被遮挡货位。")

# 3
doc.add_heading("三、路径、冲突与待命规则", level=1)
doc.add_heading("3.1 单任务路径", level=2)
add_body(doc, "每个任务都必须形成完整闭环路径。车辆从当前点出发，经过货架点和入库/出库口，再返回自己的home。任务的end时间是返回home并完成该任务所对应路径后的时间。")
add_code(doc, "delivery:  current_position → inbound_port → shelf_loading_point → vehicle_home")
add_code(doc, "retrieval: current_position → shelf_loading_point → outbound_port → vehicle_home")
add_body(doc, "SIPP根据时间窗、已占用顶点和已占用边生成路径。路径不能穿过货架、设备区、其他车辆home，也不能与其他车辆产生时空冲突。候选方案只有在完整SIPP路径通过后才能commit。")

doc.add_heading("3.2 无任务时的车辆状态", level=2)
add_body(doc, "如果车辆完成任务但当前没有ready任务，它保持在自己的home位置并记录为standby。若车辆仍在执行任务，则继续沿现有SIPP路径运行；系统每个仿真步推进1秒后再重新检查车辆是否空闲以及是否出现新的ready任务。")

# 4
doc.add_heading("四、数学模型与评价指标", level=1)
doc.add_heading("4.1 决策变量", level=2)
add_body(doc, "对当前批次任务集合J和车辆集合K，调度方案包含两个核心变量：")
add_code(doc, "x(j,k) ∈ {0,1}：任务j是否分配给车辆k")
add_code(doc, "πk：车辆k所执行任务的访问顺序")
add_body(doc, "每个已分配任务只能由一辆车执行：")
add_code(doc, "Σk∈K x(j,k) ≤ 1,  对所有 j∈J")
add_body(doc, "车辆顺序、库存层序、任务发布、车辆可用时间和SIPP冲突共同决定任务的真实完成时间Cj。")

doc.add_heading("4.2 正式目标函数", level=2)
add_code(doc, "F = 0.5 × T / 900 + 0.3 × R / 900 + 0.2 × D / 5400")
add_body(doc, "其中：")
add_bullet(doc, "T：最后一个订单完成的时间；")
add_bullet(doc, "R：所有订单从发布到完成的平均响应时间，R = (1/|J|)Σj(Cj - releasej)；")
add_bullet(doc, "D：车辆总移动距离，包括任务移动、待命移动和最终返库移动；")
add_bullet(doc, "F越小越好。所有策略使用相同的目标函数和归一化尺度。")

doc.add_heading("4.3 搜索阶段与正式评价的区别", level=2)
add_body(doc, "GA和匹配算法在搜索阶段可以使用距离、预计完成时间和代理响应时间快速筛选候选，但这些代理值不替代正式评价。最终结果必须由SIPP真实执行，再由完整轨迹计算T、R、D和F。")

# 5
doc.add_heading("五、精确匹配算法", level=1)
doc.add_heading("5.1 匹配问题", level=2)
add_body(doc, "精确匹配在当前空闲车辆和当前ready任务之间构造代价矩阵。每条边表示一辆车执行一个任务的预计完成时间、响应代价或移动代价。算法优先保证可匹配任务数量，再在固定边代价下优化组合。")
add_code(doc, "min Σ(k,j) c(k,j) x(k,j)")
add_code(doc, "Σk x(k,j) ≤ 1；Σj x(k,j) ≤ 1；x(k,j)∈{0,1}")
add_body(doc, "匹配结果仍需逐个经过原有SIPP trip和commit验证。不能执行的组合被跳过，并在后续调度时刻重新尝试。")

# 6
doc.add_heading("六、联合遗传算法（Joint GA）", level=1)
doc.add_heading("6.1 为什么叫联合GA", level=2)
add_body(doc, "当前GA同时搜索任务顺序和车辆归属，而不是先固定车辆再只排顺序，也不是先分车再分阶段优化。一个染色体同时包含：")
add_code(doc, "染色体 = (任务排列 task_order, 任务到车辆的映射 vehicle_by_task)")
add_body(doc, "例如：")
add_code(doc, "task_order = [3, 0, 2, 1]")
add_code(doc, "vehicle_by_task = {0:1, 1:0, 2:1, 3:0}")
add_body(doc, "这表示任务顺序和车辆归属共同构成一个候选调度。改变车辆归属会改变车辆的可用时间、路径长度、拥堵和后续任务顺序；改变顺序也会反过来影响车辆归属的效果，因此两者一起搜索。")

doc.add_heading("6.2 普通顺序GA与联合GA的区别", level=2)
add_table(doc, ["方法", "染色体内容", "可优化范围", "局限"], [
    ("顺序GA", "任务排列", "固定车辆分配下的访问顺序", "无法发现换车带来的收益"),
    ("两阶段方法", "先分车，再排顺序", "每一阶段局部优化", "前一阶段可能限制后一阶段"),
    ("联合GA", "任务排列 + 车辆映射", "顺序和车辆归属共同优化", "搜索空间更大，需要代理预算和SIPP复核"),
], [3.0, 4.0, 5.0, 4.0])

doc.add_heading("6.3 GA个体评价", level=2)
add_body(doc, "每个个体先由MixedCosts进行无预约快速估计，得到预计的T、R、D，再用正式目标权重计算排序分数。当前实现保留12个体的种群、交叉、顺序交换/插入和车辆归属变异，并受代理评价预算限制。")
add_code(doc, "score(individual) = 0.5*T_proxy/900 + 0.3*R_proxy/900 + 0.2*D_proxy/5400")
add_body(doc, "代理评价只用于搜索排序。最优候选会进入完整SIPP预演，预演通过后才提交到真实world。")

doc.add_heading("6.4 匈牙利初始化种子", level=2)
add_body(doc, "hga和rl中的GA可以将当前可见任务生成的匈牙利匹配方案放入初始种群，替换部分随机个体。种子只影响搜索起点，不锁定任务分配；后续交叉和变异仍然可以改变车辆归属和任务顺序。")

# 7
doc.add_heading("七、RL自适应策略选择", level=1)
doc.add_heading("7.1 状态特征", level=2)
add_table(doc, ["特征", "定义"], [
    ("订单压力 pressure", "min(2, 未分配已发布任务数 / 车辆数)"),
    ("车辆利用率 utilization", "忙碌车辆数 / 车辆总数"),
    ("拥堵 congestion", "最近车辆历史中相邻位置未变化的比例"),
    ("库存风险 inventory_risk", "当前库存规模相对任务规模的截断比例"),
], [5.0, 10.0])
add_code(doc, "φ(s) = [1, pressure, utilization, congestion, inventory_risk]")

doc.add_heading("7.2 动作空间", level=2)
add_body(doc, "RL只负责在两个已有执行器之间选择：")
add_bullet(doc, "matching：调用精确批量匹配；")
add_bullet(doc, "ga：调用保留匈牙利种子的联合GA；")
add_bullet(doc, "wait：不是调度算法，只在没有空闲车辆或没有ready任务时作为执行前置状态。")
add_body(doc, "RL不生成路线、不修改库存、不绕过ready检查，也不替代SIPP。")

doc.add_heading("7.3 线性Q估计与在线更新", level=2)
add_code(doc, "Q(s,a) = w_a · φ(s)")
add_code(doc, "a* = argmax_a Q(s,a)，以ε概率进行随机探索")
add_code(doc, "target = r + γ max_a Q(s',a)")
add_code(doc, "δ = target - Q(s,a)")
add_code(doc, "w_a ← w_a + α × δ × φ(s)")
add_body(doc, "当前实现使用固定随机种子、epsilon-greedy、线性权重和小学习率，便于审计和复现。RL奖励用于在线选择，不替代正式F目标。")

# 8
doc.add_heading("八、GA自适应变异率", level=1)
add_body(doc, "GA每代记录当前最优分数best、连续停滞代数stagnant以及任务顺序多样性diversity。启用自适应模式时，变异率按以下规则调整：")
add_code(doc, "rate = mutation_rate × (1 + 0.20×stagnant + 0.60×(1-diversity))")
add_code(doc, "rate = max(0.05, min(0.95, rate))")
add_body(doc, "当搜索停滞或种群顺序趋同，变异率升高以扩大搜索；当搜索仍在改善且种群保持多样时，扰动不额外放大。每代的rate、best、diversity和stagnant均写入mutation_history。")

# 9
doc.add_heading("九、整体执行流程", level=1)
add_code(doc, "发布新任务并更新WMS货位绑定")
add_code(doc, "筛选当前ready任务和空闲车辆")
add_code(doc, "RL选择matching或联合GA；条件不满足时推进1秒等待")
add_code(doc, "匹配或GA生成候选任务分配")
add_code(doc, "SIPP为候选生成真实无冲突路径")
add_code(doc, "commit通过库存、层序和时空冲突检查")
add_code(doc, "车辆执行；完成后返回home并重新进入调度循环")
add_body(doc, "每个仿真循环推进1秒。没有空闲车辆或没有ready任务时，不强行调用算法；时间推进后重新发布、完成和检查。")

# 10
doc.add_heading("十、当前代码入口与复现命令", level=1)
add_table(doc, ["内容", "文件"], [
    ("冻结输入与地图参数", "data/protocol.json"),
    ("地图和任务模型", "baseline/engine/src/agv/warehouse/mixed.py；baseline/engine/wepa/data.py"),
    ("库存、ready和路径闭环", "baseline/engine/wepa/kernel.py"),
    ("联合GA", "improved/genetic.py；improved/proxy.py"),
    ("RL选择器", "rl_scheduler.py；improved/policy.py"),
    ("测试", "test_adaptive.py；test_hungarian.py；test_boundary.py；test_variants.py"),
], [5.0, 11.0])
add_code(doc, "python run_main.py --case wepa-day40-bin3885 --profile rl --output my-rl-result.json")
add_code(doc, "python -B -m unittest test_adaptive test_hungarian test_boundary test_variants test_threshold_policy")

# 11
doc.add_heading("十一、实验边界与解释", level=1)
add_body(doc, "当前文档描述的是已经实现并通过物理回放的机制。单个窗口或单个随机种子的结果不能证明RL在所有仓库负载下都优于固定策略。正式比较应使用相同输入窗口、相同目标函数、相同物理规则，并报告每个策略的F、T、R、D、P90、空驶、等待、CPU和有效性。")
add_body(doc, "历史阈值实验和当前RL实验属于不同策略机制。当前rl配置不使用pending/free阈值直接选择matching或GA；pending等状态只作为RL输入特征。")

# Footer
for section in doc.sections:
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = footer.add_run("AGV仓库建模与调度算法说明")
    set_run_font(r, size=9, color=(120,120,120))

doc.core_properties.title = "现有AGV仓库实验的建模规则与调度算法说明"
doc.core_properties.subject = "AGV仓库建模、联合GA与RL自适应调度"
doc.core_properties.author = "OpenAI Codex"
doc.save(OUT)
print(OUT)
