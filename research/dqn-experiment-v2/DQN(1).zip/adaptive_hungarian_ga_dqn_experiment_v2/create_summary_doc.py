from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.section import WD_SECTION

OUT = 'AGV切换策略简要说明.docx'

def set_cell_shading(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = tcPr.find(qn('w:shd'))
    if shd is None:
        shd = OxmlElement('w:shd')
        tcPr.append(shd)
    shd.set(qn('w:fill'), fill)

def set_cell_text(cell, text, bold=False, color=None):
    cell.text = ''
    p = cell.paragraphs[0]
    r = p.add_run(str(text))
    r.bold = bold
    if color:
        r.font.color.rgb = RGBColor(*color)
    r.font.name = 'Microsoft YaHei'
    r._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
    r.font.size = Pt(9)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER

def set_font(run, size=10.5, bold=False, color=None):
    run.font.name = 'Microsoft YaHei'
    run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
    run.font.size = Pt(size)
    run.bold = bold
    if color:
        run.font.color.rgb = RGBColor(*color)

def add_bullet(doc, text):
    p = doc.add_paragraph(style='List Bullet')
    r = p.add_run(text)
    set_font(r)
    p.paragraph_format.space_after = Pt(3)
    return p

def add_body(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(5)
    p.paragraph_format.line_spacing = 1.15
    r = p.add_run(text)
    set_font(r)
    return p

def add_heading(doc, text, level=1):
    p = doc.add_heading(text, level=level)
    for r in p.runs:
        set_font(r, 13 if level == 1 else 11, True, (31,78,121) if level == 1 else (55,55,55))
    p.paragraph_format.space_before = Pt(8)
    p.paragraph_format.space_after = Pt(4)
    return p

doc = Document()
sec = doc.sections[0]
sec.top_margin = Cm(1.6)
sec.bottom_margin = Cm(1.5)
sec.left_margin = Cm(1.8)
sec.right_margin = Cm(1.8)
styles = doc.styles
styles['Normal'].font.name = 'Microsoft YaHei'
styles['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
styles['Normal'].font.size = Pt(10.5)

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run('AGV任务分配切换策略简要说明')
set_font(r, 17, True, (31,78,121))
p.paragraph_format.space_after = Pt(3)
p2 = doc.add_paragraph()
p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p2.add_run('ready/idle阈值策略与原策略对比')
set_font(r, 10, False, (100,100,100))

add_heading(doc, '一、先给结论', 1)
add_body(doc, '原策略在订单仍然到达时确实可以理解为“pending/idle≤1时使用精确批量匹配，否则使用联合GA”。但它在900秒订单到达窗口结束后会固定进入GA分支，因此不能简单等同于一个始终生效的“阈值1策略”。')
add_body(doc, '本轮实验在ready/idle指标上测试了阈值0.5、1、1.5、2、3。开发阶段选择出τ=2，但验证阶段τ=2相对原策略的综合目标F退化1.789%，所以最终没有切换，继续保留原策略。')

add_heading(doc, '二、原策略到底是什么', 1)
t = doc.add_table(rows=1, cols=3)
t.alignment = WD_TABLE_ALIGNMENT.CENTER
t.style = 'Table Grid'
for c, h in zip(t.rows[0].cells, ['时间/条件', '判断指标', '使用的算法']):
    set_cell_text(c, h, True, (255,255,255)); set_cell_shading(c, '1F4E79')
rows = [
    ('900秒之前，pending≤idle', 'pending / idle ≤ 1', '精确批量匹配'),
    ('900秒之前，pending>idle', 'pending / idle > 1', '联合GA'),
    ('900秒之后，需要重新派单', '不再判断上述阈值', '联合GA'),
]
for row in rows:
    cells = t.add_row().cells
    for c, v in zip(cells, row): set_cell_text(c, v)
add_body(doc, '900秒表示“新订单不再到达”，不是仿真停止时间。900秒之后，已有任务仍会继续执行并最终返库；只是原策略不再允许用pending/idle条件选择匹配，而是在发生新的派单决策时进入GA。')

add_heading(doc, '三、本轮新策略与原策略的区别', 1)
add_body(doc, '新策略把在线指标改为ready/idle：ready是当前已经发布、尚未分配且当前可执行的任务数；idle是当前空闲车辆数。只要ready和idle都大于0，就按ready/idle与阈值τ比较：')
add_bullet(doc, 'ready / idle ≤ τ：使用精确批量匹配。')
add_bullet(doc, 'ready / idle > τ：使用联合GA。')
add_bullet(doc, '900秒前后都使用同一套规则，不再因为订单流结束而强制切换GA。')
add_body(doc, '因此，虽然原策略和新策略都出现过数字“1”，但它们不是同一个策略：原策略使用pending并带有闭流后的GA规则；新策略使用ready并让阈值在闭流后继续生效。')

add_heading(doc, '四、实验结果', 1)
add_body(doc, '固定大型62×47地图、6辆车、5层库存和原始完整订单窗口，开发阶段96次、验证阶段48次，共144次有效实验。F越低越好，计算CPU时间单独统计。')
t2 = doc.add_table(rows=1, cols=5)
t2.alignment = WD_TABLE_ALIGNMENT.CENTER
t2.style = 'Table Grid'
for c, h in zip(t2.rows[0].cells, ['策略', '验证平均F', '相对原策略', '平均CPU秒', '结论']):
    set_cell_text(c, h, True, (255,255,255)); set_cell_shading(c, '1F4E79')
results = [
    ('原策略', '0.899159', '基准', '80.621', '保留'),
    ('纯联合GA', '0.898339', '-0.095%', '78.388', '略优，但不是切换结论'),
    ('纯精确批量匹配', '0.925603', '+2.960%', '2.237', '速度快但物理指标变差'),
    ('ready/idle，τ=2', '0.915052', '+1.789%', '61.316', '不采用'),
]
for row in results:
    cells = t2.add_row().cells
    for c, v in zip(cells, row): set_cell_text(c, v)
add_body(doc, 'τ=2平均CPU时间比原策略低约23.9%，但F变差1.789%。本轮采用判据要求验证阶段F相对原策略改善且全部运行有效，因此τ=2不满足采用条件。')

add_heading(doc, '五、给学长的最终判断', 1)
add_body(doc, '“原策略本质上就是阈值1”这句话只对900秒之前、且把指标限定为pending/idle时成立。完整策略还包含“订单到达结束后进入GA”的闭流规则，所以不能直接把它与持续生效的ready/idle阈值1混为一谈。')
add_body(doc, '就目前这批数据而言，没有证据支持把原策略替换为ready/idle混合策略。建议暂时保留原策略；如果后续更重视CPU而能接受少量F退化，τ=2可以作为工程上的折中候选，但应在更多独立日期和不同订单到达模式上继续验证。')

p = doc.add_paragraph()
p.paragraph_format.space_before = Pt(8)
r = p.add_run('实验依据：144次主实验、独立轨迹审计通过；详细结果见“切换边界结果报告.md”。')
set_font(r, 9, False, (100,100,100))

doc.core_properties.title = 'AGV任务分配切换策略简要说明'
doc.core_properties.subject = 'ready/idle阈值策略与原策略对比'
doc.core_properties.author = 'AGV scheduling study'
doc.save(OUT)
print(OUT)
