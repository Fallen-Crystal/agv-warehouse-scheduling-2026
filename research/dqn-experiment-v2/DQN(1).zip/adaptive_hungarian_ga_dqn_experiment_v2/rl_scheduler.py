"""用于选择匹配或联合 GA 的轻量上下文 bandit。

动作只有两个：``matching`` 和 ``ga``。状态来自订单压力、车辆利用率、
拥堵和库存风险。它不改变 SIPP 或执行器，只学习在当前状态下选择哪个
已有算法；默认使用确定性 epsilon-greedy，便于复现实验。
"""
from dataclasses import asdict, dataclass
import random


@dataclass(frozen=True)
class State:
    pressure: float
    utilization: float
    congestion: float
    inventory_risk: float

    def vector(self):
        return (1.0, self.pressure, self.utilization,
                self.congestion, self.inventory_risk)


def observe(world):
    vehicles = max(1, len(world.active))
    pending = len(set(world.visible) - world.assigned)
    pressure = min(2.0, pending / vehicles)
    utilization = sum(item is not None for item in world.active) / vehicles
    history = world.history[-1] if getattr(world, "history", None) else []
    congestion = (
        sum(a == b for a, b in zip(history, history[1:])) / (len(history) - 1)
        if len(history) > 1 else 0.0
    )
    stock = getattr(world, "stock", set())
    inventory_risk = min(1.0, len(stock) / max(1, len(getattr(world, "tasks", {}))))
    return State(pressure, utilization, congestion, inventory_risk)


class ContextualSelector:
    """确定性、可审计的在线 Q 选择器。"""

    ACTIONS = ("matching", "ga")

    def __init__(self, seed=0, *, epsilon=0.05, learning_rate=0.08,
                 discount=0.90, train_enabled=True):
        self.rng = random.Random(seed)
        self.train_enabled = bool(train_enabled)
        self.epsilon = float(epsilon)
        self.learning_rate = float(learning_rate)
        self.discount = float(discount)
        self.weights = {action: [0.0] * 5 for action in self.ACTIONS}
        # 先验只表达常识，后续由奖励更新；它不是阈值规则。
        self.weights["matching"] = [0.15, -0.30, 0.10, -0.20, -0.10]
        self.weights["ga"] = [-0.05, 0.55, 0.25, 0.30, 0.20]
        self.pending = None
        self.episode_actions = []
        self.logs = []

    def q_values(self, state):
        vector = state.vector()
        return {
            action: sum(a * b for a, b in zip(self.weights[action], vector))
            for action in self.ACTIONS
        }

    def choose(self, state, *, idle, ready):
        values = self.q_values(state)
        if idle <= 0 or ready <= 0:
            action = "wait"
        elif self.rng.random() < self.epsilon:
            action = self.rng.choice(self.ACTIONS)
        else:
            action = min(self.ACTIONS, key=lambda name: (-values[name], name))
        self.pending = (state, action)
        event = dict(state=asdict(state), action=action, q_values=values,
                     epsilon=self.epsilon)
        self.logs.append(event)
        self.episode_actions.append((state, action, event))
        return action

    def finish_episode(self, *, objective, distance=0.0, traffic_wait=0.0):
        """Apply terminal feedback after a complete physical simulation.

        The reward follows the measured objective, with small penalties for
        movement and traffic waiting. This lets training persist across
        windows while evaluation can freeze the learned weights.
        """
        if not self.train_enabled:
            self.episode_actions.clear()
            self.pending = None
            return
        reward = -(float(objective) + 0.00001 * float(distance)
                   + 0.0005 * float(traffic_wait))
        updates = 0
        for state, action, event in self.episode_actions:
            if action == "wait":
                continue
            current = self.q_values(state)[action]
            error = reward - current
            for index, feature in enumerate(state.vector()):
                self.weights[action][index] += self.learning_rate * error * feature
            event.update(reward=reward, td_error=error,
                         updated_weights=list(self.weights[action]))
            updates += 1
        self.episode_actions.clear()
        self.pending = None
        return updates

    def edge_score(self, *, distance, wait=0.0, inventory_risk=0.0):
        """RL层提供的轻量边评分；不替代精确匹配的主成本。"""
        return -(float(distance) + 0.25 * float(wait) + 0.5 * float(inventory_risk))

    def update(self, reward, next_state=None):
        """以调度后的即时奖励更新所选动作，返回 TD 误差。"""
        if self.pending is None or self.pending[1] == "wait":
            return 0.0
        state, action = self.pending
        current = self.q_values(state)[action]
        future = max(self.q_values(next_state).values()) if next_state else 0.0
        target = float(reward) + self.discount * future
        error = target - current
        for index, feature in enumerate(state.vector()):
            self.weights[action][index] += self.learning_rate * error * feature
        self.logs[-1].update(reward=float(reward), td_error=error,
                             updated_weights=list(self.weights[action]))
        self.pending = None
        return error
