"""跨seed汇总的证据边界：拒绝残缺/不一致实验，保留退化seed。"""
import copy
import json
import unittest
from pathlib import Path
from unittest.mock import patch
from summarize_dqn_expanded import summarize


class ExpandedEvidenceTests(unittest.TestCase):
    def fixture(self):
        manifests, reports = [], []
        for seed in range(3):
            manifests.append(dict(config=dict(seed=seed, rounds=6, variant='enhanced'),
                                  double_dqn=True, output_scale=.01,
                                  observation_schema='published-v2-24',
                                  hashes={'source': 'same'}, train=['dev'], monitor=['monitor']))
            # seed0改善、seed1不变、seed2退化；最优中间轮不替代最终轮。
            curve = [dict(F=.9) for _ in range(7)]
            curve[2]['F'] = .7
            curve[6]['F'] = (.8, .9, 1.)[seed]
            reports.append(dict(complete=True, observed=31, valid_count=31,
                                monitor=curve, train_steps=100, replay_size=163, stability={}))
        return manifests, reports

    def run_fixture(self, manifests, reports):
        def read(path, **kwargs):
            return json.dumps(manifests[int(path.parent.name[1:])])
        with patch.object(Path, 'read_text', read), patch('summarize_dqn_expanded.analyze', side_effect=reports):
            return summarize('unused')

    def test_final_endpoint_keeps_regression_and_equal_seed_weight(self):
        result = self.run_fixture(*self.fixture())
        self.assertEqual(result['improved_seeds'], 1)
        self.assertAlmostEqual(result['epochs'][-1]['mean_F'], .9)
        self.assertAlmostEqual(result['epochs'][-1]['sample_sd_F'], .1)
        self.assertEqual(result['per_seed'][2]['final_F'], 1.)
        self.assertEqual(result['per_seed'][2]['best_monitor_F'], .7)
        self.assertLess(result['per_seed'][2]['improvement_percent'], 0)

    def test_rejects_incomplete_invalid_or_mixed_sources(self):
        manifests, reports = self.fixture()
        for field, value in [('complete', False), ('observed', 30), ('valid_count', 30)]:
            broken = copy.deepcopy(reports)
            broken[1][field] = value
            with self.assertRaises(AssertionError):
                self.run_fixture(manifests, broken)
        for mutate in (
            lambda m: m['config'].update(seed=0),
            lambda m: m['hashes'].update(source='different'),
            lambda m: m.update(monitor=['different']),
        ):
            broken = copy.deepcopy(manifests)
            mutate(broken[1])
            with self.assertRaises(AssertionError):
                self.run_fixture(broken, reports)


class ReplayEvidenceTests(unittest.TestCase):
    def test_rejects_checkpoint_state_and_metric_corruption(self):
        from verify_dqn_expanded_replays import verify
        row = dict(case='case', phase='monitor', epoch=6, valid=True, F=.8,
                   T=1000, R=200, D=4000, traffic_wait=0, actions={'ga': 1},
                   train_steps=100, replay_size=163, reward_sum=-.8,
                   initial_cost=.01, learning_reward_sum=-.79,
                   observation_schema='published-v2-24', transitions=[], losses=[])
        replays = [dict(seed=s, frozen_state_verified=True,
                        checkpoint_sha256='same', rows=[copy.deepcopy(row)]) for s in range(3)]

        def run():
            def read(path, **kwargs):
                seed = int(path.parent.name[1:])
                if path.name == 'manifest.json':
                    return json.dumps(dict(config=dict(rounds=6), monitor=['case']))
                if path.name == 'final_replay.json':
                    return json.dumps(replays[seed])
                return json.dumps(row)
            with patch.object(Path, 'read_text', read), patch('verify_dqn_expanded_replays.sha', return_value='same'):
                return verify('unused')

        self.assertEqual(len(run()['rows']), 3)
        original = copy.deepcopy(replays)
        for mutate in (
            lambda r: r.update(frozen_state_verified=False),
            lambda r: r.update(checkpoint_sha256='wrong'),
            lambda r: r['rows'][0].update(F=.7),
            lambda r: r['rows'][0].update(actions={'matching': 1}),
        ):
            replays = copy.deepcopy(original)
            mutate(replays[1])
            with self.assertRaises(AssertionError):
                run()


if __name__ == '__main__':
    unittest.main()
