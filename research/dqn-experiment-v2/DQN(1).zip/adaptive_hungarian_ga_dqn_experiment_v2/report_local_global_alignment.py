"""局部可见工作改善与最终整窗F的描述性对照；不作因果推断。"""
import gzip
import json
from paths import ROOT,sha
from audit_search_headroom import audit_folder
from run_search_headroom import commit


def main():
    folder=ROOT/'results/search_headroom_v1'
    verified=audit_folder(folder)
    rows=[]
    bases={r['case']:r for r in verified['rows'] if r['budget_name']=='baseline'}
    for row in verified['rows']:
        raw=folder/row['trajectory_file']
        if sha(raw)!=row['trajectory_sha256']:
            raise ValueError('Trajectory identity changed')
        trajectory=json.loads(gzip.decompress(raw.read_bytes()))
        logs=[entry for entry in trajectory['search_log'] if 'previews' in entry]
        reductions=[entry['base_score']-entry['score'] for entry in logs]
        if any(x < -1e-9 for x in reductions):
            raise ValueError('Search accepted worse than anchor')
        rows.append(dict(case=row['case'],source_day=row['source_day'],budget_name=row['budget_name'],
            final_F=row['F'],paired_improvement_pct=100*(1-row['F']/bases[row['case']]['F']),
            locally_improved_searches=sum(x>1e-12 for x in reductions),searches=len(logs),
            sum_overlapping_local_F_reductions=sum(reductions),
            mean_local_F_reduction=sum(reductions)/len(reductions) if reductions else 0))
    commit(folder,'local_global_alignment.json',dict(rows=rows,
        caveats=['Each search compares only current visible work and its own realized state.',
                 'Overlapping local reductions are not additive episode savings; do not report as percent gain.',
                 'Different arms reach different states, so counts are descriptive rather than causal.',
                 'Increased local improvement with worse final F can motivate boundary/replanning investigation, but does not identify its cause.']))
    text=['# 局部预览与最终整窗F', '',
          '| 日期 | 组 | 局部改善搜索数 | 搜索总数 | 最终F | 整窗改善率 |',
          '|---|---|---:|---:|---:|---:|']
    for r in rows:
        text.append(f"| {r['source_day']} | {r['budget_name']} | {r['locally_improved_searches']} | {r['searches']} | {r['final_F']:.6f} | {r['paired_improvement_pct']:+.3f}% |")
    text+=['', '每次搜索只能看到当前已发布任务。局部改善不能相加为整窗收益；各组进入的物理状态不同，次数也不是干预因果证据。', '',
           'day40扩大预览组比原组有更多局部改善搜索，但整窗F反而更差。这支持检查在线预测边界和重规划目标的必要性，不能直接证明哪个边界设定更好，也不能为了提升而使用尚未发布订单。','']
    (folder/'局部与整窗对照.md').write_text('\n'.join(text),encoding='utf-8')
    print(rows,flush=True)


if __name__=='__main__':
    main()
