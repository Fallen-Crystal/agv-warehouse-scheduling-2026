"""多轮多种子探索性稳定性实验；不修改历史协议或历史训练器。"""
import argparse
from collections import Counter
import json
import random
import statistics
import time
from pathlib import Path

from paths import ROOT, sha, verify_baseline
from objective import LinearObjective, checked_score
from improved.execute import run
from improved.policy import ResearchPolicy
from stable_rl import StableSelector


def split_cases(protocol):
    # 6窗训练覆盖原开发集及已使用过的40/61；83/87仅用于监测。
    # 这些窗口曾用于历史实验，不能声称是全新测试集。
    train = protocol["development"] + protocol["validation"][:2]
    monitor = protocol["validation"][2:]
    if set(train) & set(monitor):
        raise ValueError("Overlapping split")
    return train, monitor


def episode(case, protocol, selector, seed, training):
    from wepa.data import build
    objective = LinearObjective(**protocol["objective"])
    model = build(case, **protocol["configuration"])
    before = {a: list(v) for a, v in selector.weights.items()}
    # 执行器有历史终局回调；临时冻结，独立轨迹校验通过后才允许学习。
    selector.train_enabled = False
    selector.logs.clear()
    started = time.perf_counter()
    result = run(model, "rl", seed, objective=objective,
                 policy_factory=lambda **kw: ResearchPolicy("rl", seed,
                     objective=objective, selector=selector))
    score = checked_score(model, result, objective)
    valid = bool(result["valid"] and score["audit"]["valid"])
    if not valid:
        raise ValueError("Invalid trajectory; refuse training")
    # 冻结回调已清空episode_actions，从本窗口日志恢复状态动作对。
    from rl_scheduler import State
    if training:
        selector.episode_actions = [(State(**e["state"]), e["action"], e)
                                    for e in selector.logs]
        selector.train_enabled = True
        selector.finish_episode(objective=score["F_linear_v2"])
    elif selector.weights != before:
        raise AssertionError("Frozen weights changed")
    counts = Counter(e["action"] for e in selector.logs)
    return dict(case=case["case"], valid=valid, F=score["F_linear_v2"],
                **{k: result[k] for k in ("T", "R", "D", "traffic_wait")},
                actions=dict(counts), decisions=sum(counts.values()),
                weights={a: list(v) for a, v in selector.weights.items()},
                max_weight_delta=max(abs(selector.weights[a][i]-before[a][i])
                                     for a in before for i in range(5)),
                wall=time.perf_counter()-started)


def stability(rows, rounds, window=3, tolerance=0.01):
    """同一seed、相同监测集合的后3次均值变幅；不是统计收敛证明。"""
    checks = []
    for seed in sorted({r["seed"] for r in rows}):
        means = []
        for epoch in rounds:
            vals = [r["F"] for r in rows if r["seed"] == seed and r["epoch"] == epoch]
            if vals:
                means.append((epoch, statistics.mean(vals)))
        tail = means[-window:]
        span = ((max(v for _, v in tail)-min(v for _, v in tail)) /
                max(1e-12, statistics.mean(v for _, v in tail))) if tail else None
        checks.append(dict(seed=seed, curve=means, relative_span=span,
                           stable=len(tail) == window and span <= tolerance))
    return dict(rule="last 3 monitor means relative range <= 1% for every seed",
                checks=checks, stable=bool(checks) and all(c["stable"] for c in checks))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--rounds", type=int, default=6)
    p.add_argument("--seeds", default="0,1,2")
    p.add_argument("--output-dir", required=True)
    args = p.parse_args()
    seeds = [int(s) for s in args.seeds.split(",")]
    if args.rounds < 3 or len(set(seeds)) != len(seeds) or not seeds:
        p.error("Need >=3 rounds and unique seeds")
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=False)
    verify_baseline()
    protocol = json.loads((ROOT/"data/protocol.json").read_text(encoding="utf-8"))
    train, monitor = split_cases(protocol)
    cases = {c["case"]: c for c in protocol["cases"]}
    metadata = dict(config=vars(args), train=train, monitor=monitor,
                    qualification="exploratory; historical validation reused; no fresh holdout",
                    version=StableSelector.VERSION,
                    hashes={name: sha(ROOT/name) for name in
                            ("stable_rl.py", "train_rl_stable.py", "data/protocol.json")})
    (out/"manifest.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    rows = []
    def record(row):
        rows.append(row)
        # 每窗口落盘，长实验中断不丢失已完成证据。
        with (out/"episodes.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(row)+"\n")
        print(json.dumps({k:v for k,v in row.items() if k != "weights"}), flush=True)
    for seed in seeds:
        selector = StableSelector(seed=seed)
        order_rng = random.Random(seed+1000)
        for epoch in range(args.rounds+1):
            if epoch:
                selector.epsilon = max(0.05, 0.20*(0.8**(epoch-1)))
                order = list(train)
                order_rng.shuffle(order)
                for name in order:
                    record(dict(seed=seed, epoch=epoch, phase="train",
                                **episode(cases[name], protocol, selector, seed, True)))
                selector.save(out/f"seed{seed}_epoch{epoch}.json", metadata=metadata)
            # 每轮均以相同物理seed冻结回放；评估不消耗训练rng。
            rng = selector.rng.getstate()
            selector.epsilon = 0.0
            for name in monitor:
                record(dict(seed=seed, epoch=epoch, phase="monitor",
                            **episode(cases[name], protocol, selector, seed, False)))
            selector.rng.setstate(rng)
    monitors = [r for r in rows if r["phase"] == "monitor"]
    report = dict(**metadata, episodes=len(rows), valid=all(r["valid"] for r in rows),
                  stability=stability(monitors, list(range(args.rounds+1))))
    (out/"summary.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report), flush=True)


if __name__ == "__main__":
    main()
