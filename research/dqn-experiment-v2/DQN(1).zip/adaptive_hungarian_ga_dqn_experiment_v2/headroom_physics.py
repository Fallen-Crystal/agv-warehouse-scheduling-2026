"""Read-only physical headroom diagnostics for complete WEPA executions.

This module neither dispatches nor changes the objective. Bounds deliberately
relax obstacles, collisions, stock/level precedence and consistency of slot
choices across jobs. They are offline diagnostics, not policy observations.
See lower_bounds() and analyze_physics() for the assumptions and exact ledgers.
"""
from math import ceil, isclose, isfinite

import paths  # Registers the frozen baseline imports; does not execute a run.
from objective import checked_score
from agv.planning.distance import DistanceOracle


def _manhattan(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def lower_bounds(model, objective):
    """Proven (possibly loose) bounds for the current four-neighbor unit grid.

    For each job j, consider ALL mapped slots with its SKU, all loading sides
    and all operating vehicles. We allow even currently occupied/unavailable
    slots: this enlarges feasibility, which is safe for a lower bound.
    q_j = min(loaded Manhattan distance + pickup/drop service).
    c_j = min(max(release_j, home-to-pickup Manhattan) + loaded + service).
    A vehicle may have moved before publication, so release + home distance is
    NOT a valid general bound. max(release, distance) is valid.

    All q_j units of loaded motion/service occur after release_j. For any
    release threshold u, m*(T-u) >= sum(q_j for release_j >= u). Empty travel
    and all conflicts are discarded. D only uses compulsory loaded movement;
    final returns are included in the true metric but omitted from this bound.
    Positive objective weights allow combining componentwise lower bounds,
    even if their minimizers are mutually inconsistent.
    """
    m = model['vehicles']
    if m != objective.vehicles or m < 1:
        raise ValueError('Fleet/objective mismatch')
    if not isclose(objective.speed_cells_per_second * objective.seconds_per_step,
                   1.0, rel_tol=0, abs_tol=1e-12):
        raise ValueError('Bounds require one cell per physical step')
    homes = model['scene'].homes[:m]  # scene has 8 homes, model may use only 6.
    if len(homes) != m:
        raise ValueError('Missing operating homes')
    rows = []
    for job in model['tasks']:
        r = job['release']
        if r < 0 or job['kind'] not in ('delivery', 'retrieval'):
            raise ValueError('Unsupported release or task kind')
        candidates = []
        for slot in model['slots']:
            if slot['sku'] != job['sku']:
                continue
            service = 1 + 2 * slot['level']
            if slot['level'] < 1:
                raise ValueError('Invalid service level')
            for side in slot['points']:
                pickup, drop = ((job['port'], side) if job['kind'] == 'delivery'
                                else (side, job['port']))
                loaded = _manhattan(pickup, drop)
                initial = min(_manhattan(home, pickup) for home in homes)
                candidates.append((loaded, service, max(r, initial) + loaded + service))
        if not candidates:
            raise ValueError(f"No relaxed slot candidates for task {job['id']}")
        completion = min(c[2] for c in candidates)
        rows.append(dict(task=job['id'], release=r,
                         loaded_distance=min(c[0] for c in candidates),
                         loaded_plus_service=min(c[0] + c[1] for c in candidates),
                         earliest_completion=completion,
                         minimum_flow=completion-r))
    individual = max((r['earliest_completion'] for r in rows), default=0)
    release_tail = max((u + ceil(sum(r['loaded_plus_service'] for r in rows
                                     if r['release'] >= u) / m)
                        for u in {r['release'] for r in rows}), default=0)
    values = dict(T=max(individual, release_tail),
                  R=sum(r['minimum_flow'] for r in rows)/len(rows) if rows else 0.0,
                  D=sum(r['loaded_distance'] for r in rows))
    values['F'] = objective.score(tuple(values[k] for k in ('T', 'R', 'D')))
    return dict(method='mixed-all-sku-slots-manhattan-release-tail-v1',
                **values, T_individual=individual, T_release_tail_workload=release_tail,
                latest_release=max((r['release'] for r in rows), default=0),
                tasks=rows,
                assumptions=['Complete task execution from time zero and own homes',
                             'One cell per step, four-neighbor movement, no teleportation',
                             'One nonpreemptive task per vehicle; no pickup before release',
                             'Legal slot has matching SKU; service is 1 + 2*slot.level',
                             'Current positive-weight LinearObjective; fixed fleet'],
                relaxed=['Obstacles and terminal/home-access restrictions',
                         'Collisions and resource/bay/port capacity constraints',
                         'Inventory, level precedence, deterministic WMS allocation',
                         'Empty travel and final home return in D',
                         'Consistency of minimizing slot/vehicle choices across tasks'])


def _moves(path, start, stop):
    """Count transitions t->t+1 for the half-open interval [start, stop)."""
    return sum(path[t] != path[t+1] for t in range(start, stop))


def analyze_physics(model, result, objective):
    """Return JSON-compatible bounds and exact, non-causal trajectory ledgers.

    Reject incomplete/invalid trajectories using the existing independent
    checker. No model/result mutation, RNG calls or physical simulation occurs.
    assigned_at-release is only 'pre-assignment time': it includes resource,
    stock and dispatch effects, NOT a measured scheduling mistake.
    """
    scoring = checked_score(model, result, objective)
    bounds = lower_bounds(model, objective)
    formal = {k: result[k] for k in ('T', 'R', 'D')}
    formal['F'] = scoring['F_linear_v2']
    for key in ('T', 'R', 'D', 'F'):
        if bounds[key] > formal[key] + 1e-8:
            raise AssertionError(f'Lower bound exceeds executed {key}')
    task_map = {j['id']: j for j in model['tasks']}
    router = DistanceOracle(model['scene'])
    keys = ('pre_assignment', 'empty_moves', 'empty_stationary',
            'pickup_service', 'loaded_moves', 'loaded_stationary', 'drop_service')
    totals = dict.fromkeys(keys, 0)
    rows = []
    for record in result['records']:
        job = task_map[record['task']]
        k = record['vehicle']
        path = result['paths'][k]
        a, pa, pe, da, end = (record[key] for key in
                            ('assigned_at', 'pickup_arrival', 'pickup_end', 'drop_arrival', 'end'))
        empty = _moves(path, a, pa)
        loaded = _moves(path, pe, da)
        parts = dict(pre_assignment=a-job['release'], empty_moves=empty,
                     empty_stationary=pa-a-empty, pickup_service=pe-pa,
                     loaded_moves=loaded, loaded_stationary=da-pe-loaded,
                     drop_service=end-da)
        if min(parts.values()) < 0 or sum(parts.values()) != end-job['release']:
            raise AssertionError('Response-time ledger does not telescope')
        # The chosen endpoints are suitable ONLY for a conditional route ledger.
        # They are not substituted into the global, all-slot lower bound above.
        de = router.distance(tuple(path[a]), tuple(record['pickup']), k)
        dl = router.distance(tuple(record['pickup']), tuple(record['drop']), k)
        if not all(isfinite(v) for v in (de, dl)) or de > empty or dl > loaded:
            raise AssertionError('Static route distance exceeds realized movement')
        for key in keys:
            totals[key] += parts[key]
        rows.append(dict(task=record['task'], vehicle=k, kind=job['kind'],
                         slot=record['slot'], release=job['release'], assigned_at=a,
                         end=end, flow=end-job['release'], execution=end-a, **parts,
                         empty_static_distance=de, loaded_static_distance=dl,
                         empty_route_excess_moves=empty-de,
                         loaded_route_excess_moves=loaded-dl))
    n = len(rows)
    means = {k: v/n if n else 0.0 for k, v in totals.items()}
    if not isclose(sum(means.values()), formal['R'], abs_tol=1e-9):
        raise AssertionError('Mean response-time partition differs from R')
    final_return_moves = 0
    for k, path in enumerate(result['paths']):
        last = max((r['end'] for r in result['records'] if r['vehicle'] == k), default=0)
        final_return_moves += _moves(path, last, result['time'])
    unassigned_moves = formal['D'] - totals['empty_moves'] - totals['loaded_moves']
    if unassigned_moves < final_return_moves:
        raise AssertionError('Distance partition has negative inter-task movement')
    label_totals = {}
    for path, labels in zip(result['paths'], result['labels']):
        for t, label in enumerate(labels):
            bucket = label_totals.setdefault(label, dict(moves=0, stationary=0))
            bucket['moves' if path[t] != path[t+1] else 'stationary'] += 1
    traffic_wait = sum(label_totals.get(label, {}).get('stationary', 0)
                       for label in ('empty', 'loaded'))
    if traffic_wait != result['traffic_wait']:
        raise AssertionError('Reported traffic_wait differs from path/label definition')
    task_stationary = totals['empty_stationary'] + totals['loaded_stationary']
    # Check labels on task travel intervals separately: WEPA's replay checker
    # independently checks physical services but does not validate every label.
    for record in result['records']:
        labels = result['labels'][record['vehicle']]
        for lo, hi, expected in ((record['assigned_at'], record['pickup_arrival'], 'empty'),
                                 (record['pickup_arrival'], record['pickup_end'], 'service'),
                                 (record['pickup_end'], record['drop_arrival'], 'loaded'),
                                 (record['drop_arrival'], record['end'], 'service')):
            if any(label != expected for label in labels[lo:hi]):
                raise AssertionError('Travel/service labels disagree with task records')
    if traffic_wait < task_stationary:
        raise AssertionError('Task travel waits exceed total labeled travel waits')
    excess = {k: formal[k]-bounds[k] for k in ('T', 'R', 'D', 'F')}
    weighted_excess = dict(zip(('T', 'R', 'D'), objective.terms(
        tuple(max(0, excess[k]) for k in ('T', 'R', 'D')))))
    return dict(schema='headroom-physics-v1', case=model['case'], tasks_count=n,
                formal=formal, weighted_terms=scoring['weighted_terms'],
                audit=scoring['audit'], lower_bounds=bounds,
                gaps=dict(absolute=excess, weighted_component_excess=weighted_excess,
                          F_reduction_ceiling_fraction=excess['F']/formal['F'] if formal['F'] else 0.0,
                          interpretation='Relaxation ceiling on possible improvement, NOT attainable gain'),
                response_time=dict(total_steps=totals, mean_steps=means,
                                   execution_mean=sum(r['execution'] for r in rows)/n if n else 0.0,
                                   identity='R = sum(mean_steps.values())'),
                distance=dict(loaded=totals['loaded_moves'], assigned_empty=totals['empty_moves'],
                              inter_task_unassigned=unassigned_moves-final_return_moves,
                              final_home_return=final_return_moves,
                              empty_route_excess=sum(r['empty_route_excess_moves'] for r in rows),
                              loaded_route_excess=sum(r['loaded_route_excess_moves'] for r in rows),
                              identity='D = loaded + assigned_empty + inter_task_unassigned + final_home_return'),
                traffic=dict(reported_labeled_wait=traffic_wait, task_travel_stationary=task_stationary,
                             unassigned_travel_stationary=traffic_wait-task_stationary,
                             labels=label_totals),
                completion=dict(critical_task_ids=[r['task'] for r in rows if r['end']==formal['T']],
                                end_of_simulation=result['time'],
                                note='T ends at final task completion, not closure or final return'),
                tasks=rows,
                caveats=[
                    'Bounds inspect all jobs offline; never expose future jobs to a policy.',
                    'Bound gap is not attainable improvement; a large gap can mean a loose relaxation.',
                    'Small improvement from a stronger heuristic does not prove near optimality.',
                    'Pre-assignment time combines stock/level/bay availability, fleet load and dispatch decisions.',
                    'Travel stationary time is an accounting category, not independently identified collision cost.',
                    'Route excess conditions on realized start/endpoints; it is not pure congestion loss or globally avoidable distance.',
                    'T is a maximum; per-task waits and route excess cannot be summed to explain its change.',
                    'F contributions are exact accounting only, not causal attribution or evidence of significance.'
                ])


__all__ = ['analyze_physics', 'lower_bounds']
