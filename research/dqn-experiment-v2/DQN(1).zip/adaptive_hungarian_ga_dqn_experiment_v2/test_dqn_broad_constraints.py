"""本轮不能为加速长窗而开启阈值门控或削减正式GA预算。"""
import json
import unittest
import paths
from paths import ROOT
from improved.profiles import PROFILES
from objective import LinearObjective


class BroadConstraintTests(unittest.TestCase):
    def test_no_gate_and_original_ga_budget(self):
        settings=PROFILES['rl']
        self.assertIs(settings['gate'],False)
        self.assertEqual((settings['proxy'],settings['previews'],settings['generations']),(192,6,16))
        self.assertTrue(settings['rl_selector'])

    def test_formal_objective_not_rescaled_to_hour(self):
        protocol=json.loads((ROOT/'data/dqn_broad_protocol.json').read_text(encoding='utf-8'))
        objective=LinearObjective(**protocol['objective'])
        self.assertEqual(objective.scales,(900,900,5400))
        self.assertEqual(tuple(objective.weights),(.5,.3,.2))
        self.assertEqual(protocol['configuration'],{'size':'large','layers':5,'vehicles':6})
        self.assertEqual(protocol['training_passes'],1)
        self.assertEqual(protocol['seed'],0)


if __name__=='__main__':
    unittest.main()
