import unittest
from types import SimpleNamespace

from rl_scheduler import ContextualSelector, observe


class AdaptiveTests(unittest.TestCase):
    def world(self, *, pending=3, ready=2, busy=2):
        tasks = {i: object() for i in range(10)}
        visible = set(range(pending))
        assigned = set()
        active = [object() if i < busy else None for i in range(4)]
        return SimpleNamespace(
            active=active, visible=visible, assigned=assigned,
            ready=lambda: [dict(id=i) for i in range(ready)],
            history=[list(range(4)), list(range(4))],
            stock=set(range(2)), tasks=tasks,
        )

    def test_state_is_deterministic_and_uses_published_work(self):
        state = observe(self.world(pending=3))
        self.assertEqual(state.pressure, 0.75)
        self.assertEqual(state.utilization, 0.5)
        self.assertGreaterEqual(state.congestion, 0.0)

    def test_selector_replays_with_same_seed(self):
        state = observe(self.world(pending=3))
        left = ContextualSelector(seed=7, epsilon=0.5)
        right = ContextualSelector(seed=7, epsilon=0.5)
        self.assertEqual(
            [left.choose(state, idle=2, ready=2) for _ in range(8)],
            [right.choose(state, idle=2, ready=2) for _ in range(8)],
        )

    def test_update_changes_selected_action_weights(self):
        state = observe(self.world(pending=3))
        selector = ContextualSelector(seed=0, epsilon=0.0)
        action = selector.choose(state, idle=2, ready=2)
        before = list(selector.weights[action])
        selector.update(1.0, state)
        self.assertNotEqual(before, selector.weights[action])
        self.assertTrue(selector.logs[-1].get("td_error") is not None)

    def test_wait_is_not_an_algorithm(self):
        state = observe(self.world(pending=0, ready=0, busy=4))
        selector = ContextualSelector(seed=0)
        self.assertEqual(selector.choose(state, idle=0, ready=0), "wait")


if __name__ == "__main__":
    unittest.main()
