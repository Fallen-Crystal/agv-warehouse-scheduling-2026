"""在冻结AGV订单上进行DQN试验；每次决策后转移学习，每轮冻结评估。"""
import argparse
import json
from pathlib import Path
import time
import random

from paths import ROOT, verify_baseline, sha
from objective import LinearObjective, checked_score
from improved.execute import run
from wepa.data import build
from dqn_agent import DQNAgent
from dqn_policy import DQNPolicy


def execute(case, protocol, agent, seed, training):
    model = build(case, **protocol["configuration"])
    objective = LinearObjective(**protocol["objective"])
    before = agent.train_steps
    started = time.perf_counter()
    result = run(model,"rl",seed,objective=objective,
                 policy_factory=lambda **kw: DQNPolicy(seed,objective=objective,
                                                        agent=agent,training=training))
    scoring = checked_score(model,result,objective)
    if not scoring["audit"]["valid"]:
        raise ValueError("Trajectory validation failed; discard this experimental run")
    if not training and agent.train_steps != before:
        raise AssertionError("Frozen evaluation updated parameters")
    if abs(result["dqn"]["reward_sum"]+scoring["F_linear_v2"])>1e-10:
        raise AssertionError("Reward failed to telescope to -F")
    info = result['dqn']
    if abs(info['learning_reward_sum']-info['initial_cost']+scoring['F_linear_v2'])>1e-10:
        raise AssertionError('Learning reward/initial cost mismatch')
    for item in info['transitions']:
        if abs(sum(item['reward_terms'].values())-item['reward'])>1e-10 or item['duration']<0:
            raise AssertionError('Reward component mismatch')
    return dict(case=case["case"],valid=True,F=scoring["F_linear_v2"],
                **{k:result[k] for k in ("T","R","D","traffic_wait")},
                **result["dqn"],epsilon=agent.epsilon,replay_size=agent.replay_size,
                wall=time.perf_counter()-started)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rounds",type=int,default=3)
    parser.add_argument("--seed",type=int,default=0)
    parser.add_argument("--output-dir",required=True)
    parser.add_argument("--train-count",type=int,default=4)
    parser.add_argument('--variant',choices=('legacy','enhanced'),default='enhanced',
                        help='legacy保留10维普通DQN；enhanced使用24维/Double DQN/小输出初始化')
    args = parser.parse_args()
    if args.rounds<1 or not 1<=args.train_count<=4:
        parser.error("rounds>=1; train-count between 1 and 4")
    verify_baseline()
    folder = Path(args.output_dir)
    folder.mkdir(parents=True,exist_ok=False)
    protocol = json.loads((ROOT/"data/protocol.json").read_text(encoding="utf-8"))
    cases = {c["case"]:c for c in protocol["cases"]}
    train = protocol["development"][:args.train_count]
    monitor = protocol["validation"][:1]
    enhanced = args.variant=='enhanced'
    agent = DQNAgent(seed=args.seed,state_dim=24 if enhanced else 10,
                     double_dqn=enhanced,output_scale=.01 if enhanced else 1.)
    metadata = dict(config=vars(args),train=train,monitor=monitor,
                    architecture=f'{agent.state_dim}-32-2 ReLU',gamma=1.0,
                    double_dqn=agent.double_dqn,output_scale=agent.output_scale,
                    observation_schema='published-v2-24' if enhanced else 'published-v1-10',
                    reward="Phi(t)-Phi(next); terminal Phi=F",
                    limitation="historically used windows; exploratory only",
                    hashes={name:sha(ROOT/name) for name in
                            ("dqn_agent.py","dqn_policy.py","train_dqn.py","data/protocol.json")})
    (folder/"manifest.json").write_text(json.dumps(metadata,indent=2),encoding="utf-8")
    order_rng = random.Random(args.seed)
    rows = []
    def record(row):
        rows.append(row)
        with (folder/"episodes.jsonl").open("a",encoding="utf-8") as stream:
            stream.write(json.dumps(row)+"\n")
        print(json.dumps({k:v for k,v in row.items() if k not in ("transitions","losses")}),flush=True)
    for epoch in range(args.rounds+1):
        if epoch:
            agent.epsilon = max(.05,.3*(.8**(epoch-1)))
            order = list(train)
            order_rng.shuffle(order)
            for name in order:
                record(dict(epoch=epoch,phase="train",
                            **execute(cases[name],protocol,agent,args.seed,True)))
            agent.save(folder/f"epoch{epoch}.npz")
        for name in monitor:
            record(dict(epoch=epoch,phase="monitor",
                        **execute(cases[name],protocol,agent,args.seed,False)))
    (folder/"summary.json").write_text(json.dumps(dict(**metadata,rows=rows),indent=2),encoding="utf-8")


if __name__ == "__main__":
    main()
