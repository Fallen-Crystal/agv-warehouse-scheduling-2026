"""Report the frozen ready/idle study; run only after analysis and audit finish."""
import csv
import json
from collections import defaultdict
from pathlib import Path
from statistics import mean, pstdev

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'boundary_results'
CANDIDATES = ('t05', 't1', 't15', 't2', 't3')
DEV_ARMS = ('original', 'ga', 'matching', *CANDIDATES)
LABELS = {'original': '原策略（pending/idle）', 'ga': '纯联合GA',
          'matching': '纯精确批量匹配', 't05': 'pending阈值0.5',
          't1': 'pending阈值1', 't15': 'pending阈值1.5',
          't2': 'pending阈值2', 't3': 'pending阈值3'}
METRICS = ('F', 'T', 'R', 'D', 'cpu', 'ga_searches')


def read_json(name):
    return json.loads((OUT / name).read_text(encoding='utf-8'))


def phase_rows(phase, protocol, arms, summary):
    """Read the analyzer's paired CSV, refusing unfinished or stale coverage."""
    cases = [c for c in protocol['cases'] if c['source_case'] in protocol[phase]]
    expected = {(c['case'], s, a) for c in cases
                for s in protocol[phase + '_seeds'] for a in arms}
    # A partial analyzer export must never become a final report while trials run.
    for case, seed, arm in expected:
        status = OUT / phase / f'{case}__{arm}__s{seed}.status.json'
        if not status.exists():
            raise ValueError(f'Phase incomplete: {status}')
    with (OUT / f'{phase}_runs.csv').open(encoding='utf-8-sig', newline='') as stream:
        rows = list(csv.DictReader(stream))
    for row in rows:
        row['seed'] = int(row['seed'])
        for key in METRICS:
            row[key] = float(row[key])
    keys = [(r['case'], r['seed'], r['arm']) for r in rows]
    if len(set(keys)) != len(keys) or not set(keys) <= expected:
        raise ValueError(f'Duplicate or unexpected CSV rows: {phase}')
    if not summary['failures'] and set(keys) != expected:
        raise ValueError(f'Incomplete paired CSV without recorded failures: {phase}')
    for arm in arms:
        count = sum(r['arm'] == arm for r in rows)
        if count != summary['overall'].get(arm, {}).get('runs', 0):
            raise ValueError(f'Summary/CSV count mismatch: {phase}/{arm}')
    return rows, len(expected)


def paired(rows, arm, reference):
    """Same untouched window and same seed; never compare ratios of grand means."""
    index = {(r['case'], r['seed'], r['arm']): r for r in rows}
    result = []
    for row in rows:
        if row['arm'] != arm:
            continue
        base = index.get((row['case'], row['seed'], reference))
        if base is None:
            continue
        result.append(dict(case=row['case'], source_case=row['source_case'],
                           seed=row['seed'], delta_F=row['F'] - base['F'],
                           relative_F=row['F'] / base['F'] - 1,
                           delta_cpu=row['cpu'] - base['cpu'],
                           relative_cpu=row['cpu'] / base['cpu'] - 1,
                           delta_searches=row['ga_searches'] - base['ga_searches']))
    return result


def balanced(rows, key):
    days = defaultdict(list)
    for row in rows:
        days[row['source_case']].append(row[key])
    return mean(mean(values) for values in days.values())


def metric_table(summary, arms):
    lines = ['|策略|有效配对次数|平均F|配对F变化/原策略|T（秒）|R（秒）|D（格）|CPU秒|GA搜索次数|可选资格|',
             '|---|---:|---:|---:|---:|---:|---:|---:|---:|---|']
    for arm in arms:
        row = summary['overall'].get(arm)
        if row is None:
            lines.append(f'|{LABELS[arm]}|0|—|—|—|—|—|—|—|无有效配对|')
            continue
        lines.append(f"|{LABELS[arm]}|{row['runs']}|{row['F']:.6f}|"
                     f"{row['relative_F_original'] * 100:+.3f}%|{row['T']:.2f}|"
                     f"{row['R']:.2f}|{row['D']:.2f}|{row['cpu']:.3f}|"
                     f"{row['ga_searches']:.2f}|{'有效' if row['eligible'] else '失败剔除资格'}|")
    return lines


def comparisons(rows, selected):
    lines = ['|参照|配对数|平均ΔF|平均配对F变化|平均ΔCPU秒|平均配对CPU变化|平均ΔGA搜索数|',
             '|---|---:|---:|---:|---:|---:|---:|']
    for reference in ('original', 'ga'):
        pairs = paired(rows, selected, reference)
        if not pairs:
            lines.append(f'|{LABELS[reference]}|0|—|—|—|—|—|')
            continue
        lines.append(f"|{LABELS[reference]}|{len(pairs)}|{balanced(pairs, 'delta_F'):+.6f}|"
                     f"{balanced(pairs, 'relative_F') * 100:+.3f}%|"
                     f"{balanced(pairs, 'delta_cpu'):+.3f}|"
                     f"{balanced(pairs, 'relative_cpu') * 100:+.3f}%|"
                     f"{balanced(pairs, 'delta_searches'):+.2f}|")
    return lines


def variation(rows, selected, phase_label):
    lines = [f'### {phase_label}：日期差异和种子敏感性', '',
             '各日期内先平均种子；下表范围与总体标准差描述种子变化，不是置信区间。百分比均为同窗口同种子的配对F变化。', '',
             '|来源窗口|有效种子数|候选F均值|候选F种子范围|候选F种子标准差|对原策略均值|对原策略种子范围|对GA均值|对GA种子范围|',
             '|---|---:|---:|---|---:|---:|---|---:|---|']
    old = paired(rows, selected, 'original')
    ga = paired(rows, selected, 'ga')
    days = sorted({r['source_case'] for r in rows if r['arm'] == selected})
    def percent_range(group):
        values = [r['relative_F'] * 100 for r in group]
        return f'{min(values):+.3f}%～{max(values):+.3f}%' if values else '—'
    def percent_mean(group):
        return f"{mean(r['relative_F'] for r in group) * 100:+.3f}%" if group else '—'
    for day in days:
        group = [r['F'] for r in rows if r['arm'] == selected and r['source_case'] == day]
        a = [r for r in old if r['source_case'] == day]
        b = [r for r in ga if r['source_case'] == day]
        lines.append(f'|{day}|{len(group)}|{mean(group):.6f}|{min(group):.6f}～{max(group):.6f}|'
                     f'{pstdev(group):.6f}|{percent_mean(a)}|{percent_range(a)}|'
                     f'{percent_mean(b)}|{percent_range(b)}|')
    lines += ['', '|种子|对原策略配对数|对原策略日期等权F变化|对GA配对数|对GA日期等权F变化|',
              '|---|---:|---:|---:|---:|']
    for seed in sorted({r['seed'] for r in rows}):
        a = [r for r in old if r['seed'] == seed]
        b = [r for r in ga if r['seed'] == seed]
        av = f"{balanced(a, 'relative_F') * 100:+.3f}%" if a else '—'
        bv = f"{balanced(b, 'relative_F') * 100:+.3f}%" if b else '—'
        lines.append(f'|{seed}|{len(a)}|{av}|{len(b)}|{bv}|')
    lines += ['', '最坏配对及日期退化（正数为退化；若最大值≤0，则未观察到F退化）：', '']
    for reference, pairs in (('original', old), ('ga', ga)):
        if not pairs:
            lines.append(f'- 对{LABELS[reference]}：无有效配对。')
            continue
        worst = max(pairs, key=lambda r: r['relative_F'])
        day_means = {day: mean(r['relative_F'] for r in pairs if r['source_case'] == day)
                     for day in {r['source_case'] for r in pairs}}
        worst_day = max(day_means, key=day_means.get)
        lines.append(f"- 对{LABELS[reference]}：最大配对F变化 {worst['relative_F'] * 100:+.3f}%"
                     f"（{worst['case']}，seed={worst['seed']}，ΔF={worst['delta_F']:+.6f}）；"
                     f"最大日期均值变化 {day_means[worst_day] * 100:+.3f}%（{worst_day}）；"
                     f"退化配对 {sum(r['relative_F'] > 0 for r in pairs)}/{len(pairs)}，"
                     f"退化日期 {sum(v > 0 for v in day_means.values())}/{len(day_means)}。")
    return lines


def wall_cost_table(dev_rows, val_rows):
    lines = ['|阶段|策略|平均CPU秒|平均墙钟秒|最大单次墙钟秒|',
             '|---|---|---:|---:|---:|']
    for phase, rows in [('开发', dev_rows), ('验证', val_rows)]:
        for arm in dict.fromkeys(r['arm'] for r in rows):
            group = [r for r in rows if r['arm'] == arm]
            walls = [float(r['wall']) for r in group]
            lines.append(f"|{phase}|{LABELS[arm]}|{mean(r['cpu'] for r in group):.3f}|"
                         f"{mean(walls):.3f}|{max(walls):.3f}|")
    lines += ['', '墙钟时间包含进程等待等外部影响，CPU时间计量该进程使用的处理器时间。'
              '两者均保留，不把墙钟与CPU的差额解释为算法计算量，也不据此删去较慢样本。'
              '开发阶段曾出现约442/484秒墙钟但仅约44/83秒CPU的运行，外部原因未经确定。']
    return lines


def decision_cost_table(selected):
    path = OUT / 'decision_costs.csv'
    if not path.exists():
        return ['机制耗时汇总尚未提供；不估算单次决策耗时。']
    with path.open(encoding='utf-8-sig', newline='') as stream:
        rows = [r for r in csv.DictReader(stream)
                if r['phase'] == 'validation' and r['arm'] == selected]
    lines = ['|验证候选分支|决策次数|均值CPU秒|中位CPU秒|P95 CPU秒|最大CPU秒|',
             '|---|---:|---:|---:|---:|---:|']
    for row in rows:
        values = '|'.join(f'{float(row[key]):.6f}' for key in
                          ('mean_cpu_seconds', 'median_cpu_seconds',
                           'p95_cpu_seconds', 'max_cpu_seconds'))
        lines.append(f"|{row['branch']}|{row['decisions']}|{values}|")
    lines += ['', 'P95采用最近秩，按策略产生的所有决策事件汇总，属于描述性统计；'
              '事件不是新增独立样本。GA分支可能复用缓存方案，因此单次分支耗时不等于单次GA搜索耗时。']
    return lines


def main():
    protocol = json.loads((ROOT / 'boundary_protocol.json').read_text(encoding='utf-8'))
    if protocol['load_levels'] != ['full'] or set(protocol['arms']) != set(DEV_ARMS):
        raise ValueError('Report requires the untouched-window pending/idle protocol')
    dev = read_json('development_summary.json')
    val = read_json('validation_summary.json')
    selection = read_json('selection.json')
    audit = read_json('audit.json')
    selected = selection['selected']
    if selected not in CANDIDATES or selection['threshold'] != protocol['arms'][selected]['threshold']:
        raise ValueError('Selection is outside the frozen candidate grid')
    val_arms = ('original', 'ga', 'matching', selected)
    dev_rows, expected_dev = phase_rows('development', protocol, DEV_ARMS, dev)
    val_rows, expected_val = phase_rows('validation', protocol, val_arms, val)
    candidate = val['overall'].get(selected)
    all_valid = (not dev['failures'] and not val['failures']
                 and len(dev_rows) == expected_dev and len(val_rows) == expected_val
                 and audit['revalidated_trials'] == expected_dev + expected_val
                 and audit['implementation_versions'] == 1 and audit['all_legacy_equal']
                 and audit.get('source_matches_current') and audit.get('protocol_slots_verified'))
    adopted = bool(candidate and candidate['relative_F_original'] < 0 and all_valid)
    change = f"{candidate['relative_F_original'] * 100:+.3f}%" if candidate else '无有效配对'
    t1 = dev['overall'].get('t1')
    t1_change = f"{t1['relative_F_original'] * 100:+.3f}%" if t1 else '无有效配对'
    replays = audit['legacy_full_load_replays']
    replay_keys = {(r['phase'], r['case'], r['seed']) for r in replays}
    skipped = [f"{phase}/{case}/s{seed}" for phase in ('development', 'validation')
               for case in protocol[phase] for seed in protocol[phase + '_seeds']
               if (phase, case, seed) not in replay_keys]
    lines = ['# 主实验：pending/idle 精确批量匹配与联合GA切换边界', '',
             f"开发阶段冻结选择 **τ={selection['threshold']}**。在线阈值指标为 **全部已发布但未分配任务数 pending / 当前空闲车辆数 idle**；ready只作为当前是否存在可执行任务的前置条件。", '',
             f'验证阶段候选相对原策略的日期等权平均配对F变化为 **{change}**（负数改善）。'
             + ('满足本实验预定采用条件。' if adopted else '未满足本实验全部采用条件，保留原默认策略。'), '',
             '采用判据是验证平均配对F改善且全部运行有效；报告不会自动修改默认策略。'
             '候选即使相对纯GA存在小幅F劣势，如同时节省CPU，仍可作为计算成本与物理性能权衡的研究结果；'
             'CPU节省不能抵消F以宣称满足采用条件，也不构成等效性或显著性证明。', '',
             '## 协议与评价口径', '',
             '- 8个未经删减、复制或重排的原始窗口：4个开发日期、4个验证日期；各臂每窗种子0/1/2。'
             f'开发计划{expected_dev}次（原策略、GA、matching、五个阈值），验证计划{expected_val}次（原策略、GA、matching、冻结阈值）。',
             '- 大型62×47地图、6车、5层；900秒是新订单到达窗口结束，不是作业停止时间。'
             '执行持续到全部任务完成及最终返库，T可超过900秒。',
             '- F=0.5T/900+0.3R/900+0.2D/5400，越低越好；T为最后一项任务完成时刻，R为任务完成时刻减发布时间的平均值，D为总行驶距离（含最终返库）。'
             'CPU单独报告，不进入F，也不等同于仿真订单延迟。',
             '- ready>0且idle>0时，pending/idle≤τ选匹配，否则选GA；无空闲车或无ready任务时等待。'
             '新臂在900秒闭流前后均用该规则，不因闭流强制GA；τ=0与τ=∞分别为纯GA、纯匹配端点。',
             '- 原策略用pending/idle阈值1，并在900秒闭流后强制GA。'
             'ready仅含当前可执行任务，pending还可能包含暂不可执行任务。',
             '- 匹配、GA算子及192代理评估/6完整预演/16代预算、SIPP执行后端保持一致。',
             '- 验证窗口在既有研究中已经使用，本轮属于历史窗口复用确认，不是新外部holdout。'
             '日期是独立分析单位，重复种子不增加独立日期数。',
             '- 本轮阈值研究是在已看到相关开发结果后开展的探索性研究，不能表述为从未接触相关结果的独立预注册；'
             '本轮所有pending候选与开发选择仍在本轮验证之前冻结。',
             '- 同级agv-boundary-study中的旧pending/idle 140次试验仅为辅助证据，'
             '不并入本轮选阈值或主结果；本报告不产生五档合成负载结论。', '',
             '## 开发阶段：所有候选及冻结选择', '', *metric_table(dev, DEV_ARMS), '',
             '仅在τ∈{0.5,1,1.5,2,3}中选择：同窗口同种子计算F_candidate/F_original，'
             '先在日期内平均三个种子，再等权平均四个日期，取最小值；表中显示该比值减1。'
             '无效或超时使候选失去资格。1e-9以内并列时先取CPU较低者，再取较小阈值。'
             '开发选择冻结后才开展验证，验证不再调参。', '',
             '## 验证阶段：四臂物理结果和计算成本', '', *metric_table(val, val_arms), '',
             '平均物理指标和CPU来自分析器汇总；完整设计下与日期等权一致。'
             '若存在失败，下表仅描述有效配对样本，不能掩盖失败或用于通过采用判据。'
             'GA搜索次数是实际搜索记录数，不是门控选择GA的事件次数；原策略没有新门控事件记录，不能把事件零值解释为未执行GA。', '',
             '### 冻结阈值相对原策略及纯GA的配对差值', '',
             'Δ=候选−参照；百分比逐个同窗口、同种子配对计算，再日期等权平均，不是两个总均值相除。', '',
             *comparisons(val_rows, selected), '',
             '### CPU与墙钟时间', '', *wall_cost_table(dev_rows, val_rows), '',
              '### 验证候选单次分支计算成本', '', *decision_cost_table(selected), '',
             *variation(dev_rows, selected, '开发'), '',
             *variation(val_rows, selected, '验证'), '',
             '## 闭流解释与精确性范围', '',
             f"开发τ=1对原策略的配对F变化为 {t1_change}。"
             '两者同时改变门控分子（pending→ready）和闭流规则，因此该对照既不能隔离闭流效应，'
             '也不能单独归因为阈值大小。需要另设消融才能识别各因素。', '',
             '精确批量匹配针对当前固定的加性估计边成本，先最大化匹配基数，再最小化估计总成本；'
             '支持任务数大于空闲车数并选择任务子集。它不保证整窗F全局最优，'
             '不覆盖后续顺序、路径耦合与未知未来到达；GA同样没有全局最优保证。'
             '总订单数/6仅是离线窗口描述，不能替代在线pending/idle或推断精确连续切换交点。', '',
             '## 完整性、复现与限制', '',
             f"- 开发失败/超时/无效记录 {len(dev['failures'])}，验证 {len(val['failures'])}；"
             f"有效配对CSV行数分别为 {len(dev_rows)}/{expected_dev}、{len(val_rows)}/{expected_val}。",
             f"- 独立物理轨迹重验 {audit['revalidated_trials']} 次；源码身份版本数 {audit['implementation_versions']}；"
             f"基线哈希核验 {audit['baseline_files']} 个文件。",
             f"- 历史原策略轨迹比较 {len(replays)} 次，"
             + ('已有参照全部一致。' if replays and audit['all_legacy_equal'] else '无可比较参照或存在差异，请检查audit.json。'),
             f"- 未纳入历史轨迹比较的原策略case/seed共 {len(skipped)} 个；历史不存在的种子跳过，"
             '不宣称这些种子已经完成历史一致性比较。独立物理有效性重验仍覆盖本轮轨迹。', '',
             '|历史对照阶段|窗口|seed|物理输出一致|', '|---|---|---:|---|']
    for replay in replays:
        lines.append(f"|{replay['phase']}|{replay['case']}|{replay['seed']}|{'是' if replay['equal'] else '否'}|")
    if skipped:
        lines += ['', '未比较历史轨迹：' + '、'.join(skipped) + '。']
    lines += ['', '检查记录：原有25项可运行测试、新增4项门控测试和2项汇总异常测试通过；'
              '另一个依赖可选OR-Tools的历史精确求解器模块未加载，不能记为通过。'
              '报告生成器本身不执行这些测试，复现命令与测试范围见[切换边界实验说明](../切换边界实验说明.md)。', '',
              '原始证据位于development/、validation/；*_runs.csv为逐次配对明细，'
              '*_summary.json为分析器汇总，selection.json为开发冻结选择，audit.json为审计记录。'
              '本报告只输出已有证据，不插补失败结果。', '',
              '本轮只有四个验证日期；种子波动、日期退化及CPU成本须同时阅读。'
              '不声称显著性、等效性、六车全局最优或未知日期的普遍适用性；仍需新日期、到达模式与更广参数范围的后续检验。']
    if (OUT / 'threshold_equivalence.json').exists():
        equivalence = read_json('threshold_equivalence.json')
        groups = [g for g in equivalence['groups'] if len(g) > 1]
        lines += ['', '## 候选阈值的可区分程度', '']
        if groups:
            for group in groups:
                lines.append('、'.join(LABELS[a] for a in group) +
                             f"：在全部{equivalence['cases_per_arm']}个开发窗口/种子组合上，除搜索日志外的完整执行结果相同。")
            lines += ['', '这些候选在本次开发轨迹上不可区分；并列选参中的CPU差别不证明物理性能优劣。'
                      '该观察不能推广成连续阈值区间，也不代表未运行的验证候选已被检验。']
        else:
            lines.append('五个候选中，没有两者在全部开发运行上产生完全相同的物理结果；这不等于差异具有统计显著性。')
    (OUT / '切换边界结果报告.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print('Report written; adopted:', adopted, 'selected:', selected)


if __name__ == '__main__':
    main()
