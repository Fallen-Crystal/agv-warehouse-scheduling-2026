"""完整小轨迹核对资源链注入确实走共享GA并遵守原预算。"""
import unittest
from paths import ROOT
from run_resource_chain import execute_resource
from run_search_headroom import PROTOCOL,read_json
from adaptive_hungarian_learning import audit_adaptation


class ResourceWiringTests(unittest.TestCase):
    def test_four_order_physical_episode_preserves_shared_adaptation(self):
        protocol=read_json(PROTOCOL)
        case=dict(case='resource-chain-synthetic',close_at=30,initial={'1':4},tasks=[
            dict(id=i,sku=1,kind=kind,release=release,source_dock=1)
            for i,(kind,release) in enumerate([
                ('retrieval',0),('delivery',4),('retrieval',12),('delivery',20)])])
        row,trajectory=execute_resource(case,protocol)
        self.assertTrue(trajectory['valid'])
        audit_adaptation(row)
        self.assertEqual(row['budget'],dict(proxy=192,generations=16,previews=6))
        self.assertEqual(len(row['resource_seed_log']),len(row['ga_searches']))
        self.assertTrue(row['ga_searches'])
        self.assertAlmostEqual(sum(row['physics']['weighted_terms'].values()),row['F'])
        for item in row['resource_seed_log']:
            if item['injected']:
                self.assertEqual(item['extra_proxy_evaluations'],0)
                self.assertEqual(item['extra_physical_previews'],0)
                self.assertFalse(item['uses_unpublished'])


if __name__=='__main__':
    unittest.main()
