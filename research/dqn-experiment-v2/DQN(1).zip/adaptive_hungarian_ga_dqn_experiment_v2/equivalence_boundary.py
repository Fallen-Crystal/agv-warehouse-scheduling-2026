"""Identify threshold candidates with identical full development trajectories."""
import hashlib
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'boundary_results'


def main():
    protocol=json.loads((ROOT/'boundary_protocol.json').read_text(encoding='utf-8'))
    candidates=['t05','t1','t15','t2','t3']
    groups={}
    signatures={}
    for arm in candidates:
        sig=[]
        for case in protocol['development']:
            for seed in protocol['development_seeds']:
                trial=json.loads((OUT/'development'/f'{case}__{arm}__s{seed}.json').read_text(encoding='utf-8'))
                assert trial['row']['valid']
                physical={k:v for k,v in trial['result'].items() if k!='search_log'}
                sig.append(hashlib.sha256(json.dumps(physical,sort_keys=True).encode()).hexdigest())
        signatures[arm]=sig
        groups.setdefault(tuple(sig),[]).append(arm)
    payload=dict(groups=list(groups.values()),cases_per_arm=len(next(iter(signatures.values()))),
        criterion='All result fields except search_log identical for every paired development case/seed. CPU and gate instrumentation excluded.',
        scope='Observed development equivalence only; does not establish an interval of universal optimal thresholds.',signatures=signatures)
    (OUT/'threshold_equivalence.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Development physical equivalence groups:',payload['groups'])

if __name__=='__main__':
    main()
