"""搜索空间诊断的开发集隔离、预算接线和分项汇总回归测试。"""
import copy
import unittest

from paths import ROOT
from adaptive_hungarian_learning import execute
from adaptive_genetic import candidates
from improved.profiles import PROFILES
from objective import LinearObjective
from test_adaptive_genetic import FakeCosts
from run_search_headroom import (
    BUDGETS, PROTOCOL, read_json, select_cases, audit_budget,
    execute_diagnostic, summarize,
)


class HeadroomTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.protocol = read_json(PROTOCOL)

    def test_selection_only_uses_training_order_counts(self):
        selected = select_cases(self.protocol)
        self.assertEqual([c['source_day'] for c in selected], [66, 40, 38])
        self.assertEqual([len(c['tasks']) for c in selected], [78, 134, 205])
        self.assertTrue(all(c['case'] in self.protocol['development'] for c in selected))

    def test_test_cases_duplicates_and_date_overlap_are_rejected(self):
        with self.assertRaises(ValueError):
            select_cases(self.protocol, self.protocol['test'][:1])
        name = self.protocol['development'][0]
        with self.assertRaises(ValueError):
            select_cases(self.protocol, [name, name])
        protocol = copy.deepcopy(self.protocol)
        by_name = {c['case']: c for c in protocol['cases']}
        by_name[name]['source_day'] = by_name[protocol['test'][0]]['source_day']
        with self.assertRaises(ValueError):
            select_cases(protocol, [name])

    def test_extended_search_still_respects_adaptive_rates_and_budget(self):
        costs = FakeCosts(8)
        plans, metadata = candidates(costs, costs.ids, {j:j%4 for j in costs.ids},
            objective=LinearObjective(), budget=768, generations=64, seed=19,
            adaptive_mutation=True, adaptive_crossover=True)
        self.assertTrue(plans)
        self.assertLessEqual(metadata['proxy_evaluations'], 768)
        self.assertLessEqual(len(metadata['mutation_history']), 64)
        self.assertGreater(len(metadata['mutation_history']), 16)
        self.assertGreater(len({h['crossover_rate'] for h in metadata['mutation_history']}), 1)

    def test_summary_uses_paired_original_F_and_additive_component_changes(self):
        base = dict(case='x', seed=0, budget_name='baseline', F=2.0,
                    physics={'weighted_terms':dict(T=1.0,R=.6,D=.4)},
                    budget_audit={}, diagnostic_wall=10)
        extra = dict(base, budget_name='both4x', F=1.9, diagnostic_wall=30,
                     physics={'weighted_terms':dict(T=1.0,R=.5,D=.4)})
        output = summarize([base, extra])
        self.assertAlmostEqual(output['pairs'][0]['improvement_pct'], 5.)
        self.assertAlmostEqual(output['pairs'][0]['weighted_component_reduction']['R'], .1)
        self.assertEqual(output['pairs'][0]['wall_ratio'], 3)
        bad = dict(extra, F=1.8)
        with self.assertRaises(ValueError):
            summarize([base, bad])

    def test_budget_audit_rejects_unaccounted_preview(self):
        row = dict(valid=True,F=1.,reward_sum=-1.,actions={'ga':1},ga_searches=[])
        logs = [dict(previews=7,proxy_evaluations=0,changed=False)]
        with self.assertRaises(ValueError):
            audit_budget(row, logs, BUDGETS['baseline'])

    def test_baseline_wiring_matches_historical_adaptive_GA(self):
        # 仅使用训练源的四订单子集测试接线，不将其当成有效统计实验窗口。
        source = next(c for c in self.protocol['cases'] if c['case']==self.protocol['development'][0])
        case = dict(source, case='headroom-four-order-wiring-only', tasks=source['tasks'][:4])
        settings_before = copy.deepcopy(PROFILES)
        baseline = execute(case, self.protocol, strategy='ga', seed=0)
        diagnostic, trajectory = execute_diagnostic(case, self.protocol, 'baseline', seed=0)
        for key in ('F','T','R','D','ga_searches','actions'):
            self.assertEqual(baseline[key], diagnostic[key], key)
        self.assertEqual(PROFILES, settings_before)
        self.assertTrue(trajectory['valid'])
        self.assertEqual(diagnostic['ga_adaptation']['proxy_budget'], 192)
        self.assertAlmostEqual(sum(diagnostic['physics']['weighted_terms'].values()), diagnostic['F'])
        # 相同物理执行和GA，只有预览上限改变；元数据不能继续误标6次。
        extended, _ = execute_diagnostic(case, self.protocol, 'preview4x', seed=0)
        self.assertEqual(extended['ga_adaptation']['previews'], 24)
        self.assertFalse(extended['same_budget_control'])
        self.assertEqual(PROFILES, settings_before)


if __name__ == '__main__':
    unittest.main()
