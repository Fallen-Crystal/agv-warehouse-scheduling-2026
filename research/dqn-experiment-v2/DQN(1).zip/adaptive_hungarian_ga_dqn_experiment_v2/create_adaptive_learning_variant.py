"""一次性建立独立双概率自适应版本；已有文件只允许内容完全相同，不覆盖历史。"""
import json
from paths import ROOT,sha
from adaptive_hungarian_learning import ADAPTATION


def create(name,text):
    path=ROOT/name
    if path.exists():
        assert path.read_text(encoding='utf-8')==text,f'Refuse overwrite: {name}'
    else: path.write_text(text,encoding='utf-8')


def replace(text,old,new):
    assert old in text,old
    return text.replace(old,new)


def main():
    original=ROOT/'data/hungarian_learning_protocol.json'
    protocol=json.loads(original.read_text(encoding='utf-8'))
    protocol.update(version='hungarian-learning-adaptive-v2',ga_adaptation=ADAPTATION,
        action_definition=['hungarian_f_surrogate','joint_adaptive_ga'],parent_protocol_sha256=sha(original),
        revision_reason='User explicitly requires adaptive mutation AND crossover. Same input dates and search budgets; new model/replay from scratch.')
    create('data/adaptive_hungarian_learning_protocol.json',json.dumps(protocol,ensure_ascii=False,indent=2)+'\n')
    runner=(ROOT/'run_hungarian_learning.py').read_text(encoding='utf-8')
    runner=replace(runner,'from hungarian_learning import MultiStepAgent,execute','from adaptive_hungarian_learning import MultiStepAgent,execute,ADAPTATION,audit_adaptation')
    runner=replace(runner,"results/hungarian_learning_v1","results/adaptive_hungarian_learning_v2")
    runner=replace(runner,'data/hungarian_learning_protocol.json','data/adaptive_hungarian_learning_protocol.json')
    runner=replace(runner,"'run_hungarian_learning.py'","'run_adaptive_hungarian_learning.py','adaptive_hungarian_learning.py','adaptive_genetic.py','create_adaptive_learning_variant.py'")
    runner=replace(runner,"('transitions','losses')","('transitions','losses','ga_searches')")
    runner=replace(runner,'def audit(row,case):\n','def audit(row,case):\n    audit_adaptation(row)\n')
    runner=replace(runner,"    cases={c['case']:c for c in protocol['cases']}","    assert protocol['ga_adaptation']==ADAPTATION\n    cases={c['case']:c for c in protocol['cases']}")
    runner=replace(runner,"        # 旧GA基线完全相同的日期/代码/物理seed，审计后复用，避免重复昂贵模拟。\n        from summarize_dqn_broad import analyze\n        assert analyze()['complete']", "        # GA算子已变，必须重新运行GA；精准/匈牙利不调用GA，复用已审计的相同对照。\n        old_manifest=read(ROOT/'results/hungarian_learning_v1/manifest.json')\n        assert all(sha(ROOT/p)==digest for p,digest in old_manifest['hashes'].items())")
    runner=replace(runner,"                if strategy=='ga':\n                    source=ROOT/f'results/dqn_broad_v1/eval_{index:02d}_fixed_ga.json'\n                    row=read(source)\n                    row.update(reused_from=source.relative_to(ROOT).as_posix(),reused_sha256=sha(source))", "                if strategy in ('exact','hungarian'):\n                    source=ROOT/f'results/hungarian_learning_v1/validation_control_{index:02d}_{strategy}.json'\n                    row=read(source)\n                    assert row['strategy']==strategy and row['seed']==0\n                    row.update(reused_from=source.relative_to(ROOT).as_posix(),reused_sha256=sha(source),ga_adaptation=ADAPTATION,ga_searches=[])")
    create('run_adaptive_hungarian_learning.py',runner)
    auditor=(ROOT/'audit_hungarian_learning.py').read_text(encoding='utf-8')
    auditor=replace(auditor,'from run_hungarian_learning import','from run_adaptive_hungarian_learning import')
    auditor=replace(auditor,'from hungarian_learning import','from adaptive_hungarian_learning import')
    auditor=replace(auditor,'data/hungarian_learning_protocol.json','data/adaptive_hungarian_learning_protocol.json')
    auditor=replace(auditor,"                if strategy=='ga':\n                    assert control['reused_sha256']==sha(ROOT/control['reused_from'])", "                if strategy in ('exact','hungarian'):\n                    assert control['reused_sha256']==sha(ROOT/control['reused_from'])\n                else: assert 'reused_from' not in control")
    create('audit_adaptive_hungarian_learning.py',auditor)
    for old,new in (('predict_hungarian_dqn.py','predict_adaptive_hungarian_dqn.py'),
        ('report_hungarian_learning.py','report_adaptive_hungarian_learning.py'),
        ('diagnose_hungarian_learning.py','diagnose_adaptive_hungarian_learning.py')):
        text=(ROOT/old).read_text(encoding='utf-8')
        text=text.replace('from hungarian_learning import','from adaptive_hungarian_learning import')
        text=text.replace('from run_hungarian_learning import','from run_adaptive_hungarian_learning import')
        text=text.replace('from audit_hungarian_learning import','from audit_adaptive_hungarian_learning import')
        text=text.replace('data/hungarian_learning_protocol.json','data/adaptive_hungarian_learning_protocol.json')
        text=text.replace('audit_hungarian_learning.py','audit_adaptive_hungarian_learning.py')
        text=text.replace("'joint_ga'","'joint_adaptive_ga'")
        text=text.replace("'纯GA'","'纯自适应GA'")
        text=text.replace('匈牙利DQN重训练结果.md','匈牙利自适应GA-DQN重训练结果.md')
        text=text.replace('动作1为原joint GA','动作1为双概率自适应joint GA')
        text=text.replace('纯GA沿用相同计划缓存','DQN与纯GA共用同一双概率自适应算子及相同计划缓存')
        create(new,text)
    print('Created separate adaptive protocol, runner, auditor and delivery utilities. Test not opened.',flush=True)

if __name__=='__main__': main()
