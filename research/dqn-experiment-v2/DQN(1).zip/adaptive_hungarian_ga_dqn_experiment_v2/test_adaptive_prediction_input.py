"""新订单库存键和JSON结构检查；只测输入边界，不加载未完成模型。"""
import copy
import unittest
from paths import ROOT
from predict_adaptive_hungarian_dqn import validate_case
from run_adaptive_hungarian_learning import read


class PredictionInputTests(unittest.TestCase):
    def setUp(self): self.case=read(ROOT/'data/hungarian_prediction_example.json')

    def test_existing_example_accepted_without_mutation(self):
        original=copy.deepcopy(self.case)
        result=validate_case(self.case)
        self.assertEqual(result['orders'],2)
        self.assertTrue(result['outside_training_input_range'])
        self.assertEqual(self.case,original)

    def test_alias_keys_cannot_silently_replace_stock(self):
        sku=next(iter(self.case['initial']))
        self.case['initial']['0'+sku]=999
        with self.assertRaisesRegex(ValueError,'collide'): validate_case(self.case)

    def test_stock_counts_and_keys_are_not_coerced(self):
        for initial in ({'101':True},{'101':1.5},{'101':-1},{1.5:1},{True:1},{'SKU101':1}):
            with self.subTest(initial=initial):
                self.case['initial']=initial
                with self.assertRaises(ValueError): validate_case(self.case)

    def test_bad_structures_have_explicit_input_errors(self):
        for value in (None,[],0):
            with self.subTest(value=value):
                with self.assertRaisesRegex(ValueError,'JSON object'): validate_case(value)
        for field,value in (('initial',[]),('initial',{}),('tasks',{}),('tasks',[]),('tasks',[None]),('tasks',[{}])):
            with self.subTest(field=field,value=value):
                case=copy.deepcopy(self.case); case[field]=value
                with self.assertRaises(ValueError): validate_case(case)

    def test_close_boundary_and_inventory_prefix_remain_enforced(self):
        for mutate in (
            lambda c:c['tasks'][0].update(release=c['close_at']),
            lambda c:c['tasks'][0].update(kind='retrieval',sku=101),
            lambda c:c['tasks'][1].update(id=c['tasks'][0]['id'])):
            case=copy.deepcopy(self.case)
            # 合成例子初始101为1；设为0才会让首个retrieval前缀不合法。
            case['initial']['101']=0
            mutate(case)
            with self.assertRaises(ValueError): validate_case(case)


if __name__=='__main__': unittest.main()
