"""训练证据审计测试：能发现冻结评估意外学习及终局记账损坏。"""
import json
import unittest
from unittest.mock import patch
from pathlib import Path
from summarize_dqn import analyze


class EvidenceTests(unittest.TestCase):
    def fixture(self):
        row = dict(epoch=0,phase="monitor",case="case",T=900,R=0,D=0,F=.5,
                   reward_sum=-.5,transitions=[dict(done=True,action=0,reward=-.5)],
                   actions=dict(matching=1),train_steps=0,replay_size=0,losses=[],valid=True)
        manifest = dict(config=dict(rounds=0),train=[],monitor=["case"],limitation="test")
        return manifest,row

    def report(self,manifest,rows):
        def read(path,**kwargs):
            return json.dumps(manifest) if path.name=="manifest.json" else "\n".join(json.dumps(r) for r in rows)
        with patch.object(Path,"read_text",read):
            return analyze("unused")

    def test_complete_valid_evidence(self):
        manifest,row = self.fixture()
        result = self.report(manifest,[row])
        self.assertTrue(result["complete"])
        self.assertEqual(result["valid_count"],1)

    def test_enhanced_reward_components_and_initial_cost(self):
        manifest,row = self.fixture()
        row.update(initial_cost=.1,initial_cost_terms=dict(T=.1,R=0.,D=0.),
                   learning_reward_sum=-.4)
        row['transitions']=[dict(done=True,action=0,reward=-.4,
                                 reward_terms=dict(T=-.4,R=0.,D=0.),duration=10)]
        self.assertTrue(self.report(manifest,[row])['complete'])
        import copy
        for mutate in (
            lambda r:r.update(initial_cost=.2),
            lambda r:r.update(learning_reward_sum=-.3),
            lambda r:r['transitions'][0]['reward_terms'].update(D=.1),
            lambda r:r['transitions'][0].update(duration=-1),
        ):
            broken=copy.deepcopy(row)
            mutate(broken)
            with self.assertRaises(AssertionError):
                self.report(manifest,[broken])

    def test_requires_three_trained_epochs_for_plateau(self):
        manifest,row = self.fixture()
        manifest['config']['rounds'] = 3
        rows = [dict(row,epoch=e) for e in range(4)]
        result = self.report(manifest,rows)
        self.assertTrue(result['stability']['case']['engineering_plateau'])
        result = self.report(manifest,rows[:3])
        self.assertFalse(result['stability']['case']['engineering_plateau'])

    def test_rejects_learning_in_frozen_evaluation(self):
        manifest,row = self.fixture()
        row["train_steps"] = 1
        with self.assertRaisesRegex(AssertionError,"Monitor trained"):
            self.report(manifest,[row])

    def test_rejects_wrong_objective_reward_and_duplicate(self):
        for field in ("F","reward_sum"):
            manifest,row = self.fixture()
            row[field] += .1
            with self.assertRaises(AssertionError):
                self.report(manifest,[row])
        manifest,row = self.fixture()
        with self.assertRaisesRegex(AssertionError,"Duplicate"):
            self.report(manifest,[row,row])


if __name__ == "__main__":
    unittest.main()
