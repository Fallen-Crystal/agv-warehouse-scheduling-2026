"""只改变在线搜索的预览终端；实际执行与正式目标保持原定义。

已发布订单全部预览完成但流尚未关闭时，以安全稳定待命结束预测，
避免把未知后续订单前的“最终回家”当成已确定未来。不是学习算法。
"""
from unittest.mock import patch
import paths
from improved.profiles import PROFILES
from run_search_headroom import execute_diagnostic
from adaptive_hungarian_learning import audit_adaptation


def execute_open_boundary(case,protocol,seed=0):
    settings=dict(PROFILES['rl'],terminal='standby')
    with patch.dict(PROFILES,{'rl':settings}):
        row,trajectory=execute_diagnostic(case,protocol,'baseline',seed)
    audit_adaptation(row)
    row.update(intervention='open_stream_standby_forecast',
        qualification='同预算预览边界消融；非正式F变更，真实执行仍最终回库；非学习结果')
    return row,trajectory
