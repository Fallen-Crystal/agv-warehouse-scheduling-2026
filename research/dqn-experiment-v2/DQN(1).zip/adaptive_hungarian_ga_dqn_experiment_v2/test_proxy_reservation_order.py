"""锁预留的最小反例：用于明确代理语义，不能当完整物理性能证据。"""
import unittest
from types import SimpleNamespace
import paths
from improved.proxy import MixedCosts


class StubCosts(MixedCosts):
    def __init__(self):
        active=dict(task=9,release=0,end=100,drop=(0,0))
        self.world=SimpleNamespace(time=0,tasks={9:dict(release=0)},records=[active],
            plans=[[(0,0)],[(0,0)]],active=[active,None],past_moves=0,locks={},
            scene=SimpleNamespace(homes=[(0,0),(0,0)]),
            router=SimpleNamespace(distance=lambda a,b,k:0),observed_closed=True)
        self.jobs={j:dict(id=j,kind='retrieval',release=0) for j in (0,1)}
        self.slots={j:dict(bay=0) for j in (0,1)}
        self.predecessor={}
        self.cache={}

    def details(self,k,position,job):
        # 每任务耗时10；无空载路程、bay在2秒取货服务结束后解锁。
        self.cache[k,tuple(position),job['id']]=(7,0,(0,0),(0,0),2,1)
        return 7,0,(0,0)


class ProxyReservationTests(unittest.TestCase):
    def test_order_reserves_future_bay_before_current_idle_vehicle(self):
        costs=StubCosts()
        forward,_=costs._schedule([0,1],{0:0,1:1})
        reversed_,_=costs._schedule([1,0],{0:0,1:1})
        # 顺序列表预留A(100..110)、bay锁至102，B被推迟到102..112。
        self.assertEqual(forward[0],112)
        # B先做0..10，随后A100..110，最后任务110。
        self.assertEqual(reversed_[0],110)
        self.assertGreater(forward[1],reversed_[1])
        # 这只证明代理的顺序相关性；实际无冲突可行性仍须物理预览验证。


if __name__=='__main__':
    unittest.main()
