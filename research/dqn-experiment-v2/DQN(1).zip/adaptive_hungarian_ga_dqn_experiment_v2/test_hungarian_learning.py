"""验证多步回报、终局屏蔽、检查点续训及新动作桥接；不访问测试日期。"""
import json
import unittest
import numpy as np
from paths import ROOT
from hungarian_learning import MultiStepAgent,execute

class LearningTests(unittest.TestCase):
    def test_multistep_terminal_and_resume(self):
        agent=MultiStepAgent(seed=7,state_dim=32,hidden=8,capacity=64,warmup=8,batch_size=8,double_dqn=True,output_scale=.01)
        for i in range(7):
            agent.remember(np.full(32,i/10),i%2,-float(i+1),np.full(32,(i+1)/10),i==6)
        np.testing.assert_allclose(agent.replay.rewards[:7],[-15,-20,-25,-22,-18,-13,-7])
        np.testing.assert_array_equal(agent.replay.dones[:7],[False,False,True,True,True,True,True])
        self.assertFalse(agent.pending)
        np.testing.assert_allclose(agent._bellman_targets(np.array([-7.]),np.zeros((1,32)),np.array([True])),[-7.])
        folder=ROOT/'results/hungarian_learning_checks'
        folder.mkdir(parents=True,exist_ok=True)
        checkpoint=folder/'resume.npz'
        agent.save(checkpoint)
        restored=MultiStepAgent.load(checkpoint)
        for candidate in (agent,restored):
            candidate.remember(np.zeros(32),0,-.1,np.zeros(32),True)
        self.assertEqual(agent.learn(),restored.learn())
        for key in agent._PARAMETERS: np.testing.assert_array_equal(agent.online[key],restored.online[key])
        self.assertEqual(agent.rng.bit_generator.state,restored.rng.bit_generator.state)

    def test_physical_adapter_and_frozen_inference(self):
        protocol=json.loads((ROOT/'data/dqn_broad_protocol.json').read_text(encoding='utf-8'))
        # 只在已用训练日期的4条订单上做桥接冒烟检查，不作为实验成绩。
        source=protocol['cases'][0]
        case=dict(source,case='synthetic-adapter-smoke',tasks=source['tasks'][:4])
        agent=MultiStepAgent(seed=0,state_dim=32,hidden=8,capacity=64,warmup=8,batch_size=8,double_dqn=True,output_scale=.01)
        row=execute(case,protocol,agent,training=True)
        self.assertAlmostEqual(row['reward_sum'],-row['F'])
        self.assertEqual(agent.replay_size,len(row['transitions']))
        self.assertFalse(agent.pending)
        frozen=execute(case,protocol,agent)
        self.assertTrue(frozen['frozen_state_verified'])
        self.assertEqual(frozen['observation_schema'],'published-hour-v3-32')
        self.assertTrue(set(frozen['actions'])<= {'hungarian','ga'})

if __name__=='__main__': unittest.main()
