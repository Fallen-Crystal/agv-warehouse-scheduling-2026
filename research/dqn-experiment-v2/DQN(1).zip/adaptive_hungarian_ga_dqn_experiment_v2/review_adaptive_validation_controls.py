"""复核四日期十二条验证对照，不运行仿真、不读取最终测试成绩。"""
from paths import ROOT,sha,verify_baseline
from run_adaptive_hungarian_learning import FOLDER,read,write,audit
from report_adaptive_hungarian_learning import summarize_adaptation
import json


def main():
    protocol=read(ROOT/'data/adaptive_hungarian_learning_protocol.json')
    manifest=read(FOLDER/'manifest.json')
    assert all(sha(ROOT/p)==digest for p,digest in manifest['hashes'].items())
    verify_baseline()
    cases={case['case']:case for case in protocol['cases']}
    rows=[]; ga=[]
    for index,name in enumerate(protocol['validation']):
        values={}
        for strategy in ('ga','exact','hungarian'):
            path=FOLDER/f'validation_control_{index:02d}_{strategy}.json'
            row=read(path); audit(row,cases[name])
            assert row['phase']=='validation_control' and row['strategy']==strategy and row['seed']==0
            if strategy=='ga':
                assert 'reused_from' not in row
                ga.append(row)
            else:
                assert sha(ROOT/row['reused_from'])==row['reused_sha256']
                source=read(ROOT/row['reused_from'])
                # 重用的匹配对照只允许添加新GA规则的元数据及来源，物理值/转移不能变化。
                assert all(row[key]==value for key,value in source.items())
            values[strategy]=row['F']
        rows.append(dict(case=name,day=cases[name]['source_day'],F=values))
    strategies=('ga','exact','hungarian')
    comparisons={candidate:{baseline:sum(row['F'][candidate]/row['F'][baseline] for row in rows)/len(rows)
        for baseline in strategies} for candidate in strategies}
    # 事后挑每个完整窗口最优策略仅作验证参照，不是可部署的DQN或性能上界证明。
    reference={baseline:100*sum(1-min(row['F'].values())/row['F'][baseline] for row in rows)/len(rows)
        for baseline in strategies}
    result=dict(phase='validation_controls_review',control_count=len(rows)*len(strategies),dates=rows,
        fixed_policy_mean_paired_ratios=comparisons,
        hindsight_whole_window_reference_mean_improvement_percent=reference,
        adaptation=summarize_adaptation(ga),
        interpretation='Validation controls only. Hindsight chooses one complete-window policy using known validation outcomes; it is not a deployed policy, DQN result, achievable bound, or unseen-test evidence.')
    write(FOLDER/'validation_controls_review.json',result)
    print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
    return result


if __name__=='__main__': main()
