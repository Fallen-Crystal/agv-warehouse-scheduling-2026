"""开发集搜索空间诊断：冻结F/物理，用2×2预算实验区分代理搜索和物理预览瓶颈。

超预算结果只是诊断参考，不是同预算算法胜出，也不是最优解或离线全知策略。
此脚本仅新增产物，不修改历史实现、模型或测试结果；正式测试日期禁止执行。
"""
import argparse
import copy
import gzip
import json
import math
import os
from pathlib import Path
import time
from unittest.mock import patch

from paths import ROOT, sha, verify_baseline
from adaptive_hungarian_learning import execute, ADAPTATION
from adaptive_genetic import adaptive_rates
from improved.profiles import PROFILES
import train_dqn

PROTOCOL = ROOT / 'data/adaptive_hungarian_learning_protocol.json'
HISTORICAL = ROOT / 'results/adaptive_hungarian_learning_v2/manifest.json'
BUDGETS = {
    'baseline': dict(proxy=192, generations=16, previews=6),
    'proxy4x': dict(proxy=768, generations=64, previews=6),
    'preview4x': dict(proxy=192, generations=16, previews=24),
    'both4x': dict(proxy=768, generations=64, previews=24),
}


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def commit(folder, name, value, *, compressed=False):
    """仅在已核对目录中原子提交；未完成单次仿真不会留下可误读的成功行。"""
    folder = Path(folder).resolve()
    target = (folder / name).resolve()
    temporary = target.with_name(target.name + '.tmp')
    if target.parent != folder or temporary.parent != folder:
        raise ValueError('Output escaped experiment directory')
    data = json.dumps(value, ensure_ascii=False, indent=None if compressed else 2,
                      allow_nan=False).encode('utf-8')
    if compressed:
        data = gzip.compress(data, mtime=0)
    temporary.write_bytes(data)
    # 两个绝对路径已核对均在同一专用实验目录；只替换该名称的实验产物。
    os.replace(temporary, target)
    return target


def select_cases(protocol, requested=None):
    """预先按训练订单数选择低/中/高三个窗口；不看任何策略成绩。"""
    cases = {c['case']: c for c in protocol['cases']}
    allowed = set(protocol['development']) | set(protocol['validation'])
    if requested is None:
        ordered = sorted(protocol['development'],
                         key=lambda n: (len(cases[n]['tasks']), n))
        requested = [ordered[i] for i in (0, len(ordered)//2, len(ordered)-1)]
    if not requested or len(requested) != len(set(requested)):
        raise ValueError('Empty or duplicate case selection')
    if not set(requested) <= allowed or set(requested) & set(protocol['test']):
        raise ValueError('Headroom diagnosis may only use development/validation dates')
    test_days = {cases[n]['source_day'] for n in protocol['test']}
    if any(cases[n]['source_day'] in test_days for n in requested):
        raise ValueError('Selected date overlaps a revealed formal test date')
    return [cases[n] for n in requested]


def frozen_identity():
    historical = read_json(HISTORICAL)
    for name, digest in historical['hashes'].items():
        if sha(ROOT / name) != digest:
            raise ValueError('Historical source drift: ' + name)
    count = verify_baseline()
    if count != historical['baseline_files']:
        raise ValueError('Baseline manifest changed')
    names = set(historical['hashes']) | {
        'run_search_headroom.py', 'headroom_physics.py',
        'data/adaptive_hungarian_learning_protocol.json',
    }
    return dict(baseline_files=count, hashes={n: sha(ROOT/n) for n in sorted(names)},
                historical_manifest_sha256=sha(HISTORICAL))


def audit_budget(row, logs, budget):
    """核对实际消耗而不只记录上限；预览包含每次搜索的锚点和缓存方案。"""
    if not row['valid'] or not math.isfinite(row['F']):
        raise ValueError('Invalid physical episode')
    if row.get('actions', {}).get('matching', 0):
        raise ValueError('Expected always-GA control')
    if abs(row['reward_sum'] + row['F']) > 1e-9:
        raise ValueError('Reward/physical objective mismatch')
    for search in row['ga_searches']:
        if not (0 <= search['proxy_evaluations'] <= budget['proxy'] and
                0 <= search['candidates'] <= budget['proxy']):
            raise ValueError('Proxy budget exceeded')
        history = search['mutation_history']
        if not history or len(history) > budget['generations']:
            raise ValueError('Generation budget exceeded')
        if not search['adaptive_mutation'] or not search['adaptive_crossover']:
            raise ValueError('Adaptive rates disabled')
        for i, h in enumerate(history):
            pm, pc = adaptive_rates(h['stagnant'], h['diversity'])
            if h['generation'] != i or abs(pm-h['mutation_rate']) > 1e-12 or abs(pc-h['crossover_rate']) > 1e-12:
                raise ValueError('Adaptive rate history mismatch')
    successful = [entry for entry in logs if 'previews' in entry]
    if len(successful) != len(row['ga_searches']):
        raise ValueError('Search accounting mismatch')
    for entry, search in zip(successful, row['ga_searches']):
        if not 1 <= entry['previews'] <= budget['previews']:
            raise ValueError('Physical preview budget exceeded')
        if entry['proxy_evaluations'] != search['proxy_evaluations']:
            raise ValueError('Proxy accounting mismatch')
    return dict(searches=len(successful), failed_anchors=len(logs)-len(successful),
                proxy_evaluations=sum(s['proxy_evaluations'] for s in successful),
                physical_previews=sum(s['previews'] for s in successful),
                improved_local_searches=sum(s['changed'] for s in successful),
                note='局部预览改善不等于最终整窗改善；失败锚点另外记录。')


def execute_diagnostic(case, protocol, budget_name, seed=0):
    """复用原纯自适应GA接线，仅覆盖预算；保留缓存、发布信息与适应率规则。"""
    from headroom_physics import analyze_physics
    budget = BUDGETS[budget_name]
    settings = dict(PROFILES['rl'], **budget)
    captured = {}
    original_run = train_dqn.run

    def capture(model, *args, **kwargs):
        result = original_run(model, *args, **kwargs)
        captured.update(model=model, result=result)
        return result

    started = time.perf_counter()
    # patch限定在单个进程/调用中，不写入历史配置；并发需使用独立进程。
    with patch.dict(PROFILES, {'rl': settings}), patch('train_dqn.run', capture):
        row = execute(case, protocol, strategy='ga', seed=seed)
    result = captured['result']
    objective = train_dqn.LinearObjective(**protocol['objective'])
    budget_audit = audit_budget(row, result['search_log'], budget)
    physics = analyze_physics(captured['model'], result, objective)
    # 历史适配器的元数据写死192/16/6，此处必须更正，不能给超预算误贴原预算标签。
    row['ga_adaptation'] = dict(ADAPTATION, proxy_budget=budget['proxy'],
                                generations=budget['generations'], previews=budget['previews'])
    row.update(version='search-headroom-v1', seed=seed, phase='development_diagnostic',
               source_day=case.get('source_day'), orders=len(case['tasks']),
               budget_name=budget_name, budget=copy.deepcopy(budget),
               same_budget_control=budget_name == 'baseline',
               budget_audit=budget_audit, physics=physics,
               diagnostic_wall=time.perf_counter()-started,
               qualification='超预算仅诊断；非同预算胜出、非最优性或未见测试证据')
    return row, result


def summarize(rows):
    pairs = []
    bases = {(r['case'], r['seed']): r for r in rows if r['budget_name']=='baseline'}
    for r in rows:
        base = bases.get((r['case'], r['seed']))
        if base is None or r['budget_name']=='baseline':
            continue
        # 使用原始正式F作分母；分项绝对收益相加必须等于F的绝对收益。
        delta = {k: base['physics']['weighted_terms'][k]-r['physics']['weighted_terms'][k]
                 for k in ('T','R','D')}
        if abs(sum(delta.values())-(base['F']-r['F'])) > 1e-9:
            raise ValueError('Component improvement does not sum to F improvement')
        pairs.append(dict(case=r['case'], seed=r['seed'], budget_name=r['budget_name'],
                          baseline_F=base['F'], diagnostic_F=r['F'],
                          improvement_pct=100*(1-r['F']/base['F']),
                          weighted_component_reduction=delta,
                          baseline_cost=base['budget_audit'], diagnostic_cost=r['budget_audit'],
                          wall_ratio=r['diagnostic_wall']/base['diagnostic_wall']))
    grouped = {}
    for name in BUDGETS:
        selected = [p for p in pairs if p['budget_name']==name]
        if selected:
            grouped[name] = dict(n=len(selected),
                mean_paired_improvement_pct=sum(p['improvement_pct'] for p in selected)/len(selected),
                wins=sum(p['improvement_pct']>1e-9 for p in selected),
                ties=sum(abs(p['improvement_pct'])<=1e-9 for p in selected),
                losses=sum(p['improvement_pct']< -1e-9 for p in selected))
    return dict(completed_runs=len(rows), pairs=pairs, aggregate=grouped,
                qualification='仅开发集诊断；更大搜索不保证逐窗单调改善；下界间隙不是可实现收益')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', default='results/search_headroom_v1')
    parser.add_argument('--cases', help='逗号分隔，仅允许训练/验证；默认训练订单数低/中/高')
    parser.add_argument('--seeds', default='0')
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--max-runs', type=int, help='本次最多完成多少个新窗口；随后可原样续跑')
    args = parser.parse_args()
    if args.max_runs is not None and args.max_runs < 1:
        parser.error('--max-runs must be positive')
    seeds = [int(s) for s in args.seeds.split(',')]
    if len(seeds) != len(set(seeds)) or any(s < 0 for s in seeds):
        parser.error('Seeds must be distinct nonnegative integers')
    protocol = read_json(PROTOCOL)
    cases = select_cases(protocol, args.cases.split(',') if args.cases else None)
    identity = frozen_identity()
    folder = Path(args.output_dir).resolve()
    # 限制新产物在results直属的新目录，拒绝覆盖任何历史结果目录。
    if folder.parent != (ROOT/'results').resolve() or folder.name == 'adaptive_hungarian_learning_v2':
        parser.error('Use a dedicated new direct child of results/')
    schedule = [(c, seed, name) for c in cases for seed in seeds for name in BUDGETS]
    manifest = dict(version='search-headroom-v1', **identity, seeds=seeds,
                    cases=[dict(case=c['case'], source_day=c['source_day'], orders=len(c['tasks'])) for c in cases],
                    budgets=BUDGETS, protocol_sha256=sha(PROTOCOL),
                    selection='training order-count min/upper-median/max' if not args.cases else 'explicit development cases',
                    blocked_test_cases=protocol['test'],
                    planned_runs=len(schedule), future_orders_visible_to_policy=False,
                    qualification='冻结开发诊断；超预算只查空间，不作同预算最终成绩')
    if args.resume:
        if read_json(folder/'manifest.json') != manifest:
            raise ValueError('Resume source/protocol/config mismatch')
    else:
        folder.mkdir(parents=True, exist_ok=False)
        commit(folder, 'manifest.json', manifest)
    rows = []
    new_runs = 0
    for index, (case, seed, name) in enumerate(schedule):
        filename = f'episode_{index:03d}.json'
        path = folder / filename
        if path.exists():
            row = read_json(path)
            if (row['case'], row['seed'], row['budget_name']) != (case['case'], seed, name):
                raise ValueError('Committed row does not match frozen schedule')
            if sha(folder/row['trajectory_file']) != row['trajectory_sha256']:
                raise ValueError('Committed trajectory changed')
            rows.append(row)
            continue
        if args.max_runs is not None and new_runs >= args.max_runs:
            break
        print(json.dumps(dict(event='start', index=index, case=case['case'], seed=seed, budget=name)), flush=True)
        row, trajectory = execute_diagnostic(case, protocol, name, seed)
        trajectory_name = f'trajectory_{index:03d}.json.gz'
        raw_path = commit(folder, trajectory_name, trajectory, compressed=True)
        row.update(trajectory_file=trajectory_name, trajectory_sha256=sha(raw_path))
        commit(folder, filename, row)
        rows.append(row)
        new_runs += 1
        commit(folder, 'summary.json', dict(summarize(rows), complete=len(rows)==len(schedule)))
        print(json.dumps(dict(event='complete', index=index, case=case['case'], budget=name,
                              F=row['F'], wall=row['diagnostic_wall'], cost=row['budget_audit']), ensure_ascii=False), flush=True)
    if frozen_identity() != identity:
        raise ValueError('Source changed during execution')
    summary = dict(summarize(rows), complete=len(rows)==len(schedule), planned_runs=len(schedule))
    commit(folder, 'summary.json', summary)
    print(json.dumps(summary, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
