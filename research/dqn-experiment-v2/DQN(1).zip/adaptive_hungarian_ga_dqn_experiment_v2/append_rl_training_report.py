"""Append persistent RL training results to the existing Word report."""
import json
from pathlib import Path
from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor

ROOT = Path(__file__).resolve().parent
DOC = ROOT / "AGV仓库建模与调度算法说明.docx"
data = json.loads((ROOT / "rl_training_round3.json").read_text(encoding="utf-8"))
validation = data["validation"]

def font(run, size=9.5, bold=False, color=None):
    run.font.name = "Microsoft YaHei"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    run.font.size = Pt(size)
    run.bold = bold
    if color:
        run.font.color.rgb = RGBColor(*color)

def para(doc, text, style="Normal"):
    p = doc.add_paragraph(style=style)
    p.paragraph_format.space_after = Pt(5)
    r = p.add_run(text)
    font(r)
    return p

doc = Document(DOC)
doc.add_heading("十三、持续训练后的RL实验", level=1)
para(doc, "在上一版单窗口在线更新的基础上，本轮新增跨窗口持续训练入口train_rl.py。训练阶段共享同一个ContextualSelector，按开发窗口顺序重复运行；每个完整窗口结束后，根据实际执行得到的F、D和traffic_wait更新动作权重。训练结束后关闭学习和epsilon探索，再在4个独立冻结验证窗口上运行。")
para(doc, "训练奖励为：")
code = doc.add_paragraph(style="No Spacing")
code.paragraph_format.left_indent = Pt(20)
r = code.add_run("r_episode = -(F + 0.00001×D + 0.0005×traffic_wait)")
font(r, size=9)
para(doc, "这种设计让训练方向与正式目标F保持一致，同时对空驶距离和交通等待增加小幅惩罚。验证阶段不再更新权重，epsilon设为0，因此验证结果是冻结策略的确定性回放。")

table = doc.add_table(rows=1, cols=8)
table.alignment = WD_TABLE_ALIGNMENT.CENTER
table.style = "Table Grid"
headers = ["验证窗口", "有效", "F", "T", "R", "D", "等待", "任务数"]
for i, h in enumerate(headers):
    r = table.rows[0].cells[i].paragraphs[0].add_run(h)
    font(r, bold=True)
for row in validation:
    vals = [row["case"], str(row["valid"]), f'{row["F"]:.6f}', row["T"], f'{row["R"]:.3f}', row["D"], row["traffic_wait"], row["tasks"]]
    cells = table.add_row().cells
    for i, val in enumerate(vals):
        r = cells[i].paragraphs[0].add_run(str(val))
        font(r)

para(doc, "与原单窗口RL结果相比，3轮持续训练后的F变化为：day40从0.874974降至0.848886，day61从1.074238降至1.062907，day83从0.828911升至0.834767，day87从0.867830升至0.867935。4个窗口全部有效，平均F由0.911488降至0.903624，约下降0.86%。")
para(doc, "day40上，3轮训练后的RL结果F=0.848886，略优于同窗口固定seeded联合GA的F=0.852476；但当前验证窗口数量和训练种子仍然有限，不能据此宣称RL在所有负载下普遍优于联合GA。正式结论仍应扩展到多个训练种子，并报告均值、标准差和置信区间。")
para(doc, "复现命令：")
for cmd in [
    "python -B train_rl.py --rounds 3 --seed 0 --output rl_training_round3.json",
    "python -B -m unittest test_adaptive test_hungarian test_variants test_boundary test_threshold_policy",
]:
    p = doc.add_paragraph(style="No Spacing")
    p.paragraph_format.left_indent = Pt(20)
    r = p.add_run(cmd)
    font(r, size=9, color=(40, 40, 40))

doc.save(DOC)
print(DOC)
