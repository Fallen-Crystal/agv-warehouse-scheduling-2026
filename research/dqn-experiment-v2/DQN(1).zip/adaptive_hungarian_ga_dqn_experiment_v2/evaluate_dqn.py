"""加载已保存DQN检查点，在冻结订单窗口独立复验，不训练。"""
import argparse
import json
from pathlib import Path
import numpy as np

from paths import ROOT, verify_baseline, sha
from dqn_agent import DQNAgent
from train_dqn import execute


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint",required=True)
    parser.add_argument("--seed",type=int,default=0)
    parser.add_argument("--cases",default="")
    parser.add_argument("--output",required=True)
    args = parser.parse_args()
    verify_baseline()
    target = Path(args.output)
    if target.exists():
        raise FileExistsError(target)
    agent = DQNAgent.load(args.checkpoint)
    protocol = json.loads((ROOT/"data/protocol.json").read_text(encoding="utf-8"))
    names = args.cases.split(",") if args.cases else protocol["validation"]
    cases = {c["case"]:c for c in protocol["cases"]}
    if len(set(names))!=len(names) or any(name not in cases for name in names):
        parser.error("Cases must be unique known frozen windows")
    # 深度核对冻结评估未改权重、随机数、经验池、优化器或训练计数。
    import copy
    before = copy.deepcopy(agent)
    rows = []
    for name in names:
        row = execute(cases[name],protocol,agent,args.seed,False)
        rows.append(row)
        print(json.dumps({k:v for k,v in row.items() if k not in ("transitions","losses")}),flush=True)
    assert agent.rng.bit_generator.state==before.rng.bit_generator.state
    assert agent.train_steps==before.train_steps and agent.replay_size==before.replay_size
    for group in ("online","target","adam_m","adam_v"):
        for key in agent._PARAMETERS:
            np.testing.assert_array_equal(getattr(agent,group)[key],getattr(before,group)[key])
    for key in ("states","next_states","actions","rewards","dones"):
        np.testing.assert_array_equal(getattr(agent.replay,key),getattr(before.replay,key))
    result = dict(checkpoint=str(args.checkpoint),checkpoint_sha256=sha(Path(args.checkpoint)),
                  seed=args.seed,rows=rows,frozen_state_verified=True,
                  qualification="historically used windows; descriptive evaluation only")
    target.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")


if __name__ == "__main__":
    main()
