"""稳定训练版选择器；保留历史 ContextualSelector 以便旧实验复现。"""
import json
import math
from pathlib import Path

from rl_scheduler import ContextualSelector


class StableSelector(ContextualSelector):
    """用正式 -F 做终局回报，逐动作批量归一化更新。

    同一窗口的相同终局标签不是独立样本；因此先平均梯度，再更新一次，
    避免订单多、决策多的窗口被隐式重复加权。此处不声称解决信用分配问题。
    """

    VERSION = "normalized-terminal-f-v1"

    def __init__(self, seed=0, *, epsilon=0.15, learning_rate=0.15,
                 discount=0.0, train_enabled=True):
        super().__init__(seed, epsilon=epsilon, learning_rate=learning_rate,
                         discount=discount, train_enabled=train_enabled)
        self.episodes = 0
        self.last_update = {}

    def finish_episode(self, *, objective, distance=0.0, traffic_wait=0.0):
        # 只使用冻结的正式目标；D 已包含在 F 内，不额外重复惩罚。
        if not math.isfinite(objective) or objective < 0:
            raise ValueError("Objective must be finite and nonnegative")
        actions = self.episode_actions
        self.episode_actions = []
        self.pending = None
        if not self.train_enabled:
            return 0
        reward = -float(objective)
        before = {key: list(value) for key, value in self.weights.items()}
        for action in self.ACTIONS:
            samples = [(state, event) for state, name, event in actions if name == action]
            if not samples:
                continue
            gradient = [0.0] * 5
            for state, event in samples:
                vector = state.vector()
                error = reward - sum(w * x for w, x in zip(before[action], vector))
                # 特征范数归一化使大压力状态不产生更大的有效步长。
                scale = max(1.0, sum(x * x for x in vector))
                for index, feature in enumerate(vector):
                    gradient[index] += error * feature / scale / len(samples)
                event.update(reward=reward, td_error=error)
            for index, value in enumerate(gradient):
                self.weights[action][index] += self.learning_rate * value
        self.episodes += 1
        self.last_update = dict(
            reward=reward, episodes=self.episodes,
            max_weight_delta=max(abs(self.weights[a][i] - before[a][i])
                                 for a in self.ACTIONS for i in range(5)))
        return sum(name in self.ACTIONS for _, name, _ in actions)

    def update(self, reward, next_state=None):
        # 实验只允许在完整且通过检查的窗口结束后进行批量更新。
        raise RuntimeError("StableSelector uses validated terminal updates only")

    def save(self, path, *, metadata=None):
        """同时保存随机数状态，恢复后探索序列也可重放。"""
        data = dict(version=self.VERSION, weights=self.weights, episodes=self.episodes,
                    epsilon=self.epsilon, learning_rate=self.learning_rate,
                    train_enabled=self.train_enabled, rng_state=self.rng.getstate(),
                    metadata=metadata or {})
        Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path):
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        if data["version"] != cls.VERSION:
            raise ValueError("Checkpoint version mismatch")
        weights = data["weights"]
        if set(weights) != set(cls.ACTIONS) or any(
            len(v) != 5 or not all(math.isfinite(x) for x in v) for v in weights.values()
        ):
            raise ValueError("Invalid weights")
        obj = cls(epsilon=data["epsilon"], learning_rate=data["learning_rate"],
                  train_enabled=data["train_enabled"])
        obj.weights = weights
        obj.episodes = data["episodes"]
        def tuples(value):
            return tuple(tuples(x) for x in value) if isinstance(value, list) else value
        obj.rng.setstate(tuples(data["rng_state"]))
        return obj
