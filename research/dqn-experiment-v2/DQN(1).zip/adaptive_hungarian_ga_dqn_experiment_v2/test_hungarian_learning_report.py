"""在内存中验证报告发布门槛和平均改善/逐日期改善的区别，不生成实验结果。"""
import copy
import unittest
from unittest.mock import patch
import report_hungarian_learning as report

class ReportTests(unittest.TestCase):
    def test_incomplete_does_not_publish(self):
        with patch.object(report,'write') as write,patch.object(report.ROOT.__class__,'write_text') as text:
            self.assertFalse(report.publish(dict(complete=False)))
            write.assert_not_called(); text.assert_not_called()

    def test_mean_improvement_does_not_claim_all_dates(self):
        fixture=dict(complete=True,fit_complete=True,training_windows=60,training_decisions=8000,train_steps=31000,
            selection=dict(epoch=2),validation_epochs=[dict(epoch=2,mean_ratios=dict(ga=.99,exact=.99,hungarian=.99))],
            mean_paired_improvement_percent=dict(ga=.4,exact=.4,hungarian=.4),test=[])
        for index in range(5):
            fixture['test'].append(dict(day=200+index,case=f'fixture-{index}',minutes=30,orders=40,
                F=dict(dqn=1.,ga=1.01,exact=1.01,hungarian=1.01),actions=dict(hungarian=40),
                improvement_percent={key:(-1. if index==0 else .75) for key in report.LABELS}))
        with patch.object(report,'read',return_value=dict(learning=dict(epochs=6))),patch.object(report,'sha',return_value='fixture-only'),\
             patch.object(report,'write') as write,patch.object(report.ROOT.__class__,'exists',return_value=False),\
             patch.object(report.ROOT.__class__,'write_text') as text:
            self.assertTrue(report.publish(fixture))
            aggregate=write.call_args.args[1]
            self.assertTrue(aggregate['average_goal_achieved'])
            self.assertFalse(aggregate['all_date_pairs_improved'])
            self.assertEqual(aggregate['paired_counts']['ga'],dict(better=4,equal=0,worse=1))
            csv=[call.args[0] for call in text.call_args_list if call.args[0].startswith('day,')][0]
            self.assertIn('-1.0',csv)
            fixture['mean_paired_improvement_percent']['hungarian']=-.1
            self.assertTrue(report.publish(fixture))
            self.assertFalse(write.call_args.args[1]['average_goal_achieved'])

if __name__=='__main__': unittest.main()
