"""只按原始输入规则枚举日期资格；不执行策略，不读取策略成绩。"""
import json
from prepare_hungarian_learning import scan
from paths import ROOT, sha


def main():
    protocol=json.loads((ROOT/'data/adaptive_hungarian_learning_protocol.json').read_text(encoding='utf-8'))
    original=json.loads((ROOT/'data/input-selection.json').read_text(encoding='utf-8'))
    broad=json.loads((ROOT/'data/dqn_broad_protocol.json').read_text(encoding='utf-8'))
    previously_used=set(original['prior_used_days']) | {c['source_day'] for c in broad['cases']}
    revealed_test={c['source_day'] for c in protocol['cases'] if c['case'] in protocol['test']}
    eligible=scan(3600)+scan(1800)
    days={c['source_day'] for c in eligible}
    fresh_before=days-previously_used
    fresh_now=fresh_before-revealed_test
    result=dict(rule='Original scan, 1800/3600 seconds, 40..240 complete orders, both kinds, 1..5 SKUs, initial<=900, all prefixes within initial+50',
        prior_used_days=sorted(previously_used), revealed_test_days=sorted(revealed_test),
        eligible_days=sorted(days), eligible_windows=len(eligible),
        eligible_fresh_before_test=sorted(fresh_before), eligible_fresh_now=sorted(fresh_now),
        original_assertion_reproduced=fresh_before=={5,19,53,55,76},
        sources={n:sha(ROOT/n) for n in ('prepare_hungarian_learning.py','freeze_hungarian_learning.py',
            'data/input-selection.json','data/dqn_broad_protocol.json',
            'deliverables/wepa_real_data/raw/2_orders.json','deliverables/wepa_real_data/raw/3_initial_fill_lvl.json')},
        caveat='Absence of eligible unused dates is conditional on the recorded used-day history and original input filter; new seeds/windows on reused dates are not independent fresh-date evidence.')
    destination=ROOT/'results/search_headroom_v1/date_eligibility_audit.json'
    with destination.open('x',encoding='utf-8') as stream:
        json.dump(result,stream,ensure_ascii=False,indent=2)
    print(json.dumps(result,ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
