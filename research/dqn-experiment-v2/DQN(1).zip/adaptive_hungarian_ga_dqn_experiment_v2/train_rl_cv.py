"""Cross-window, multi-seed RL training and stability evaluation."""
import argparse
import json
import statistics
from pathlib import Path

from paths import ROOT, verify_baseline
from rl_scheduler import ContextualSelector
from train_rl import DEFAULT_DEV, DEFAULT_VAL, execute_case

ALL_CASES = DEFAULT_DEV + DEFAULT_VAL
FOLDS = [
    (ALL_CASES[:6], ALL_CASES[6:]),
    (ALL_CASES[2:], ALL_CASES[:2]),
]


def summarize(rows):
    values = [row["F"] for row in rows if row["valid"]]
    return dict(
        count=len(rows),
        valid_count=sum(row["valid"] for row in rows),
        valid_rate=sum(row["valid"] for row in rows) / max(1, len(rows)),
        mean_F=statistics.mean(values) if values else None,
        stdev_F=statistics.stdev(values) if len(values) > 1 else 0.0,
        min_F=min(values) if values else None,
        max_F=max(values) if values else None,
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rounds", type=int, default=1)
    parser.add_argument("--seeds", default="0,1")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    target = Path(args.output).resolve()
    if target.exists():
        raise ValueError("Refuse to overwrite an experiment")
    protocol = json.loads((ROOT / "data/protocol.json").read_text(encoding="utf-8"))
    verify_baseline()
    by_name = {case["case"]: case for case in protocol["cases"]}
    seeds = [int(item.strip()) for item in args.seeds.split(",") if item.strip()]
    all_runs, fold_summaries = [], []
    for fold_id, (development, validation) in enumerate(FOLDS, 1):
        fold_rows = []
        for seed in seeds:
            selector = ContextualSelector(seed=seed, epsilon=0.05, train_enabled=True)
            for epoch in range(args.rounds):
                for name in development:
                    row = execute_case(by_name[name], protocol, selector, seed, True)
                    record = dict(fold=fold_id, seed=seed, phase="train",
                                  epoch=epoch + 1, **row)
                    all_runs.append(record)
                    print(json.dumps(record, ensure_ascii=False), flush=True)
            selector.train_enabled = False
            selector.epsilon = 0.0
            for name in validation:
                row = execute_case(by_name[name], protocol, selector, seed, False)
                record = dict(fold=fold_id, seed=seed, phase="validation", **row)
                all_runs.append(record)
                fold_rows.append(record)
                print(json.dumps(record, ensure_ascii=False), flush=True)
        fold_summaries.append(dict(
            fold=fold_id, development=development, validation=validation,
            summary=summarize(fold_rows),
        ))
    validation_rows = [row for row in all_runs if row["phase"] == "validation"]
    by_seed = {str(seed): summarize([r for r in validation_rows if r["seed"] == seed])
               for seed in seeds}
    output = dict(config=vars(args), folds=[dict(development=d, validation=v)
                                            for d, v in FOLDS],
                  runs=all_runs, fold_summaries=fold_summaries,
                  validation_summary=summarize(validation_rows),
                  seed_summaries=by_seed, objective=protocol["objective"])
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(dict(output=str(target), validation_summary=output["validation_summary"],
                          seed_summaries=by_seed), ensure_ascii=False))


if __name__ == "__main__":
    main()
