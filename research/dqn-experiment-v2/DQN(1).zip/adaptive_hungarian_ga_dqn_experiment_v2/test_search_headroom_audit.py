"""Pure-memory audit tests with fabricated traces and mocked validators.

No real fixture directories/files, dispatcher or simulation are used. These
checks do NOT test Windows permissions, real atomic writes or real replay;
the parent performs those separately on an existing authorized result folder.
"""
from contextlib import ExitStack, contextmanager
import copy
import fnmatch
import gzip
import hashlib
import io
import json
from pathlib import PurePosixPath
import posixpath
import unittest
from unittest.mock import patch


class MemoryPath:
    """Minimal in-memory Path double: never delegates to the operating system."""
    files = {}

    def __init__(self, value):
        self.value = posixpath.normpath(str(value))

    def __str__(self):
        return self.value

    def __truediv__(self, other):
        return MemoryPath(posixpath.join(self.value, str(other)))

    def __eq__(self, other):
        return isinstance(other, MemoryPath) and self.value == other.value

    @property
    def parent(self):
        return MemoryPath(str(PurePosixPath(self.value).parent))

    @property
    def name(self):
        return PurePosixPath(self.value).name

    def resolve(self, strict=False):
        if strict and not self.exists():
            raise FileNotFoundError(self.value)
        return self

    def exists(self):
        return self.value in self.files or any(n.startswith(self.value+'/') for n in self.files)

    def is_symlink(self):
        return False

    def glob(self, pattern):
        return [MemoryPath(n) for n in self.files
                if MemoryPath(n).parent == self and fnmatch.fnmatch(MemoryPath(n).name, pattern)]

    def read_bytes(self):
        return self.files[self.value]

    def write_bytes(self, data):
        self.files[self.value] = data
        return len(data)

    def write_text(self, text, encoding='utf-8'):
        return self.write_bytes(text.encode(encoding))

    @contextmanager
    def open(self, mode, encoding='utf-8'):
        if 'x' in mode and self.exists():
            raise FileExistsError(self.value)
        initial = self.files.get(self.value, b'') if 'a' in mode else b''
        stream = io.BytesIO(initial) if 'b' in mode else io.StringIO(initial.decode(encoding))
        stream.seek(0, 2)
        try:
            yield stream
            value = stream.getvalue()
            self.files[self.value] = value if isinstance(value, bytes) else value.encode(encoding)
        finally:
            stream.close()


def memory_sha(path):
    return hashlib.sha256(MemoryPath(path).read_bytes()).hexdigest()


def memory_read_json(path):
    return json.loads(MemoryPath(path).read_bytes().decode('utf-8'))


def memory_commit(folder, name, value):
    # Atomic replacement is intentionally outside this in-memory test's scope.
    path = MemoryPath(folder)/name
    path.write_text(json.dumps(value, allow_nan=False))
    return path

import audit_search_headroom as audit
from objective import LinearObjective


class HeadroomAuditTests(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        MemoryPath.files = {}
        self.root = MemoryPath('/memory-only-root')
        self.folder = self.root/'experiment'
        for name, replacement in (('Path', MemoryPath), ('sha', memory_sha),
                                  ('read_json', memory_read_json), ('commit', memory_commit)):
            self.stack.enter_context(patch.object(audit, name, replacement))
        for name in audit.EXTRA_SOURCES:
            path = self.root/name
            path.write_text('synthetic audit identity fixture', encoding='utf-8')
        self.case = dict(case='synthetic-dev', source_day=900, tasks=[])
        self.protocol = dict(cases=[self.case, dict(case='synthetic-test', source_day=901, tasks=[])],
                             development=['synthetic-dev'], validation=[], test=['synthetic-test'],
                             configuration={}, objective=LinearObjective().to_dict())
        # to_dict includes metadata not accepted by the constructor; use defaults.
        self.protocol['objective'] = {}
        protocol_path = self.root/'protocol.json'
        self.dump(protocol_path, self.protocol)
        identity = dict(baseline_files=0, hashes={'fake.py': 'fixture-only'},
                        historical_manifest_sha256='fixture-only')
        manifest = dict(identity, version='search-headroom-v1', seeds=[0],
                        cases=[dict(case=self.case['case'], source_day=900, orders=0)],
                        budgets=audit.BUDGETS, protocol_sha256=audit.sha(protocol_path),
                        blocked_test_cases=self.protocol['test'], planned_runs=4,
                        future_orders_visible_to_policy=False)
        self.dump(self.folder/'manifest.json', manifest)
        self.stack.enter_context(patch.object(audit, 'ROOT', self.root))
        self.stack.enter_context(patch.object(audit, 'PROTOCOL', protocol_path))
        self.stack.enter_context(patch.object(audit, 'frozen_identity', return_value=identity))
        self.build = self.stack.enter_context(patch.object(audit, 'build', return_value={'mock_model': True}))
        objective = LinearObjective()
        score = objective.score((10, 5, 8))
        usage = lambda calls, reason: dict(route_calls=calls, reason=reason)
        self.logs = [dict(previews=2, proxy_evaluations=3, changed=True,
                          anchor_usage=usage(7, 'complete'),
                          candidates=[dict(usage=usage(5, 'bound_pruned'))]),
                     dict(error='anchor_incomplete', usage=usage(3, 'query_budget'))]
        self.raw = dict(valid=True, method='rl', objective_sha256=objective.fingerprint,
                        T=10, R=5, D=8, traffic_wait=2, search_log=self.logs,
                        dqn=dict(reward_sum=-score, actions={'ga': 2}))
        self.physics = dict(formal=dict(T=10, R=5, D=8, F=score),
                            weighted_terms=dict(zip(('T', 'R', 'D'), objective.terms((10, 5, 8)))))
        self.check = self.stack.enter_context(patch.object(audit, 'checked_score', return_value={'F_linear_v2': score}))
        self.analyze = self.stack.enter_context(patch.object(audit, 'analyze_physics', return_value=self.physics))
        self.row = dict(case=self.case['case'], seed=0, budget_name='baseline',
                        budget=copy.deepcopy(audit.BUDGETS['baseline']), valid=True, source_day=900,
                        orders=0, same_budget_control=True, version='search-headroom-v1',
                        phase='development_diagnostic', ga_adaptation=dict(audit.ADAPTATION),
                        F=score, T=10, R=5, D=8, traffic_wait=2, physics=copy.deepcopy(self.physics),
                        wall=1.0, diagnostic_wall=2.0, **self.raw['dqn'],
                        ga_searches=[dict(proxy_evaluations=3, candidates=3,
                                          adaptive_mutation=True, adaptive_crossover=True,
                                          mutation_history=[dict(generation=0, stagnant=0, diversity=1,
                                                                 mutation_rate=.7, crossover_rate=.9)])])
        self.row['budget_audit'] = audit.audit_budget(self.row, self.logs, audit.BUDGETS['baseline'])
        raw_name = 'trajectory_000.json.gz'
        (self.folder/raw_name).write_bytes(gzip.compress(json.dumps(self.raw).encode('utf-8')))
        self.row.update(trajectory_file=raw_name, trajectory_sha256=audit.sha(self.folder/raw_name))
        self.save_row()
        audit.freeze_supplement(self.folder)

    @staticmethod
    def dump(path, value):
        path.write_text(json.dumps(value), encoding='utf-8')

    def save_row(self):
        self.dump(self.folder/'episode_000.json', self.row)

    def test_valid_partial_audit_corrects_costs_and_preserves_originals(self):
        names = ('manifest.json', 'episode_000.json', 'trajectory_000.json.gz', audit.SUPPLEMENT)
        before = {name: audit.sha(self.folder/name) for name in names}
        data = audit.audit_folder(self.folder)
        self.assertTrue(data['valid'])
        self.assertFalse(data['complete'])
        self.assertEqual(data['completed_runs'], 1)
        row = data['rows'][0]
        self.assertEqual(row['corrected_budget_totals']['total_physical_previews'], 3)
        self.assertEqual(row['corrected_budget_totals']['rollout_route_calls'], 15)
        self.assertEqual(row['corrected_budget_totals']['physical_previews_total'], 3)
        self.assertEqual(row['corrected_budget_totals']['failed_anchor_previews'], 1)
        self.assertEqual(row['corrected_budget_totals']['successful_search_previews'], 2)
        self.assertEqual(row['corrected_budget_totals']['rollout_route_calls_total'], 15)
        self.assertEqual(row['corrected_budget_totals']['searches'], 1)
        self.assertEqual(row['corrected_budget_totals']['proxy_evaluations'], 3)
        self.assertEqual(row['execution_wall'], 1)
        self.assertEqual(row['diagnostic_wall'], 2)
        self.assertEqual(row['source_split'], 'training')
        self.assertEqual(before, {name: audit.sha(self.folder/name) for name in names})
        self.assertTrue((self.folder/'audit.json').exists())
        self.check.assert_called_once()
        self.analyze.assert_called_once()
        json.dumps(data, allow_nan=False)

    def test_supplement_is_exclusive_and_records_after_start_scope(self):
        with self.assertRaises(FileExistsError):
            audit.freeze_supplement(self.folder)
        value = audit.read_json(self.folder/audit.SUPPLEMENT)
        self.assertEqual(value['capture_timing'], 'after_job_start')
        self.assertIn('does not retroactively', value['caveat'])
        self.assertIn('+00:00', value['captured_at_utc'])

    def test_reject_source_or_manifest_drift(self):
        with (self.root/'paths.py').open('a', encoding='utf-8') as stream:
            stream.write('changed')
        with self.assertRaisesRegex(ValueError, 'supplement.hashes'):
            audit.audit_folder(self.folder)

    def test_reject_wrong_trajectory_path_before_read(self):
        self.row['trajectory_file'] = '../trajectory_000.json.gz'
        self.save_row()
        with self.assertRaisesRegex(ValueError, 'trajectory_file'):
            audit.audit_folder(self.folder)
        self.check.assert_not_called()

    def test_reject_metric_physics_seed_and_budget_tampering(self):
        original = copy.deepcopy(self.row)
        variants = [('F', 99), ('seed', 99), ('budget', {'proxy': 999}),
                    ('ga_adaptation', {}), ('physics', {}), ('diagnostic_wall', -1)]
        for field, value in variants:
            with self.subTest(field=field):
                self.row = dict(original, **{field: value})
                self.save_row()
                with self.assertRaises(ValueError):
                    audit.audit_folder(self.folder)

    def test_reject_raw_hash_mismatch(self):
        with (self.folder/'trajectory_000.json.gz').open('ab') as stream:
            stream.write(b'changed')
        with self.assertRaisesRegex(ValueError, 'trajectory_sha256'):
            audit.audit_folder(self.folder)

    def test_reject_unexpected_episode(self):
        self.dump(self.folder/'episode_999.json', self.row)
        with self.assertRaisesRegex(ValueError, 'Unexpected episode'):
            audit.audit_folder(self.folder)

    def test_reject_unaccounted_rollout_and_invalid_usage(self):
        logs = copy.deepcopy(self.logs)
        logs[0]['previews'] = 3
        with self.assertRaisesRegex(ValueError, 'previews_vs_rollouts'):
            audit.corrected_budget_totals(logs)
        logs = copy.deepcopy(self.logs)
        logs[1]['usage']['route_calls'] = -1
        with self.assertRaisesRegex(ValueError, 'route_calls'):
            audit.corrected_budget_totals(logs)

    def test_no_committed_rows_is_partial_not_failure(self):
        # Another namespace in the same in-memory dictionary, no filesystem IO.
        empty = self.root/'empty-experiment'
        self.dump(empty/'manifest.json', audit.read_json(self.folder/'manifest.json'))
        audit.freeze_supplement(empty)
        data = audit.audit_folder(empty)
        self.assertEqual(data['rows'], [])
        self.assertFalse(data['complete'])
        self.build.assert_not_called()


if __name__ == '__main__':
    unittest.main()
