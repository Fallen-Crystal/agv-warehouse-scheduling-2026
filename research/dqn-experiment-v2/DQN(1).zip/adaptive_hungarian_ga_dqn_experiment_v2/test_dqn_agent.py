"""使用 unittest 验证 DQN 数学、训练状态和无 pickle 检查点。"""

import copy
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

from dqn_agent import DQNAgent


class DQNAgentTests(unittest.TestCase):
    def make_agent(self, **kwargs):
        options = dict(seed=7, state_dim=2, hidden=4, batch_size=2,
                       capacity=8, warmup=2, target_interval=3)
        options.update(kwargs)
        return DQNAgent(**options)

    def fill(self, agent, count=8):
        for i in range(count):
            s = np.array([i / 10, -i / 20])
            agent.remember(s, i % 2, (i % 3) - 1, s + 0.1, i % 4 == 0)

    def assert_agents_equal(self, a, b):
        self.assertEqual(a.double_dqn, b.double_dqn)
        self.assertEqual(a.output_scale, b.output_scale)
        self.assertEqual(a.train_steps, b.train_steps)
        self.assertEqual(a.replay_size, b.replay_size)
        self.assertEqual(a.replay.position, b.replay.position)
        self.assertEqual(json.dumps(a.rng.bit_generator.state),
                         json.dumps(b.rng.bit_generator.state))
        for group in ("online", "target", "adam_m", "adam_v"):
            for key in a._PARAMETERS:
                np.testing.assert_array_equal(getattr(a, group)[key],
                                              getattr(b, group)[key])
        for key in ("states", "next_states", "actions", "rewards", "dones"):
            np.testing.assert_array_equal(getattr(a.replay, key), getattr(b.replay, key))

    def test_bellman_terminal_mask_and_huber_loss(self):
        agent = self.make_agent(gamma=0.5)
        for weights in (agent.online, agent.target):
            for value in weights.values():
                value.fill(0)
        agent.target["b2"][:] = [2, 4]
        targets = agent._bellman_targets(np.array([1., 1.]),
                                         np.zeros((2, 2)), np.array([True, False]))
        np.testing.assert_array_equal(targets, [1, 3])
        agent.remember([0, 0], 0, 1, [0, 0], True)
        agent.remember([0, 0], 1, 1, [0, 0], False)
        # 预测为零，目标为 1 和 3，Huber 平均为 (0.5 + 2.5) / 2。
        self.assertEqual(agent.learn(), 1.5)

    def test_double_dqn_online_selects_target_evaluates_with_terminal_mask(self):
        agent = self.make_agent(gamma=0.5, double_dqn=True)
        for weights in (agent.online, agent.target):
            for value in weights.values():
                value.fill(0)
        # 排序相反：online选0，而target的最大值在1；Double DQN必须评价0。
        agent.online["b2"][:] = [5, 1]
        agent.target["b2"][:] = [2, 8]
        rewards, states, dones = np.ones(2), np.zeros((2, 2)), np.array([True, False])
        np.testing.assert_array_equal(agent._bellman_targets(rewards, states, dones), [1, 2])
        agent.double_dqn = False
        np.testing.assert_array_equal(agent._bellman_targets(rewards, states, dones), [1, 5])

    def test_small_output_initialization_preserves_hidden_weights_and_rng(self):
        original = self.make_agent()
        small = self.make_agent(output_scale=0.01)
        self.assertFalse(original.double_dqn)
        self.assertEqual(original.output_scale, 1.0)
        for key in ("w1", "b1", "b2"):
            np.testing.assert_array_equal(original.online[key], small.online[key])
        np.testing.assert_array_equal(small.online["w2"], original.online["w2"] * 0.01)
        for key in small._PARAMETERS:
            np.testing.assert_array_equal(small.target[key], small.online[key])
        states = np.array([[0.2, -0.4], [1., 0.5]])
        np.testing.assert_allclose(small._forward(states, small.online)[0],
                                   original._forward(states, original.online)[0] * 0.01)
        self.assertEqual(original.rng.bit_generator.state, small.rng.bit_generator.state)

    def test_legacy_checkpoint_missing_config_fields_keeps_old_defaults(self):
        agent = self.make_agent()
        self.fill(agent)
        agent.learn()
        config = {k: getattr(agent, k) for k in (
            "state_dim", "hidden", "batch_size", "capacity", "learning_rate",
            "gamma", "target_interval", "warmup", "epsilon")}
        metadata = dict(version=1, config=config, train_steps=agent.train_steps,
                        rng=agent.rng.bit_generator.state,
                        replay_position=agent.replay.position, replay_size=agent.replay_size)
        arrays = {"metadata": np.array(json.dumps(metadata))}
        for group in ("online", "target", "adam_m", "adam_v"):
            arrays.update({f"{group}_{k}": v.copy() for k, v in getattr(agent, group).items()})
        for key in ("states", "next_states", "actions", "rewards", "dones"):
            arrays[f"replay_{key}"] = getattr(agent.replay, key).copy()
        # 内存模拟旧npz上下文，不依赖临时目录权限。
        with patch("dqn_agent.np.load") as mocked:
            mocked.return_value.__enter__.return_value = arrays
            restored = DQNAgent.load("legacy-checkpoint.npz")
        self.assert_agents_equal(agent, restored)
        self.assertEqual(agent.learn(), restored.learn())
        self.assert_agents_equal(agent, restored)

    def test_only_selected_output_gets_gradient_and_loss_decreases(self):
        agent = self.make_agent(learning_rate=0.03)
        for value in agent.online.values():
            value.fill(0)
        for i in range(2):
            agent.remember([0, 0], 0, 0.75, [0, 0], True)
        initial = agent.learn()
        self.assertGreater(agent.online["b2"][0], 0)
        self.assertEqual(agent.online["b2"][1], 0)
        self.assertEqual(agent.adam_m["b2"][1], 0)
        losses = [agent.learn() for _ in range(15)]
        self.assertLess(losses[-1], initial)

    def test_target_sync_occurs_on_successful_train_steps(self):
        agent = self.make_agent(target_interval=2)
        initial = {k: v.copy() for k, v in agent.target.items()}
        self.assertIsNone(agent.learn())
        self.assertEqual(agent.train_steps, 0)
        self.fill(agent)
        agent.learn()
        for k in agent._PARAMETERS:
            np.testing.assert_array_equal(agent.target[k], initial[k])
        self.assertTrue(any(not np.array_equal(agent.online[k], initial[k])
                            for k in agent._PARAMETERS))
        agent.learn()
        self.assertEqual(agent.train_steps, 2)
        for k in agent._PARAMETERS:
            np.testing.assert_array_equal(agent.online[k], agent.target[k])
            self.assertFalse(np.shares_memory(agent.online[k], agent.target[k]))

    def test_replay_warmup_capacity_and_copies(self):
        agent = self.make_agent(warmup=4, capacity=5)
        state = np.array([1., 2.])
        agent.remember(state, 0, 0, state, False)
        state[:] = 99
        np.testing.assert_array_equal(agent.replay.states[0], [1, 2])
        self.fill(agent, 2)
        self.assertEqual(len(agent.replay), 3)
        rng_before = copy.deepcopy(agent.rng.bit_generator.state)
        self.assertIsNone(agent.learn())
        self.assertEqual(agent.rng.bit_generator.state, rng_before)
        self.fill(agent, 1)
        self.assertIsInstance(agent.learn(), float)
        self.fill(agent, 10)
        self.assertEqual(agent.replay_size, 5)
        self.assertEqual(agent.replay.position, 4)
        self.assertEqual(agent.train_steps, 1)

    def test_checkpoint_exact_resume_with_wrapped_replay(self):
        agent = self.make_agent(epsilon=0.7, double_dqn=True, output_scale=0.01)
        self.fill(agent, 13)
        for _ in range(4):
            agent.select([0.2, -0.4])
            agent.learn()
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            path = Path(directory) / "checkpoint.custom"
            agent.save(path)
            self.assertTrue(path.is_file())
            with np.load(path, allow_pickle=False) as archive:
                for key in archive.files:
                    self.assertNotEqual(archive[key].dtype.kind, "O")
            restored = DQNAgent.load(path)
        self.assert_agents_equal(agent, restored)
        for i in range(12):
            state = np.array([i / 7, -0.4])
            self.assertEqual(agent.select(state), restored.select(state))
            for current in (agent, restored):
                current.remember(state, i % 2, i / 9, state + 0.2, i % 3 == 0)
            self.assertEqual(agent.learn(), restored.learn())
            self.assert_agents_equal(agent, restored)

    def test_frozen_inference_consumes_no_rng_and_changes_no_state(self):
        agent = self.make_agent(epsilon=1.0)
        self.fill(agent)
        agent.learn()
        before = copy.deepcopy(agent)
        expected = int(np.argmax(agent._forward(np.array([0.3, 0.5]), agent.online)[0]))
        for _ in range(30):
            self.assertEqual(agent.select([0.3, 0.5], training=False), expected)
        self.assert_agents_equal(agent, before)
        # 相同随机状态在推断之后仍会产生完全相同的探索和训练。
        self.assertEqual(agent.select([0, 0]), before.select([0, 0]))
        self.assertEqual(agent.learn(), before.learn())
        self.assert_agents_equal(agent, before)

    def test_invalid_input_is_rejected(self):
        with self.assertRaises(ValueError):
            self.make_agent(capacity=1)
        for scale in (0, -1, np.nan, np.inf, -np.inf):
            with self.subTest(output_scale=scale), self.assertRaises(ValueError):
                self.make_agent(output_scale=scale)
        with self.assertRaises(ValueError):
            self.make_agent(double_dqn=1)
        agent = self.make_agent()
        with self.assertRaises(ValueError):
            agent.select([0])
        with self.assertRaises(ValueError):
            agent.remember([0, 0], 2, 1, [0, 0], False)
        with self.assertRaises(ValueError):
            agent.remember([0, 0], 0, np.nan, [0, 0], False)


if __name__ == "__main__":
    unittest.main()
