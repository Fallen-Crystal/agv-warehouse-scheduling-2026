"""保留障碍的全SKU槽位放宽下界；station允许穿越，非可实现收益。

静态距离图是无向图，反向从端口及各车home查询以复用少量BFS表。
仍独立放宽槽位一致性、库存、资源、冲突、空载及最终回库。
"""
from copy import copy
from math import ceil,isfinite
import paths
from agv.planning.distance import DistanceOracle
from headroom_physics import lower_bounds


def static_lower_bounds(model,objective):
    basic=lower_bounds(model,objective)
    geometry=copy(model['scene'])
    geometry.map_info={**geometry.map_info,'station_access':'relaxed_motion'}
    oracle=DistanceOracle(geometry)
    vehicles=model['vehicles']
    rows=[]
    templates={}
    for job in model['tasks']:
        key=(job['sku'],job['kind'],tuple(job['port']))
        if key not in templates:
            options=[]
            for slot in model['slots']:
                if slot['sku']!=job['sku']:
                    continue
                service=1+2*slot['level']
                for point in slot['points']:
                    pickup=job['port'] if job['kind']=='delivery' else point
                    for k,home in enumerate(geometry.homes[:vehicles]):
                        initial=oracle.distance(pickup,home,k)
                        loaded=oracle.distance(point,job['port'],k)
                        if isfinite(initial) and isfinite(loaded):
                            options.append((loaded,loaded+service,initial))
            if not options:
                raise ValueError('No relaxed static option')
            templates[key]=options
        options=templates[key]
        completion=min(max(job['release'],initial)+work for loaded,work,initial in options)
        rows.append(dict(task=job['id'],release=job['release'],loaded=min(o[0] for o in options),
                         work=min(o[1] for o in options),completion=completion,
                         flow=completion-job['release']))
    individual=max((r['completion'] for r in rows),default=0)
    tail=max((u+ceil(sum(r['work'] for r in rows if r['release']>=u)/vehicles)
              for u in {r['release'] for r in rows}),default=0)
    values=dict(T=max(individual,tail),R=sum(r['flow'] for r in rows)/len(rows) if rows else 0,
                D=sum(r['loaded'] for r in rows))
    values['F']=objective.score(tuple(values[k] for k in ('T','R','D')))
    if any(values[k]<basic[k]-1e-9 for k in ('T','R','D','F')):
        raise ValueError('Static relaxation unexpectedly weaker than Manhattan')
    return dict(method='all-sku-static-relaxed-station-release-tail-v1',**values,
                manhattan_F=basic['F'],tasks=rows,
                caveat='Offline relaxation only; gap is not attainable gain; excludes stock/resources/collisions/empty travel/final returns.')
