"""离线核验并汇总已提交开发轨迹的等待分类；不重新调度。"""
import argparse
import gzip
import json

from paths import ROOT, sha
from wepa.data import build
from audit_search_headroom import audit_folder
from headroom_waiting import analyze_waiting, CATEGORIES
from run_search_headroom import PROTOCOL, read_json, commit


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', default='results/search_headroom_v1')
    args = parser.parse_args()
    folder = (ROOT / args.input).resolve()
    verified = audit_folder(folder)
    protocol = read_json(PROTOCOL)
    cases = {c['case']: c for c in protocol['cases']}
    rows = []
    for row in verified['rows']:
        raw = folder / row['trajectory_file']
        if raw.resolve().parent != folder or sha(raw) != row['trajectory_sha256']:
            raise ValueError('Trajectory identity changed')
        trajectory = json.loads(gzip.decompress(raw.read_bytes()))
        model = build(cases[row['case']], **protocol['configuration'])
        ledger = analyze_waiting(model, trajectory)
        expected = row['physics']['response_time']['total_steps']['pre_assignment']
        if ledger['aggregate']['pre_assignment_total'] != expected:
            raise ValueError('Waiting and physical ledgers disagree')
        rows.append(dict(case=row['case'], source_day=row['source_day'], seed=row['seed'],
                         budget_name=row['budget_name'], trajectory_sha256=row['trajectory_sha256'],
                         waiting=ledger))
    commit(folder, 'waiting_analysis.json', dict(complete=verified['complete'], rows=rows,
        source_hashes={name:sha(ROOT/name) for name in ('headroom_waiting.py','report_headroom_waiting.py')},
        qualification='离线业务状态账本，非因果归因；空车不证明可行路径或可消除等待'))
    lines = ['# 开发集分配前等待账本', '',
             '逐tick复核原始分配、WMS绑定、库存与资源状态；不重新调度。分类按表中从左到右优先级互斥计数，单位为每单平均秒。', '',
             '| 日期 | seed | 预算组 | 未绑定槽位 | bay锁 | 层级前序 | 就绪但全车忙 | 就绪且有空车 | 合计 |',
             '|---|---:|---|---:|---:|---:|---:|---:|---:|']
    for row in rows:
        a=row['waiting']['aggregate']
        values=' | '.join(f"{a['mean_steps'][k]:.3f}" for k in CATEGORIES)
        lines.append(f"| {row['source_day']} | {row['seed']} | {row['budget_name']} | {values} | {a['pre_assignment_mean']:.3f} |")
    lines += ['', '这些类别是已实现轨迹的状态账本，不是独立可消除的损失。bay锁可能同时遮蔽层级和车辆限制；未绑定槽位不全等于缺货；就绪且有空车也不证明存在无冲突路径或分配后F会更好。',
              '', f"状态：{'全部计划完成' if verified['complete'] else '仅已提交的部分窗口'}。", '']
    (folder/'等待分项.md').write_text('\n'.join(lines), encoding='utf-8')
    print(json.dumps([dict(case=r['case'],budget=r['budget_name'],aggregate=r['waiting']['aggregate']) for r in rows],ensure_ascii=False),flush=True)


if __name__ == '__main__':
    main()
