"""Isolated reproducible threshold trial with independent physical validation."""
import argparse
from functools import partial
import hashlib
import json
import os
from pathlib import Path
import threading
import time

from paths import ROOT, verify_baseline
from objective import LinearObjective, checked_score
from improved.execute import run
from boundary_policy import BoundaryPolicy
from wepa.data import build


def source_hashes():
    # The batch runner only schedules trials; exclude it so a concurrency
    # override cannot invalidate physical experiment provenance.
    files = [p for p in ROOT.glob('boundary*.py') if p.name != 'boundary_batch.py']
    files += list((ROOT/'improved').glob('*.py'))
    files += [ROOT/'boundary_protocol.json']
    return {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(files)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--case', required=True)
    parser.add_argument('--arm', required=True)
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    output = Path(args.output)
    if output.exists():
        raise ValueError('Refuse to overwrite trial')
    protocol = json.loads((ROOT/'boundary_protocol.json').read_text(encoding='utf-8'))
    case = next(c for c in protocol['cases'] if c['case'] == args.case)
    arm = protocol['arms'][args.arm]
    verify_baseline()
    frozen = source_hashes()
    objective = LinearObjective(**protocol['objective'])
    model = build(case, **protocol['configuration'])
    factory = None if args.arm == 'original' else partial(
        BoundaryPolicy, threshold=float(arm['threshold']),
        keep_closed_rule=arm['keep_closed_rule'],
        profile=arm.get('ga_profile', 'gate'))
    cpu, wall = time.process_time(), time.perf_counter()
    stop = threading.Event()
    def guard():
        while not stop.wait(0.25):
            if time.process_time() - cpu > 600:
                os._exit(124)
    threading.Thread(target=guard, daemon=True).start()
    result = run(model, 'gate', args.seed, objective=objective, policy_factory=factory)
    try:
        score = checked_score(model, result, objective)
    except ValueError as error:
        score = {'audit': {'valid': False, 'error': str(error)}, 'F_linear_v2': None}
    events = [e for e in result['search_log'] if e.get('mode') == 'boundary_decision']
    row = dict(case=args.case, source_case=case['source_case'], load_level=case['load_level'],
               tasks=len(case['tasks']), vehicles=model['vehicles'],
               orders_per_vehicle=len(case['tasks'])/model['vehicles'],
               arm=args.arm, seed=args.seed,
               valid=result['valid'] and score['audit']['valid'],
               cpu=time.process_time()-cpu, wall=time.perf_counter()-wall,
               F=score['F_linear_v2'],
               **{k:result[k] for k in ('T','R','D','p90','empty_distance','traffic_wait')},
               matching_events=sum(e['branch']=='matching' for e in events),
               ga_events=sum(e['branch']=='ga' for e in events),
               ga_searches=sum(e.get('optimizer') in ('joint_ga', 'hungarian_seeded_joint_ga') for e in result['search_log']))
    stop.set()
    if frozen != source_hashes():
        raise ValueError('Experiment source changed during trial')
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('x', encoding='utf-8') as stream:
        json.dump(dict(row=row, case=case, arm=arm, result=result, scoring=score,
                       implementation_sha256=frozen),stream,ensure_ascii=False)
    print(json.dumps(row), flush=True)
    if not row['valid']:
        raise SystemExit(1)

if __name__ == '__main__':
    main()
