"""仅按输入筛选1小时真实订单窗口；先冻结协议，再执行任何策略。"""
import json
from collections import Counter, defaultdict
from pathlib import Path
import paths
from paths import ROOT, sha
from wepa.data import build


def main():
    raw = ROOT/'deliverables/wepa_real_data/raw'
    provenance = json.loads((ROOT/'data/input-selection.json').read_text(encoding='utf-8'))
    assert sha(raw/'2_orders.json') == provenance['source_sha256']
    assert sha(raw/'3_initial_fill_lvl.json') == provenance['initial_stock_sha256']
    orders = json.loads((raw/'2_orders.json').read_text(encoding='utf-8'))
    stock = Counter({int(k):v for k,v in json.loads((raw/'3_initial_fill_lvl.json').read_text()).items()})
    bins = defaultdict(list)
    for index, row in enumerate(orders):
        bins[int(row[2]//3600)].append((index,row))
    selected, days = [], set()
    # 每日取最早合格整点小时；不查询算法成绩，不拆分同一时刻的订单批次。
    for bucket, entries in sorted(bins.items()):
        day = bucket//24
        skus = {r[1] for _,r in entries}
        initial = {s:stock[s] for s in skus}
        kinds = {r[0] for _,r in entries}
        valid = 60<=len(entries)<=240 and len(kinds)==2 and 2<=len(skus)<=5 and sum(initial.values())<=900
        ledger = Counter(initial)
        for _,r in entries:
            ledger[r[1]] += 1 if r[0]=='delivery' else -1
            # 沿用固定的每SKU初始库存+50储位容量，不扩大物理容量。
            if ledger[r[1]]<0 or ledger[r[1]]>initial[r[1]]+50:
                valid=False
        if valid and day not in days:
            case = dict(case=f'wepa-hour-day{day}-bin{bucket}', source_day=day,
                        source_bin=bucket,start_seconds=bucket*3600,end_seconds=(bucket+1)*3600,
                        close_at=3600,initial={str(k):v for k,v in sorted(initial.items())},
                        tasks=[dict(id=j,source_row=i,kind=r[0],sku=r[1],release=r[2]-bucket*3600,
                                    source_time=r[2],source_dock=r[3],batch=r[4],week=r[5])
                               for j,(i,r) in enumerate(entries)])
            build(case,size='large',layers=5,vehicles=6)
            selected.append(case)
            days.add(day)
        for _,r in entries:
            stock[r[1]] += 1 if r[0]=='delivery' else -1
    prior = set(provenance['prior_used_days'])
    train = [c['case'] for c in selected if c['source_day'] in prior]
    evaluation = [c['case'] for c in selected if c['source_day'] not in prior]
    assert len(train)==10 and len(evaluation)==4
    old = json.loads((ROOT/'data/protocol.json').read_text())
    protocol = dict(version='dqn-broad-hour-v1',configuration=old['configuration'],objective=old['objective'],
                    seed=0,training_passes=1,development=train,evaluation=evaluation,cases=selected,
                    source_sha256=sha(raw/'2_orders.json'),initial_stock_sha256=sha(raw/'3_initial_fill_lvl.json'),
                    previously_used_days=sorted(prior),
                    selection='Earliest eligible aligned hour per day: 60..240 orders, both kinds, 2..5 SKUs, initial stock <=900; every prefix within initial+50 capacity.',
                    evaluation_rule='Days absent from recorded prior_used_days; no evaluation until training checkpoint frozen. Fixed GA paired controls on same windows/seed.',
                    normalization='Formal F unchanged: T/900, R/900, D/5400; compare methods within identical hour windows, not old absolute 15-minute F.',
                    limitation='Input-selected feasible subset; no claim to represent all dates, all loads or the original plant.')
    target = ROOT/'data/dqn_broad_protocol.json'
    if target.exists():
        assert json.loads(target.read_text(encoding='utf-8'))==protocol, 'Refuse to alter frozen selection'
    else:
        target.write_text(json.dumps(protocol,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(dict(training_days=[c['source_day'] for c in selected if c['case'] in train],
                          evaluation_days=[c['source_day'] for c in selected if c['case'] in evaluation],
                          train_orders=sum(len(c['tasks']) for c in selected if c['case'] in train),
                          evaluation_orders=sum(len(c['tasks']) for c in selected if c['case'] in evaluation),
                          unique_minutes=len(selected)*60,windows=len(selected)),ensure_ascii=False))


if __name__=='__main__':
    main()
