import unittest
from types import SimpleNamespace
import paths
from objective import LinearObjective
from dqn_policy import physical_potential, physical_terms, observation, enhanced_observation, DQNPolicy


class PolicyTests(unittest.TestCase):
    def world(self):
        return SimpleNamespace(active=[None],visible={0:dict(release=2,kind="retrieval")},
            assigned=set(),completed=set(),tasks={0:dict(release=2)},records=[],time=5,
            past_moves=3,history=[[(0,0),(0,1)]],labels=[["empty"]],stock=set(),
            slots=[{}],ready=lambda:[])

    def test_observation_does_not_depend_on_unpublished_orders(self):
        w = self.world()
        before = observation(w)
        w.tasks[99] = dict(release=10000,kind="delivery")
        self.assertEqual(before,observation(w))

    def test_enhanced_state_only_uses_published_committed_information(self):
        w = self.world()
        w.plans = [[(0,0),(0,1),(1,1)]]
        w.scene = SimpleNamespace(width=62,height=47)
        w.visible[0].update(id=0,port=(5,6))
        w.ready = lambda:list(w.visible.values())
        policy = SimpleNamespace(plan=None,last_search=0)
        before = enhanced_observation(w,policy)
        self.assertEqual(len(before),24)
        self.assertEqual(before[:10],observation(w))
        w.tasks[99] = dict(release=99999,port=(61,46))
        self.assertEqual(before,enhanced_observation(w,policy))
        policy.plan = ([0],{0:0})
        after = enhanced_observation(w,policy)
        self.assertEqual(after[20:22],[1.,1.])
        w.active[0] = dict(end=105)
        self.assertGreater(enhanced_observation(w,policy)[10],before[10])

    def test_reward_terms_and_initial_cost_audit(self):
        class Agent:
            state_dim=24
            train_steps=0
            def select(self,state,training=False):
                assert len(state)==24
                return 0
        w = self.world()
        w.plans=[[(0,0)]]
        w.scene=SimpleNamespace(width=62,height=47)
        w.visible[0].update(id=0,port=(0,0))
        policy=DQNPolicy(0,objective=LinearObjective(),agent=Agent(),training=False)
        # 不执行分支，只测试真实转移与奖励分项接口。
        initial=physical_terms(w,policy.objective)
        policy.initial_cost=sum(initial.values())
        policy.initial_cost_terms=initial
        policy.reward_sum=-policy.initial_cost
        policy.previous=([0]*24,0,policy.initial_cost)
        policy.previous_terms,policy.previous_time=initial,w.time
        result=dict(valid=True,T=10,R=8,D=7,time=20,
                    objective_value=policy.objective.score((10,8,7)))
        policy.finish_episode(result)
        info=result['dqn']
        self.assertAlmostEqual(info['learning_reward_sum']-info['initial_cost'],-result['objective_value'])
        last=info['transitions'][-1]
        self.assertAlmostEqual(sum(last['reward_terms'].values()),last['reward'])
        self.assertEqual(last['duration'],15)
        self.assertEqual(info['observation_schema'],'published-v2-24')

    def test_terminal_potential_is_formal_objective(self):
        w = self.world()
        objective = LinearObjective()
        self.assertEqual(len(observation(w)),10)
        w.completed = {0}
        w.records = [dict(task=0,end=10)]
        w.time = 20  # 最后返库不额外抬高T。
        self.assertAlmostEqual(physical_potential(w,objective),objective.score((10,8,3)))

    def test_decision_rewards_telescope_and_terminal_flag(self):
        class Agent:
            train_steps = 0
            def __init__(self): self.items=[]
            def remember(self,*item): self.items.append(item)
            def learn(self): return None
        agent = Agent()
        policy = DQNPolicy(0,objective=LinearObjective(),agent=agent,training=True)
        policy.previous = ([0]*10,0,.1)
        policy.reward_sum = -.1
        policy.transition([1]*10,.3,False)
        policy.previous = ([1]*10,1,.3)
        result = dict(valid=True,objective_value=.8)
        policy.finish_episode(result)
        self.assertAlmostEqual(result["dqn"]["reward_sum"],-.8)
        self.assertFalse(agent.items[0][-1])
        self.assertTrue(agent.items[1][-1])
        self.assertEqual(len(agent.items),2)


if __name__ == "__main__":
    unittest.main()
