"""报告成功路径与未完成门槛；仅内存模拟，不写正式结果。"""
import unittest
import csv
import io
from unittest.mock import patch
import summarize_hungarian_intervention as module


class ReportTests(unittest.TestCase):
    def test_incomplete_does_not_publish(self):
        with patch.object(module,'analyze',return_value={'complete':False}),patch.object(module,'ROOT') as root:
            module.main()
            root.__truediv__.assert_not_called()

    def test_complete_contains_eight_pairs(self):
        files={}
        class MemoryPath:
            def __init__(self,name=''): self.name=name
            def __truediv__(self,name): return MemoryPath(self.name+'/'+name if self.name else name)
            def exists(self): return self.name in files
            def read_text(self,**kw): return files[self.name]
            def write_text(self,text,**kw): files[self.name]=text
        rows=[]
        for variant in ('same_cost','f_surrogate'):
            for day in (41,52,59,65):
                rows.append(dict(variant=variant,case=f'wepa-hour-day{day}-bin0',F=2.4,T=3600,R=200,D=10000,
                                 original_dqn_F=2.5,fixed_ga_F=2.6,
                                 improvement_vs_original_percent=4.,improvement_vs_ga_percent=7.69))
        report=dict(complete=True,completed=8,rows=rows,means={v:dict(improvement_vs_original_percent=4.,
                    improvement_vs_ga_percent=7.69) for v in ('same_cost','f_surrogate')})
        with patch.object(module,'analyze',return_value=report),patch.object(module,'ROOT',MemoryPath()):
            module.main()
        text=files['docs/匈牙利替换实验结果.md']
        self.assertIn('不是新的独立泛化',text)
        self.assertIn('未执行新的学习',text)
        data=list(csv.DictReader(io.StringIO(files['results/hungarian_intervention_v1/paired_results.csv'])))
        self.assertEqual(len(data),8)
        self.assertEqual({row['variant'] for row in data},{'same_cost','f_surrogate'})
        self.assertTrue(all(float(row['F'])==2.4 for row in data))


if __name__=='__main__': unittest.main()
