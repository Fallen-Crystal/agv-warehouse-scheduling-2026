"""用SVG绘制已完成的冻结监测曲线；标准库即可运行。"""
import argparse
import html
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder")
    args = parser.parse_args()
    folder = Path(args.folder)
    rows = [json.loads(line) for line in (folder/"episodes.jsonl").read_text(encoding="utf-8").splitlines() if line]
    monitor = [r for r in rows if r["phase"]=="monitor"]
    if not monitor:
        raise ValueError("No frozen monitoring rows")
    epochs = max(3,max(r["epoch"] for r in monitor))
    low = min(r["F"] for r in monitor)-.02
    high = max(r["F"] for r in monitor)+.02
    x = lambda e: 90+e/epochs*600
    y = lambda f: 320-(f-low)/(high-low)*240
    svg = ['<svg xmlns="http://www.w3.org/2000/svg" width="760" height="420" viewBox="0 0 760 420">',
           '<rect width="760" height="420" fill="white"/>',
           '<g font-family="Arial, sans-serif" fill="#243047">',
           '<text x="70" y="35" font-size="20">DQN frozen monitoring: lower F is better</text>',
           '<path d="M90 70V320H710" fill="none" stroke="#7c8799"/>']
    for index in range(5):
        value = low+(high-low)*index/4
        pos = y(value)
        svg.append(f'<path d="M90 {pos}H710" stroke="#e8ecf0"/><text x="22" y="{pos+5}" font-size="13">{value:.3f}</text>')
    for epoch in range(epochs+1):
        svg.append(f'<text x="{x(epoch)-4}" y="345" font-size="14">{epoch}</text>')
    for index,case in enumerate(sorted({r["case"] for r in monitor})):
        group = sorted((r for r in monitor if r["case"]==case),key=lambda r:r["epoch"])
        color = ["#2463bc","#bc5424","#358052","#8c4dac"][index%4]
        points = " ".join(f'{x(r["epoch"])},{y(r["F"])}' for r in group)
        svg.append(f'<polyline points="{points}" fill="none" stroke="{color}" stroke-width="3"/>')
        for row in group:
            svg.append(f'<circle cx="{x(row["epoch"])}" cy="{y(row["F"])}" r="5" fill="{color}"/>')
            svg.append(f'<text x="{x(row["epoch"])-25}" y="{y(row["F"])-13}" font-size="13">{row["F"]:.5f}</text>')
        svg.append(f'<text x="{110+index*180}" y="385" font-size="13" fill="{color}">{html.escape(case)}</text>')
    svg.append('<text x="338" y="365" font-size="14">Training epoch</text></g></svg>')
    target = folder/"learning_curve.svg"
    if target.exists():
        target.read_text(encoding="utf-8")
    target.write_text("\n".join(svg),encoding="utf-8")
    print(target)


if __name__ == "__main__":
    main()
