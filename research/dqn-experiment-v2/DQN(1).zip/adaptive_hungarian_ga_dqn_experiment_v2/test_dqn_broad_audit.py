"""用已落盘真实小时轨迹检验审计器能拒绝损坏证据，不启动仿真。"""
import copy
import json
import unittest
from paths import ROOT
from summarize_dqn_broad import audit_row


class BroadAuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.row=json.loads((ROOT/'results/dqn_broad_v1/train_00.json').read_text(encoding='utf-8'))

    def test_real_record(self):
        audit_row(self.row)

    def test_corrupt_evidence_rejected(self):
        # 分别破坏物理目标、累计奖励、分项奖励、终局以及有限损失。
        changes=[lambda r:r.update(F=r['F']+.01),
                 lambda r:r.update(learning_reward_sum=r['learning_reward_sum']+.01),
                 lambda r:r['transitions'][0]['reward_terms'].update(T=123),
                 lambda r:r['transitions'][-1].update(done=False),
                 lambda r:r.update(losses=[float('nan')])]
        for change in changes:
            row=copy.deepcopy(self.row)
            change(row)
            with self.assertRaises(AssertionError):
                audit_row(row)


if __name__=='__main__':
    unittest.main()
