"""重验资源链同预算消融的物理轨迹、源身份与配对收益，不重跑调度。"""
import argparse
import gzip
import json
from paths import ROOT, sha
from objective import LinearObjective, checked_score
from wepa.data import build
from adaptive_hungarian_learning import audit_adaptation
from headroom_physics import analyze_physics
from audit_search_headroom import audit_folder, corrected_budget_totals, _same
from run_search_headroom import read_json, commit, PROTOCOL, frozen_identity, audit_budget


def audit(folder):
    folder=(ROOT/folder).resolve()
    manifest=read_json(folder/'manifest.json')
    _same(manifest['identity'],frozen_identity(),'identity')
    for name,digest in manifest['hashes'].items():
        _same(sha(ROOT/name),digest,'source.'+name)
    protocol=read_json(PROTOCOL)
    cases={c['case']:c for c in protocol['cases']}
    baseline=audit_folder(ROOT/'results/search_headroom_v1')
    bases={r['case']:r for r in baseline['rows'] if r['budget_name']=='baseline' and r['seed']==0}
    objective=LinearObjective(**protocol['objective'])
    rows=[]
    pairs=[]
    for index,name in enumerate(manifest['cases']):
        episode=folder/f'episode_{index:03d}.json'
        if not episode.exists():
            continue
        digest=sha(episode)
        row=read_json(episode)
        _same(row['case'],name,'case')
        _same(row['seed'],0,'seed')
        # 种群/精英由共享GA的适应元信息检查；row预算只存proxy/generations/previews。
        _same(row['budget'],{k:manifest['budget'][k] for k in ('proxy','generations','previews')},'budget')
        _same(row['intervention'],'resource_chain_one_seed','intervention')
        _same(row['source_day'],cases[name]['source_day'],'source_day')
        expected=f'trajectory_{index:03d}.json.gz'
        _same(row['trajectory_file'],expected,'trajectory_file')
        raw=folder/expected
        if raw.is_symlink() or raw.resolve().parent!=folder:
            raise ValueError('Trajectory escaped folder')
        _same(sha(raw),row['trajectory_sha256'],'trajectory_sha256')
        trajectory=json.loads(gzip.decompress(raw.read_bytes()))
        model=build(cases[name],**protocol['configuration'])
        score=checked_score(model,trajectory,objective)
        _same(row['F'],score['F_linear_v2'],'F')
        for key in ('T','R','D','traffic_wait'):
            _same(row[key],trajectory[key],key)
        _same(row['physics'],analyze_physics(model,trajectory,objective),'physics')
        for key,value in trajectory['dqn'].items():
            _same(row.get(key),value,'dqn.'+key)
        _same(trajectory['method'],'rl','method')
        _same(trajectory['objective_sha256'],objective.fingerprint,'objective_sha256')
        audit_adaptation(row)
        _same(row['budget_audit'],audit_budget(row,trajectory['search_log'],row['budget']),'budget_audit')
        if len(row['resource_seed_log'])!=len(row['ga_searches']):
            raise ValueError('Seed injection/search accounting mismatch')
        row['corrected_budget_totals']=corrected_budget_totals(trajectory['search_log'])
        _same(sha(episode),digest,'episode_changed_during_audit')
        rows.append(row)
        if name in bases:
            b=bases[name]
            pairs.append(dict(case=name,source_day=row['source_day'],baseline_F=b['F'],candidate_F=row['F'],
                improvement_pct=100*(1-row['F']/b['F']),
                component_reduction={k:b['physics']['weighted_terms'][k]-row['physics']['weighted_terms'][k] for k in ('T','R','D')},
                baseline_cost=b['corrected_budget_totals'],candidate_cost=row['corrected_budget_totals'],
                injections=sum(x['injected'] for x in row['resource_seed_log'])))
    result=dict(valid=True,complete=len(rows)==len(manifest['cases']) and len(pairs)==len(rows),rows=rows,pairs=pairs,
        mean_paired_improvement_pct=sum(p['improvement_pct'] for p in pairs)/len(pairs) if pairs else None,
        qualification='同每次搜索预算；实际搜索次数可能变化；仅开发证据，不是新日期泛化')
    commit(folder,'audit.json',result)
    text=['# 资源链初始化同预算消融', '', result['qualification'], '',
          '| 日期 | 原GA F | 资源链GA F | 改善率 | 注入次数 |', '|---|---:|---:|---:|---:|']
    for p in pairs:
        text.append(f"| {p['source_day']} | {p['baseline_F']:.6f} | {p['candidate_F']:.6f} | {p['improvement_pct']:+.3f}% | {p['injections']} |")
    text+=['',f"已完成{len(rows)}/{len(manifest['cases'])}候选窗口，已有{len(pairs)}个原预算配对。",'',
           '只改一个外部初始化种子，保留第一匈牙利种子；正式F、物理规则、GA算子和适应率不变。不得把尚未完成或失败的结果称为成功改进。','',
           '## 实际计算量', '',
           '| 日期 | 原GA搜索 | 候选搜索 | 原GA代理评估 | 候选代理评估 | 原GA预览 | 候选预览 | 原GA预览路由查询 | 候选预览路由查询 |',
           '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    by_case={r['case']:r for r in rows}
    for p in pairs:
        b=bases[p['case']]['budget_audit']
        c=by_case[p['case']]['budget_audit']
        bc,cc=p['baseline_cost'],p['candidate_cost']
        text.append(f"| {p['source_day']} | {b['searches']} | {c['searches']} | {b['proxy_evaluations']} | {c['proxy_evaluations']} | {bc['physical_previews_total']} | {cc['physical_previews_total']} | {bc['rollout_route_calls_total']} | {cc['rollout_route_calls_total']} |")
    text+=['', '相同每次搜索上限不保证相同整窗计算量。预览包含失败锚点，路由查询仅计预览；并行运行耗时不能用于速度结论。', '']
    (folder/'同预算结果.md').write_text('\n'.join(text),encoding='utf-8')
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',default='results/resource_chain_v1')
    r=audit(p.parse_args().input)
    print(json.dumps({k:r[k] for k in ('valid','complete','pairs','mean_paired_improvement_pct')},ensure_ascii=False),flush=True)
