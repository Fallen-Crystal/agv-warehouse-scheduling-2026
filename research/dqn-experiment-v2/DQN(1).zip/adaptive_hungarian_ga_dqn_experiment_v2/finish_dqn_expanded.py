"""全部训练完成后统一审计、冻结复验并汇总；可安全重用已验证复验文件。"""
import json
import subprocess
import sys
from pathlib import Path
from paths import ROOT
from summarize_dqn_expanded import summarize, plot
from verify_dqn_expanded_replays import verify


def save_json(path, data):
    if path.exists():
        path.read_text(encoding='utf-8')
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def main():
    root = ROOT / 'results/dqn_expanded_v1'
    # 必须先确认93条全部有效，缺数据时在任何复验启动前停止。
    report = summarize(root)
    for seed in (0, 1, 2):
        folder = root / f's{seed}'
        output = folder / 'final_replay.json'
        if not output.exists():
            # 继承终端流，避免管道及跨进程缓冲；失败立即停止，不产生完整结论。
            subprocess.run([sys.executable, '-B', str(ROOT / 'evaluate_dqn.py'),
                            '--checkpoint', str(folder / 'epoch6.npz'), '--seed', str(seed),
                            '--cases', 'wepa-day40-bin3885', '--output', str(output)],
                           cwd=ROOT, check=True)
    verified = verify(root)
    save_json(root / 'replay_verification.json', verified)
    save_json(root / 'aggregate.json', report)
    plot(report, root / 'learning_curves.svg')
    # 只在全部训练和独立复验均成功后生成结果说明，避免留下半成品结论。
    lines = ['# 增强DQN扩大实验结果', '',
             '正式F、物理规则、GA预算和增强DQN配置保持不变。3个seed各6轮，93/93条记录有效：其中72条为开发窗口训练记录（每seed每轮4窗），21条为day40冻结监测记录（每seed含初始及6轮监测）。训练窗口成绩不作为冻结监测成绩；最终检查点均通过独立冻结复验。', '',
             '第6轮为预定主要终点；改善率为(初始F−最终F)/初始F。', '',
             '| seed | 初始F | 第3轮F | 第6轮F | 相对初始改善 | 更新数 | 经验数 |',
             '|---|---:|---:|---:|---:|---:|---:|']
    for row in report['per_seed']:
        lines.append(f"| {row['seed']} | {row['initial_F']:.9f} | {row['epoch3_F']:.9f} | {row['final_F']:.9f} | {row['improvement_percent']:.3f}% | {row['train_steps']} | {row['replay_size']} |")
    final = report['epochs'][-1]
    lines += ['', f"第6轮跨seed平均F为{final['mean_F']:.9f}，样本标准差为{final['sample_sd_F']:.9f}；相对各自初始值的平均配对改善率为{final['mean_paired_improvement_percent']:.3f}%，改善seed数为{report['improved_seeds']}/3。", '',
              '## 逐轮冻结结果', '',
              '| 轮次 | seed0 F | seed1 F | seed2 F | 平均F |',
              '|---|---:|---:|---:|---:|']
    for row in report['epochs']:
        values = ' | '.join(f'{value:.9f}' for value in row['F_by_seed'])
        lines.append(f"| {row['epoch']} | {values} | {row['mean_F']:.9f} |")
    lines += ['', '## 证据与局限', '',
              '- 每窗审计正式F、完整奖励、初始成本与学习奖励、T/R/D奖励分项、终局掩码及更新计数。',
              '- 独立复验核对检查点哈希，精确比对F、T/R/D、动作及转移记录；冻结期间权重、目标网络、优化器、经验池、随机数状态不变。',
              '- 源码身份与191个冻结基线文件重新校验。',
              '- 单个历史使用过的监测窗口、三个seed，仅为探索性证据；不能证明收敛、统计显著性或泛化。',
              '- seed同时影响网络、探索、训练顺序和仿真随机性。中间最优轮仅作描述，不能替换第6轮终点。',
              '- 相对初始策略改善不等于超过固定GA或旧版DQN；本轮未生成所有seed的固定分支配对对照。', '',
              '完整证据见results/dqn_expanded_v1下的aggregate.json、replay_verification.json、source_identity.json、learning_curves.svg以及各seed目录。']
    target = ROOT / 'docs/DQN扩大实验结果.md'
    if target.exists():
        target.read_text(encoding='utf-8')
    target.write_text('\n'.join(lines)+'\n', encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
