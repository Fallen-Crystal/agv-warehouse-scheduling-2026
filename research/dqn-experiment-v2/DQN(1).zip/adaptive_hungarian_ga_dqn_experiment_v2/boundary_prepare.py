"""Freeze the screenshot-aligned ready/idle threshold experiment."""
import copy
import hashlib
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent


def prepare():
    original=json.loads((ROOT/'data/protocol.json').read_text(encoding='utf-8'))
    cases=[]
    for source in original['cases']:
        case=copy.deepcopy(source)
        case.update(source_case=source['case'],load_level='full')
        cases.append(case)
    thresholds={'ga':0,'t05':0.5,'t1':1,'t15':1.5,'t2':2,'t3':3,'matching':'inf'}
    protocol=dict(version='ready-idle-20261102-v2',
        source_commit='d1d36f1fc7484f5f435b171ff72e3de9519429c0',
        source_protocol_sha256=hashlib.sha256((ROOT/'data/protocol.json').read_bytes()).hexdigest(),
        objective=original['objective'],configuration=original['configuration'],
        development=original['development'],validation=original['validation'],
        development_seeds=[0,1,2],validation_seeds=[0,1,2],thresholds=thresholds,
        arms={**{k:dict(threshold=v,keep_closed_rule=False) for k,v in thresholds.items()},
              'original':dict(threshold=1,keep_closed_rule=True)},load_levels=['full'],
        selection='Among t05,t1,t15,t2,t3, minimize development paired F/original.F, first averaging seeds within source date then equally weighting dates. Invalid/timeout disqualifies a candidate. Ties within 1e-9: lower CPU, then smaller threshold. Freeze selection before validation. Report F vs CPU tradeoff separately; retain default original unless validation paired mean F improves and all runs are valid.',
        validation_arms=['original','ga','matching','DEVELOPMENT_SELECTED'],
        limits=dict(wall_seconds=900,workers=2),
        scope='Eight untouched original main-scenario windows. Three seeds per arm. Development 96 runs, validation 48. Previously published validation windows are reused confirmation, not fresh external holdout. Date is the independent unit. Earlier 140 pending/idle synthetic-load runs are auxiliary evidence only and do not enter ready-threshold selection.',
        closed_rule='Threshold arms use ready/idle before and after stream closure; original retains pending/idle plus forced GA at closure. Thus t1 vs original changes both numerator and closure policy and does NOT isolate closure.',
        online_ratio='currently executable released unassigned tasks (world.ready) / currently idle vehicles; wait when either count is zero',
        scenario_ratio='total original window tasks / 6; offline description only',cases=cases)
    path=ROOT/'boundary_protocol.json'
    text=json.dumps(protocol,ensure_ascii=False,indent=2)
    if path.exists() and path.read_text(encoding='utf-8')!=text:
        raise ValueError('Refuse to alter frozen protocol')
    path.write_text(text,encoding='utf-8')
    print('Frozen original windows:',len(cases),'development trials: 96; validation trials: 48')

if __name__=='__main__':
    prepare()
