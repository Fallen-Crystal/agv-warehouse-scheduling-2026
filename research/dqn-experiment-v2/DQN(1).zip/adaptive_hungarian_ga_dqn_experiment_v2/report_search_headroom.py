"""从已提交开发诊断生成中文报告；不执行调度，不读取正式测试轨迹。"""
import argparse
from pathlib import Path

from run_search_headroom import read_json, summarize, commit
from audit_search_headroom import audit_folder


def render(folder):
    folder = Path(folder).resolve()
    manifest = read_json(folder/'manifest.json')
    if manifest['version'] != 'search-headroom-v1':
        raise ValueError('Unknown diagnostic manifest')
    # 报告前重验已提交轨迹、物理账本、预算与源身份；不重跑任何调度。
    verification = audit_folder(folder)
    rows = verification['rows']
    summary = summarize(rows)
    complete = verification['complete']
    planned_runs = verification['planned_runs']
    lines = ['# 开发集搜索空间诊断结果', '',
             f"状态：{'全部完成' if complete else '部分完成，不能当作完整实验结论'}；{len(rows)}/{planned_runs}次仿真。",
             '', '## 口径', '',
             '- 仅训练/验证开发数据；没有执行既有正式测试日期。',
             '- 原正式F、物理规则、自适应GA和计划缓存不变。',
             '- 超预算搜索仅检查可改善空间，不是同预算算法胜出或最优性证明。',
             '- 预先按训练订单数选择低/中/高窗口，不依据策略成绩挑选。',
             '- 当前种子为'+str(manifest['seeds'])+'；小样本诊断不支持统计显著性和泛化宣称。',
             '', '## 配对F变化', '',
             '| 日期 | seed | 预算组 | 原预算F | 诊断F | 改善率 |',
             '|---|---:|---|---:|---:|---:|']
    by_case = {c['case']:c['source_day'] for c in manifest['cases']}
    for p in summary['pairs']:
        lines.append(f"| {by_case[p['case']]} | {p['seed']} | {p['budget_name']} | {p['baseline_F']:.6f} | {p['diagnostic_F']:.6f} | {p['improvement_pct']:+.3f}% |")
    lines += ['', '正数表示改善；各组增大的是每次搜索上限，不保证实际用满。', '',
              '| 预算组 | 已有配对窗口数 | 平均配对改善率 | 胜/平/负 |',
              '|---|---:|---:|---|']
    for name, item in summary['aggregate'].items():
        lines.append(f"| {name} | {item['n']} | {item['mean_paired_improvement_pct']:+.3f}% | {item['wins']}/{item['ties']}/{item['losses']} |")
    lines += ['', '## 实际计算量', '',
              '| 日期 | seed | 组 | 成功搜索数 | 代理评估数 | 全部物理预览 | 预览路由查询 | 执行及原校验秒 | 含诊断总秒 |',
              '|---|---:|---|---:|---:|---:|---:|---:|---:|']
    for r in rows:
        a=r['budget_audit']
        c=r['corrected_budget_totals']
        lines.append(f"| {r['source_day']} | {r['seed']} | {r['budget_name']} | {a['searches']} | {a['proxy_evaluations']} | {c['physical_previews_total']} | {c['rollout_route_calls_total']} | {r['execution_wall']:.1f} | {r['diagnostic_wall']:.1f} |")
    lines += ['', '全部物理预览包含失败锚点；预览路由查询不含真实执行的额外查询。执行耗时包含原轨迹评分/奖励校验，总耗时另含新增物理账本诊断；均不是独立重复的纯搜索速度基准。搜索次数可能因轨迹改变而变化。', '',
              '## 原预算物理成本与放宽下界', '',
              '| 日期 | T | R | D | 正式F | 放宽F下界 | 理论可改善上限（较松） |',
              '|---|---:|---:|---:|---:|---:|---:|']
    for r in rows:
        if r['budget_name']!='baseline':
            continue
        p=r['physics']
        lines.append(f"| {r['source_day']} | {r['T']} | {r['R']:.3f} | {r['D']} | {r['F']:.6f} | {p['lower_bounds']['F']:.6f} | {100*p['gaps']['F_reduction_ceiling_fraction']:.2f}% |")
    lines += ['', '**下界间隙不是可实现的收益**：它放宽障碍、碰撞、库存、槽位一致性等约束。即使间隙很大，也不能承诺获得同等改善。', '',
              '## 原预算响应时间分解（每订单平均秒）', '',
              '| 日期 | 分配前 | 空载移动 | 空载静止 | 取货服务 | 载货移动 | 载货静止 | 放货服务 |',
              '|---|---:|---:|---:|---:|---:|---:|---:|']
    keys=('pre_assignment','empty_moves','empty_stationary','pickup_service','loaded_moves','loaded_stationary','drop_service')
    for r in rows:
        if r['budget_name']=='baseline':
            parts=r['physics']['response_time']['mean_steps']
            lines.append('| '+str(r['source_day'])+' | '+' | '.join(f'{parts[k]:.3f}' for k in keys)+' |')
    lines += ['', '各项严格加总为R。分配前时间混合车辆繁忙、库存/槽位条件、调度等影响，不全是可消除的策略损失。', '',
              '## 两类预算同时增加时的F分项变化', '',
              '| 日期 | T贡献下降 | R贡献下降 | D贡献下降 | 合计F下降 |',
              '|---|---:|---:|---:|---:|']
    for p in summary['pairs']:
        if p['budget_name']=='both4x':
            d=p['weighted_component_reduction']
            lines.append(f"| {by_case[p['case']]} | {d['T']:+.6f} | {d['R']:+.6f} | {d['D']:+.6f} | {sum(d.values()):+.6f} |")
    lines += ['', '这是加权成本账本，不是拥堵或调度错误的因果归因。', '',
              '## 后续判断原则', '',
              '1. 代理搜索扩展有效时，检查候选生成、局部邻域和学习算子选择。',
              '2. 物理预览扩展有效时，检查代理排序与实际路径成本的偏差，争取同预算筛选改进。',
              '3. 两者都弱时结合物理分项继续定位；更强启发式未改善不能证明接近最优。',
              '4. 真正的算法改进需在原预算下重新比较，并用新留出日期和多seed确认。', '']
    output=folder/'诊断结果.md'
    output.write_text('\n'.join(lines), encoding='utf-8')
    commit(folder, 'verified_summary.json', dict(summary, complete=complete, planned_runs=planned_runs))
    return output


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', default='results/search_headroom_v1')
    args=parser.parse_args()
    print(render(args.input))
