"""Train the RL scheduler across development windows, then freeze and validate."""
import argparse
import json
import time
from pathlib import Path

from paths import ROOT, verify_baseline
from objective import LinearObjective, checked_score
from improved.execute import run
from rl_scheduler import ContextualSelector
from wepa.data import build

DEFAULT_DEV = ["wepa-day12-bin1164", "wepa-day32-bin3113",
               "wepa-day33-bin3229", "wepa-day45-bin4335"]
DEFAULT_VAL = ["wepa-day40-bin3885", "wepa-day61-bin5902",
               "wepa-day83-bin7983", "wepa-day87-bin8393"]


def execute_case(case, protocol, selector, seed, train_enabled):
    objective = LinearObjective(**protocol["objective"])
    model = build(case, **protocol["configuration"])
    selector.train_enabled = train_enabled
    policy_factory = lambda *, seed, objective: __import__(
        "improved.policy", fromlist=["ResearchPolicy"]
    ).ResearchPolicy("rl", seed, objective=objective, selector=selector)
    start = time.perf_counter()
    result = run(model, "rl", seed, objective=objective,
                 policy_factory=policy_factory)
    score = checked_score(model, result, objective)
    return dict(case=case["case"], valid=bool(result["valid"] and score["audit"]["valid"]),
                F=score["F_linear_v2"], T=result["T"], R=result["R"], D=result["D"],
                p90=result["p90"], traffic_wait=result["traffic_wait"],
                tasks=len(case["tasks"]), wall=time.perf_counter() - start,
                actions=len(selector.logs), weights={k: list(v) for k, v in selector.weights.items()})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rounds", type=int, default=3)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    target = Path(args.output).resolve()
    if target.exists():
        raise ValueError("Refuse to overwrite an experiment")
    protocol = json.loads((ROOT / "data/protocol.json").read_text(encoding="utf-8"))
    verify_baseline()
    by_name = {case["case"]: case for case in protocol["cases"]}
    selector = ContextualSelector(seed=args.seed, epsilon=0.05, train_enabled=True)
    training = []
    for epoch in range(args.rounds):
        for name in DEFAULT_DEV:
            row = execute_case(by_name[name], protocol, selector, args.seed, True)
            training.append(dict(epoch=epoch + 1, **row))
            print(json.dumps(dict(epoch=epoch + 1, **row), ensure_ascii=False), flush=True)
    # Freeze both learning and exploration before held-out evaluation.
    selector.train_enabled = False
    selector.epsilon = 0.0
    validation = []
    for name in DEFAULT_VAL:
        row = execute_case(by_name[name], protocol, selector, args.seed, False)
        validation.append(row)
        print(json.dumps(dict(validation=True, **row), ensure_ascii=False), flush=True)
    output = dict(config=vars(args), development_cases=DEFAULT_DEV,
                  validation_cases=DEFAULT_VAL, training=training,
                  validation=validation, frozen_weights={k: list(v) for k, v in selector.weights.items()},
                  objective=protocol["objective"])
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(dict(output=str(target), rounds=args.rounds,
                          validation_valid=all(x["valid"] for x in validation)), ensure_ascii=False))


if __name__ == "__main__":
    main()
