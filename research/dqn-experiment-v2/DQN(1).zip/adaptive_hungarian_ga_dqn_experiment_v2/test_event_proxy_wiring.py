"""小型完整物理接线：事件代理仍用共享自适应GA和原预算。"""
import unittest
from run_event_proxy_pilot import execute_event
from run_search_headroom import PROTOCOL,read_json
from adaptive_hungarian_learning import audit_adaptation


class EventWiringTests(unittest.TestCase):
    def test_four_orders(self):
        protocol=read_json(PROTOCOL)
        case=dict(case='event-proxy-synthetic',close_at=30,initial={'1':4},tasks=[
            dict(id=i,sku=1,kind=kind,release=release,source_dock=1)
            for i,(kind,release) in enumerate([
                ('retrieval',0),('delivery',4),('retrieval',12),('delivery',20)])])
        row,trajectory=execute_event(case,protocol)
        self.assertTrue(trajectory['valid'])
        audit_adaptation(row)
        self.assertEqual(row['budget'],dict(proxy=192,generations=16,previews=6))
        self.assertAlmostEqual(sum(row['physics']['weighted_terms'].values()),row['F'])


if __name__=='__main__':
    unittest.main()
