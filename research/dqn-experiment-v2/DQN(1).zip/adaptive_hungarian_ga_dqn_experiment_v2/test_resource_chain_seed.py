"""资源链初始化只提供候选，不消耗额外代理评分或读取未来。"""
import unittest
from types import SimpleNamespace
from resource_chain_seed import resource_seed, inject_seed


class Costs:
    def __init__(self):
        self.world=SimpleNamespace(time=0,active=[None,None],plans=[[(0,0)],[(9,0)]],locks={})
        self.jobs={j:dict(id=j,kind='retrieval',release=0) for j in range(3)}
        self.slots={0:dict(bay=0),1:dict(bay=0),2:dict(bay=1)}
        self.predecessor={1:0}
        self.cache={}
        self.evaluations=0

    def details(self,k,position,job):
        jid=job['id']
        pickup=(jid*3,0)
        drop=(5,0)
        approach=abs(position[0]-pickup[0])
        distance=approach+abs(pickup[0]-drop[0])
        self.cache[k,tuple(position),jid]=(distance,approach,pickup,drop,2,1)
        return distance,approach,pickup


class ResourceSeedTests(unittest.TestCase):
    def test_complete_deterministic_chain_seed_without_proxy_evaluations(self):
        costs=Costs()
        order=[2,0,1]
        owners={0:1,1:1,2:1}
        first=resource_seed(costs,order,owners)
        self.assertEqual(first,resource_seed(costs,order,owners))
        self.assertEqual(first[0][0],0)
        self.assertLess(first[0].index(0),first[0].index(1))
        self.assertEqual(set(first[0]),set(order))
        self.assertEqual(set(first[1]),set(order))
        self.assertEqual(costs.evaluations,0)
        self.assertEqual(costs.world.locks,{})
        self.assertEqual(costs.world.active,[None,None])

    def test_injection_retains_first_hungarian_and_limits_to_two_seeds(self):
        costs=Costs()
        order=[2,0,1]
        owners={0:1,1:1,2:1}
        old=[(order,owners,'hungarian_duration'),(order,{0:0,1:0,2:0},'hungarian_linear')]
        seeds,meta=inject_seed(costs,order,owners,old)
        self.assertTrue(meta['injected'])
        self.assertEqual(len(seeds),2)
        self.assertEqual(seeds[0],old[0])
        self.assertEqual(seeds[1][2],'resource_chain_seed')
        self.assertEqual(meta['extra_proxy_evaluations'],0)
        self.assertEqual(meta['extra_physical_previews'],0)

    def test_cycle_falls_back_and_duplicate_does_not_replace_seed(self):
        costs=Costs()
        costs.predecessor={0:1,1:0,2:2}
        seeds,meta=inject_seed(costs,[0,1,2],{j:0 for j in range(3)},[])
        self.assertFalse(meta['injected'])
        self.assertEqual(seeds,[])
        costs=Costs()
        candidate=resource_seed(costs,[0,1,2],{j:0 for j in range(3)})
        seeds,meta=inject_seed(costs,*candidate[:2],[])
        self.assertFalse(meta['injected'])
        self.assertEqual(seeds,[])


if __name__=='__main__':
    unittest.main()
