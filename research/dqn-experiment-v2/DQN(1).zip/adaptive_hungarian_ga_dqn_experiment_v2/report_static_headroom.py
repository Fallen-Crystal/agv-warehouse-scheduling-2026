"""对已提交原预算开发轨迹增加障碍保留界；不重跑仿真。"""
from paths import ROOT,sha
from run_search_headroom import read_json,commit,PROTOCOL
from audit_search_headroom import audit_folder
from headroom_static_bounds import static_lower_bounds
from wepa.data import build
from objective import LinearObjective


def main():
    folder=ROOT/'results/search_headroom_v1'
    verified=audit_folder(folder)
    protocol=read_json(PROTOCOL)
    cases={c['case']:c for c in protocol['cases']}
    objective=LinearObjective(**protocol['objective'])
    rows=[]
    for row in verified['rows']:
        if row['budget_name']!='baseline':
            continue
        model=build(cases[row['case']],**protocol['configuration'])
        bounds=static_lower_bounds(model,objective)
        if any(bounds[k]>row[k]+1e-9 for k in ('T','R','D','F')):
            raise ValueError('Claimed bound exceeds validated feasible execution')
        rows.append(dict(case=row['case'],source_day=row['source_day'],F=row['F'],bounds=bounds,
                         F_reduction_ceiling_pct=100*(1-bounds['F']/row['F'])))
    commit(folder,'static_bounds.json',dict(rows=rows,complete=verified['complete'],
        source_hashes={n:sha(ROOT/n) for n in ('headroom_static_bounds.py','report_static_headroom.py')},
        qualification='All-slot obstacle-preserving relaxation; no attainability or optimality claim'))
    print([(r['source_day'],r['F'],r['bounds']['F'],r['F_reduction_ceiling_pct']) for r in rows],flush=True)


if __name__=='__main__':
    main()
