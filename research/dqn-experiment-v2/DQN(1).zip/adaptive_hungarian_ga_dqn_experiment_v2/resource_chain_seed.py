"""用已发布任务的货架阻塞链构造GA初始解；不增加代理/物理预览额度。

只替换最多两个外部初始解中的一个，保留另一匈牙利种子。链信息来自
当前可见任务和锚点绑定，不能改变WMS实际分配，也不读取未发布订单。
"""
from math import isfinite


def resource_seed(costs, order, owners):
    """事件驱动的无预约列表构造：先释放长阻塞链，再选近且较早空闲车辆。

    此为候选启发式，不改变正式评分。沿用代理的predecessor约束，增加
    对仍有多少后继受同一bay影响的优先级。距离调用复用MixedCosts缓存，
    不调用estimate_joint/rollout；最终GA评估消耗原192上限。
    """
    if not order:
        return None
    world = costs.world
    pending = set(order)
    remaining = {}
    for jid in order:
        bay = costs.slots[jid]['bay']
        remaining[bay] = remaining.get(bay, 0) + 1
    times = [r['end'] if r else world.time for r in world.active]
    positions = [r['drop'] if r else world.plans[k][0] for k, r in enumerate(world.active)]
    locks = dict(world.locks)
    result, assigned = [], {}
    clock = world.time
    while pending:
        ready = [j for j in sorted(pending)
                 if costs.predecessor.get(j) not in pending
                 and locks.get(costs.slots[j]['bay'], 0) <= clock]
        cars = [k for k, t in enumerate(times) if t <= clock]
        options = []
        for jid in ready:
            bay = costs.slots[jid]['bay']
            for k in cars:
                costs.details(k, positions[k], costs.jobs[jid])
                distance, approach, pickup, drop, ps, ds = costs.cache[k, tuple(positions[k]), jid]
                if not isfinite(distance):
                    continue
                # 检索在pickup结束释放bay，入库在drop结束释放；越长链越优先。
                unlock = approach + ps if costs.jobs[jid]['kind']=='retrieval' else distance + ps + ds
                options.append((-(remaining[bay]-1), unlock, distance+ps+ds,
                                costs.jobs[jid]['release'], jid, k, distance, drop, ps, ds, approach))
        if not options:
            events = [t for t in times if t > clock] + [t for t in locks.values() if t > clock]
            if not events:
                return None
            clock = min(events)
            continue
        _, _, _, _, jid, k, distance, drop, ps, ds, approach = min(options)
        finish = clock + distance + ps + ds
        times[k], positions[k] = finish, drop
        bay = costs.slots[jid]['bay']
        locks[bay] = clock + approach + ps if costs.jobs[jid]['kind']=='retrieval' else finish
        remaining[bay] -= 1
        pending.remove(jid)
        result.append(jid)
        assigned[jid] = k
    return result, assigned, 'resource_chain_seed'


def inject_seed(costs, order, owners, seed_plans):
    """保持原种群12：只替换一个随机/匈牙利初始化位置，不额外扩大种群。"""
    original = list(seed_plans or [])[:2]
    candidate = resource_seed(costs, order, owners)
    if candidate is None:
        return original, dict(injected=False, reason='construction_incomplete')
    key = lambda p: (tuple(p[0]), tuple(p[1][j] for j in p[0]))
    if key(candidate) in {key((order, owners)), *(key(p) for p in original)}:
        return original, dict(injected=False, reason='duplicate')
    return original[:1] + [candidate], dict(injected=True, reason='resource_chain',
        retained_hungarian_seeds=min(1,len(original)), extra_proxy_evaluations=0,
        extra_physical_previews=0, uses_unpublished=False)
