"""Small synthetic-only physical-bound tests; no formal test dates are loaded."""
import copy
import json
from types import SimpleNamespace
import unittest

import paths
from objective import LinearObjective
from wepa.data import build
from improved.execute import run
from headroom_physics import analyze_physics, lower_bounds


class HeadroomPhysicsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # A self-contained four-order physical smoke case, not a source-day slice.
        case = dict(case='headroom-synthetic-four-orders', close_at=30,
                    initial={'1': 4}, tasks=[
                        dict(id=i, sku=1, kind=kind, release=release, source_dock=1)
                        for i, (kind, release) in enumerate([
                            ('retrieval', 0), ('delivery', 4),
                            ('retrieval', 12), ('delivery', 20)])])
        cls.model = build(case, vehicles=6)
        cls.objective = LinearObjective(vehicles=6)
        cls.result = run(cls.model, method='fcfs', seed=0, objective=cls.objective)

    def test_complete_four_order_bounds_and_exact_ledgers(self):
        before = copy.deepcopy(self.result)
        data = analyze_physics(self.model, self.result, self.objective)
        self.assertTrue(data['audit']['valid'])
        self.assertEqual(data['tasks_count'], 4)
        for key in ('T', 'R', 'D', 'F'):
            self.assertLessEqual(data['lower_bounds'][key], data['formal'][key]+1e-10)
        self.assertAlmostEqual(sum(data['response_time']['mean_steps'].values()), self.result['R'])
        self.assertEqual(sum(data['distance'][k] for k in
                             ('loaded', 'assigned_empty', 'inter_task_unassigned', 'final_home_return')),
                         self.result['D'])
        self.assertAlmostEqual(sum(data['gaps']['weighted_component_excess'].values()),
                               data['gaps']['absolute']['F'])
        self.assertEqual(self.result, before)
        json.dumps(data, allow_nan=False)

    def test_json_roundtrip_trace(self):
        restored = json.loads(json.dumps(self.result))
        data = analyze_physics(self.model, restored, self.objective)
        self.assertEqual(data['formal']['D'], self.result['D'])
        self.assertAlmostEqual(data['formal']['R'], self.result['R'])

    @staticmethod
    def analytic_model(releases=(100,)):
        # Extra scene home must NOT become a second operating vehicle.
        return dict(vehicles=1, scene=SimpleNamespace(homes=[(0, 0), (2, 0)]),
                    slots=[dict(id=0, sku=1, level=1, points=[(2, 0)]),
                           dict(id=1, sku=1, level=5, points=[(1, 0)])],
                    tasks=[dict(id=i, kind='retrieval', sku=1, release=r, port=(5, 0))
                           for i, r in enumerate(releases)])

    def test_release_is_max_not_sum_and_service_uses_all_slots(self):
        data = lower_bounds(self.analytic_model(), LinearObjective(vehicles=1))
        self.assertEqual(data['T'], 106)  # max(100,2) + distance3 + service3
        self.assertEqual(data['R'], 6)
        self.assertEqual(data['D'], 3)
        self.assertEqual(data['tasks'][0]['loaded_plus_service'], 6)
        self.assertEqual(data['latest_release'], 100)

    def test_release_tail_capacity_bound_and_operating_fleet(self):
        data = lower_bounds(self.analytic_model((10, 10, 10, 10)), LinearObjective(vehicles=1))
        self.assertEqual(data['T_individual'], 16)
        self.assertEqual(data['T_release_tail_workload'], 34)
        self.assertEqual(data['T'], 34)
        self.assertEqual(data['D'], 12)

    def test_reject_incomplete_or_inconsistent_metric(self):
        for field, value in (('valid', False), ('R', self.result['R']+1)):
            broken = copy.deepcopy(self.result)
            broken[field] = value
            with self.assertRaises(ValueError):
                analyze_physics(self.model, broken, self.objective)

    def test_reject_inconsistent_labels(self):
        broken = copy.deepcopy(self.result)
        record = broken['records'][0]
        broken['labels'][record['vehicle']][record['pickup_arrival']] = 'empty'
        # It changes reported labeled wait, or the independent interval ledger.
        with self.assertRaises(AssertionError):
            analyze_physics(self.model, broken, self.objective)

    def test_empty_case_has_zero_bounds_and_closure_not_makespan(self):
        model = build(dict(case='headroom-synthetic-empty', close_at=2, initial={}, tasks=[]), vehicles=1)
        objective = LinearObjective(vehicles=1)
        result = run(model, method='fcfs', seed=0, objective=objective)
        data = analyze_physics(model, result, objective)
        self.assertEqual(data['formal'], dict(T=0, R=0, D=0, F=0))
        self.assertEqual(data['lower_bounds']['T'], 0)
        self.assertEqual(data['completion']['end_of_simulation'], 2)
        self.assertEqual(data['gaps']['F_reduction_ceiling_fraction'], 0)

    def test_reject_wrong_speed_or_fleet(self):
        with self.assertRaises(ValueError):
            lower_bounds(self.analytic_model(), LinearObjective(vehicles=2))
        with self.assertRaises(ValueError):
            lower_bounds(self.analytic_model(), LinearObjective(vehicles=1, speed_cells_per_second=2))


if __name__ == '__main__':
    unittest.main()
