"""预先限定day66的小型同预算事件代理试验，不改其他已运行源文件。"""
import gzip
import json
from unittest.mock import patch
from paths import ROOT,sha
from event_proxy import EventCosts
from run_search_headroom import execute_diagnostic,PROTOCOL,read_json,commit,frozen_identity
from adaptive_hungarian_learning import audit_adaptation


def execute_event(case,protocol,seed=0):
    with patch('improved.policy.MixedCosts',EventCosts):
        row,trajectory=execute_diagnostic(case,protocol,'baseline',seed)
    audit_adaptation(row)
    row.update(intervention='event_proxy_keep_anchor_predecessor',
        qualification='同预算开发探索；只改变代理预留语义，非DQN学习或新日期证据')
    return row,trajectory


def main():
    protocol=read_json(PROTOCOL)
    name='wepa-hour-day66-bin1599'
    case=next(c for c in protocol['cases'] if c['case']==name)
    folder=ROOT/'results/event_proxy_pilot_v1'
    folder.mkdir(exist_ok=False)
    identity=frozen_identity()
    sources=('event_proxy.py','run_event_proxy_pilot.py','test_event_proxy.py')
    manifest=dict(identity=identity,hashes={n:sha(ROOT/n) for n in sources},case=name,seed=0,
        budget=dict(proxy=192,generations=16,previews=6),
        selection='Single training pilot fixed before event-proxy execution; previously inspected development date',
        intervention='event_proxy_keep_anchor_predecessor')
    commit(folder,'manifest.json',manifest)
    row,trajectory=execute_event(case,protocol)
    raw=commit(folder,'trajectory_000.json.gz',trajectory,compressed=True)
    row.update(trajectory_file=raw.name,trajectory_sha256=sha(raw))
    commit(folder,'episode_000.json',row)
    baseline=read_json(ROOT/'results/search_headroom_v1/episode_000.json')
    if baseline['case']!=name or baseline['budget_name']!='baseline':
        raise ValueError('Baseline mismatch')
    if frozen_identity()!=identity or any(sha(ROOT/n)!=manifest['hashes'][n] for n in sources):
        raise ValueError('Source changed')
    summary=dict(case=name,baseline_F=baseline['F'],event_F=row['F'],
                 improvement_pct=100*(1-row['F']/baseline['F']),
                 baseline_cost=baseline['budget_audit'],event_cost=row['budget_audit'],
                 qualification='One reused training window, no independent confirmation')
    commit(folder,'summary.json',summary)
    print(json.dumps(summary,ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
