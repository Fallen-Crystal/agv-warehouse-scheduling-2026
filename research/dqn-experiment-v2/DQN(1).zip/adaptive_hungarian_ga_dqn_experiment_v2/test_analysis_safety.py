"""Failure-reference regressions using in-memory outputs, no scheduler runs."""
import contextlib
import io
import json
import unittest
from unittest.mock import patch
import analyze_boundary as analysis


class MemoryOutput:
    def __init__(self, files, name=''):
        self.files,self.name=files,name

    def __truediv__(self, name):
        return MemoryOutput(self.files,name)

    @contextlib.contextmanager
    def open(self, *args, **kwargs):
        stream=io.StringIO()
        yield stream
        self.files[self.name]=stream.getvalue()
        stream.close()

    def exists(self):
        return self.name in self.files

    def write_text(self, text, **kwargs):
        self.files[self.name]=text

    def read_text(self, **kwargs):
        return self.files[self.name]


class AnalysisSafety(unittest.TestCase):
    def sample(self):
        arms=['original','ga','t1']
        protocol=dict(arms={a:dict(threshold=1) for a in arms},load_levels=['full'],
            cases=[dict(case='case',source_case='case')],development=['case'],
            development_seeds=[0,1],selection='paired F')
        rows=[]
        for arm in arms:
            for seed in (0,1):
                rows.append(dict(case='case',source_case='case',seed=seed,arm=arm,
                    load_level='full',F=1.,T=1.,R=1.,D=1.,cpu=1.,p90=1.,
                    empty_distance=1.,traffic_wait=1.,ga_searches=1,
                    matching_events=0,ga_events=0))
        return protocol,arms,rows

    def execute(self, data, expect_failure=False):
        files={}
        with patch.object(analysis,'OUT',MemoryOutput(files)), patch.object(analysis,'load_phase',return_value=data), contextlib.redirect_stdout(io.StringIO()):
            if expect_failure:
                with self.assertRaisesRegex(ValueError,'No eligible threshold'):
                    analysis.summarize('development')
            else:
                analysis.summarize('development')
        summary=json.loads(files['development_summary.json'])
        selected=json.loads(files['selection.json']) if 'selection.json' in files else None
        return summary,selected

    def test_failed_ga_keeps_failure_and_available_comparisons(self):
        protocol,arms,rows=self.sample()
        rows=[r for r in rows if not (r['arm']=='ga' and r['seed']==1)]
        summary,selection=self.execute((protocol,arms,rows,[dict(arm='ga',status='failed')]))
        self.assertEqual(len(summary['failures']),1)
        self.assertFalse(summary['overall']['ga']['eligible'])
        self.assertEqual(selection['selected'],'t1')
        self.assertEqual(next(r for r in summary['by_load'] if r['arm']=='t1')['relative_F_ga'],0)

    def test_missing_original_prevents_incomplete_pair_selection(self):
        protocol,arms,rows=self.sample()
        rows=[r for r in rows if not (r['arm']=='original' and r['seed']==1)]
        summary,selection=self.execute((protocol,arms,rows,[dict(arm='original',status='failed')]),expect_failure=True)
        self.assertFalse(summary['overall']['t1']['eligible'])
        self.assertIsNone(selection)

if __name__=='__main__':
    unittest.main()
