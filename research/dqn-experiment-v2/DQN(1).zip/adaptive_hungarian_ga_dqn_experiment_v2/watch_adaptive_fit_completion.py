"""用Windows目录变更事件等待fit标记，然后执行已有审计门槛；无轮询。"""
import ctypes
from ctypes import wintypes
import json
import os
from pathlib import Path
import subprocess
import sys
from paths import ROOT
from run_adaptive_hungarian_learning import FOLDER


def wait_for_marker(marker,on_ready=None):
    """先订阅目录再检查文件，避免初始化期间漏事件；不打开训练进程。"""
    if os.name!='nt':
        raise RuntimeError('This listener requires Windows directory notifications')
    marker=Path(marker)
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    first=kernel.FindFirstChangeNotificationW
    first.argtypes=[wintypes.LPCWSTR,wintypes.BOOL,wintypes.DWORD]
    first.restype=wintypes.HANDLE
    again=kernel.FindNextChangeNotification
    again.argtypes=[wintypes.HANDLE]; again.restype=wintypes.BOOL
    wait=kernel.WaitForSingleObject
    wait.argtypes=[wintypes.HANDLE,wintypes.DWORD]; wait.restype=wintypes.DWORD
    close=kernel.FindCloseChangeNotification
    close.argtypes=[wintypes.HANDLE]; close.restype=wintypes.BOOL
    handle=first(str(marker.parent),False,0x1|0x10) # 文件名变动与最后写入
    if handle==ctypes.c_void_p(-1).value:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        if on_ready is not None: on_ready()
        while not marker.is_file():
            outcome=wait(handle,0xFFFFFFFF) # 阻塞等待目录事件，不设置轮询超时
            if outcome!=0:
                raise ctypes.WinError(ctypes.get_last_error())
            # 先重订阅再检查，防止检查与下一次等待之间丢失创建事件。
            if not again(handle):
                raise ctypes.WinError(ctypes.get_last_error())
    finally:
        if not close(handle):
            raise ctypes.WinError(ctypes.get_last_error())


def main():
    # 独占启动记录防止重复监听/收尾；不自动删除，供重启时人工复核。
    with (FOLDER/'post_fit_listener_python_started.json').open('x',encoding='utf-8') as stream:
        json.dump(dict(mode='windows_directory_notifications',pid=os.getpid(),experiment=str(FOLDER)),stream)
    print('Windows directory listener armed; waiting for fit_complete.json.',flush=True)
    wait_for_marker(FOLDER/'fit_complete.json')
    print('Completion marker received; post-fit audit will verify its content and hashes.',flush=True)
    # 继承stdio，不创建捕获子进程的管道。收尾入口独立核验60窗/6轮及选模身份。
    subprocess.run([sys.executable,'-B',str(ROOT/'post_fit_adaptive_learning.py')],cwd=ROOT,check=True)


if __name__=='__main__': main()
