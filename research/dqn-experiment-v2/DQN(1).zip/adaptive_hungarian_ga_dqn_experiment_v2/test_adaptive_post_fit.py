"""核对自动收尾不会提前打开未见测试，也不会在评估失败时宣称交付完成。"""
import copy
import io
from contextlib import redirect_stdout
import subprocess
import unittest
from unittest.mock import patch
from paths import ROOT
import post_fit_adaptive_learning as postfit


def fit_report(ratios=None):
    return dict(fit_complete=True,complete=False,selection=dict(epoch=2,
        mean_ratios=ratios or dict(ga=.999,exact=.998,hungarian=.997)))


class PostFitTests(unittest.TestCase):
    def setUp(self):
        self.inputs=self.enterContext(patch.object(postfit,'verify_inputs',return_value=dict(valid=True)))
        self.analyze=self.enterContext(patch.object(postfit,'analyze'))
        self.write=self.enterContext(patch.object(postfit,'write'))
        self.diagnostics=self.enterContext(patch.object(postfit,'training_diagnostics',return_value={'training_only':True}))
        self.run=self.enterContext(patch.object(postfit.subprocess,'run'))
        self.publish=self.enterContext(patch.object(postfit,'publish',return_value=True))
        self.enterContext(patch.object(postfit,'sha',return_value='frozen-model-sha'))
        self.enterContext(redirect_stdout(io.StringIO()))

    def test_invalid_input_provenance_stops_before_test(self):
        self.inputs.side_effect=AssertionError('raw source hash changed')
        with self.assertRaisesRegex(AssertionError,'raw source hash changed'): postfit.main()
        self.analyze.assert_not_called(); self.run.assert_not_called()
        self.write.assert_not_called(); self.publish.assert_not_called()

    def test_source_change_after_test_prevents_publication(self):
        self.inputs.side_effect=[dict(valid=True),AssertionError('raw source changed during test')]
        self.analyze.return_value=fit_report()
        with self.assertRaisesRegex(AssertionError,'during test'): postfit.main()
        self.assertEqual(self.run.call_count,1)
        self.publish.assert_not_called()
        self.assertEqual(self.analyze.call_count,1)

    def test_incomplete_fit_does_not_write_or_open_test(self):
        self.analyze.return_value=dict(fit_complete=False)
        with self.assertRaisesRegex(RuntimeError,'Fit incomplete'): postfit.main()
        self.write.assert_not_called(); self.run.assert_not_called()
        self.diagnostics.assert_not_called(); self.publish.assert_not_called()

    def test_one_unimproved_baseline_preserves_unopened_test(self):
        self.analyze.return_value=fit_report(dict(ga=.999,exact=1.0001,hungarian=.998))
        result=postfit.main()
        self.assertEqual(result['status'],'needs_training_improvement')
        self.assertLess(result['validation_mean_improvement_percent']['exact'],0)
        self.run.assert_not_called(); self.publish.assert_not_called()
        self.diagnostics.assert_called_once_with()

    def test_ready_fit_runs_test_before_report_and_prediction(self):
        final=dict(complete=True,mean_paired_improvement_percent=dict(ga=.01,exact=-.01,hungarian=.005))
        self.analyze.side_effect=[fit_report(),copy.deepcopy(final)]
        result=postfit.main()
        self.assertEqual(self.run.call_count,2)
        commands=[call.args[0] for call in self.run.call_args_list]
        self.assertIn('--phase',commands[0]); self.assertEqual(commands[0][-1],'test')
        self.assertEqual(commands[1][2],'predict_adaptive_hungarian_dqn.py')
        self.assertTrue(all(call.kwargs['check'] for call in self.run.call_args_list))
        self.publish.assert_called_once_with(final)
        self.assertEqual(result['status'],'final_evaluation_complete')
        # 最终评价完成不代表性能达标；负改善原样保留，不能自动重新调参。
        self.assertLess(result['test_mean_improvement_percent']['exact'],0)

    def test_rejected_report_prevents_prediction_and_completion(self):
        # 测试仿真完成也不能绕过发布审计，更不能跳到推断交付。
        self.analyze.side_effect=[fit_report(),dict(complete=False)]
        self.publish.return_value=False
        with self.assertRaisesRegex(RuntimeError,'Final audit/report incomplete'):
            postfit.main()
        self.assertEqual(self.run.call_count,1)
        self.assertFalse(any(call.args[1].get('status')=='final_evaluation_complete'
            for call in self.write.call_args_list))

    def test_failed_prediction_never_records_completion(self):
        # 报告成功不等于推断入口可用；冒烟失败须向调用者传播。
        final=dict(complete=True,mean_paired_improvement_percent=dict(ga=.01,exact=.01,hungarian=.01))
        self.analyze.side_effect=[fit_report(),final]
        self.run.side_effect=[None,subprocess.CalledProcessError(1,['prediction'])]
        with self.assertRaises(subprocess.CalledProcessError):
            postfit.main()
        self.publish.assert_called_once_with(final)
        self.assertEqual(self.run.call_count,2)
        self.assertFalse(any(call.args[1].get('status')=='final_evaluation_complete'
            for call in self.write.call_args_list))

    def test_failed_test_never_publishes_or_runs_prediction(self):
        self.analyze.return_value=fit_report()
        self.run.side_effect=subprocess.CalledProcessError(1,['test'])
        with self.assertRaises(subprocess.CalledProcessError): postfit.main()
        self.assertEqual(self.run.call_count,1); self.publish.assert_not_called()
        self.assertEqual(self.analyze.call_count,1)


if __name__=='__main__': unittest.main()
