"""只替换DQN的matching分支，不改冻结源码、GA分支或物理提交。

same_cost仅替换DP求解器；f_surrogate同时改变瞬时边代价，必须分开解释。
进程内patch局限在单次execute期间，结束即恢复，绝不覆盖历史源码。
"""
from improved.hungarian import minimum_assignment, matching_hungarian


def same_cost_matching(world, scorer=None):
    cars=[k for k,r in enumerate(world.active) if r is None]
    jobs=list(world.ready())
    matrix=[]
    for k in cars:
        row=[]
        for job in jobs:
            estimate=world.estimate(k,job)
            distance=float(estimate[1] if isinstance(estimate,tuple) else estimate)
            value=float(estimate)
            if scorer is not None:
                value-=1e-6*scorer.edge_score(distance=distance,wait=0.)
            row.append(value)
        matrix.append(row)
    # 固定按车辆顺序提交；并列最优解及提交顺序可能与原DP不同。
    pairs=[(cars[i],jobs[j]['id']) for i,j in minimum_assignment(matrix)]
    accepted=[]
    for k,jid in pairs:
        job=next((j for j in world.ready() if j['id']==jid),None)
        if job is None:
            continue
        proposal=world.trip(k,job)
        if proposal is not None:
            world.commit(k,job,proposal)
            accepted.append((k,jid))
    return accepted


def intervention(variant,objective):
    if variant=='same_cost':
        return same_cost_matching
    if variant=='f_surrogate':
        # scorer只用于旧边代价；本变体明确使用正式目标的瞬时代理。
        return lambda world,scorer=None: matching_hungarian(world,objective)[0]
    raise ValueError(variant)
