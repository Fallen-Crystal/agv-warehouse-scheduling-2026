"""Audit saved gate states and summarize per-decision CPU cost."""
from collections import Counter, defaultdict
from statistics import mean, median
import math
import csv
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'boundary_results'


def write_csv(name, rows):
    if rows:
        with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=list(rows[0]))
            writer.writeheader(); writer.writerows(rows)


def main():
    counts=Counter()
    costs=defaultdict(list)
    checked=0
    for phase in ('development','validation'):
        for path in (OUT/phase).glob('*.json'):
            if path.name.endswith('.status.json'):
                continue
            trial=json.loads(path.read_text(encoding='utf-8'))
            arm=trial['row']['arm']
            for event in trial['result']['search_log']:
                if event.get('mode')!='boundary_decision':
                    continue
                visible={t['id'] for t in trial['case']['tasks'] if t['release']<=event['time']}
                assert set(event['visible_ids'])==visible
                assert event['free']>0 and event['ready']>0
                assert event['pending']>=event['ready']
                assert event['pending_per_free']==event['pending']/event['free']
                assert event['ready_per_free']==event['ready']/event['free']
                expected='matching' if event['pending']/event['free']<=float(event['threshold']) else 'ga'
                assert event['branch']==expected
                assert event['closed']==(event['time']>=trial['case']['close_at'])
                ratio=event['pending_per_free']
                bins=[(0.5,'(0,0.5]'),(1,'(0.5,1]'),(1.5,'(1,1.5]'),(2,'(1.5,2]'),(3,'(2,3]')]
                bucket=next((label for bound,label in bins if ratio<=bound),'(3,inf)')
                key=(phase,arm,trial['row']['load_level'],event['closed'],bucket,event['branch'])
                counts[key]+=1
                costs[(phase,arm,event['branch'])].append(event['cpu_seconds'])
                checked+=1
    rows=[dict(zip(('phase','arm','load_level','closed','pending_per_free_bin','branch','decisions'),(*key,count)))
          for key,count in sorted(counts.items())]
    write_csv('decision_states.csv',rows)
    rows=[]
    for (phase,arm,branch),values in sorted(costs.items()):
        ordered=sorted(values)
        rows.append(dict(phase=phase,arm=arm,branch=branch,decisions=len(values),
            mean_cpu_seconds=mean(values),median_cpu_seconds=median(values),
            p95_cpu_seconds=ordered[math.ceil(.95*len(ordered))-1],max_cpu_seconds=max(values)))
    write_csv('decision_costs.csv',rows)
    (OUT/'mechanism_audit.json').write_text(json.dumps(dict(checked_decisions=checked,
        checks=['released-only visible IDs','positive free and ready','ready <= pending','ratio arithmetic','branch satisfies frozen pending/idle threshold','closure matches actual 900s signal'],
        caution='Decision counts and pooled CPU percentiles are descriptive policy-dependent observations, not independent experimental units. P95 uses nearest rank. GA branch may reuse cached plan; ga_searches records actual searches. Original arm has no boundary event instrumentation.'),ensure_ascii=False,indent=2),encoding='utf-8')
    print('Audited boundary decisions:',checked)

if __name__=='__main__':
    main()
