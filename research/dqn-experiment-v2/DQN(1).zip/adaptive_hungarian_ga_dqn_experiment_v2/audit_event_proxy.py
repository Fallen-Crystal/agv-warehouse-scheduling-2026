"""独立复核事件代理pilot；不重新运行调度。"""
import gzip
import json
from paths import ROOT,sha
from objective import LinearObjective,checked_score
from wepa.data import build
from headroom_physics import analyze_physics
from adaptive_hungarian_learning import audit_adaptation
from audit_search_headroom import _same,audit_folder,corrected_budget_totals
from run_search_headroom import frozen_identity,read_json,commit,PROTOCOL,audit_budget


def main():
    folder=ROOT/'results/event_proxy_pilot_v1'
    manifest=read_json(folder/'manifest.json')
    _same(manifest['identity'],frozen_identity(),'identity')
    for name,digest in manifest['hashes'].items():
        _same(sha(ROOT/name),digest,'source.'+name)
    row=read_json(folder/'episode_000.json')
    _same(row['case'],manifest['case'],'case')
    _same(row['seed'],manifest['seed'],'seed')
    _same(row['budget'],manifest['budget'],'budget')
    _same(row['trajectory_file'],'trajectory_000.json.gz','trajectory_file')
    raw=folder/row['trajectory_file']
    if raw.is_symlink() or raw.resolve().parent!=folder:
        raise ValueError('Invalid trajectory path')
    _same(sha(raw),row['trajectory_sha256'],'trajectory_sha256')
    trajectory=json.loads(gzip.decompress(raw.read_bytes()))
    protocol=read_json(PROTOCOL)
    case=next(c for c in protocol['cases'] if c['case']==row['case'])
    model=build(case,**protocol['configuration'])
    objective=LinearObjective(**protocol['objective'])
    score=checked_score(model,trajectory,objective)
    _same(row['F'],score['F_linear_v2'],'F')
    for key in ('T','R','D','traffic_wait'):
        _same(row[key],trajectory[key],key)
    _same(row['physics'],analyze_physics(model,trajectory,objective),'physics')
    for key,value in trajectory['dqn'].items():
        _same(row.get(key),value,'dqn.'+key)
    _same(trajectory['method'],'rl','method')
    _same(trajectory['objective_sha256'],objective.fingerprint,'objective_sha256')
    audit_adaptation(row)
    _same(row['budget_audit'],audit_budget(row,trajectory['search_log'],row['budget']),'budget_audit')
    baseline=next(r for r in audit_folder(ROOT/'results/search_headroom_v1')['rows']
                  if r['case']==row['case'] and r['budget_name']=='baseline' and r['seed']==0)
    result=dict(valid=True,case=row['case'],baseline_F=baseline['F'],event_F=row['F'],
                improvement_pct=100*(1-row['F']/baseline['F']),
                component_reduction={k:baseline['physics']['weighted_terms'][k]-row['physics']['weighted_terms'][k] for k in ('T','R','D')},
                baseline_cost=baseline['corrected_budget_totals'],
                event_cost=corrected_budget_totals(trajectory['search_log']),
                qualification='单个反复检查过的训练窗口，非学习收益或独立验证；并行墙钟不可用作速度证据')
    commit(folder,'audit.json',result)
    print(json.dumps(result,ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
