"""固定day66开放流预测终端pilot；同GA预算，独立结果目录。"""
import argparse
import json
from paths import ROOT,sha
from open_boundary_policy import execute_open_boundary
from run_search_headroom import PROTOCOL,read_json,commit,frozen_identity
from audit_search_headroom import audit_folder


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--resume',action='store_true')
    args=parser.parse_args()
    protocol=read_json(PROTOCOL)
    name='wepa-hour-day66-bin1599'
    case=next(c for c in protocol['cases'] if c['case']==name)
    identity=frozen_identity()
    sources=('open_boundary_policy.py','run_open_boundary_pilot.py','test_open_boundary_policy.py')
    manifest=dict(version='open-boundary-pilot-v1',identity=identity,
        hashes={n:sha(ROOT/n) for n in sources},case=name,seed=0,
        budget=dict(proxy=192,generations=16,previews=6),
        intervention='open_stream_standby_forecast',
        selection='Single reused training date fixed before execution; development pilot only',
        qualification='Forecast terminal changes; formal episode F and final-home execution unchanged')
    folder=ROOT/'results/open_boundary_pilot_v1'
    if args.resume:
        if read_json(folder/'manifest.json')!=manifest:
            raise ValueError('Source/config changed')
    else:
        folder.mkdir(exist_ok=False)
        commit(folder,'manifest.json',manifest)
    episode=folder/'episode_000.json'
    if episode.exists():
        row=read_json(episode)
        if row['case']!=name or row['trajectory_file']!='trajectory_000.json.gz' or sha(folder/row['trajectory_file'])!=row['trajectory_sha256']:
            raise ValueError('Committed identity mismatch')
    else:
        row,trajectory=execute_open_boundary(case,protocol)
        raw=commit(folder,'trajectory_000.json.gz',trajectory,compressed=True)
        row.update(trajectory_file=raw.name,trajectory_sha256=sha(raw))
        commit(folder,'episode_000.json',row)
    baseline=next(r for r in audit_folder(ROOT/'results/search_headroom_v1')['rows']
                  if r['case']==name and r['seed']==0 and r['budget_name']=='baseline')
    if frozen_identity()!=identity or any(sha(ROOT/n)!=manifest['hashes'][n] for n in sources):
        raise ValueError('Source changed during execution')
    summary=dict(case=name,baseline_F=baseline['F'],candidate_F=row['F'],
        improvement_pct=100*(1-row['F']/baseline['F']),
        baseline_cost=baseline['corrected_budget_totals'],candidate_cost=row['budget_audit'],
        qualification='One reused training date; not learning gain or independent generalization')
    commit(folder,'summary.json',summary)
    print(json.dumps(summary,ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
