"""用可手算的Q函数检查训练诊断，尤其防止环形回放错配最近一窗。

不执行物理仿真，不读取任何验证/测试输入，也不更新模型。
"""
import copy
import math
import unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
from paths import ROOT
from adaptive_hungarian_learning import MultiStepAgent
from diagnose_adaptive_hungarian_learning import summarize


def make_agent():
    agent=MultiStepAgent(seed=17,state_dim=32,hidden=2,capacity=4,batch_size=1,warmup=1,double_dqn=True)
    for group in ('online','target'):
        for weights in getattr(agent,group).values(): weights.fill(0)
    # 对正x：Q_H=0、Q_G=x-.5，三个负荷组的贪心动作可直接手算。
    agent.online['w1'][0,0]=1
    agent.online['w2'][0,1]=1
    agent.online['b2'][1]=-.5
    return agent


def add(agent,x,action,reward,cached=False):
    state=np.zeros(32); state[0]=x; state[20]=float(cached)
    agent.replay.append(state,action,reward,np.zeros(32),True)


class DiagnosticTests(unittest.TestCase):
    def test_cli_snapshot_cannot_be_mistaken_for_training_row(self):
        import diagnose_adaptive_hungarian_learning as diagnostic
        agent=make_agent(); add(agent,.2,0,-1)
        row=dict(case='namespace',transitions=[dict(action=0,reward=-1)],checkpoint_sha256='known-digest')
        writes={}
        # 本测试检查真实main组装的输出路径；存储/加载数值由其他检查点测试覆盖。
        with patch.object(diagnostic,'read',return_value=row),patch.object(diagnostic,'sha',return_value='known-digest'),patch.object(diagnostic.MultiStepAgent,'load',return_value=agent),patch.object(diagnostic,'write',side_effect=lambda path,value:writes.update({path.name:value})),patch('sys.argv',['diagnostic','--checkpoint-row','train_e01_00.json']),patch('builtins.print'):
            diagnostic.main()
        self.assertEqual(set(writes),{'diagnostics_train_e01_00.json','training_diagnostics.json'})
        self.assertEqual(writes['diagnostics_train_e01_00.json'],writes['training_diagnostics.json'])
        names=['train_e01_00.json',*writes]
        self.assertEqual([name for name in names if Path(name).match('train_e*_*.json')],['train_e01_00.json'])

    def test_cache_groups_and_behavior_switches(self):
        agent=make_agent()
        add(agent,.2,0,-1,cached=False)
        add(agent,.9,1,-2,cached=True)
        row=dict(case='cache',transitions=[dict(action=0,reward=-1),dict(action=1,reward=-2)])
        report=summarize(agent,row)
        self.assertEqual(report['cached_plan_groups']['absent']['states'],1)
        self.assertEqual(report['cached_plan_groups']['absent']['greedy_ga_fraction'],0)
        self.assertEqual(report['cached_plan_groups']['present']['states'],1)
        self.assertEqual(report['cached_plan_groups']['present']['greedy_ga_fraction'],1)
        self.assertEqual(report['last_training_episode_action_switches'],1)
        self.assertEqual(report['last_training_episode_action_switch_fraction'],1)

    def test_empty_replay_rejected(self):
        with self.assertRaisesRegex(ValueError,'No replay samples'):
            summarize(make_agent(),dict(case='empty',transitions=[]))

    def test_unfilled_buffer_excludes_unused_slots(self):
        agent=make_agent()
        add(agent,.2,0,-1)
        row=dict(case='one',epoch=1,transitions=[dict(action=0,reward=-1)])
        report=summarize(agent,row)
        self.assertEqual(report['replay_size'],1)
        self.assertEqual(report['replay_state_greedy_actions'],dict(hungarian=1,ga=0))
        self.assertEqual(report['backlog_groups']['pending_below_6']['states'],1)
        self.assertIsNone(report['backlog_groups']['pending_at_least_24']['greedy_ga_fraction'])
        self.assertAlmostEqual(report['five_step_bellman_rmse'],1)
        self.assertAlmostEqual(report['last_training_episode_behavior_return_rmse'],1)
        self.assertIsNone(report['last_training_episode_action_switch_fraction'])
        self.assertIsNone(report['cached_plan_groups']['present']['greedy_ga_fraction'])

    def test_wrapped_replay_uses_last_episode_in_chronological_order(self):
        agent=make_agent()
        # 五条写入四槽池；最旧的x=.1必须被排除，最后两条跨越物理数组末端。
        for args in ((.1,0,-99),(.2,0,-1),(.6,1,-2),(.9,1,-3),(.7,0,-4)):
            add(agent,*args)
        self.assertEqual(agent.replay.position,1)
        before=copy.deepcopy(agent)
        row=dict(case='wrapped',epoch=2,transitions=[dict(action=1,reward=-3),dict(action=0,reward=-4)])
        report=summarize(agent,row)
        self.assertEqual(report['replay_behavior_actions'],dict(hungarian=2,ga=2))
        self.assertEqual(report['replay_state_greedy_actions'],dict(hungarian=1,ga=3))
        self.assertEqual({k:v['states'] for k,v in report['backlog_groups'].items()},
            dict(pending_below_6=1,pending_6_to_23=2,pending_at_least_24=1))
        self.assertAlmostEqual(report['ga_minus_hungarian_Q_quantiles']['0'],-.3)
        self.assertAlmostEqual(report['ga_minus_hungarian_Q_quantiles']['1'],.4)
        self.assertAlmostEqual(report['mean_abs_Q'],.125)
        # 实际行为Q分别0、.1、.4、0；目标网络全零，Bellman目标为存储奖励。
        self.assertAlmostEqual(report['five_step_bellman_rmse'],math.sqrt((1+2.1**2+3.4**2+4**2)/4))
        # 最近一窗原始回报为[-7,-4]，对应Q为[.4,0]，必须按跨槽顺序对齐。
        self.assertAlmostEqual(report['last_training_episode_behavior_return_rmse'],math.sqrt((7.4**2+4**2)/2))
        self.assertEqual(agent.rng.bit_generator.state,before.rng.bit_generator.state)
        self.assertEqual(agent.train_steps,before.train_steps)
        self.assertEqual(agent.replay.position,before.replay.position)
        self.assertEqual(list(agent.pending),list(before.pending))
        for group in ('online','target','adam_m','adam_v'):
            for key,value in getattr(agent,group).items():
                np.testing.assert_array_equal(value,getattr(before,group)[key])
        for key in ('states','next_states','actions','rewards','dones'):
            np.testing.assert_array_equal(getattr(agent.replay,key),getattr(before.replay,key))


if __name__=='__main__': unittest.main()
