"""持续训练防回归：冻结、样本归一化、检查点、划分和稳定判据。"""
import json
import tempfile
import unittest
from pathlib import Path
from rl_scheduler import State
from stable_rl import StableSelector
from train_rl_stable import split_cases, stability


class StableTests(unittest.TestCase):
    def test_normalization_is_independent_of_repeated_decisions(self):
        state = State(1, .5, .2, .4)
        left, right = StableSelector(epsilon=0), StableSelector(epsilon=0)
        left.choose(state, idle=1, ready=1)
        for _ in range(100):
            right.choose(state, idle=1, ready=1)
        left.finish_episode(objective=1)
        right.finish_episode(objective=1)
        for action in left.ACTIONS:
            for a, b in zip(left.weights[action], right.weights[action]):
                self.assertAlmostEqual(a, b)

    def test_frozen_ignores_terminal_feedback(self):
        s = StableSelector(train_enabled=False, epsilon=0)
        before = json.dumps(s.weights)
        s.choose(State(1, 1, 1, 1), idle=1, ready=1)
        s.finish_episode(objective=2)
        self.assertEqual(before, json.dumps(s.weights))
        self.assertEqual(s.episodes, 0)
        with self.assertRaises(RuntimeError):
            s.update(1)

    def test_checkpoint_replays_rng_weights_and_episode_count(self):
        s = StableSelector(seed=3, epsilon=.9)
        state = State(1, .5, .2, .4)
        s.choose(state, idle=1, ready=1)
        s.finish_episode(objective=1)
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/"checkpoint.json"
            s.save(path)
            loaded = StableSelector.load(path)
        self.assertEqual(s.weights, loaded.weights)
        self.assertEqual(s.episodes, loaded.episodes)
        self.assertEqual([s.choose(state, idle=1, ready=1) for _ in range(20)],
                         [loaded.choose(state, idle=1, ready=1) for _ in range(20)])

    def test_split_and_stability_not_confused_with_validity(self):
        train, monitor = split_cases(dict(development=["a","b","c","d"],
                                          validation=["e","f","g","h"]))
        self.assertEqual(len(train), 6)
        self.assertFalse(set(train)&set(monitor))
        rows = [dict(seed=0,epoch=i,F=v) for i,v in enumerate([1,1.1,1.2])]
        self.assertFalse(stability(rows,[0,1,2])["stable"])
        rows[-1]["F"] = rows[-2]["F"] = 1.001
        self.assertTrue(stability(rows,[0,1,2])["stable"])
        self.assertFalse(stability(rows[:2],[0,1])["stable"])


if __name__ == "__main__":
    unittest.main()
