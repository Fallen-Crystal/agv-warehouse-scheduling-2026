"""Exact offline pre-assignment waiting ledger, not causal attribution.

Only publication, WMS binding, inventory, locks and active-task state are
replayed. No World constructor, router, dispatcher, physical advance or new
simulation is called. Physical trajectory validity is checked separately.
"""
from collections import defaultdict
from types import SimpleNamespace

import paths
from wepa.check import validate
from wepa.kernel import World

CATEGORIES = ('unbound_slot', 'bay_locked', 'layer_precedence',
              'ready_fleet_busy', 'ready_with_idle_vehicle')


def _require(condition, message):
    if not condition:
        raise ValueError('Waiting replay: ' + message)


def _blocked_by_level(state, job):
    slot = state.slots[state.bound[job['id']]]
    if job['kind'] == 'retrieval':
        return any(q['bay'] == slot['bay'] and q['level'] > slot['level']
                   and q['id'] in state.stock for q in state.slots)
    return any(q['bay'] == slot['bay'] and q['level'] < slot['level']
               and q['id'] in state.in_reserved for q in state.slots)


def _replay_logic(model, result):
    """Internal business-ledger replay; public callers must use analyze_waiting.

    Exposed internally for crafted business-state tests that deliberately do
    not pretend to be complete physically validated warehouse trajectories.
    """
    tasks = {j['id']: dict(j) for j in model['tasks']}
    _require(len(tasks) == len(model['tasks']), 'duplicate task ids')
    _require(type(model['vehicles']) is int and model['vehicles'] > 0, 'invalid fleet')
    _require(type(result['time']) is int and result['time'] >= 0, 'invalid end time')
    _require(all(type(j['release']) is int and j['release'] >= 0
                 and j['kind'] in ('delivery', 'retrieval') for j in tasks.values()),
             'unsupported task kind/release')
    _require(all(s['id'] == i for i, s in enumerate(model['slots'])), 'slot indexing mismatch')
    records = result['records']
    _require(len(records) == len(tasks) and {r['task'] for r in records} == set(tasks),
             'incomplete/duplicate task records')
    _require([r['assigned_at'] for r in records] == sorted(r['assigned_at'] for r in records),
             'records are not in original chronological commit order')
    assignments = defaultdict(list)
    by_task = {}
    for record in records:
        job = tasks[record['task']]
        _require(all(type(record[k]) is int for k in ('assigned_at', 'pickup_end', 'end', 'vehicle', 'slot')),
                 'noninteger record business event')
        _require(job['release'] <= record['assigned_at'] < record['pickup_end'] < record['end'] <= result['time'],
                 'invalid event chronology')
        _require(0 <= record['vehicle'] < model['vehicles'], 'vehicle out of range')
        assignments[record['assigned_at']].append(record)
        by_task[record['task']] = record
    # Deliberately not World(model): no router allocation, path planning or RNG.
    state = SimpleNamespace(model=model, tasks=tasks, slots=model['slots'],
                            stock=set(model['occupied']), out_reserved={}, in_reserved={},
                            bound={}, visible={}, active=[None]*model['vehicles'], records=[],
                            completed=set(), assigned=set(), processed_pickups=set(), locks={},
                            time=0, closed=False)
    counts = {jid: dict.fromkeys(CATEGORIES, 0) for jid in tasks}
    intervals = {jid: [] for jid in tasks}
    observed_commits = 0
    for tick in range(result['time']+1):
        state.time = tick
        World.publish_and_complete(state)
        for original in assignments.get(tick, []):
            jid, vehicle = original['task'], original['vehicle']
            _require(jid in state.visible, f'unpublished assignment {jid} at {tick}')
            _require(state.bound.get(jid) == original['slot'], f'WMS slot mismatch for {jid} at {tick}')
            _require(jid in {j['id'] for j in World.ready(state)}, f'nonready assignment {jid} at {tick}')
            _require(state.active[vehicle] is None and jid not in state.assigned,
                     f'busy/duplicate assignment {jid} at {tick}')
            # Equivalent to commit's business effects, never its routing effects.
            record = dict(original)
            state.records.append(record)
            state.active[vehicle] = record
            state.assigned.add(jid)
            bay = state.slots[record['slot']]['bay']
            state.locks[bay] = record['pickup_end'] if tasks[jid]['kind']=='retrieval' else record['end']
            observed_commits += 1
        ready = {j['id'] for j in World.ready(state)}
        fleet_busy = all(record is not None for record in state.active)
        for jid, job in state.visible.items():
            if jid in state.assigned:
                continue
            _require(job['release'] <= tick < by_task[jid]['assigned_at'], 'waiting interval mismatch')
            if jid not in state.bound:
                category = 'unbound_slot'
            elif state.locks.get(state.slots[state.bound[jid]]['bay'], 0) > tick:
                category = 'bay_locked'
            elif _blocked_by_level(state, job):
                category = 'layer_precedence'
            else:
                category = 'ready_fleet_busy' if fleet_busy else 'ready_with_idle_vehicle'
            _require((jid in ready) == category.startswith('ready_'),
                     f'classification/World.ready mismatch for {jid} at {tick}')
            counts[jid][category] += 1
            spans = intervals[jid]
            if spans and spans[-1]['category'] == category and spans[-1]['stop'] == tick:
                spans[-1]['stop'] = tick+1
            else:
                spans.append(dict(start=tick, stop=tick+1, category=category))
    _require(observed_commits == len(records), 'missed assignment events')
    _require(state.assigned == set(tasks), 'final assignment mismatch')
    _require(state.completed == set(tasks) == set(result['completed']), 'final completion mismatch')
    _require(state.stock == set(result['final_stock']), 'final inventory mismatch')
    _require(not state.out_reserved and not state.in_reserved, 'unconsumed final reservations')
    _require(all(record is None for record in state.active), 'active task after final time')
    _require(state.closed, 'publisher not closed by final time')
    rows = []
    totals = dict.fromkeys(CATEGORIES, 0)
    for job in model['tasks']:
        jid = job['id']
        record = by_task[jid]
        expected = record['assigned_at']-job['release']
        _require(sum(counts[jid].values()) == expected, f'partition does not telescope for {jid}')
        for key in CATEGORIES:
            totals[key] += counts[jid][key]
        rows.append(dict(task=jid, kind=job['kind'], release=job['release'],
                         assigned_at=record['assigned_at'], slot=record['slot'],
                         vehicle=record['vehicle'], pre_assignment=expected,
                         partition=counts[jid], intervals=intervals[jid]))
    n = len(rows)
    return dict(schema='headroom-waiting-v1', case=model.get('case'), tasks_count=n,
                category_priority=list(CATEGORIES), tasks=rows,
                aggregate=dict(total_steps=totals,
                               mean_steps={key: value/n if n else 0.0 for key, value in totals.items()},
                               pre_assignment_total=sum(totals.values()),
                               pre_assignment_mean=sum(totals.values())/n if n else 0.0),
                replay=dict(ticks=result['time']+1, commits=observed_commits,
                            final_stock=sorted(state.stock), completed=sorted(state.completed),
                            all_reservations_consumed=True, all_vehicles_inactive=True),
                timing='At each integer t: publish/complete; apply all recorded commits in original order; '
                       'classify remaining published unassigned jobs for [t,t+1). Assigned-at tick is excluded.',
                definitions=dict(unbound_slot='No deterministic WMS slot binding after publication/completion',
                                 bay_locked='Bound bay lock expiry is greater than current tick',
                                 layer_precedence='Higher occupied level blocks retrieval or lower inbound-reserved level blocks delivery',
                                 ready_fleet_busy='World.ready holds, but all vehicles have active tasks AFTER same-tick commits',
                                 ready_with_idle_vehicle='World.ready holds and at least one vehicle has no active task AFTER same-tick commits'),
                caveats=[
                    'Categories are an exact priority-ordered business-state ledger, NOT causal avoidable losses.',
                    'ready_with_idle_vehicle is NOT called avoidable: idle does not prove a collision-free feasible route or a better dispatch.',
                    'Inventory/WMS binding, stock and reservations depend on earlier realized decisions; categories are not independent interventions.',
                    'A bay lock is prioritized over simultaneous level or fleet constraints; counts are exclusive, not all causes.',
                    'Inactive vehicles may still have return/hold paths; inactive means no active task, not stationary at home.',
                    'Same-tick assignments are all applied before classification, so newly occupied vehicles count as busy.',
                    'No policy, router or physical advance is run; recorded assignments are replayed, not optimized.',
                    'Full trajectory validation is independent; this replay additionally checks deterministic binding and commit readiness.'
                ])


def analyze_waiting(model, result):
    """Validate a completed trace, then return its exact noncausal waiting ledger."""
    audit = validate(model, result)
    data = _replay_logic(model, result)
    data['physical_validation'] = audit
    return data


__all__ = ['analyze_waiting']
