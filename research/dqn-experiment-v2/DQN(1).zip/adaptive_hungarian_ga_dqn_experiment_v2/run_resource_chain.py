"""原预算资源链种子消融；与已冻结诊断的baseline配对，不训练DQN。"""
import argparse
import copy
from unittest.mock import patch

from paths import ROOT, sha
import adaptive_genetic
from resource_chain_seed import inject_seed
from run_search_headroom import (PROTOCOL, read_json, select_cases, execute_diagnostic,
                                 commit, frozen_identity)
from adaptive_hungarian_learning import audit_adaptation
from audit_search_headroom import audit_folder


def execute_resource(case, protocol, seed=0):
    original=adaptive_genetic.candidates
    injections=[]
    def candidates(costs, order, owners, **kwargs):
        seeds,meta=inject_seed(costs,order,owners,kwargs.get('seed_plans'))
        kwargs['seed_plans']=seeds
        injections.append(dict(time=costs.world.time, **meta))
        return original(costs,order,owners,**kwargs)
    # 只干预初始化，原GA算子、适应率、评估器与6次物理预览完全复用。
    with patch('adaptive_genetic.candidates',candidates):
        row,trajectory=execute_diagnostic(case,protocol,'baseline',seed)
    audit_adaptation(row)
    row.update(intervention='resource_chain_one_seed',resource_seed_log=injections,
               qualification='同预算开发消融；未训练DQN，不构成新日期泛化证据')
    return row,trajectory


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',default='results/resource_chain_v1')
    parser.add_argument('--resume',action='store_true')
    args=parser.parse_args()
    protocol=read_json(PROTOCOL)
    cases=select_cases(protocol)
    identity=frozen_identity()
    sources=('resource_chain_seed.py','run_resource_chain.py','test_resource_chain_seed.py')
    manifest=dict(version='resource-chain-one-seed-v1',cases=[c['case'] for c in cases],seeds=[0],
        identity=identity,hashes={n:sha(ROOT/n) for n in sources},
        change='Replace second external seed with resource-chain construction if distinct; retain first Hungarian seed',
        budget=dict(proxy=192,generations=16,previews=6,population=12,elites=2),
        qualification='Development experiment; identical formal objective/physics; no claim of unseen test')
    folder=(ROOT/args.output).resolve()
    if folder.parent!=(ROOT/'results').resolve() or folder.name=='search_headroom_v1':
        raise ValueError('Use separate direct results child')
    if args.resume:
        if read_json(folder/'manifest.json')!=manifest:
            raise ValueError('Resume source drift')
    else:
        folder.mkdir(exist_ok=False)
        commit(folder,'manifest.json',manifest)
    rows=[]
    for index,case in enumerate(cases):
        name=f'episode_{index:03d}.json'
        if (folder/name).exists():
            row=read_json(folder/name)
            if row['case']!=case['case'] or sha(folder/row['trajectory_file'])!=row['trajectory_sha256']:
                raise ValueError('Committed identity mismatch')
        else:
            print('start '+case['case'],flush=True)
            row,trajectory=execute_resource(case,protocol)
            filename=f'trajectory_{index:03d}.json.gz'
            path=commit(folder,filename,trajectory,compressed=True)
            row.update(trajectory_file=filename,trajectory_sha256=sha(path))
            commit(folder,name,row)
            print(f"complete {case['case']} F={row['F']:.9f}",flush=True)
        rows.append(row)
    baseline=audit_folder(ROOT/'results/search_headroom_v1')['rows']
    base={r['case']:r for r in baseline if r['budget_name']=='baseline' and r['seed']==0}
    pairs=[dict(case=r['case'],baseline_F=base[r['case']]['F'],candidate_F=r['F'],
                improvement_pct=100*(1-r['F']/base[r['case']]['F']),
                injected=sum(item['injected'] for item in r['resource_seed_log']),
                candidate_cost=r['budget_audit'],baseline_cost=base[r['case']]['budget_audit'])
           for r in rows if r['case'] in base]
    if frozen_identity()!=identity or any(sha(ROOT/n)!=manifest['hashes'][n] for n in sources):
        raise ValueError('Source changed during experiment')
    commit(folder,'summary.json',dict(completed_runs=len(rows),pairs=pairs,
        all_baselines_available=len(pairs)==len(rows),
        qualification='同预算但每窗重规划次数由轨迹决定，必须同时报告实际成本；仅开发集'))
    print(pairs,flush=True)


if __name__=='__main__':
    main()
