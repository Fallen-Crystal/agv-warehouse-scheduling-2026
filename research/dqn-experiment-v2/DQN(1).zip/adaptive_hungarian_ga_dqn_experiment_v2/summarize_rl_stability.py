"""从逐窗口落盘证据重算稳定性；支持运行中快照，绝不将缺失结果补齐。"""
import argparse
import json
import statistics
from collections import Counter
from pathlib import Path

from train_rl_stable import stability


def stats(values):
    return dict(n=len(values), mean=statistics.mean(values) if values else None,
                sd=statistics.stdev(values) if len(values)>1 else None,
                minimum=min(values) if values else None,
                maximum=max(values) if values else None)


def analyze(folder):
    folder = Path(folder)
    manifest = json.loads((folder/"manifest.json").read_text(encoding="utf-8"))
    path = folder/"episodes.jsonl"
    lines = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
    # 写入中最后一条可能尚未写完整；只在无换行的尾部忽略它。
    rows = []
    for index, line in enumerate(lines):
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            if index != len(lines)-1:
                raise
    seeds = [int(x) for x in manifest["config"]["seeds"].split(",")]
    rounds = manifest["config"]["rounds"]
    train, monitor = manifest["train"], manifest["monitor"]
    expected = {(seed, epoch, "train", case) for seed in seeds
                for epoch in range(1,rounds+1) for case in train}
    expected |= {(seed, epoch, "monitor", case) for seed in seeds
                 for epoch in range(rounds+1) for case in monitor}
    keys = [(r["seed"],r["epoch"],r["phase"],r["case"]) for r in rows]
    if len(keys) != len(set(keys)) or set(keys)-expected:
        raise ValueError("Duplicate or unexpected episode evidence")
    for r in rows:
        f = .5*r["T"]/900 + .3*r["R"]/900 + .2*r["D"]/5400
        if abs(f-r["F"]) > 1e-12:
            raise ValueError("Objective mismatch")
        if sum(r["actions"].values()) != r["decisions"]:
            raise ValueError("Action counts mismatch")
    curves = []
    for epoch in range(rounds+1):
        group = [r for r in rows if r["epoch"]==epoch and r["phase"]=="monitor"]
        curves.append(dict(epoch=epoch, complete=len(group)==len(seeds)*len(monitor),
                           by_case={case:stats([r["F"] for r in group if r["case"]==case])
                                    for case in monitor},
                           by_seed={str(seed):stats([r["F"] for r in group if r["seed"]==seed])
                                    for seed in seeds}))
    monitor_rows = [r for r in rows if r["phase"]=="monitor"]
    full_epochs = [c["epoch"] for c in curves if c["complete"]]
    ready = len(rows)==len(expected)
    last = max(full_epochs) if full_epochs else None
    paired = []
    action_counts = Counter()
    for seed in seeds:
        for case in monitor:
            get = lambda e: next((r for r in monitor_rows if r["seed"]==seed and
                                  r["case"]==case and r["epoch"]==e),None)
            start, end = get(0), get(last)
            if start and end and last != 0:
                paired.append(dict(seed=seed, case=case, initial_F=start["F"],
                                   latest_F=end["F"], relative_change=end["F"]/start["F"]-1))
                action_counts.update(end["actions"])
    check = stability(monitor_rows, full_epochs)
    # 仅完整计划结束后才发布预先声明的最终稳定性判定。
    return dict(complete=ready, observed=len(rows), expected=len(expected),
                valid_count=sum(r["valid"] for r in rows),
                missing=[list(k) for k in sorted(expected-set(keys))],
                latest_complete_epoch=last, learning_curves=curves,
                paired_initial_to_latest=paired,
                mean_paired_relative_change=statistics.mean(p["relative_change"] for p in paired)
                                            if paired else None,
                latest_action_counts=dict(action_counts),
                provisional_stability=check,
                final_stable=check["stable"] if ready else None,
                qualification=manifest["qualification"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder")
    args = parser.parse_args()
    report = analyze(args.folder)
    target = Path(args.folder)/"analysis.json"
    target.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps({k:v for k,v in report.items() if k not in
                      ("missing","learning_curves","paired_initial_to_latest")},ensure_ascii=False))


if __name__ == "__main__":
    main()
