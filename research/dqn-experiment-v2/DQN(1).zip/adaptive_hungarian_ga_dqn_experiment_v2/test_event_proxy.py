"""事件代理只修正预留语义，仍保留锚点前驱与bay资源限制。"""
import unittest
from test_proxy_reservation_order import StubCosts
from event_proxy import EventCosts


class EventStub(StubCosts,EventCosts):
    _schedule=EventCosts._schedule


class EventProxyTests(unittest.TestCase):
    def test_idle_vehicle_can_fill_gap_before_future_bay_task(self):
        costs=EventStub()
        forward,_=costs._schedule([0,1],{0:0,1:1})
        reverse,_=costs._schedule([1,0],{0:0,1:1})
        self.assertEqual(forward,reverse)
        self.assertEqual(forward[0],110)

    def test_existing_predecessor_still_blocks_gap(self):
        costs=EventStub()
        costs.predecessor={1:0}
        result,_=costs._schedule([0,1],{0:0,1:1})
        self.assertEqual(result[0],112)

    def test_bay_lock_and_cycle_are_respected(self):
        costs=EventStub()
        costs.world.locks={0:150}
        result,_=costs._schedule([0,1],{0:0,1:1})
        self.assertEqual(result[0],162)
        costs.predecessor={0:1,1:0}
        result,_=costs._schedule([0,1],{0:0,1:1})
        self.assertEqual(result,(float('inf'),)*3)


if __name__=='__main__':
    unittest.main()
