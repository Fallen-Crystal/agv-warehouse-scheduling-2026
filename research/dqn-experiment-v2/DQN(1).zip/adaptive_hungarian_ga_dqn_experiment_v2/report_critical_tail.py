"""核对决定T的实际任务及其阻塞账本；不把关键路径账本当成因果归因。"""
import gzip
import json
from paths import ROOT,sha
from run_search_headroom import read_json,PROTOCOL,commit
from audit_search_headroom import audit_folder
from headroom_waiting import analyze_waiting
from wepa.data import build


def main():
    folder=ROOT/'results/search_headroom_v1'
    verified=audit_folder(folder)
    protocol=read_json(PROTOCOL)
    cases={c['case']:c for c in protocol['cases']}
    rows=[]
    for row in verified['rows']:
        if row['budget_name']!='baseline':
            continue
        raw=folder/row['trajectory_file']
        if sha(raw)!=row['trajectory_sha256']:
            raise ValueError('Trajectory changed')
        trajectory=json.loads(gzip.decompress(raw.read_bytes()))
        ledger=analyze_waiting(build(cases[row['case']],**protocol['configuration']),trajectory)
        waiting={r['task']:r for r in ledger['tasks']}
        critical=set(row['physics']['completion']['critical_task_ids'])
        details=[dict(physics=t,waiting=waiting[t['task']]) for t in row['physics']['tasks'] if t['task'] in critical]
        slots=build(cases[row['case']],**protocol['configuration'])['slots']
        task_map={j['id']:j for j in cases[row['case']]['tasks']}
        # 锁来源由同bay、实际分配先后和严格expiry>tick识别；可有连续多项阻塞。
        for detail in details:
            target=detail['physics']
            bay=slots[target['slot']]['bay']
            blockers=[]
            for record in trajectory['records']:
                if record['task']==target['task'] or slots[record['slot']]['bay']!=bay:
                    continue
                expiry=record['pickup_end'] if task_map[record['task']]['kind']=='retrieval' else record['end']
                start=max(target['release'],record['assigned_at'])
                stop=min(target['assigned_at'],expiry)
                if stop>start:
                    blockers.append(dict(task=record['task'],vehicle=record['vehicle'],
                        kind=task_map[record['task']]['kind'],release=task_map[record['task']]['release'],
                        assigned_at=record['assigned_at'],bay_unlock=expiry,
                        overlap_ticks=stop-start,waiting=waiting[record['task']]['partition'],
                        end=record['end']))
            detail['same_bay_blockers']=blockers
        rows.append(dict(case=row['case'],source_day=row['source_day'],T=row['T'],critical=details))
    commit(folder,'critical_tail.json',dict(rows=rows,
        caveat='Tasks attaining realized max completion only. Improving them may expose a different critical task. Observed resource waits are not independent avoidable losses.'))
    for r in rows:
        print(json.dumps(r,ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
