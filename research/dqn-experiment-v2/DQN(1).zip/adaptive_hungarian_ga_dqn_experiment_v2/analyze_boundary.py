"""Paired, source-day-balanced summaries; never tune on validation."""
import argparse
from collections import defaultdict
import csv
import json
from pathlib import Path
from statistics import mean

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'boundary_results'


def load_phase(phase):
    protocol = json.loads((ROOT/'boundary_protocol.json').read_text(encoding='utf-8'))
    arms = list(protocol['arms']) if phase=='development' else [
        'original','ga','matching',json.loads((OUT/'selection.json').read_text(encoding='utf-8'))['selected']]
    cases = [c for c in protocol['cases'] if c['source_case'] in protocol[phase]]
    rows, failures = [], []
    for case in cases:
        for arm in arms:
            for seed in protocol[phase+'_seeds']:
                stem = OUT/phase/f"{case['case']}__{arm}__s{seed}"
                status_path = stem.with_suffix('.status.json')
                if not status_path.exists():
                    raise ValueError('Phase incomplete: '+str(status_path))
                status = json.loads(status_path.read_text(encoding='utf-8'))
                if status['status']!='ok':
                    failures.append(status)
                    continue
                row = json.loads(stem.with_suffix('.json').read_text(encoding='utf-8'))['row']
                if not row['valid']:
                    failures.append(status)
                else:
                    rows.append(row)
    return protocol, arms, rows, failures


def summarize(phase):
    protocol, arms, rows, failures = load_phase(phase)
    index = {(r['case'],r['seed'],r['arm']):r for r in rows}
    paired=[]
    for row in rows:
        original = index.get((row['case'],row['seed'],'original'))
        ga = index.get((row['case'],row['seed'],'ga'))
        if original is None:
            continue
        item = dict(row)
        if row['arm'] == 'original':
            # Legacy execution has no boundary_decision instrumentation; zero in
            # the raw row means no such records, not zero matching/GA actions.
            item['matching_events'] = None
            item['ga_events'] = None
        item['relative_F_original'] = row['F']/original['F']-1
        item['relative_F_ga'] = row['F']/ga['F']-1 if ga else None
        item['cpu_change_original'] = row['cpu']/original['cpu']-1
        paired.append(item)
    failed_arms = {f['arm'] for f in failures}
    expected_pairs = sum(c['source_case'] in protocol[phase] for c in protocol['cases']) * len(protocol[phase+'_seeds'])
    overall, by_load, by_day = {},[],[]
    for arm in arms:
        group=[r for r in paired if r['arm']==arm]
        if not group:
            continue
        # Full factorial is balanced; explicitly aggregate seeds, then load, then day.
        days=defaultdict(lambda:defaultdict(list))
        for row in group:
            days[row['source_case']][row['load_level']].append(row)
        day_scores=[]
        for day, levels in days.items():
            score=mean(mean(r['relative_F_original'] for r in reps) for reps in levels.values())
            day_scores.append(score)
            by_day.append(dict(arm=arm,source_case=day,relative_F_original=score))
        overall[arm]=dict(eligible=arm not in failed_arms and len(group)==expected_pairs, runs=len(group),
            relative_F_original=mean(day_scores), day_min=min(day_scores), day_max=max(day_scores),
            **{key:mean(r[key] for r in group) for key in ('F','T','R','D','cpu','p90','empty_distance','traffic_wait','ga_searches')})
        for level in protocol['load_levels']:
            part=[r for r in group if r['load_level']==level]
            if part:
                by_load.append(dict(arm=arm,load_level=level,runs=len(part),
                    **{key:(mean(values) if (values := [r[key] for r in part if r[key] is not None]) else None) for key in ('F','T','R','D','cpu','relative_F_original','relative_F_ga','ga_searches')}))
    def csv_write(name, data):
        if data:
            with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
                writer=csv.DictWriter(f,fieldnames=list(data[0]))
                writer.writeheader(); writer.writerows(data)
    csv_write(phase+'_runs.csv',paired)
    csv_write(phase+'_loads.csv',by_load)
    csv_write(phase+'_days.csv',by_day)
    summary=dict(phase=phase,overall=overall,by_load=by_load,by_day=by_day,failures=failures,
                 analysis_unit='source date; three seeds are repeated measures; original full windows only')
    (OUT/(phase+'_summary.json')).write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    if phase=='development':
        candidates=[a for a in ('t05','t1','t15','t2','t3') if overall.get(a,{}).get('eligible')]
        if not candidates:
            raise ValueError('No eligible threshold')
        best=min(overall[a]['relative_F_original'] for a in candidates)
        tied=[a for a in candidates if overall[a]['relative_F_original']<=best+1e-9]
        selected=min(tied,key=lambda a:(overall[a]['cpu'],float(protocol['arms'][a]['threshold'])))
        selection=dict(selected=selected,threshold=protocol['arms'][selected]['threshold'],
                       criterion=protocol['selection'],scores=overall)
        destination=OUT/'selection.json'
        if destination.exists():
            prior=json.loads(destination.read_text(encoding='utf-8'))
            if prior != selection:
                raise ValueError('Refuse to change frozen selection')
        else:
            destination.write_text(json.dumps(selection,ensure_ascii=False,indent=2),encoding='utf-8')
        print('Development-selected threshold:',selected)
    print(json.dumps(overall,ensure_ascii=False,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--phase',choices=['development','validation'],required=True)
    summarize(p.parse_args().phase)
