"""在托管后台等待训练完成，再执行既定审计；不启动或修改训练。"""
import subprocess
import sys
import time
from paths import ROOT


def main():
    root = ROOT / 'results/dqn_expanded_v1'
    deadline = time.monotonic() + 48*3600
    # analysis.json由单seed训练结束后的审计写出；三份均在才启动独立复验。
    while not all((root / f's{seed}' / 'analysis.json').exists() for seed in range(3)):
        if time.monotonic() > deadline:
            raise TimeoutError('48小时内训练未全部完成；保留现有证据，不生成完整结论')
        time.sleep(30)
    subprocess.run([sys.executable, '-B', str(ROOT / 'finish_dqn_expanded.py')],
                   cwd=ROOT, check=True)


if __name__ == '__main__':
    main()
