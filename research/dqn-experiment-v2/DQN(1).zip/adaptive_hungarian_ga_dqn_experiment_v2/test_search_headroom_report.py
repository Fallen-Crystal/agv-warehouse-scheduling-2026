"""中文报告使用独立审计成本且不把部分面板写成完整结论；纯内存测试。"""
import unittest
from unittest.mock import patch

from paths import ROOT
from report_search_headroom import render


class HeadroomReportTests(unittest.TestCase):
    def test_partial_report_uses_corrected_cost_and_separate_timing(self):
        manifest = dict(version='search-headroom-v1', seeds=[0],
                        cases=[dict(case='synthetic',source_day=0)])
        parts = dict(pre_assignment=1.,empty_moves=1.,empty_stationary=1.,
                     pickup_service=1.,loaded_moves=1.,loaded_stationary=1.,drop_service=1.)
        row = dict(case='synthetic',source_day=0,seed=0,budget_name='baseline',
                   F=1.,T=10,R=7.,D=10,diagnostic_wall=12.,execution_wall=10.,
                   physics=dict(weighted_terms=dict(T=.5,R=.3,D=.2),
                                lower_bounds=dict(F=.5),
                                gaps=dict(F_reduction_ceiling_fraction=.5),
                                response_time=dict(mean_steps=parts)),
                   budget_audit=dict(searches=1,proxy_evaluations=192,physical_previews=6),
                   corrected_budget_totals=dict(physical_previews_total=7,
                                                rollout_route_calls_total=123))
        folder=(ROOT/'not-created-report-test').resolve()
        verification=dict(rows=[row],complete=False,planned_runs=12)
        # 不创建目录：验证报告内容及发布边界，不把这称作真实落盘测试。
        with patch('report_search_headroom.read_json', return_value=manifest), \
             patch('report_search_headroom.audit_folder', return_value=verification) as audit, \
             patch('pathlib.Path.write_text') as write, \
             patch('report_search_headroom.commit') as commit:
            output=render(folder)
        audit.assert_called_once_with(folder)
        text=write.call_args.args[0]
        self.assertEqual(output.name,'诊断结果.md')
        self.assertIn('部分完成，不能当作完整实验结论',text)
        self.assertIn('1/12次仿真',text)
        self.assertIn('| 192 | 7 | 123 | 10.0 | 12.0 |',text)
        self.assertIn('全部物理预览包含失败锚点',text)
        self.assertIn('下界间隙不是可实现的收益',text)
        self.assertFalse(commit.call_args.args[2]['complete'])

    def test_audit_failure_prevents_publishing_report(self):
        with patch('report_search_headroom.read_json', return_value=dict(version='search-headroom-v1')), \
             patch('report_search_headroom.audit_folder',side_effect=ValueError('tampered row')), \
             patch('pathlib.Path.write_text') as write, \
             patch('report_search_headroom.commit') as commit:
            with self.assertRaisesRegex(ValueError,'tampered row'):
                render(ROOT/'not-created-report-test')
        write.assert_not_called()
        commit.assert_not_called()


if __name__=='__main__':
    unittest.main()
