"""小矩阵穷举与原DP对照；不运行昂贵仿真。"""
import unittest
import random
import paths
from agv.planning.f_search import match_batch
from improved.hungarian import minimum_assignment
from hungarian_intervention import same_cost_matching


class HungarianTests(unittest.TestCase):
    def test_same_cardinality_and_cost_as_exact_dp(self):
        rng=random.Random(17)
        # 包括矩形、负代价、并列成本和禁用边；不要求并列解相同。
        for n in range(1,7):
            for m in range(1,10):
                for repeat in range(4):
                    matrix=[[float('inf') if rng.random()<.2 else rng.randrange(-5,15)
                             for j in range(m)] for i in range(n)]
                    dp=match_batch([{'id':i} for i in range(n)],[{'id':j} for j in range(m)],
                                   lambda v,j:matrix[v['id']][j['id']])
                    hu=minimum_assignment(matrix)
                    self.assertEqual(len(dp),len(hu))
                    self.assertAlmostEqual(sum(matrix[i][j] for i,j in dp),sum(matrix[i][j] for i,j in hu))

    def test_f_surrogate_against_independent_enumeration(self):
        from itertools import product
        from math import isfinite
        from objective import LinearObjective
        from improved.hungarian import linear_batch
        objective=LinearObjective()
        rng=random.Random(23)
        for n,m in ((2,3),(3,2),(3,4)):
            for repeat in range(8):
                edges={(i,j):(rng.randrange(1,40),rng.randrange(1,60))
                       for i in range(n) for j in range(m)}
                for key in list(edges):
                    if rng.random()<.2: edges[key]=(float('inf'),float('inf'))
                now,fixed,visible=100,125,10
                def score(pairs):
                    finish=max([fixed]+[now+edges[p][0] for p in pairs])
                    residual=sum(.3/900/visible*edges[p][0]+.2/5400*edges[p][1] for p in pairs)
                    return -len(pairs),.5/900*finish+residual
                candidates=[]
                for owners in product(range(-1,m),repeat=n):
                    jobs=[j for j in owners if j>=0]
                    if len(jobs)!=len(set(jobs)): continue
                    pairs=[(i,j) for i,j in enumerate(owners) if j>=0]
                    if all(all(isfinite(v) for v in edges[p]) for p in pairs): candidates.append(pairs)
                expected=min(score(p) for p in candidates)
                pairs,meta=linear_batch(list(range(n)),list(range(m)),edges,objective,now,fixed,visible)
                self.assertEqual(len(pairs),-expected[0])
                self.assertAlmostEqual(score(pairs)[1],expected[1])

    def test_physical_commit_rechecks_ready(self):
        # 评分不提交路线，真正提交仍调用世界的trip/commit，并复查可用订单。
        class World:
            active=[None,None]
            def __init__(self):
                self.jobs=[{'id':0},{'id':1}]
                self.committed=[]
            def ready(self): return self.jobs
            def estimate(self,k,j): return 1 if k==j['id'] else 10
            def trip(self,k,j): return ('physical',k,j['id'])
            def commit(self,k,j,p):
                self.committed.append((k,j['id'],p))
                self.jobs=[x for x in self.jobs if x['id']!=j['id']]
        w=World()
        self.assertEqual(same_cost_matching(w),[(0,0),(1,1)])
        self.assertEqual(len(w.committed),2)


if __name__=='__main__':
    unittest.main()
