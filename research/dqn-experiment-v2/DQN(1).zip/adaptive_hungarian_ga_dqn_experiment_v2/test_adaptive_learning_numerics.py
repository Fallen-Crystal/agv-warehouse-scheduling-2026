"""独立数值回归：不运行仿真、不写模型、不修改冻结学习实现。"""
import copy
import unittest

import numpy as np
from paths import ROOT  # 初始化正式训练依赖的模块路径。
from dqn_agent import DQNAgent
from hungarian_learning import MultiStepAgent


class LearningNumericsTests(unittest.TestCase):
    def test_scaled_initialization_huber_gradients_match_finite_differences(self):
        """用首步Adam动量反推出实际梯度，与中心差分对照。

        output_scale只缩小初始化，不是前向计算的额外乘子。
        两组奖励分别覆盖Huber二次区间与线性区间；ReLU远离零点。
        """
        for rewards in ([.1, -.2], [2., -2.]):
            with self.subTest(rewards=rewards):
                agent = DQNAgent(seed=2, state_dim=2, hidden=2, batch_size=2,
                    capacity=8, warmup=2, output_scale=.01, double_dqn=True,
                    target_interval=100)
                agent.online = dict(w1=np.array([[.2, .1], [.1, .3]]),
                    b1=np.array([.2, .2]), w2=np.array([[.004, -.002], [.003, .001]]),
                    b2=np.array([.02, -.01]))
                states = np.array([[.2, .3], [.4, .1]])
                for index, state in enumerate(states):
                    # 全部终局，目标固定为reward，数值差分不包含自举目标导数。
                    agent.remember(state, index, rewards[index], state, True)
                weights = copy.deepcopy(agent.online)

                def loss():
                    q = DQNAgent._forward(states, weights)[0]
                    error = q[np.arange(2), np.arange(2)] - rewards
                    absolute = np.abs(error)
                    return np.mean(np.where(absolute <= 1, .5 * error**2, absolute - .5))

                expected_loss = loss()
                numerical = {}
                for key, value in weights.items():
                    derivative = np.zeros_like(value)
                    for index in np.ndindex(value.shape):
                        original = value[index]
                        value[index] = original + 1e-6
                        plus = loss()
                        value[index] = original - 1e-6
                        minus = loss()
                        value[index] = original
                        derivative[index] = (plus - minus) / 2e-6
                    numerical[key] = derivative
                norm = np.sqrt(sum(np.sum(g*g) for g in numerical.values()))
                self.assertLess(norm, 10.)  # 明确排除梯度裁剪改变比较对象。
                self.assertAlmostEqual(agent.learn(), expected_loss, places=12)
                for key in agent._PARAMETERS:
                    np.testing.assert_allclose(agent.adam_m[key] / .1,
                        numerical[key], rtol=2e-6, atol=2e-9, err_msg=key)

    def test_seven_transition_episode_flushes_exact_five_step_returns(self):
        """前两条有五步自举，其余终局截断；每个原转移恰好入池一次。"""
        agent = MultiStepAgent(state_dim=2, hidden=2, batch_size=2,
            capacity=16, warmup=2, gamma=1, double_dqn=True)
        for index in range(7):
            agent.remember([index, 0], index % 2, index+1,
                [index+1, 0], index == 6)
        self.assertEqual(agent.replay_size, 7)
        self.assertEqual(len(agent.pending), 0)
        np.testing.assert_array_equal(agent.replay.rewards[:7], [15, 20, 25, 22, 18, 13, 7])
        np.testing.assert_array_equal(agent.replay.dones[:7], [False, False, True, True, True, True, True])
        np.testing.assert_array_equal(agent.replay.states[:7, 0], np.arange(7))
        np.testing.assert_array_equal(agent.replay.next_states[:7, 0], [5, 6, 7, 7, 7, 7, 7])

    def test_short_episode_flushes_without_cross_episode_rewards(self):
        agent = MultiStepAgent(state_dim=2, hidden=2, batch_size=2,
            capacity=16, warmup=2, gamma=1)
        for reward, terminal in ((1, False), (2, False), (3, True), (10, True)):
            agent.remember([0, 0], 0, reward, [1, 0], terminal)
        np.testing.assert_array_equal(agent.replay.rewards[:4], [6, 5, 3, 10])
        self.assertTrue(agent.replay.dones[:4].all())
        self.assertEqual(len(agent.pending), 0)


if __name__ == '__main__':
    unittest.main()
