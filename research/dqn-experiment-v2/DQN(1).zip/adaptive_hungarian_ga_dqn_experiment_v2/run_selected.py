"""Run the validated recommendation on an original full-load protocol window."""
import argparse
from functools import partial
import json
from pathlib import Path
import time
from paths import ROOT, verify_baseline
from boundary_policy import BoundaryPolicy
from improved.execute import run
from objective import LinearObjective, checked_score
from wepa.data import build


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--case',required=True,help='Original case ID, e.g. wepa-day45-bin4335')
    p.add_argument('--seed',type=int,default=0)
    p.add_argument('--output',required=True)
    args=p.parse_args()
    target=Path(args.output)
    if target.exists():
        raise ValueError('Refuse to overwrite output')
    protocol=json.loads((ROOT/'data/protocol.json').read_text(encoding='utf-8'))
    selection=json.loads((ROOT/'boundary_results/selection.json').read_text(encoding='utf-8'))
    validation=json.loads((ROOT/'boundary_results/validation_summary.json').read_text(encoding='utf-8'))
    selected=selection['selected']
    development=json.loads((ROOT/'boundary_results/development_summary.json').read_text(encoding='utf-8'))
    audit=json.loads((ROOT/'boundary_results/audit.json').read_text(encoding='utf-8'))
    frozen=json.loads((ROOT/'boundary_protocol.json').read_text(encoding='utf-8'))
    from report_boundary import phase_rows, DEV_ARMS
    from boundary_trial import source_hashes
    from audit_boundary import physical_hashes
    if selected not in ('t05','t1','t15','t2','t3') or selection['threshold']!=frozen['arms'][selected]['threshold']:
        raise ValueError('Selection does not match frozen threshold grid')
    phase_rows('development',frozen,DEV_ARMS,development)
    phase_rows('validation',frozen,('original','ga','matching',selected),validation)
    evidence=ROOT/'boundary_results/development'/f"{frozen['development'][0]}__original__s{frozen['development_seeds'][0]}.json"
    if physical_hashes(json.loads(evidence.read_text(encoding='utf-8'))['implementation_sha256']) != physical_hashes(source_hashes()):
        raise ValueError('Current source differs from audited experiment')
    qualified=(not development['failures'] and not validation['failures']
               and audit.get('source_matches_current') and audit.get('protocol_slots_verified')
               and validation['overall'][selected]['relative_F_original']<0
               and audit['revalidated_trials']==144
               and audit['implementation_versions']==1 and audit['all_legacy_equal'])
    arm=selected if qualified else 'original'
    case=next(c for c in protocol['cases'] if c['case']==args.case)
    objective=LinearObjective(**protocol['objective'])
    verify_baseline()
    model=build(case,**protocol['configuration'])
    factory=partial(
        BoundaryPolicy,
        threshold=float(selection['threshold']),
        keep_closed_rule=False,
        profile='hga',
    ) if qualified else None
    start=time.process_time()
    result=run(model,'gate',args.seed,objective=objective,policy_factory=factory)
    score=checked_score(model,result,objective)
    payload=dict(case=args.case,arm=arm,threshold=selection['threshold'] if qualified else 1,
                 adopted=bool(qualified),gate_metric='ready/idle' if qualified else 'pending/idle',
                 keep_closed_rule=not qualified,
                 recommendation_basis='Development-frozen threshold and reused-window validation; equal weighting of source dates after averaging three seeds.',
                 seed=args.seed,cpu=time.process_time()-start,result=result,scoring=score)
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('x',encoding='utf-8') as f:
        json.dump(payload,f,ensure_ascii=False)
    print(json.dumps(dict(arm=arm,valid=score['audit']['valid'],F=score['F_linear_v2'],cpu=payload['cpu'])))
    if not result['valid'] or not score['audit']['valid']:
        raise SystemExit(1)

if __name__=='__main__':
    main()
