"""六轮fit结束后独立审计；验证达标才开启最终测试和交付检查。

本文件只编排已有冻结入口，不修改模型、动作、奖励或预算。
验证未达标时正常返回needs_training_improvement，保留未见测试不开放。
"""
import json
import subprocess
import sys
from paths import ROOT,sha
from run_adaptive_hungarian_learning import FOLDER,read,write
from adaptive_hungarian_learning import MultiStepAgent
from audit_adaptive_hungarian_learning import analyze,verify_inputs
from diagnose_adaptive_hungarian_learning import summarize
from report_adaptive_hungarian_learning import publish


def training_diagnostics():
    """只读取训练经验：同时检查最后模型和验证选中的模型，不仿真。"""
    selected=read(FOLDER/'selection.json')
    rows=sorted(FOLDER.glob('train_e*_*.json'))
    last=rows[-1]
    chosen=FOLDER/f"train_e{selected['epoch']:02d}_09.json"
    diagnostics={}
    for label,path in (('latest',last),('selected',chosen)):
        row=read(path); checkpoint=path.with_suffix('.npz')
        assert row['checkpoint_sha256']==sha(checkpoint)
        diagnostics[label]=dict(summarize(MultiStepAgent.load(checkpoint),row),checkpoint_sha256=sha(checkpoint))
    return diagnostics


def main():
    # 自动入口也必须验证原始订单/库存来源，不能仅依赖冻结协议内的案例。
    verify_inputs()
    report=analyze()
    # 审计器会核对全部60个训练窗口、6轮验证、源代码与选模哈希。
    if not report['fit_complete']:
        raise RuntimeError('Fit incomplete: do not run post-fit review or open test')
    write(FOLDER/'audit.json',report)
    selected=report['selection']
    improvements={k:100*(1-v) for k,v in selected['mean_ratios'].items()}
    assert set(improvements)=={'ga','exact','hungarian'}
    ready=all(v>1e-8 for v in improvements.values())
    review=dict(status='validation_ready' if ready else 'needs_training_improvement',
        selected_epoch=selected['epoch'],validation_mean_improvement_percent=improvements,
        diagnostics=training_diagnostics(),test_opened_before_review=(FOLDER/'test_lock.json').exists())
    write(FOLDER/'post_fit_review.json',review)
    print(json.dumps(review,ensure_ascii=False,indent=2),flush=True)
    if not ready:
        return review
    # 继承stdio，避免捕获子进程管道；每个已有入口也独立检查冻结身份。
    subprocess.run([sys.executable,'-B','run_adaptive_hungarian_learning.py','--phase','test'],cwd=ROOT,check=True)
    # 最终测试耗时期间输入来源若变化，拒绝发布而不是沿用旧审计。
    verify_inputs()
    final=analyze()
    write(FOLDER/'audit.json',final)
    if not publish(final):
        raise RuntimeError('Final audit/report incomplete: do not mark delivery complete')
    subprocess.run([sys.executable,'-B','predict_adaptive_hungarian_dqn.py',
        '--case-json',str(ROOT/'data/hungarian_prediction_example.json'),
        '--output',str(FOLDER/'prediction_smoke.json')],cwd=ROOT,check=True)
    review.update(status='final_evaluation_complete',
        test_mean_improvement_percent=final['mean_paired_improvement_percent'],model_sha256=sha(FOLDER/'best.npz'))
    write(FOLDER/'post_fit_review.json',review)
    print(json.dumps(review,ensure_ascii=False,indent=2),flush=True)
    return review


if __name__=='__main__': main()
