"""障碍保留下界必须不超完整可行执行，也不弱于Manhattan。"""
import unittest
from headroom_static_bounds import static_lower_bounds
from objective import LinearObjective,checked_score
from wepa.data import build
from improved.execute import run
from agv.planning.distance import DistanceOracle
from copy import copy


class StaticBoundTests(unittest.TestCase):
    def test_complete_small_case_and_empty(self):
        for tasks in ([],[dict(id=0,sku=1,kind='retrieval',release=0,source_dock=1),
                            dict(id=1,sku=1,kind='delivery',release=10,source_dock=1)]):
            model=build(dict(case='static-bound-synthetic',close_at=20,initial={'1':3},tasks=tasks),vehicles=6)
            objective=LinearObjective()
            result=run(model,method='fcfs',objective=objective)
            score=checked_score(model,result,objective)
            bounds=static_lower_bounds(model,objective)
            for k in ('T','R','D'):
                self.assertLessEqual(bounds[k],result[k])
            self.assertLessEqual(bounds['F'],score['F_linear_v2']+1e-12)
            self.assertGreaterEqual(bounds['F']+1e-12,bounds['manhattan_F'])

    def test_reverse_cache_matches_forward_distances_for_all_actual_options(self):
        case=dict(case='static-cache-equivalence',close_at=20,initial={'1':3},tasks=[
            dict(id=0,sku=1,kind='retrieval',release=0,source_dock=1)])
        model=build(case,vehicles=6)
        scene=copy(model['scene'])
        scene.map_info={**scene.map_info,'station_access':'relaxed_motion'}
        router=DistanceOracle(scene)
        port=model['tasks'][0]['port']
        # 覆盖各层、两侧与所有operating homes；不只检查最终最小值。
        points=list(dict.fromkeys(tuple(p) for s in model['slots'] if s['sku']==1 for p in s['points']))
        for k,home in enumerate(scene.homes[:6]):
            for point in points:
                self.assertEqual(router.distance(home,point,k),router.distance(point,home,k))
                self.assertEqual(router.distance(port,point,k),router.distance(point,port,k))


if __name__=='__main__':
    unittest.main()
