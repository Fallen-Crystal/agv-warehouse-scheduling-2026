"""只有完整审计通过后才生成跨日期中文报告，不选择中途检查点。"""
import json
import csv
from paths import ROOT
from summarize_dqn_broad import analyze


def main():
    report=analyze()
    assert report['complete'], 'Experiment incomplete; do not publish a final conclusion'
    # 发布前重新独立核验源行和起点库存，而非只依赖训练时的选窗检查。
    from verify_dqn_broad_inputs import verify
    report['input_verification'] = verify()
    # 读取最终经验池，量化旧状态尺度在1小时窗口中的信息截断；不更新模型。
    from dqn_agent import DQNAgent
    agent = DQNAgent.load(ROOT/'results/dqn_broad_v1/final.npz')
    states = agent.replay.states[:agent.replay_size]
    report['observation_clipping'] = {
        name:dict(count=int((states[:,index]>=1).sum()),fraction=float((states[:,index]>=1).mean()))
        for index,name in [(5,'pending_age_1800s'),(6,'elapsed_time_2700s'),
                           (10,'mean_remaining_route_900s'),(11,'max_remaining_route_900s')]}
    protocol=json.loads((ROOT/'data/dqn_broad_protocol.json').read_text(encoding='utf-8'))
    cases={c['case']:c for c in protocol['cases']}
    lines=['# 扩大真实数据覆盖的DQN实验结果','',
           '单seed=0，从头训练一次遍历；10个小时窗口训练，4个独立日期窗口冻结评估。正式F、物理规则与GA预算不变。', '',
           'DQN直接选择matching或联合GA，阈值门控关闭。GA预算保持proxy=192、previews=6、generations=16；仓库62×47、6台AGV、5层货架和SIPP物理规则不变。', '',
           '正式目标（越小越好）：F=0.5T/900+0.3R/900+0.2D/5400。T不含最后回库到达时刻，R为平均订单释放至完成时间，D包含最终回库路程。', '',
           '## 真实数据使用范围','',
           '| 用途 | 日期数 | 不重复分钟数 | 不同源订单数 |','|---|---:|---:|---:|']
    for label,key in [('训练','development'),('冻结评估','evaluation')]:
        selected=[cases[n] for n in protocol[key]]
        lines.append(f'| {label} | {len(selected)} | {sum(c["close_at"] for c in selected)//60} | {sum(len(c["tasks"]) for c in selected)} |')
    lines+=['','每个日期只使用以下1小时，不是全天。day为源时间戳的日索引，不是已知公历日期。', '',
            '| 日期 | 用途 | 日内起止时刻 | 分钟 | 订单数 |','|---|---|---|---:|---:|']
    for case in sorted(cases.values(),key=lambda c:c['start_seconds']):
        hour=case['start_seconds']%86400//3600
        phase='训练' if case['case'] in protocol['development'] else '冻结评估'
        lines.append(f'| day{case["source_day"]} | {phase} | {hour:02d}:00–{hour+1:02d}:00 | 60 | {len(case["tasks"])} |')
    lines+=['','评估日期未列入此前登记的已用日期清单；不声称排除未登记使用。训练结束后冻结唯一最终检查点，评估不用于调参或择优。', '',
            '## 同窗口配对结果','',
            '改善率=(固定GA的F−DQN的F)/固定GA的F；正值表示DQN较好。固定GA为同一策略桥接中的固定GA分支，保留原有计划缓存。','',
            '| 日期 | 订单数 | DQN F | 固定GA F | DQN改善率 |','|---|---:|---:|---:|---:|']
    for pair in report['pairs']:
        case=cases[pair['case']]
        lines.append(f'| day{case["source_day"]} | {len(case["tasks"])} | {pair["dqn_F"]:.9f} | {pair["fixed_ga_F"]:.9f} | {pair["improvement_percent"]:.3f}% |')
    mean_improvement=report['mean_paired_improvement_percent']
    direction='平均改善' if mean_improvement>1e-10 else '平均退化' if mean_improvement < -1e-10 else '平均无差异'
    report['descriptive_conclusion']=direction
    lines+=['',f'4个日期的平均配对改善率为{mean_improvement:.3f}%，改善日期数{report["improved_dates"]}/4。',
            f'描述性结论：相对固定GA，DQN在本次4个日期上{direction}。这不是显著性、收敛或普遍优越性的证明。', '',
            '## 物理指标','',
            '| 日期 | 方法 | T | R | D | matching/GA动作数 |','|---|---|---:|---:|---:|---:|']
    for pair in report['pairs']:
        for key,label in [('dqn','DQN'),('fixed_ga','固定GA')]:
            row=pair[key]
            actions=row['actions']
            lines.append(f'| day{cases[pair["case"]]["source_day"]} | {label} | {row["T"]} | {row["R"]:.3f} | {row["D"]} | {actions.get("matching",0)}/{actions.get("ga",0)} |')
    lines+=['','## 审计与解释边界','',
            f'- 10条训练记录与8条冻结/固定对照记录全部有效；累计{report["train_steps"]}次更新、{report["replay_size"]}条经验。',
            '- 每窗正式F、奖励总账和分项、终局标记、有限损失及更新计数通过审计；DQN评估期间权重、目标网络、优化器、经验池、RNG保持不变。',
            '- 协议与执行源码哈希、冻结基线文件重新核对；不修改既有物理与GA源码。',
            '- F仍使用T/900、R/900、D/5400，小时窗绝对F不与旧15分钟窗口直接比较。',
            '- 只用一个seed，结果反映这一训练随机条件；不支持随机稳健性、统计显著性或收敛宣称。',
            '- 本轮仅与固定GA配对，不含固定matching或未训练DQN对照；因此即使优于GA，也不能单独证明收益来自学习而非动作策略差异。',
            '- 输入筛选要求库存、SKU及订单量适配现有模型，仅代表可行子集；货架与运动为仿真，非原工厂运行复现。',
            '- 既有24维状态的900秒归一化保留，小时窗中部分特征可能达到截断上限。',
            '- 4个日期仅作为有限参考；若依据其结果改模型，后续应重新保留测试日期。','',
            '机器可读结果：results/dqn_broad_v1/aggregate.json；输入协议：data/dqn_broad_protocol.json。']
    lines += ['', '## 最终训练经验中的状态截断', '',
              '以下比例以最终经验池中的决策状态为分母，不是分钟数或订单数占比。', '',
              '| 特征上限 | 达到上限的状态数 | 比例 |', '|---|---:|---:|']
    for name,clipping in report['observation_clipping'].items():
        lines.append(f'| {name} | {clipping["count"]} | {clipping["fraction"]:.3%} |')
    target=ROOT/'docs/DQN扩大数据实验结果.md'
    if target.exists():
        target.read_text(encoding='utf-8')
    target.write_text('\n'.join(lines)+'\n',encoding='utf-8')
    output=ROOT/'results/dqn_broad_v1/aggregate.json'
    if output.exists():
        output.read_text(encoding='utf-8')
    output.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    csv_target=ROOT/'results/dqn_broad_v1/paired_results.csv'
    import io
    csv_stream=io.StringIO()
    writer=csv.writer(csv_stream)
    writer.writerow(['case','source_day','orders','method','F','T','R','D','matching_actions','ga_actions','traffic_wait'])
    for pair in report['pairs']:
        case=cases[pair['case']]
        for method,key in [('DQN','dqn'),('固定GA','fixed_ga')]:
            row=pair[key]
            writer.writerow([pair['case'],case['source_day'],len(case['tasks']),method,
                             f'{pair[key+"_F"]:.9f}',row['T'],f'{row['R']:.6f}',row['D'],
                             row['actions'].get('matching',0),row['actions'].get('ga',0),row['traffic_wait']])
    csv_target.write_text(csv_stream.getvalue(),encoding='utf-8-sig')
    print(target)


if __name__=='__main__':
    main()
