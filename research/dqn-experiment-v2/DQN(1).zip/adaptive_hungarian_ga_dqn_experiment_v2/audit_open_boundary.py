"""开放流预测边界pilot独立重验；只读原轨迹，写派生审计和中文结果。"""
import gzip
import json
from paths import ROOT,sha
from objective import LinearObjective,checked_score
from wepa.data import build
from headroom_physics import analyze_physics
from adaptive_hungarian_learning import audit_adaptation
from audit_search_headroom import _same,audit_folder,corrected_budget_totals
from run_search_headroom import frozen_identity,read_json,commit,PROTOCOL,audit_budget


def main():
    folder=ROOT/'results/open_boundary_pilot_v1'
    manifest=read_json(folder/'manifest.json')
    _same(manifest['identity'],frozen_identity(),'identity')
    for name,digest in manifest['hashes'].items():
        _same(sha(ROOT/name),digest,'source.'+name)
    row=read_json(folder/'episode_000.json')
    for key in ('case','seed','budget','intervention'):
        _same(row[key],manifest[key],key)
    _same(row['trajectory_file'],'trajectory_000.json.gz','trajectory_file')
    raw=folder/row['trajectory_file']
    if raw.is_symlink() or raw.resolve().parent!=folder:
        raise ValueError('Trajectory escaped result directory')
    _same(sha(raw),row['trajectory_sha256'],'trajectory_sha256')
    trajectory=json.loads(gzip.decompress(raw.read_bytes()))
    protocol=read_json(PROTOCOL)
    case=next(c for c in protocol['cases'] if c['case']==row['case'])
    model=build(case,**protocol['configuration'])
    objective=LinearObjective(**protocol['objective'])
    score=checked_score(model,trajectory,objective)
    _same(row['F'],score['F_linear_v2'],'F')
    for key in ('T','R','D','traffic_wait'):
        _same(row[key],trajectory[key],key)
    _same(row['physics'],analyze_physics(model,trajectory,objective),'physics')
    for key,value in trajectory['dqn'].items():
        _same(row.get(key),value,'dqn.'+key)
    _same(trajectory['objective_sha256'],objective.fingerprint,'objective_sha256')
    _same([p[-1] for p in trajectory['paths']],model['scene'].homes[:model['vehicles']],'final_homes')
    audit_adaptation(row)
    _same(row['budget_audit'],audit_budget(row,trajectory['search_log'],row['budget']),'budget_audit')
    boundary_counts={}
    for entry in trajectory['search_log']:
        usages=[entry['anchor_usage']] + [c['usage'] for c in entry['candidates']] if 'previews' in entry else [entry['usage']]
        for usage in usages:
            _same(usage['terminal'],'standby','rollout.terminal')
            key='closed' if usage['observed_closed'] else 'open'
            boundary_counts[key]=boundary_counts.get(key,0)+1
    baseline=next(r for r in audit_folder(ROOT/'results/search_headroom_v1')['rows']
                  if r['case']==row['case'] and r['seed']==0 and r['budget_name']=='baseline')
    result=dict(valid=True,case=row['case'],baseline_F=baseline['F'],candidate_F=row['F'],
        improvement_pct=100*(1-row['F']/baseline['F']),
        component_reduction={k:baseline['physics']['weighted_terms'][k]-row['physics']['weighted_terms'][k] for k in ('T','R','D')},
        baseline_cost=baseline['corrected_budget_totals'],candidate_cost=corrected_budget_totals(trajectory['search_log']),
        boundary_counts=boundary_counts,
        qualification='单个复用训练窗，非DQN学习或新日期泛化证据；正式F及最终回库未改变')
    commit(folder,'audit.json',result)
    lines=['# 开放流预测边界单窗结果','',result['qualification'],'',
           '| 日期 | 原GA F | 开放边界GA F | 改善率 |','|---|---:|---:|---:|',
           f"| {row['source_day']} | {baseline['F']:.6f} | {row['F']:.6f} | {result['improvement_pct']:+.3f}% |",'',
           '这改变了预测尾部估计，不改变正式F。单窗结果不能证明泛化或归因于学习；必须同时检查实际计算消耗。','']
    (folder/'单窗结果.md').write_text('\n'.join(lines),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
