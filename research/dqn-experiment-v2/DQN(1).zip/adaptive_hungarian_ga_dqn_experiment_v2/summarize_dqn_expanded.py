"""汇总预先指定的三个增强DQN seed；最终轮为主要结果，不择优汇报。"""
import argparse
import json
import statistics
from pathlib import Path
from summarize_dqn import analyze


def summarize(root):
    root = Path(root)
    # 结果汇总时核验训练期间登记的物理/策略源码；不能默默合并代码漂移后的结果。
    identity_path = root / 'source_identity.json'
    if identity_path.exists():
        from paths import ROOT, sha, verify_baseline
        identity = json.loads(identity_path.read_text(encoding='utf-8'))
        assert all(sha(ROOT / name) == digest for name, digest in identity['hashes'].items()), 'Source drift'
        assert verify_baseline() == identity['baseline_files']
    reports = []
    manifests = []
    for seed in (0, 1, 2):
        folder = root / f's{seed}'
        manifest = json.loads((folder / 'manifest.json').read_text(encoding='utf-8'))
        assert manifest['config']['seed'] == seed
        assert manifest['config']['rounds'] == 6
        assert manifest['config']['variant'] == 'enhanced'
        assert manifest['double_dqn'] and manifest['output_scale'] == .01
        assert manifest['observation_schema'] == 'published-v2-24'
        report = analyze(folder)
        assert report['complete'] and report['observed'] == report['valid_count'] == 31
        reports.append(report)
        manifests.append(manifest)
    # 三个seed必须使用相同代码/协议及窗口，否则不能合并成同一实验。
    assert all(m['hashes'] == manifests[0]['hashes'] and
               m['train'] == manifests[0]['train'] and
               m['monitor'] == manifests[0]['monitor'] for m in manifests)
    per_seed = []
    for seed, report in enumerate(reports):
        curve = report['monitor']
        initial, final = curve[0]['F'], curve[-1]['F']
        per_seed.append(dict(seed=seed, initial_F=initial, final_F=final,
                             improvement_percent=100*(initial-final)/initial,
                             epoch3_F=curve[3]['F'],
                             final_vs_epoch3_percent=100*(curve[3]['F']-final)/curve[3]['F'],
                             best_monitor_F=min(r['F'] for r in curve),
                             train_steps=report['train_steps'], replay_size=report['replay_size'],
                             stability=report['stability']))
    epochs = []
    for epoch in range(7):
        values = [r['monitor'][epoch]['F'] for r in reports]
        gains = [100*(r['monitor'][0]['F']-r['monitor'][epoch]['F'])/r['monitor'][0]['F'] for r in reports]
        epochs.append(dict(epoch=epoch, F_by_seed=values, mean_F=statistics.mean(values),
                           sample_sd_F=statistics.stdev(values),
                           mean_paired_improvement_percent=statistics.mean(gains)))
    return dict(complete=True, valid_count=93, per_seed=per_seed, epochs=epochs,
                improved_seeds=sum(r['improvement_percent']>0 for r in per_seed),
                qualification='Exploratory: three seeds, one historically used monitor; no convergence or generalization claim. Final epoch6 is primary; best monitor is descriptive only.')


def plot(report, target):
    """逐seed实线及跨seed均值；不以三个seed绘制置信区间。"""
    values = [v for row in report['epochs'] for v in row['F_by_seed']]
    low, high = min(values)-.015, max(values)+.015
    x = lambda epoch: 90+epoch*100
    y = lambda value: 330-250*(value-low)/(high-low)
    svg = ['<svg xmlns="http://www.w3.org/2000/svg" width="800" height="440">',
           '<rect width="800" height="440" fill="white"/>',
           '<g font-family="Arial,sans-serif" font-size="14" fill="#243047">',
           '<text x="65" y="32" font-size="20">Enhanced DQN: frozen day40 F (lower is better)</text>',
           '<path d="M90 70V330H710" stroke="#7c8799" fill="none"/>']
    for i in range(6):
        value = low+(high-low)*i/5
        pos = y(value)
        svg.append(f'<path d="M90 {pos}H710" stroke="#e8ecf0"/><text x="25" y="{pos+5}">{value:.3f}</text>')
    for epoch in range(7):
        svg.append(f'<text x="{x(epoch)-4}" y="353">{epoch}</text>')
    colors = ['#2463bc', '#bc5424', '#358052', '#202733']
    for index, color in enumerate(colors):
        series = [r['F_by_seed'][index] if index<3 else r['mean_F'] for r in report['epochs']]
        points = ' '.join(f'{x(e)},{y(v)}' for e, v in enumerate(series))
        svg.append(f'<polyline points="{points}" stroke="{color}" stroke-width="{3 if index==3 else 2}" fill="none"/>')
        label = f'seed {index}' if index<3 else 'mean (3 seeds)'
        svg.append(f'<text x="{90+index*165}" y="400" fill="{color}">{label}</text>')
    svg.append('<text x="340" y="375">Training epoch</text><text x="90" y="425" font-size="12">Exploratory: one historically used monitor; epoch 6 is the primary endpoint.</text></g></svg>')
    if target.exists():
        target.read_text(encoding='utf-8')
    target.write_text('\n'.join(svg), encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root')
    args = parser.parse_args()
    report = summarize(args.root)
    target = Path(args.root) / 'aggregate.json'
    if target.exists():
        target.read_text(encoding='utf-8')
    target.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    plot(report, Path(args.root) / 'learning_curves.svg')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
