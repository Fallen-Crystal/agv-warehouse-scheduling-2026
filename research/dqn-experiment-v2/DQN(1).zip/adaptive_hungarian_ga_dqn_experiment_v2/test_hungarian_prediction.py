"""新输入边界验证；无仿真，不访问训练/验证/测试订单。"""
import copy
import unittest
from paths import ROOT
from run_hungarian_learning import read
from predict_hungarian_dqn import validate_case

class InputTests(unittest.TestCase):
    def setUp(self): self.case=read(ROOT/'data/hungarian_prediction_example.json')

    def test_valid_small_input_flags_training_range(self):
        self.assertEqual(validate_case(self.case),dict(orders=2,skus=1,initial_stock=1,seconds=1800,outside_training_input_range=True))

    def test_rejects_negative_and_window_end_release(self):
        for release in (-1,1800,True,1.5):
            with self.subTest(release=release):
                case=copy.deepcopy(self.case); case['tasks'][0]['release']=release
                with self.assertRaises(ValueError): validate_case(case)

    def test_rejects_duplicate_and_unknown_task_fields(self):
        for key,value in (('id',0),('kind','unknown'),('sku',999),('source_dock',0),('release',-1)):
            with self.subTest(field=key):
                case=copy.deepcopy(self.case); case['tasks'][1][key]=value
                with self.assertRaises(ValueError): validate_case(case)

    def test_rejects_prefix_shortage_and_capacity_overflow(self):
        for first_kind,count in (('retrieval',0),('delivery',1)):
            case=copy.deepcopy(self.case); case['initial']['101']=count
            if first_kind=='retrieval': case['tasks'][0]['kind']=first_kind
            else:
                case['tasks']=[dict(case['tasks'][0],id=i) for i in range(51)]
            with self.assertRaises(ValueError): validate_case(case)

if __name__=='__main__': unittest.main()
