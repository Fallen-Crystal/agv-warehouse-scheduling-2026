"""搜索预算使用率与物理预览终止原因；不把剪枝称作无效或不合法。"""
import gzip
import json
from paths import ROOT,sha
from audit_search_headroom import audit_folder
from run_search_headroom import commit


def analyze(row,trajectory):
    searches=row['ga_searches']
    generations=[len(s['mutation_history']) for s in searches]
    diverse=[h['diversity'] for s in searches for h in s['mutation_history']]
    reasons={}
    by_kind={}
    for entry in trajectory['search_log']:
        uses=[('anchor',entry['anchor_usage'],entry.get('base_score'))] if 'previews' in entry else [('anchor_failed',entry['usage'],None)]
        uses += [(c['kind'],c['usage'],c['score']) for c in entry.get('candidates',[])]
        for kind,usage,score in uses:
            reason=usage['reason']
            reasons[reason]=reasons.get(reason,0)+1
            item=by_kind.setdefault(kind,dict(attempts=0,route_calls=0,completed=0,strictly_better_than_anchor=0))
            item['attempts']+=1
            item['route_calls']+=usage['route_calls']
            item['completed']+=score is not None
            if kind!='anchor' and score is not None and score<entry.get('base_score',float('-inf'))-1e-12:
                item['strictly_better_than_anchor']+=1
    cap=row['budget']['proxy']
    return dict(case=row['case'],source_day=row['source_day'],budget_name=row['budget_name'],
        F=row['F'],searches=len(searches),
        proxy_evaluations=sum(s['proxy_evaluations'] for s in searches),
        proxy_ceiling_sum=cap*len(searches),
        proxy_budget_fill_fraction=sum(s['proxy_evaluations'] for s in searches)/(cap*len(searches)) if searches else 0,
        mean_generations=sum(generations)/len(generations) if generations else 0,
        mean_population_diversity=sum(diverse)/len(diverse) if diverse else 0,
        rollout_reasons=reasons,by_kind=by_kind)


def main():
    folder=ROOT/'results/search_headroom_v1'
    verified=audit_folder(folder)
    rows=[]
    for row in verified['rows']:
        raw=folder/row['trajectory_file']
        if sha(raw)!=row['trajectory_sha256']:
            raise ValueError('Trajectory changed')
        trajectory=json.loads(gzip.decompress(raw.read_bytes()))
        rows.append(analyze(row,trajectory))
    result=dict(rows=rows,complete=verified['complete'],
        qualification='Pruning means certified unable to beat current visible-work incumbent under the implemented rollout bound; not infeasibility or proof of global optimality. Duplicate proposals may leave proxy allowance unused. No future data enters policy.')
    commit(folder,'search_efficiency.json',result)
    lines=['# 搜索预算实际使用与预览终止', '',
        '| 日期 | 组 | 搜索 | 代理评估 | 上限占比 | 平均代数 | 平均多样性 | 预览终止原因 |',
        '|---|---|---:|---:|---:|---:|---:|---|']
    for row in rows:
        lines.append(f"| {row['source_day']} | {row['budget_name']} | {row['searches']} | {row['proxy_evaluations']} | {100*row['proxy_budget_fill_fraction']:.1f}% | {row['mean_generations']:.2f} | {row['mean_population_diversity']:.3f} | {row['rollout_reasons']} |")
    lines+=['','代理评估是不同染色体的缓存未命中计数；上限占比低可能来自可见任务少、重复方案或固定代数，不直接证明搜索不足。多样性均值混合不同规模任务队列，仅为描述。', '',
            'bound_pruned表示该次预览在实现中的下界已不能胜过当时incumbent，不能叫路径不合法；query_budget/incomplete才表示该预览未完整结束。剪枝无法证明在线整窗已近最优。','']
    (folder/'搜索使用率.md').write_text('\n'.join(lines),encoding='utf-8')
    print([(r['source_day'],r['budget_name'],r['proxy_budget_fill_fraction'],r['rollout_reasons']) for r in rows],flush=True)


if __name__=='__main__':
    main()
