"""Ready/idle gate with an explicit, readable GA implementation choice.

The boundary study keeps the dispatch rule separate from the optimizer:
``matching`` handles the light-load branch, while ``seeded_joint_ga``
handles the backlog branch.  The seeded GA starts from two deterministic
feasible matching plans and then uses the existing joint GA search.
"""
import math
import time
from improved.policy import ResearchPolicy
from improved.matching import matching


SUPPORTED_PROFILES = {"gate", "hga"}


def use_matching(pending, free, threshold, closed=False, keep_closed_rule=True):
    """Choose the fast branch from all visible unassigned work.

    ``pending`` is the complete published-but-unassigned workload.  The
    policy still waits when no task is executable, but the switching ratio
    deliberately does not discard blocked or predecessor-dependent tasks.
    """
    if free <= 0 or pending <= 0:
        return False
    if keep_closed_rule and closed:
        return False
    return pending / free <= threshold


class BoundaryPolicy(ResearchPolicy):
    def __init__(self, seed, *, objective, threshold=1.0,
                 keep_closed_rule=True, profile="gate"):
        """Create one threshold policy.

        ``gate`` is the historical ordinary joint-GA profile.  ``hga`` is
        the new seeded profile: it inserts deterministic initial matching
        plans before the same joint-GA crossover/mutation search.  Keeping
        the profile explicit makes old and new experiments reproducible.
        """
        if math.isnan(threshold) or threshold < 0:
            raise ValueError('Threshold must be nonnegative')
        if profile not in SUPPORTED_PROFILES:
            raise ValueError(f'Unsupported GA profile: {profile}')
        super().__init__(profile, seed, objective=objective)
        # The boundary policy owns the ready/idle gate.  ResearchPolicy's
        # own pending/free gate must therefore stay disabled here.
        self.settings = dict(self.settings, gate=False)
        self.threshold = threshold
        self.keep_closed_rule = keep_closed_rule
        self.ga_profile = profile

    def action(self, world):
        pending = len(set(world.visible) - world.assigned)
        ready = len(world.ready())
        free = sum(r is None for r in world.active)
        if not ready or not free:
            return []
        selected = use_matching(pending, free, self.threshold,
                                world.closed, self.keep_closed_rule)
        event = dict(time=world.time, mode='boundary_decision', pending=pending,
                     ready=ready, pending_per_free=pending/free,
                     gate_metric='pending/idle',
                     free=free, vehicles=len(world.active),
                     ready_per_free=ready/free if free else None,
                     pending_per_vehicle=pending/len(world.active),
                     closed=world.closed, threshold='inf' if math.isinf(self.threshold) else self.threshold,
                     branch='matching' if selected else 'ga',
                     visible_ids=sorted(world.visible))
        self.logs.append(event)
        before = time.process_time()
        if selected:
            self.plan = None
            pairs = matching(world)
        else:
            pairs = super().action(world)
        event['cpu_seconds'] = time.process_time() - before
        event['assigned_count'] = len(pairs)
        return pairs
