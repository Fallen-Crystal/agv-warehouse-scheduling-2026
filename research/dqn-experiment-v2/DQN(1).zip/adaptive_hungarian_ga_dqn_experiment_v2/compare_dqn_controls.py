"""同代码、同物理seed的固定动作对照；不把门控hga冒充始终GA。"""
import argparse
import json
from pathlib import Path
from paths import ROOT, verify_baseline, sha
from train_dqn import execute


class FixedActionAgent:
    """使用DQN完全相同的策略桥接，只固定动作，无网络/学习。"""
    train_steps = 0
    replay_size = 0
    epsilon = 0.0
    def __init__(self, action):
        self.action = action
    def select(self, state, training=False):
        if training:
            raise ValueError("Fixed control cannot train")
        return self.action


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--cases", default="wepa-day40-bin3885")
    p.add_argument("--seed",type=int,default=0)
    p.add_argument("--output",required=True)
    args = p.parse_args()
    target = Path(args.output)
    if target.exists():
        raise FileExistsError(target)
    verify_baseline()
    protocol = json.loads((ROOT/"data/protocol.json").read_text(encoding="utf-8"))
    cases = {c["case"]:c for c in protocol["cases"]}
    names = args.cases.split(",")
    if len(names)!=len(set(names)) or any(name not in cases for name in names):
        p.error("Unknown or duplicate cases")
    rows = []
    for action,name in enumerate(("always_matching","always_ga_branch")):
        for case in names:
            row = dict(strategy=name,seed=args.seed,
                       **execute(cases[case],protocol,FixedActionAgent(action),args.seed,False))
            rows.append(row)
            print(json.dumps({k:v for k,v in row.items() if k not in ("transitions","losses")}),flush=True)
    result = dict(rows=rows,qualification="paired current-code controls; GA branch may reuse cached plan",
                  hashes={name:sha(ROOT/name) for name in
                          ("dqn_policy.py","compare_dqn_controls.py","data/protocol.json")})
    target.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")


if __name__ == "__main__":
    main()
