"""Independent, offline audit for committed search-headroom-v1 episodes.

Never changes the running experiment, source files, manifest or episode rows.
The supplemental identity is exclusive/create-once. audit.json is a derived
snapshot and may be refreshed. No dispatcher or simulation runner is called.
"""
import argparse
from datetime import datetime, timezone
import gzip
import json
import math
from pathlib import Path

from paths import ROOT, sha
from objective import LinearObjective, checked_score
from wepa.data import build
from headroom_physics import analyze_physics
from adaptive_hungarian_learning import ADAPTATION
from run_search_headroom import (
    BUDGETS, PROTOCOL, read_json, frozen_identity, select_cases, audit_budget, commit,
)

SUPPLEMENT = 'supplement_identity.json'
EXTRA_SOURCES = ('paths.py', 'data/baseline-manifest.json',
                 'audit_search_headroom.py', 'test_search_headroom_audit.py')
CAPTURE_CAVEAT = ('Captured after the experiment job started; this does not retroactively '
                  'prove these files were unchanged before capture.')


def _same(actual, expected, location):
    """Compare complete JSON structures; tolerate only floating-point roundoff."""
    if isinstance(expected, bool) or expected is None or isinstance(expected, str):
        valid = type(actual) is type(expected) and actual == expected
    elif isinstance(expected, (int, float)):
        valid = (isinstance(actual, (int, float)) and not isinstance(actual, bool)
                 and math.isfinite(actual) and math.isfinite(expected)
                 and math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-9))
    elif isinstance(expected, dict):
        valid = isinstance(actual, dict) and actual.keys() == expected.keys()
        if valid:
            for key in expected:
                _same(actual[key], expected[key], f'{location}.{key}')
    elif isinstance(expected, (list, tuple)):
        valid = isinstance(actual, (list, tuple)) and len(actual) == len(expected)
        if valid:
            for i, value in enumerate(expected):
                _same(actual[i], value, f'{location}[{i}]')
    else:
        raise TypeError(f'Non-JSON audit value at {location}')
    if not valid:
        raise ValueError('Audit mismatch: ' + location)


def _inside(folder, name):
    path = folder / name
    if path.resolve().parent != folder or path.name != name or path.is_symlink():
        raise ValueError('Audit path escaped its experiment directory: ' + name)
    return path


def _verify_original(folder):
    manifest = read_json(_inside(folder, 'manifest.json'))
    current = frozen_identity()  # Includes historical hashes and verify_baseline().
    for key, value in current.items():
        _same(manifest.get(key), value, 'manifest.' + key)
    return manifest


def freeze_supplement(folder):
    """Create supplemental identity once; explicitly NOT a pre-launch freeze."""
    folder = Path(folder).resolve(strict=True)
    _verify_original(folder)
    payload = dict(schema='headroom-supplement-v1',
                   captured_at_utc=datetime.now(timezone.utc).isoformat(),
                   capture_timing='after_job_start', caveat=CAPTURE_CAVEAT,
                   manifest_sha256=sha(_inside(folder, 'manifest.json')),
                   hashes={name: sha(ROOT / name) for name in EXTRA_SOURCES})
    destination = _inside(folder, SUPPLEMENT)
    # 'x' refuses replacement, including races with another freeze invocation.
    with destination.open('x', encoding='utf-8') as stream:
        json.dump(payload, stream, ensure_ascii=False, indent=2, allow_nan=False)
    return payload


def _verify_supplement(folder):
    supplement = read_json(_inside(folder, SUPPLEMENT))
    _same(supplement.get('schema'), 'headroom-supplement-v1', 'supplement.schema')
    _same(supplement.get('capture_timing'), 'after_job_start', 'supplement.capture_timing')
    _same(supplement.get('caveat'), CAPTURE_CAVEAT, 'supplement.caveat')
    captured = datetime.fromisoformat(supplement['captured_at_utc'])
    if captured.tzinfo is None:
        raise ValueError('Supplement capture time must include timezone')
    _same(supplement.get('manifest_sha256'), sha(_inside(folder, 'manifest.json')),
          'supplement.manifest_sha256')
    _same(supplement.get('hashes'), {name: sha(ROOT/name) for name in EXTRA_SOURCES},
          'supplement.hashes')
    return supplement


def corrected_budget_totals(logs):
    """Count every rollout, including failed anchors and pruned candidates."""
    successful_previews = failed_anchors = success_searches = route_calls = 0
    reasons = {}
    for entry in logs:
        if 'previews' in entry:
            success_searches += 1
            usages = [entry['anchor_usage']] + [c['usage'] for c in entry['candidates']]
            _same(entry['previews'], len(usages), 'search.previews_vs_rollouts')
            successful_previews += len(usages)
        else:
            _same(entry.get('error'), 'anchor_incomplete', 'failed_search.error')
            usages = [entry['usage']]
            failed_anchors += 1
        for usage in usages:
            calls = usage['route_calls']
            if isinstance(calls, bool) or not isinstance(calls, int) or calls < 0:
                raise ValueError('Invalid rollout route_calls')
            route_calls += calls
            reason = usage['reason']
            reasons[reason] = reasons.get(reason, 0) + 1
    return dict(successful_searches=success_searches, failed_anchors=failed_anchors,
                successful_search_previews=successful_previews,
                total_physical_previews=successful_previews+failed_anchors,
                physical_previews_total=successful_previews+failed_anchors,
                failed_anchor_previews=failed_anchors,
                rollout_route_calls=route_calls, rollout_route_calls_total=route_calls,
                rollout_reasons=reasons,
                note='Counts all attempted rollouts, including failed anchors and bound-pruned trials; '
                     'route_calls excludes execution routing outside rollouts and is not wall time.')


def audit_folder(folder):
    """Validate committed episodes and write only a derived audit.json snapshot.

    A missing supplement is an error: explicitly call freeze_supplement first.
    New episodes committed concurrently after the snapshot are audited next time.
    Returned rows are copies of original rows, with corrected cost fields added.
    Seed is verified against the frozen schedule, not independently reconstructed
    from trajectories (the original raw trace does not store its RNG seed).
    """
    folder = Path(folder).resolve(strict=True)
    started = datetime.now(timezone.utc).isoformat()
    manifest = _verify_original(folder)
    supplement = _verify_supplement(folder)
    protocol = read_json(PROTOCOL)
    _same(manifest.get('version'), 'search-headroom-v1', 'manifest.version')
    _same(manifest.get('protocol_sha256'), sha(PROTOCOL), 'manifest.protocol_sha256')
    _same(manifest.get('budgets'), BUDGETS, 'manifest.budgets')
    _same(manifest.get('future_orders_visible_to_policy'), False, 'manifest.future_orders_visible_to_policy')
    _same(manifest.get('blocked_test_cases'), protocol['test'], 'manifest.blocked_test_cases')
    cases = select_cases(protocol, [c['case'] for c in manifest['cases']])
    _same(manifest['cases'], [dict(case=c['case'], source_day=c['source_day'], orders=len(c['tasks']))
                              for c in cases], 'manifest.cases')
    seeds = manifest['seeds']
    if (not seeds or any(type(s) is not int or s < 0 for s in seeds)
            or len(set(seeds)) != len(seeds)):
        raise ValueError('Invalid frozen seeds')
    schedule = [(case, seed, name) for case in cases for seed in seeds for name in BUDGETS]
    _same(manifest.get('planned_runs'), len(schedule), 'manifest.planned_runs')
    # Snapshot committed row names once; an orphan trajectory is not a committed row.
    names = {path.name for path in folder.glob('episode_*.json')}
    expected = {f'episode_{i:03d}.json' for i in range(len(schedule))}
    if not names <= expected:
        raise ValueError('Unexpected episode filename outside the frozen schedule')
    objective = LinearObjective(**protocol['objective'])
    rows, digests = [], {}
    for i, (case, seed, name) in enumerate(schedule):
        filename = f'episode_{i:03d}.json'
        if filename not in names:
            continue
        path = _inside(folder, filename)
        digest = sha(path)
        row = read_json(path)
        budget = BUDGETS[name]
        for key, value in dict(case=case['case'], seed=seed, budget_name=name, budget=budget,
                               valid=True, source_day=case['source_day'], orders=len(case['tasks']),
                               same_budget_control=name=='baseline', version='search-headroom-v1',
                               phase='development_diagnostic', ga_adaptation=dict(ADAPTATION,
                               proxy_budget=budget['proxy'], generations=budget['generations'],
                               previews=budget['previews'])).items():
            _same(row.get(key), value, filename+'.'+key)
        raw_name = f'trajectory_{i:03d}.json.gz'
        _same(row.get('trajectory_file'), raw_name, filename+'.trajectory_file')
        raw_path = _inside(folder, raw_name)
        _same(sha(raw_path), row['trajectory_sha256'], filename+'.trajectory_sha256')
        raw = json.loads(gzip.decompress(raw_path.read_bytes()).decode('utf-8'))
        model = build(case, **protocol['configuration'])
        scoring = checked_score(model, raw, objective)
        physics = analyze_physics(model, raw, objective)
        _same(row.get('F'), scoring['F_linear_v2'], filename+'.F')
        for key in ('T', 'R', 'D', 'traffic_wait'):
            _same(row.get(key), raw[key], filename+'.'+key)
        _same(row.get('physics'), physics, filename+'.physics')
        for key, value in raw['dqn'].items():
            _same(row.get(key), value, filename+'.dqn.'+key)
        _same(raw.get('method'), 'rl', filename+'.raw.method')
        _same(raw.get('objective_sha256'), objective.fingerprint, filename+'.raw.objective_sha256')
        recalculated = audit_budget(row, raw['search_log'], budget)
        _same(row.get('budget_audit'), recalculated, filename+'.budget_audit')
        corrected = dict(recalculated, **corrected_budget_totals(raw['search_log']))
        # Within corrected totals, the familiar field now means ALL attempts.
        # The original row['budget_audit'] remains untouched for provenance.
        corrected['physical_previews'] = corrected['total_physical_previews']
        for key in ('wall', 'diagnostic_wall'):
            value = row.get(key)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
                raise ValueError('Invalid wall time: '+filename+'.'+key)
        # Detect concurrent edits during expensive replay before accepting a row.
        _same(sha(path), digest, filename+'.stable_sha256')
        _same(sha(raw_path), row['trajectory_sha256'], filename+'.stable_trajectory_sha256')
        digests[filename] = digest
        rows.append(dict(row, corrected_budget_totals=corrected,
                         execution_wall=row['wall'], diagnostic_wall=row['diagnostic_wall'],
                         source_split='training' if case['case'] in protocol['development'] else 'validation',
                         audit_episode_sha256=digest))
    _same(_verify_original(folder), manifest, 'manifest.stable')
    _same(_verify_supplement(folder), supplement, 'supplement.stable')
    result = dict(schema='headroom-independent-audit-v1', valid=True,
                  started_at_utc=started, finished_at_utc=datetime.now(timezone.utc).isoformat(),
                  complete=len(rows)==len(schedule), completed_runs=len(rows), planned_runs=len(schedule),
                  committed_episode_sha256=digests, rows=rows, supplement=supplement,
                  caveats=[CAPTURE_CAVEAT,
                           'Audit snapshots committed row names; the running job may commit more rows afterwards.',
                           'Seed provenance is schedule consistency only; raw trajectories contain no independent seed.',
                           'Execution wall includes original scoring/reward checks; diagnostic wall additionally includes audit/physics analysis.',
                           'Neither wall value is pure GA search time; both are original measurements, not independently remeasured.',
                           'GA mutation histories are checked algebraically and against logged counts, not rerun from RNG.',
                           'Raw trace hashes establish integrity relative to the row, not an external signature.'])
    commit(folder, 'audit.json', result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('folder', help='Existing headroom experiment directory')
    parser.add_argument('--freeze', action='store_true', help='Exclusively create supplemental identity')
    parser.add_argument('--audit', action='store_true', help='Audit committed rows without rerunning simulation')
    args = parser.parse_args()
    if not (args.freeze or args.audit):
        parser.error('Choose --freeze and/or --audit')
    if args.freeze:
        print(json.dumps(freeze_supplement(args.folder), ensure_ascii=False), flush=True)
    if args.audit:
        result = audit_folder(args.folder)
        print(json.dumps({k: result[k] for k in ('valid', 'complete', 'completed_runs', 'planned_runs')},
                         ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
