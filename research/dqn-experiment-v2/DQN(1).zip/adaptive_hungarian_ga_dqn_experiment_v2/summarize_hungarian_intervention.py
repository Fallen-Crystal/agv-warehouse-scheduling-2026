"""替换实验独立审计与中文报告；未齐8条记录时不发布最终结论。"""
import csv
import io
import json
import statistics
from paths import ROOT,sha,verify_baseline
from summarize_dqn_broad import analyze as original_analysis,audit_row


def analyze():
    original=original_analysis()
    assert original['complete']
    folder=ROOT/'results/hungarian_intervention_v1'
    manifest=json.loads((folder/'manifest.json').read_text(encoding='utf-8'))
    assert verify_baseline()==manifest['baseline_files']
    assert all(sha(ROOT/name)==digest for name,digest in manifest['hashes'].items()),'Source drift'
    assert sha(ROOT/'results/dqn_broad_v1/final.npz')==manifest['checkpoint_sha256']
    rows=[]
    for variant in manifest['variants']:
        for i,name in enumerate(manifest['evaluation']):
            path=folder/f'{variant}_{i:02d}.json'
            if not path.exists():
                continue
            row=json.loads(path.read_text(encoding='utf-8'))
            audit_row(row)
            assert row['variant']==variant and row['case']==name and row['seed']==0
            assert row['frozen_state_verified'] and not row['losses']
            assert row['checkpoint_sha256']==manifest['checkpoint_sha256']
            assert (row['train_steps'],row['replay_size'])==(original['train_steps'],original['replay_size'])
            prior=next(p for p in original['pairs'] if p['case']==name)
            rows.append(dict(variant=variant,case=name,F=row['F'],T=row['T'],R=row['R'],D=row['D'],
                             actions=row['actions'],wall=row['wall'],original_dqn_F=prior['dqn_F'],
                             fixed_ga_F=prior['fixed_ga_F'],
                             improvement_vs_original_percent=100*(prior['dqn_F']-row['F'])/prior['dqn_F'],
                             improvement_vs_ga_percent=100*(prior['fixed_ga_F']-row['F'])/prior['fixed_ga_F']))
    return dict(complete=len(rows)==8,completed=len(rows),rows=rows,
                means={v:{key:statistics.mean(r[key] for r in rows if r['variant']==v)
                          for key in ('improvement_vs_original_percent','improvement_vs_ga_percent')}
                       for v in manifest['variants'] if any(r['variant']==v for r in rows)})


def main():
    report=analyze()
    print(json.dumps(report,ensure_ascii=False,indent=2))
    if not report['complete']:
        return
    folder=ROOT/'results/hungarian_intervention_v1'
    labels={'same_cost':'同成本匈牙利','f_surrogate':'F代理成本匈牙利'}
    lines=['# 匈牙利替换探索性实验','',
           '## 设计与解释边界','',
           '- 原精准匹配是精确最大匹配数、最小成本位掩码DP，不是贪心。相同矩阵下匈牙利不可能降低数学最优成本，但并列解、提交顺序会改变后续物理调度。',
           '- 同成本变体仅替换求解器；F代理变体同时改变当前批次代价，不能将其收益全部归因于匈牙利求解器。',
           '- 两变体各执行day41、52、59、65的一小时窗口一次：共504条不同订单，8次仿真；复用原最终DQN，无继续训练、无阈值门控。',
           '- 正式F=0.5T/900+0.3R/900+0.2D/5400（越小越好），物理执行和GA预算不变。',
           '- 原DQN的matching动作含义在替换后发生变化，未针对新动作重新学习；该结果是冻结策略干预效果，不代表新组合重新训练后的上限。',
           '- 这些日期已在上一轮评估使用，本轮属于探索性诊断，不是新的独立泛化或显著性证据。', '',
           '## 逐日期正式F','',
           '改善率=(参考F−变体F)/参考F；正数更好。', '',
           '| 变体 | 日期 | 变体F | 原DQN F | 固定GA F | 对原DQN改善 | 对GA改善 |',
           '|---|---|---:|---:|---:|---:|---:|']
    for r in report['rows']:
        day=r['case'].split('-')[2]
        lines.append(f'| {labels[r["variant"]]} | {day} | {r["F"]:.9f} | {r["original_dqn_F"]:.9f} | {r["fixed_ga_F"]:.9f} | {r["improvement_vs_original_percent"]:.3f}% | {r["improvement_vs_ga_percent"]:.3f}% |')
    lines+=['','## 平均配对结果','']
    for v,mean in report['means'].items():
        lines.append(f'- {labels[v]}：对原DQN平均改善{mean["improvement_vs_original_percent"]:.3f}%；对固定GA平均改善{mean["improvement_vs_ga_percent"]:.3f}%。')
        values=[r['improvement_vs_original_percent'] for r in report['rows'] if r['variant']==v]
        better=sum(x>1e-10 for x in values)
        worse=sum(x < -1e-10 for x in values)
        equal=len(values)-better-worse
        lines.append(f'  相对原DQN：改善{better}个日期、持平{equal}个、退化{worse}个。')
        if worse:
            lines.append('  存在退化日期，即使平均改善也不能称为稳定优于原策略。')
    lines+=['','本轮不证明持续学习收益：两变体均未重新训练；也不根据已看过的4个日期直接认定可部署或具有普遍优势。']
    lines+=['','## 自学习能否一直变好？','',
            '不能保证。继续训练可能改善，也可能过拟合、灾难性遗忘或退化。本轮仅检验分支替换，未执行新的学习。',
            '后续若训练，应先固定新动作定义，在训练/验证集上选择模型，并保留未用日期作最终测试；允许候选模型不如旧模型时拒绝部署，但这也不能保证未知未来数据单调改善。', '',
            '## 审计','',
            '8条结果均通过轨迹有效标志、正式F复算、奖励总账与分项、终局标记审计；冻结权重/优化器/经验池/RNG检查由运行器逐次执行；最终检查点哈希和执行源码哈希一致。',
            '运行耗时仅作为原始诊断字段保留：不同时间的机器负载不受控，不据此宣称加速。']
    target=ROOT/'docs/匈牙利替换实验结果.md'
    if target.exists(): target.read_text(encoding='utf-8')
    target.write_text('\n'.join(lines)+'\n',encoding='utf-8')
    target=folder/'aggregate.json'
    if target.exists(): target.read_text(encoding='utf-8')
    target.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    stream=io.StringIO()
    keys=['variant','case','F','T','R','D','original_dqn_F','fixed_ga_F',
          'improvement_vs_original_percent','improvement_vs_ga_percent']
    writer=csv.DictWriter(stream,fieldnames=keys,extrasaction='ignore')
    writer.writeheader()
    writer.writerows(report['rows'])
    target=folder/'paired_results.csv'
    if target.exists(): target.read_text(encoding='utf-8-sig')
    target.write_text(stream.getvalue(),encoding='utf-8-sig')


if __name__=='__main__':
    main()
