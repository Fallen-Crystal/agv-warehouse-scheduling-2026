"""独立核验扩大数据协议：源行完整、日期隔离、窗口边界与库存前缀。"""
import bisect
import json
from collections import Counter
from paths import ROOT, sha


def verify():
    protocol = json.loads((ROOT/'data/dqn_broad_protocol.json').read_text(encoding='utf-8'))
    raw = ROOT/'deliverables/wepa_real_data/raw'
    assert sha(raw/'2_orders.json') == protocol['source_sha256']
    assert sha(raw/'3_initial_fill_lvl.json') == protocol['initial_stock_sha256']
    orders = json.loads((raw/'2_orders.json').read_text(encoding='utf-8'))
    times = [r[2] for r in orders]
    assert times == sorted(times), 'Source order stream not chronological'
    cases = {c['case']:c for c in protocol['cases']}
    assert len(cases) == len(protocol['cases']) == 14
    train, evaluation = set(protocol['development']), set(protocol['evaluation'])
    assert train.isdisjoint(evaluation) and train|evaluation == set(cases)
    train_days = {cases[n]['source_day'] for n in train}
    evaluation_days = {cases[n]['source_day'] for n in evaluation}
    assert len(train_days)==10 and len(evaluation_days)==4
    assert train_days.isdisjoint(evaluation_days)
    assert evaluation_days.isdisjoint(protocol['previously_used_days'])
    # 从原始起始库存逐笔回放，独立验证各窗口起点的完整前缀账本。
    stock = Counter({int(k):v for k,v in json.loads((raw/'3_initial_fill_lvl.json').read_text()).items()})
    cursor = 0
    selected_rows = set()
    for case in sorted(cases.values(),key=lambda c:c['start_seconds']):
        start,end = case['start_seconds'],case['end_seconds']
        left,right = bisect.bisect_left(times,start),bisect.bisect_left(times,end)
        while cursor < left:
            r = orders[cursor]
            stock[r[1]] += 1 if r[0]=='delivery' else -1
            cursor += 1
        initial = {int(k):v for k,v in case['initial'].items()}
        assert all(stock[s]==v for s,v in initial.items()), 'Initial stock prefix mismatch'
        assert [t['source_row'] for t in case['tasks']] == list(range(left,right))
        assert start%3600==0 and end-start==case['close_at']==3600
        assert case['source_day']==start//86400
        assert 60<=len(case['tasks'])<=240 and 2<=len(initial)<=5 and sum(initial.values())<=900
        assert {t['kind'] for t in case['tasks']}=={'delivery','retrieval'}
        ledger=Counter(initial)
        for index,t in enumerate(case['tasks']):
            source=t['source_row']
            assert source not in selected_rows
            selected_rows.add(source)
            assert t['id']==index
            assert orders[source]==[t[k] for k in ('kind','sku','source_time','source_dock','batch','week')]
            assert 0<=t['release']==t['source_time']-start<3600
            ledger[t['sku']] += 1 if t['kind']=='delivery' else -1
            assert 0<=ledger[t['sku']]<=initial[t['sku']]+50
    assert len(selected_rows)==1831
    return dict(verified=True,windows=14,unique_orders=len(selected_rows),unique_minutes=840,
                initial_stock_prefix_verified=True,training_days=sorted(train_days),
                evaluation_days=sorted(evaluation_days))


if __name__=='__main__':
    print(json.dumps(verify(),ensure_ascii=False,indent=2))
