"""审计DQN逐窗结果，区分未训练基线、训练成绩与冻结监测成绩。"""
import argparse
import json
import math
import statistics
from pathlib import Path


def analyze(folder):
    folder = Path(folder)
    manifest = json.loads((folder/"manifest.json").read_text(encoding="utf-8"))
    rows = [json.loads(line) for line in (folder/"episodes.jsonl").read_text(encoding="utf-8").splitlines() if line]
    rounds = manifest["config"]["rounds"]
    expected = {(e,"train",c) for e in range(1,rounds+1) for c in manifest["train"]}
    expected |= {(e,"monitor",c) for e in range(rounds+1) for c in manifest["monitor"]}
    keys = [(r["epoch"],r["phase"],r["case"]) for r in rows]
    assert len(keys)==len(set(keys)) and set(keys)<=expected,"Duplicate or unexpected rows"
    previous_steps = previous_replay = 0
    for row in rows:
        formal = .5*row["T"]/900 + .3*row["R"]/900 + .2*row["D"]/5400
        assert abs(formal-row["F"])<1e-12,"Formal objective mismatch"
        assert abs(row["reward_sum"]+row["F"])<1e-10,"Reward accounting mismatch"
        transitions = row["transitions"]
        if 'initial_cost' in row:
            assert abs(sum(row['initial_cost_terms'].values())-row['initial_cost'])<1e-10,'Initial cost terms mismatch'
            assert abs(sum(t['reward'] for t in transitions)-row['learning_reward_sum'])<1e-10,'Learning reward sum mismatch'
            assert abs(row['learning_reward_sum']-row['initial_cost']+row['F'])<1e-10,'Initial/learning reward mismatch'
            for item in transitions:
                assert abs(sum(item['reward_terms'].values())-item['reward'])<1e-10,'Reward terms mismatch'
                assert item['duration']>=0,'Negative transition duration'
        assert len(transitions)==sum(row["actions"].values()),"Action/transition mismatch"
        assert sum(bool(t["done"]) for t in transitions)==1 and transitions[-1]["done"],"Terminal mask error"
        assert all(math.isfinite(loss) for loss in row["losses"]),"Nonfinite loss"
        if row["phase"]=="monitor":
            assert row["train_steps"]==previous_steps,"Monitor trained network"
            assert row["replay_size"]==previous_replay,"Monitor modified replay"
            assert not row["losses"],"Monitor performed optimization"
        else:
            assert row["train_steps"]-previous_steps==len(row["losses"]),"Missing updates"
            assert row["replay_size"]-previous_replay==len(transitions),"Missing experiences (pilot capacity not full)"
        previous_steps,previous_replay = row["train_steps"],row["replay_size"]
    monitor = [{k:r[k] for k in ("epoch","case","F","T","R","D","actions","train_steps")}
               for r in rows if r["phase"]=="monitor"]
    initial = {r["case"]:r["F"] for r in monitor if r["epoch"]==0}
    for row in monitor:
        row["relative_to_initial"] = row["F"]/initial[row["case"]]-1
    losses = [loss for r in rows for loss in r["losses"]]
    # 性能平台与性能优越性分开记录：三轮变幅小不代表比固定策略更好。
    stability = {}
    for case in manifest["monitor"]:
        tail = [r for r in monitor if r["case"]==case and r["epoch"]>0][-3:]
        values = [r["F"] for r in tail]
        relative_span = ((max(values)-min(values))/statistics.mean(values)) if values else None
        stability[case] = dict(epochs=[r["epoch"] for r in tail],relative_span=relative_span,
                              engineering_plateau=len(values)==3 and relative_span<=.01)
    return dict(complete=set(keys)==expected,observed=len(rows),expected=len(expected),
                valid_count=sum(r["valid"] for r in rows),train_steps=previous_steps,
                replay_size=previous_replay,finite_losses=all(math.isfinite(x) for x in losses),
                loss_mean=statistics.mean(losses) if losses else None,
                monitor=monitor,stability=stability,qualification=manifest["limitation"],
                convergence=f"not established: one seed, {rounds} epochs, {len(manifest['monitor'])} monitoring window(s)")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder")
    args = parser.parse_args()
    report = analyze(args.folder)
    target = Path(args.folder)/"analysis.json"
    if target.exists():
        target.read_text(encoding="utf-8")
    target.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__ == "__main__":
    main()
