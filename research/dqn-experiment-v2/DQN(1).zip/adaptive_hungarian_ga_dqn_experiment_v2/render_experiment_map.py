"""Render the frozen large experiment geometry for review."""
import json
from pathlib import Path

from PIL import Image, ImageDraw

import paths
from wepa.data import build

CASE = "wepa-day40-bin3885"
protocol = json.loads((paths.ROOT / "data/protocol.json").read_text(encoding="utf-8"))
case = next(item for item in protocol["cases"] if item["case"] == CASE)
model = build(case, size="large", layers=5, vehicles=6)
scene = model["scene"]

cell = 14
margin = 70
image = Image.new("RGB", (scene.width * cell + margin * 2, scene.height * cell + margin * 2), "white")
draw = ImageDraw.Draw(image)

def rect(point):
    x, y = point
    return (margin + x * cell, margin + y * cell,
            margin + (x + 1) * cell - 1, margin + (y + 1) * cell - 1)

# Draw free space first, then fixed map elements on top.
for x in range(scene.width):
    for y in range(scene.height):
        draw.rectangle(rect((x, y)), fill="#f7f7f7", outline="#e5e5e5")
for point in scene.blocked:
    draw.rectangle(rect(point), fill="#303030")
for point in scene.shelves:
    draw.rectangle(rect(point), fill="#8b6f47")
for point in scene.pickup_zones:
    draw.rectangle(rect(point), fill="#f5d58a")
for point in scene.transit_only:
    draw.rectangle(rect(point), fill="#f7f7f7")
for point in model["inlets"]:
    draw.rectangle(rect(point), fill="#75b9e6")
for point in model["outlets"]:
    draw.rectangle(rect(point), fill="#e78b8b")
for index, point in enumerate(scene.homes[:6]):
    draw.rectangle(rect(point), fill="#79bd83")
    draw.text((rect(point)[0] + 2, rect(point)[1] + 1), str(index + 1), fill="black")

# Legend and exact geometry metadata.
legend_x = margin
legend_y = 20
items = [("#303030", "blocked / equipment"), ("#8b6f47", "rack"),
         ("#f5d58a", "legal loading point"), ("#75b9e6", "inbound"),
         ("#e78b8b", "outbound"), ("#79bd83", "vehicle home")]
for color, label in items:
    draw.rectangle((legend_x, legend_y, legend_x + 14, legend_y + 14), fill=color)
    draw.text((legend_x + 20, legend_y - 1), label, fill="black")
    legend_x += 150

draw.text((margin, image.height - 45),
          f"{CASE}: {scene.width}x{scene.height}, 6 vehicles, 5 shelf levels",
          fill="black")
output = Path("experiment_map_large.png")
image.save(output)
print(output.resolve())
