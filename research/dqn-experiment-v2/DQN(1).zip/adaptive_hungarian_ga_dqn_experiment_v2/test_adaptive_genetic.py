"""验证双概率真正控制算子、预算与确定性，以及DQN/纯GA接线一致性。"""
import copy
import unittest
from types import SimpleNamespace
import numpy as np
from paths import ROOT
from objective import LinearObjective
from adaptive_genetic import candidates,adaptive_rates
from adaptive_hungarian_learning import execute,MultiStepAgent,audit_adaptation
from run_adaptive_hungarian_learning import read

class FakeCosts:
    def __init__(self,count):
        self.ids=list(range(count)); self.evaluations=0
        self.obs=dict(vehicles=[dict(position=(0,0)) for _ in range(4)])
        self.world=SimpleNamespace(time=0,active=[None]*4,scene=SimpleNamespace(height=10))
        self.jobs={j:dict(id=j) for j in self.ids}
        self.slots={j:dict(shelf=(0,j%10)) for j in self.ids}
    def details(self,vehicle,position,job): return (vehicle+job['id']+1,)
    def estimate_joint(self,order,owners):
        assert sorted(order)==self.ids and set(owners)==set(self.ids)
        assert all(0<=v<4 for v in owners.values())
        self.evaluations+=1
        assert self.evaluations<=self.allowance
        return (float(sum((i+1)*(j+1)+owners[j] for i,j in enumerate(order))),0.,0.)

class GeneticTests(unittest.TestCase):
    def run_fake(self,count=6,**kwargs):
        costs=FakeCosts(count); order=costs.ids.copy(); owners={j:j%4 for j in order}
        before=copy.deepcopy((order,owners))
        result=candidates(costs,order,owners,objective=LinearObjective(),soft=True,seed=17,**kwargs)
        self.assertEqual((order,owners),before)
        return result

    def test_rates_bounds_and_response(self):
        normal=adaptive_rates(0,1)
        low_diversity=adaptive_rates(0,.2)
        stagnant=adaptive_rates(3,1)
        self.assertGreater(low_diversity[0],normal[0]); self.assertLess(low_diversity[1],normal[1])
        self.assertGreater(stagnant[0],normal[0]); self.assertLess(stagnant[1],normal[1])
        self.assertEqual(adaptive_rates(100,0),(.95,.55))
        for invalid in ((-1,.5),(1,1.1),(1,float('nan'))):
            with self.assertRaises(ValueError): adaptive_rates(*invalid)

    def test_actual_crossover_and_order_mutation_switches(self):
        for cross in (0.,1.):
            for mutation in (0.,1.):
                with self.subTest(cross=cross,mutation=mutation):
                    _,meta=self.run_fake(adaptive_crossover=False,crossover_rate=cross,adaptive_mutation=False,mutation_rate=mutation)
                    for generation in meta['mutation_history']:
                        self.assertEqual(generation['crossovers'],int(cross*10))
                        self.assertEqual(generation['order_mutations'],int(mutation*10))

    def test_joint_legality_determinism_and_budget(self):
        for count,budget in ((1,192),(6,192),(6,2)):
            with self.subTest(count=count,budget=budget):
                first=self.run_fake(count,budget=budget,generations=16)
                second=self.run_fake(count,budget=budget,generations=16)
                self.assertEqual(first,second)
                self.assertLessEqual(first[1]['proxy_evaluations'],budget)
                self.assertLessEqual(len(first[1]['mutation_history']),16)
                if count==1: self.assertGreater(first[1]['mutation_history'][0]['diversity'],1/12)

    def test_both_rates_change_across_generations(self):
        _,meta=self.run_fake(budget=192,generations=16)
        history=meta['mutation_history']
        self.assertGreater(len({h['mutation_rate'] for h in history}),1)
        self.assertGreater(len({h['crossover_rate'] for h in history}),1)

    def test_dqn_ga_branch_matches_pure_adaptive_ga(self):
        protocol=read(ROOT/'data/dqn_broad_protocol.json')
        source=protocol['cases'][0]
        case=dict(source,case='adaptive-four-order-wiring-only',tasks=source['tasks'][:4])
        agent=MultiStepAgent(seed=0,state_dim=32,hidden=8,capacity=64,warmup=8,batch_size=8,double_dqn=True,output_scale=.01)
        for weights in agent.online.values(): weights.fill(0)
        agent.online['b2'][:]=[-1,1] # 仅用于测试接线，正式模型从零学习而不固定动作。
        dqn=execute(case,protocol,agent)
        fixed=execute(case,protocol,strategy='ga')
        for row in (dqn,fixed):
            audit_adaptation(row)
            self.assertTrue(row['ga_searches'])
            self.assertTrue(all(s['adaptive_crossover'] and s['adaptive_mutation'] for s in row['ga_searches']))
        for key in ('F','T','R','D','ga_searches'): self.assertEqual(dqn[key],fixed[key])
        self.assertTrue(dqn['frozen_state_verified'])
        self.assertEqual(dqn['action_definition'],['hungarian_f_surrogate','joint_adaptive_ga'])

if __name__=='__main__': unittest.main()
