"""Ready/idle gate semantics, physical validity, and untouched input checks."""
from collections import Counter
from functools import partial
import json
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from paths import ROOT
from boundary_policy import BoundaryPolicy, use_matching
from improved.execute import run
from objective import LinearObjective, checked_score
from wepa.data import build

class ThresholdTests(unittest.TestCase):
    def test_boundaries(self):
        for ready,free,threshold,expected in [(1,0,1,False),(0,6,1,False),
            (6,6,1,True),(7,6,1,False),(9,6,1.5,True),(10,6,1.5,False),
            (18,6,3,True),(19,6,3,False),(1,6,0,False),(100,1,float('inf'),True)]:
            self.assertEqual(use_matching(ready,free,threshold),expected)
        self.assertTrue(use_matching(1,6,1,closed=True,keep_closed_rule=False))

    def test_pending_ratio_and_no_spurious_ga(self):
        policy=BoundaryPolicy(0,objective=LinearObjective(),threshold=1,keep_closed_rule=False)
        world=SimpleNamespace(visible={i:{} for i in range(20)},assigned=set(),
            active=[None]*6,ready=lambda:[{}]*2,time=901,closed=True)
        with patch('boundary_policy.matching',return_value=[]) as match, patch('improved.policy.ResearchPolicy.action') as ga:
            # Twenty published unassigned tasks force GA even though only two
            # are executable at this instant: the gate uses pending/idle.
            policy.action(world)
            match.assert_not_called(); ga.assert_called_once()
            self.assertEqual(policy.logs[-1]['pending_per_free'],20/6)
            self.assertEqual(policy.logs[-1]['gate_metric'],'pending/idle')
            world.ready=lambda:[]
            policy.action(world)
            world.ready=lambda:[{}]
            world.active=[{}]*6
            policy.action(world)
            ga.assert_called_once()
            self.assertEqual(match.call_count,0)

    def test_inputs_are_original_and_capacity_feasible(self):
        protocol=json.loads((ROOT/'boundary_protocol.json').read_text(encoding='utf-8'))
        original=json.loads((ROOT/'data/protocol.json').read_text(encoding='utf-8'))
        sources={c['case']:c for c in original['cases']}
        for case in protocol['cases']:
            source=sources[case['source_case']]
            for key,value in source.items():
                self.assertEqual(case[key],value)
            model=build(case,**protocol['configuration'])
            capacity=Counter(s['sku'] for s in model['slots'])
            stock=Counter({int(k):v for k,v in case['initial'].items()})
            for task in sorted(case['tasks'],key=lambda t:(t['release'],t['id'])):
                stock[task['sku']]+=1 if task['kind']=='delivery' else -1
                self.assertGreaterEqual(stock[task['sku']],0)
                self.assertLessEqual(stock[task['sku']],capacity[task['sku']])

    def test_main_scenario_trace_is_valid(self):
        protocol=json.loads((ROOT/'boundary_protocol.json').read_text(encoding='utf-8'))
        case=min(protocol['cases'],key=lambda c:len(c['tasks']))
        obj=LinearObjective(**protocol['objective'])
        model=build(case,**protocol['configuration'])
        result=run(model,'gate',objective=obj,policy_factory=partial(BoundaryPolicy,threshold=1,keep_closed_rule=False))
        self.assertTrue(checked_score(model,result,obj)['audit']['valid'])
        self.assertTrue(any(e.get('branch')=='matching' for e in result['search_log']))

if __name__=='__main__':
    unittest.main()
