"""单seed单遍跨日期训练，最终冻结评估与固定GA配对；逐窗落盘可续跑。"""
import copy
import json
import random
import numpy as np
from paths import ROOT, sha, verify_baseline
from dqn_agent import DQNAgent
from train_dqn import execute
from compare_dqn_controls import FixedActionAgent


def frozen(agent, case, protocol):
    before = copy.deepcopy(agent)
    row = execute(case, protocol, agent, 0, False)
    assert agent.rng.bit_generator.state == before.rng.bit_generator.state
    assert (agent.train_steps,agent.replay_size)==(before.train_steps,before.replay_size)
    for group in ('online','target','adam_m','adam_v'):
        for key in agent._PARAMETERS:
            np.testing.assert_array_equal(getattr(agent,group)[key],getattr(before,group)[key])
    for key in ('states','next_states','actions','rewards','dones'):
        np.testing.assert_array_equal(getattr(agent.replay,key),getattr(before.replay,key))
    row['frozen_state_verified']=True
    return row


def main():
    verify_baseline()
    protocol=json.loads((ROOT/'data/dqn_broad_protocol.json').read_text(encoding='utf-8'))
    folder=ROOT/'results/dqn_broad_v1'
    folder.mkdir(parents=True,exist_ok=True)
    identity={p:sha(ROOT/p) for p in ['data/dqn_broad_protocol.json','run_dqn_broad_data.py',
               'train_dqn.py','dqn_agent.py','dqn_policy.py','compare_dqn_controls.py']}
    manifest=folder/'manifest.json'
    if manifest.exists():
        assert json.loads(manifest.read_text())['hashes']==identity, 'Source drift'
    else:
        manifest.write_text(json.dumps(dict(hashes=identity,seed=0,passes=1,baseline_files=verify_baseline()),indent=2))
    cases={c['case']:c for c in protocol['cases']}
    order=list(protocol['development'])
    random.Random(0).shuffle(order)
    # 每个训练窗单独提交检查点和记录；训练未提交时仅重跑该窗，不重复已提交数据。
    agent=DQNAgent(seed=0,state_dim=24,double_dqn=True,output_scale=.01)
    agent.epsilon=.3
    for index,name in enumerate(order):
        output=folder/f'train_{index:02d}.json'
        checkpoint=folder/f'train_{index:02d}.npz'
        if output.exists():
            assert checkpoint.exists()
            agent=DQNAgent.load(checkpoint)
            continue
        row=dict(phase='train',**execute(cases[name],protocol,agent,0,True))
        agent.save(checkpoint)
        output.write_text(json.dumps(row,ensure_ascii=False),encoding='utf-8')
        print(json.dumps({k:v for k,v in row.items() if k not in ('transitions','losses')}),flush=True)
    final=folder/'final.npz'
    agent.save(final)
    final_hash=sha(final)
    # 训练完成后才访问4个评估日期；不按评估成绩调参或挑选检查点。
    for index,name in enumerate(protocol['evaluation']):
        for strategy in ('dqn','fixed_ga'):
            output=folder/f'eval_{index:02d}_{strategy}.json'
            if output.exists():
                continue
            row=frozen(agent,cases[name],protocol) if strategy=='dqn' else execute(cases[name],protocol,FixedActionAgent(1),0,False)
            row.update(phase='evaluation',strategy=strategy,seed=0,checkpoint_sha256=final_hash if strategy=='dqn' else None)
            output.write_text(json.dumps(row,ensure_ascii=False),encoding='utf-8')
            print(json.dumps({k:v for k,v in row.items() if k not in ('transitions','losses')}),flush=True)
    assert sha(final)==final_hash
    print('All 10 training windows and 8 paired evaluation runs completed.',flush=True)


if __name__=='__main__':
    main()
