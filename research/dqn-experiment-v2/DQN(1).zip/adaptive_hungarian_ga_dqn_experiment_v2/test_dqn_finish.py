"""只在完整审计与冻结复验成功后发布汇总；测试不调用真实仿真。"""
import unittest
from pathlib import Path
from unittest.mock import patch
import finish_dqn_expanded as finish


class FinishTests(unittest.TestCase):
    def report(self):
        seed = dict(seed=0, initial_F=.9, epoch3_F=.85, final_F=.84,
                    improvement_percent=6.6667, train_steps=1200, replay_size=1263)
        epoch = dict(epoch=6, F_by_seed=[.84, .84, .84], mean_F=.84,
                     sample_sd_F=0., mean_paired_improvement_percent=6.6667)
        return dict(per_seed=[dict(seed, seed=s) for s in range(3)], epochs=[epoch], improved_seeds=3)

    def test_publishes_only_after_verified_and_generates_report(self):
        writes = {}
        def write(path, content, **kwargs):
            writes[path.name] = content
        with patch.object(finish, 'summarize', return_value=self.report()), \
             patch.object(finish, 'verify', return_value=dict(complete=True)), \
             patch.object(finish.subprocess, 'run') as run, \
             patch.object(Path, 'exists', return_value=False), \
             patch.object(Path, 'write_text', write), patch('builtins.print'):
            finish.main()
        self.assertEqual(run.call_count, 3)
        self.assertIn('第6轮为预定主要终点', writes['DQN扩大实验结果.md'])
        self.assertIn('93/93', writes['DQN扩大实验结果.md'])
        self.assertIn('aggregate.json', writes)
        self.assertIn('<svg', writes['learning_curves.svg'])

    def test_failed_replay_does_not_publish(self):
        with patch.object(finish, 'summarize', return_value=self.report()), \
             patch.object(finish, 'verify', side_effect=AssertionError('replay mismatch')), \
             patch.object(Path, 'exists', return_value=True), \
             patch.object(Path, 'write_text') as write:
            with self.assertRaisesRegex(AssertionError, 'replay mismatch'):
                finish.main()
        write.assert_not_called()


if __name__ == '__main__':
    unittest.main()
