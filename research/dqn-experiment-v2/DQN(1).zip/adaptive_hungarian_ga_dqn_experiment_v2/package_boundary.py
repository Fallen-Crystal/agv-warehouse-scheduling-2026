"""Package the reproducible study and full evidence without generated caches."""
import hashlib
import json
import os
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parent


def main():
    audit=json.loads((ROOT/'boundary_results/audit.json').read_text(encoding='utf-8'))
    if (audit['revalidated_trials']!=144 or not audit['all_legacy_equal']
            or audit['implementation_versions']!=1 or not audit.get('source_matches_current')
            or not audit.get('protocol_slots_verified')):
        raise ValueError('Do not package incomplete or failed study')
    report=ROOT/'boundary_results/切换边界结果报告.md'
    if not report.exists():
        raise ValueError('Generate report first')
    files=[]
    for directory,dirs,names in os.walk(ROOT):
        dirs[:]=[d for d in dirs if d!='__pycache__' and not d.startswith('analysis-safety-')]
        for name in names:
            path=Path(directory)/name
            if path.suffix not in ('.pyc','.zip') and name!='study_manifest.json':
                files.append(path)
    manifest={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
              for p in sorted(files)}
    manifest_path=ROOT/'study_manifest.json'
    manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    target=ROOT.parent/'AGV_Ready_Boundary_Study_20261102.zip'
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for path in files+[manifest_path]:
            archive.write(path,'agv-ready-study/'+path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(target) as archive:
        bad=archive.testzip()
        if bad:
            raise ValueError('Corrupt member: '+bad)
        assert len(archive.infolist())==len(files)+1
    print(json.dumps(dict(path=str(target),files=len(files)+1,bytes=target.stat().st_size,
                         sha256=hashlib.sha256(target.read_bytes()).hexdigest()),ensure_ascii=False))

if __name__=='__main__':
    main()
