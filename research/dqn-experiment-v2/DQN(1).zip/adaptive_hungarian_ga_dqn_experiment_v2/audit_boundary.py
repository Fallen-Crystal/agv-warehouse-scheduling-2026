"""Verify protocol coverage, source identity, physical scores and legacy replays."""
from collections import Counter
import json
from paths import ROOT, verify_baseline
from boundary_trial import source_hashes


def physical_hashes(hashes):
    """Ignore runner-only files when checking trial physical provenance."""
    return {key:value for key,value in hashes.items()
            if key not in {'boundary_trial.py', 'boundary_batch.py'}}
from objective import LinearObjective, checked_score
from wepa.data import build


def main():
    protocol=json.loads((ROOT/'boundary_protocol.json').read_text(encoding='utf-8'))
    out=ROOT/'boundary_results'
    selection=json.loads((out/'selection.json').read_text(encoding='utf-8'))
    selected=selection['selected']
    assert selected in ('t05','t1','t15','t2','t3')
    assert selection['threshold']==protocol['arms'][selected]['threshold']
    current=physical_hashes(source_hashes())
    checks, skipped, validated=[],[],[]
    identities=Counter()
    fields=('paths','labels','records','completed','decisions','T','R','D','p90',
            'empty_distance','traffic_wait','holds','final_stock')
    objective=LinearObjective(**protocol['objective'])
    for phase in ('development','validation'):
        arms=list(protocol['arms']) if phase=='development' else ['original','ga','matching',selected]
        cases=[c for c in protocol['cases'] if c['source_case'] in protocol[phase]]
        expected={f"{c['case']}__{a}__s{s}.json" for c in cases for a in arms for s in protocol[phase+'_seeds']}
        actual={p.name for p in (out/phase).glob('*.json') if not p.name.endswith('.status.json')}
        assert actual==expected,(phase,'missing',expected-actual,'extra',actual-expected)
        for case in cases:
            for arm in arms:
                for seed in protocol[phase+'_seeds']:
                    path=out/phase/f"{case['case']}__{arm}__s{seed}.json"
                    status=json.loads(path.with_suffix('.status.json').read_text(encoding='utf-8'))
                    trial=json.loads(path.read_text(encoding='utf-8'))
                    assert status['status']=='ok' and status['returncode']==0,str(path)
                    for record in (status,trial['row']):
                        assert (record['case'],record['arm'],record['seed'])==(case['case'],arm,seed),str(path)
                    assert trial['case']==case and trial['arm']==protocol['arms'][arm],str(path)
                    recorded=physical_hashes(trial['implementation_sha256'])
                    assert recorded==current,str(path)
                    identities[json.dumps(recorded,sort_keys=True)]+=1
                    model=build(case,**protocol['configuration'])
                    scoring=checked_score(model,trial['result'],objective)
                    assert scoring['audit']['valid'] and trial['row']['valid'],str(path)
                    assert scoring['F_linear_v2']==trial['row']['F']==trial['scoring']['F_linear_v2'],str(path)
                    for field in ('T','R','D','p90','empty_distance','traffic_wait'):
                        assert trial['row'][field]==trial['result'][field],(path,field)
                    validated.append(str(path.relative_to(out)))
                    if arm!='original':
                        continue
                    old=ROOT/'results'/phase/'traces'/f"{case['source_case']}-gate-s{seed}.json"
                    if not old.exists():
                        skipped.append(dict(phase=phase,case=case['case'],seed=seed,reason='No archived same-seed reference'))
                        continue
                    prior=json.loads(old.read_text(encoding='utf-8'))
                    differing=[k for k in fields if trial['result'][k]!=prior['result'][k]]
                    checks.append(dict(phase=phase,case=case['case'],seed=seed,equal=not differing,differing=differing))
    assert len(validated)==144 and len(identities)==1
    assert checks and all(c['equal'] for c in checks)
    assert current==physical_hashes(source_hashes())
    result=dict(baseline_files=verify_baseline(),legacy_full_load_replays=checks,
        skipped_history=skipped,revalidated_trials=len(validated),expected_trials=144,
        implementation_versions=len(identities),source_matches_current=True,
        protocol_slots_verified=True,all_legacy_equal=True)
    (out/'audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()
