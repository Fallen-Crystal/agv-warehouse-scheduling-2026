"""Append reproducible comparison results to the AGV Word report."""
import json
from pathlib import Path
from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor

ROOT = Path(__file__).resolve().parent
DOC = ROOT / "AGV仓库建模与调度算法说明.docx"
files = [
    ROOT / "experiment_hungarian_day40.json",
    ROOT / "experiment_hga_day40.json",
    ROOT / "rl_smoke_v2.json",
    ROOT / "experiment_rl_day61.json",
    ROOT / "experiment_rl_day83.json",
    ROOT / "experiment_rl_day87.json",
]
rows = []
for path in files:
    data = json.loads(path.read_text(encoding="utf-8"))
    row = data["row"]
    rows.append((row["case"], row["profile"], row["seed"], row["valid"], row["tasks"], row["F"], row["T"], row["R"], row["D"], row["cpu"]))

def font(run, size=9.5, bold=False, color=None):
    run.font.name = "Microsoft YaHei"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    run.font.size = Pt(size)
    run.bold = bold
    if color:
        run.font.color.rgb = RGBColor(*color)

def add_text(doc, text, style="Normal"):
    p = doc.add_paragraph(style=style)
    p.paragraph_format.space_after = Pt(5)
    r = p.add_run(text)
    font(r)
    return p

doc = Document(DOC)
doc.add_heading("十二、基于现有代码的对照实验", level=1)
add_text(doc, "本轮实验使用冻结的protocol.json、相同的地图、相同的原始目标函数和seed=0。day40窗口比较精确匹配、匈牙利初始化联合GA和RL自适应选择；另外三个冻结验证窗口运行RL配置，用于检查跨窗口物理有效性。每个结果均由run_trial.py生成，并通过完整轨迹审计。")

table = doc.add_table(rows=1, cols=10)
table.alignment = WD_TABLE_ALIGNMENT.CENTER
table.style = "Table Grid"
headers = ["窗口", "策略", "seed", "有效", "任务数", "F", "T", "R", "D", "CPU(s)"]
for i, h in enumerate(headers):
    cell = table.rows[0].cells[i]
    r = cell.paragraphs[0].add_run(h)
    font(r, bold=True)
for row in rows:
    cells = table.add_row().cells
    vals = [row[0], row[1], row[2], str(row[3]), row[4], f"{row[5]:.6f}", row[6], f"{row[7]:.3f}", row[8], f"{row[9]:.3f}"]
    for i, val in enumerate(vals):
        r = cells[i].paragraphs[0].add_run(str(val))
        font(r)
add_text(doc, "在day40窗口中，RL的F为0.874974，低于hungarian的0.911193，但高于hga的0.852476。这个窗口说明RL已经能够在matching和联合GA之间做出物理有效的动态选择，但当前参数和训练方式尚未证明能够稳定超过固定的seeded联合GA。")
add_text(doc, "三个额外验证窗口的RL结果全部valid=true，说明当前策略可以在不同任务规模和库存输入下完成合法SIPP执行。它们的F分别为day61=1.074238、day83=0.828911、day87=0.867830。由于这三个窗口没有在同一轮同时运行对照臂，不能据此推断RL相对其他策略的普遍优势。")
add_text(doc, "复现实验命令示例：")
for cmd in [
    "python -B run_trial.py --case wepa-day40-bin3885 --profile hungarian --seed 0 --output experiment_hungarian_day40.json",
    "python -B run_trial.py --case wepa-day40-bin3885 --profile hga --seed 0 --output experiment_hga_day40.json",
    "python -B run_trial.py --case wepa-day40-bin3885 --profile rl --seed 0 --output rl_smoke_v2.json",
]:
    p = doc.add_paragraph(style="No Spacing")
    p.paragraph_format.left_indent = Pt(20)
    r = p.add_run(cmd)
    font(r, size=9, color=(40,40,40))

doc.save(DOC)
print(DOC)
