"""搜索报告计数回归，不接触真实日期或轨迹。"""
import unittest
from report_search_efficiency import analyze


class EfficiencyTests(unittest.TestCase):
    def test_pruned_candidate_not_counted_as_completed_or_failed_path(self):
        row=dict(case='synthetic',source_day=0,budget_name='baseline',F=1.,budget={'proxy':192},
                 ga_searches=[dict(proxy_evaluations=48,mutation_history=[{'diversity':.5},{'diversity':1.}])])
        trajectory=dict(search_log=[dict(previews=3,base_score=1.,
            anchor_usage=dict(route_calls=10,reason='complete'),candidates=[
                dict(kind='ga',score=None,usage=dict(route_calls=2,reason='bound_pruned')),
                dict(kind='ga',score=.9,usage=dict(route_calls=9,reason='complete'))]),
            dict(error='anchor_incomplete',usage=dict(route_calls=512,reason='query_budget'))])
        result=analyze(row,trajectory)
        self.assertEqual(result['rollout_reasons'],dict(complete=2,bound_pruned=1,query_budget=1))
        self.assertEqual(result['by_kind']['ga'],dict(attempts=2,route_calls=11,completed=1,strictly_better_than_anchor=1))
        self.assertEqual(result['by_kind']['anchor_failed']['completed'],0)
        self.assertEqual(result['proxy_budget_fill_fraction'],.25)
        self.assertEqual(result['mean_population_diversity'],.75)

    def test_no_search_has_finite_zero_statistics(self):
        result=analyze(dict(case='empty',source_day=0,budget_name='baseline',F=0.,
                           budget={'proxy':192},ga_searches=[]),dict(search_log=[]))
        self.assertEqual(result['proxy_budget_fill_fraction'],0)
        self.assertEqual(result['mean_generations'],0)
        self.assertEqual(result['rollout_reasons'],{})


if __name__=='__main__':
    unittest.main()
