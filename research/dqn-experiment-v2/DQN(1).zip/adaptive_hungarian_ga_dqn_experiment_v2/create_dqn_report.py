"""生成中文DQN实验补充报告；仅读取已落盘记录，不虚构完成量。"""
import json
from pathlib import Path
from docx import Document
from docx.oxml.ns import qn
from docx.shared import Pt

ROOT = Path(__file__).parent


def main():
    source = ROOT/"docs/DQN调度实验说明.md"
    document = Document()
    normal = document.styles["Normal"]
    normal.font.name = "宋体"
    normal.font.size = Pt(11)
    normal.element.rPr.rFonts.set(qn("w:eastAsia"),"宋体")
    in_code = False
    for line in source.read_text(encoding="utf-8").splitlines():
        if line.startswith("```"):
            in_code = not in_code
            continue
        if line.startswith("|"):
            continue  # 固定策略数据由下方真实JSON生成，避免把Markdown表格作为正文。
        if not line.strip():
            continue
        if line.startswith("# "):
            document.add_heading(line[2:],0)
        elif line.startswith("## "):
            document.add_heading(line[3:],1)
        else:
            document.add_paragraph(line)
    document.add_heading("实际执行记录",1)
    folder = ROOT/"results/dqn_pilot_v2_s0"
    path = folder/"episodes.jsonl"
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line] if path.exists() else []
    complete = (folder/"summary.json").exists()
    document.add_paragraph(f"当前已落盘{len(rows)}次完整仿真，轨迹有效{sum(r['valid'] for r in rows)}次。"
                           +("首批计划已结束。" if complete else "首批计划尚未结束，以下是运行中快照。"))
    document.add_heading("冻结监测曲线",2)
    table = document.add_table(rows=1,cols=7)
    table.style = "Table Grid"
    for cell,text in zip(table.rows[0].cells,["轮次","窗口","F","T","R","D","更新步数"]):
        cell.text = text
    for row in rows:
        if row["phase"] != "monitor":
            continue
        cells = table.add_row().cells
        values = [row["epoch"],row["case"].replace("wepa-",""),f"{row['F']:.6f}",
                  row["T"],f"{row['R']:.2f}",row["D"],row["train_steps"]]
        for cell,text in zip(cells,values):
            cell.text = str(text)
    document.add_heading("学习活动与结论边界",2)
    training = [r for r in rows if r["phase"]=="train"]
    actions = {key:sum(r["actions"].get(key,0) for r in training) for key in ("matching","ga")}
    document.add_paragraph(f"训练记录{len(training)}窗；matching选择{actions['matching']}次，GA选择{actions['ga']}次。"
                           "经验预热前train_steps为0属于设计行为，不代表记录缺失。")
    monitor = [r for r in rows if r["phase"]=="monitor"]
    if len(monitor)>1:
        change = (monitor[-1]["F"]/monitor[0]["F"]-1)*100
        document.add_paragraph(f"相对未训练网络，同窗最新冻结F变化为{change:+.3f}%。"
                               "仅一个种子及一个监测窗口，不可推出稳定收敛或对新订单泛化。")
    control_path = ROOT/"results/dqn_controls_day40_s0.json"
    if control_path.exists():
        controls = json.loads(control_path.read_text(encoding="utf-8"))["rows"]
        document.add_heading("同版本固定动作对照",2)
        for control in controls:
            text = f"{control['strategy']}：F={control['F']:.6f}，T={control['T']}，R={control['R']:.2f}，D={control['D']}。"
            if monitor:
                delta = (monitor[-1]['F']/control['F']-1)*100
                text += f" DQN最新同窗相对变化{delta:+.3f}%。"
            document.add_paragraph(text)
        document.add_paragraph("固定GA分支与DQN使用同一缓存计划机制；该比较只有一个窗口、一个seed，不构成显著性结论。")
    if len(monitor)>1:
        best = min(monitor[1:],key=lambda r:r['F'])
        document.add_heading("最好一轮与最后一轮",2)
        document.add_paragraph(f"训练后监测最优为第{best['epoch']}轮，F={best['F']:.9f}；"
                               f"最后完成轮次为第{monitor[-1]['epoch']}轮，F={monitor[-1]['F']:.9f}。"
                               "最优结果是查看监测曲线后的回顾性选择，不是独立测试结论。")
        if len(monitor)>2 and any(b['F']>a['F'] for a,b in zip(monitor[1:],monitor[2:])):
            document.add_paragraph("冻结成绩出现回退，当前证据不支持单调改善或稳定收敛。")
    document.add_paragraph("网络、环境与证据审计14项测试通过，包含终局掩码、目标同步、冻结推断、经验池、未发布订单隔离与检查点精确恢复。"
                           "试验源代码保留中文注释，报告为原仓库建模说明的补充，不改变原建模协议。")
    target = ROOT/"DQN调度实验补充报告.docx"
    # 文档重复生成时先读取旧文件，且仅替换本脚本拥有的完整报告。
    if target.exists():
        Document(target)
    document.save(target)
    reopened = Document(target)
    assert any(p.text=="实际执行记录" for p in reopened.paragraphs)
    assert len(reopened.tables)==1
    print(str(target))


if __name__ == "__main__":
    main()
