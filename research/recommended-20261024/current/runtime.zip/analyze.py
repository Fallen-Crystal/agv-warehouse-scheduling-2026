"""Revalidate complete trajectories and paired outcomes without retuning."""
import csv,json
from statistics import mean
from paths import ROOT,hashes,verify_baseline
from objective import LinearObjective,checked_score
from wepa.data import build
from exact.fixtures import make
from micro_check import check_references


def main():
    p=json.loads((ROOT/'data/protocol.json').read_text());obj=LinearObjective(**p['objective'])
    cases={c['case']:c for c in p['cases']};groups={};all_rows=[];activity={};regression=[]
    for split in ('development','validation'):
        directory=ROOT/'results'/split
        before=json.loads((directory/'phase-before.json').read_text());after=json.loads((directory/'phase-after.json').read_text())
        if before['source']!=hashes() or not after['source_unchanged']:raise ValueError('Phase identity differs')
        rows=json.loads((directory/'runs.json').read_text())
        expected={(c,a,s) for c in p[split] for a in p['treatments'] for s in ([0] if split=='development' else [0,1])}
        if {(r['case'],r['profile'],r['seed']) for r in rows}!=expected or len(rows)!=len(expected):raise ValueError('Missing/duplicate runs')
        by_case={}
        for row in rows:
            if not row['valid']:raise ValueError('Invalid run disqualifies arm; preserve failure rather than average it away')
            trace=json.loads((ROOT/row['trace']).read_text())
            if trace['implementation_sha256']!=hashes():raise ValueError('Trace identity differs')
            score=checked_score(build(cases[row['case']],**p['configuration']),trace['result'],obj)
            if score!=trace['scoring'] or abs(score['F_linear_v2']-row['F'])>1e-12:raise ValueError('Physical score differs')
            if any(row[k]!=trace['result'][k] for k in ('T','R','D','p90','empty_distance','traffic_wait')):raise ValueError('Row metrics differ')
            act=activity.setdefault(row['profile'],dict(searches=0,previews=0,proxy_evaluations=0,
                seeded_searches=0,unique_seeds=0,seed_matching_solves=0,rolling_batches=0,rolling_matching_solves=0))
            for log in trace['result']['search_log']:
                if 'previews' in log:
                    if log['previews']>6 or log['proxy_evaluations']>192:raise ValueError('Search budget exceeded')
                    if log['score']>log['base_score']+1e-12:raise ValueError('Worse forecast accepted')
                    if row['profile']=='hungarian':raise ValueError('Pure Hungarian unexpectedly used GA previews')
                    act['searches']+=1;act['previews']+=log['previews'];act['proxy_evaluations']+=log['proxy_evaluations']
                    for candidate in log['candidates']:
                        if candidate['usage']['route_calls']>512:raise ValueError('Preview routing budget exceeded')
                if 'hungarian_initialization' in log:
                    meta=log['hungarian_initialization']
                    if meta['generated']>2 or meta['routing_previews']!=0 or meta['used_unpublished']:raise ValueError('Invalid seed budget')
                    act['seeded_searches']+=1;act['unique_seeds']+=meta['generated']
                    act['seed_matching_solves']+=sum(x['solves'] for x in meta['variants'])
                if log.get('mode')=='rolling_hungarian':
                    act['rolling_batches']+=1;act['rolling_matching_solves']+=log['matching']['solves']
            if split=='development' and row['profile']=='gate':
                old=json.loads((ROOT/f"data/control-reference/{row['case']}-gate-s0.json").read_text())
                if not all(old['result'][k]==trace['result'][k] for k in ('paths','labels','records','decisions','T','R','D','final_stock')):
                    raise ValueError('Control physical replay changed')
                regression.append(dict(case=row['case'],exact_physical_replay=True))
            by_case.setdefault(row['case'],{}).setdefault(row['profile'],[]).append(row)
            all_rows.append(dict(split=split,**row))
        aggregates={};comparisons={}
        for arm in p['treatments']:
            aggregates[arm]={key:mean(mean(r[key] for r in by_case[c][arm]) for c in p[split])
                for key in ('F','J','T','R','D','cpu','wall','p90','empty_distance','traffic_wait')}
            paired=[]
            for case in p[split]:
                original=by_case[case]['gate'];trial=by_case[case][arm]
                if sorted(r['seed'] for r in original)!=sorted(r['seed'] for r in trial):raise ValueError('Unpaired seeds')
                base=mean(r['F'] for r in original);new=mean(r['F'] for r in trial)
                paired.append(dict(case=case,gate=base,F=new,gain_percent=100*(base-new)/base,
                    seed_pairs=[dict(seed=r['seed'],gain_percent=100*(next(x['F'] for x in original if x['seed']==r['seed'])-r['F'])/next(x['F'] for x in original if x['seed']==r['seed'])) for r in sorted(trial,key=lambda x:x['seed'])]))
            comparisons[arm]=dict(cases=paired,mean_paired_gain_percent=mean(r['gain_percent'] for r in paired),
                improved=sum(r['gain_percent']>1e-10 for r in paired),worsened=sum(r['gain_percent']< -1e-10 for r in paired))
        groups[split]=dict(aggregates=aggregates,comparisons=comparisons)
    choice=json.loads((ROOT/'results/selection.json').read_text())
    if choice['source']!=hashes() or choice['validation_read']:raise ValueError('Invalid pre-validation selection')
    selected=choice['selected'];gain=groups['validation']['comparisons'][selected]['mean_paired_gain_percent']
    recommended=selected if selected!='gate' and gain>0 else 'gate'
    refs,ref_count=check_references()
    micro=json.loads((ROOT/'results/micro-regression.json').read_text())
    if micro['source']!=hashes() or len(micro['rows'])!=12:raise ValueError('Micro source/count differs')
    for r in micro['rows']:
        if checked_score(make(r['case']),r['result'],LinearObjective(vehicles=2))!=r['scoring']:raise ValueError('Micro audit failed')
    summary=dict(executions=len(all_rows),independently_revalidated=len(all_rows)+12+ref_count,
        groups=groups,activity=activity,selected_before_validation=selected,recommended=recommended,
        source=hashes(),baseline_files_unchanged=verify_baseline(),control_regression=regression,
        validation_retuning=False,validation_scope=p['validation_scope'],
        wall_budget_overruns=[{k:r[k] for k in ('case','profile','seed','wall','cpu')} for r in all_rows if r['wall']>p['limits']['wall_seconds']],
        micro=[{k:r[k] for k in ('case','profile','F','F_optimal','gap_percent')} for r in micro['rows']],
        scope='Four new windows on previously used source dates; no fresh-date generalization or six-car global optimality certificate')
    (ROOT/'results/summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    with (ROOT/'results/comparison.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(all_rows[0]));writer.writeheader();writer.writerows(all_rows)
    print(json.dumps(dict(executions=summary['executions'],recommended=recommended,groups=groups,activity=activity),ensure_ascii=False))


if __name__=='__main__':main()
