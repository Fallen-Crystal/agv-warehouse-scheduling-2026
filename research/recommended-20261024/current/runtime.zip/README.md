# 匈牙利＋SIPP / 联合GA＋SIPP / 匈牙利初始化联合GA＋SIPP

阅读 [实验设计](docs/实验设计.md) 和 [结果报告](docs/结果报告.md)。三组的物理规则和线性F相同。

```powershell
python run_main.py --case wepa-day40-bin3885 --output my-result.json
python run_main.py --case wepa-day40-bin3885 --profile hga --output my-hga-result.json
python run_main.py --case wepa-day40-bin3885 --profile hungarian --output my-hungarian-result.json
```

运行主算法仅需Python 3.12标准库。输出文件必须不存在；默认方案由results/summary.json的预先开发选择与验证规则决定。代码或输入漂移后主入口会拒绝沿用旧结果。批次之间安全待命，全部请求流结束且所有任务完成后最终返库。

新增实现：

- improved/hungarian.py：返回匹配对的矩形匈牙利算法，支持禁配边和最大匹配数；用完工阈值处理瞬时成本中的T。
- improved/hungarian_seed.py：只读虚拟分轮匹配，生成最多2个完整初始方案。
- improved/genetic.py：保留联合归属/顺序编码与原遗传算子，接受可选种子，替换部分随机初始个体。
- improved/policy.py：三组接口及预算；hga没有再次锁死或覆盖GA输出。
- improved/execute.py：原SIPP执行后端；不启用额外局部路径协调。

对照gate保持原低负载动态规划精确匹配；hga使用同一支路，隔离GA初始化的影响。纯hungarian是完整的F感知滚动派单策略，不能把它的全流程结果当作仅更换匹配求解器的效果。

data/protocol.json包含所有选中请求及初始库存，运行不依赖外部大数据文件。verify_input.py --raw <原始文件目录> 可验证选择及前缀账本。验证使用未测窗口，但日期此前曾用过，不称外部新日期验证。

`python -m unittest test_hungarian -v` 运行新增8项标准库测试。完整30项测试（test_hungarian、test_coupled、test_boundary、test_variants）还包括历史精确模型代码，需可选`pip install -r requirements-exact.txt`。OR-Tools不用于六车主算法。本轮micro_check.py只复核既有4个微型最优参照并重跑三组，不重新求解。

baseline/的191文件是冻结依赖，旧配置、旧文档保留用于回归，不代表本轮全部启用。正式入口仅提供gate、hungarian、hga。源码、协议、完整轨迹、预算、单项指标和所有退化结果均保存。CPU时间未计入仿真F。
