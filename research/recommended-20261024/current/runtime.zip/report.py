"""Render conclusions from audited results; never manufacture improvements."""
import json
from collections import Counter
from paths import ROOT


def main():
    s=json.loads((ROOT/'results/summary.json').read_text());p=json.loads((ROOT/'data/protocol.json').read_text())
    names={'gate':'原联合GA＋SIPP','hungarian':'滚动匈牙利＋SIPP','hga':'匈牙利初始化联合GA＋SIPP'}
    lines=['# 匈牙利、联合GA与混合初始化：配对比较','',
        '本轮完成12次开发、24次验证，共36次主运行。算法、预算及输入在运行前冻结，验证没有调参。仓库规则、真实请求、评价公式和SIPP后端均保持相同。','',
        f"开发预先选定：**{names[s['selected_before_validation']]}**。按预定采用规则，本轮默认：**{names[s['recommended']]}**。",'',
        '## 三组实际做了什么','',
        '|组别|订单调度|路径及物理检查|','|---|---|---|',
        '|gate|当前原方案：低负载精确批量匹配；其他时刻联合GA搜索车辆归属和顺序|原SIPP及预约表|',
        '|hungarian|每个决策点做F感知瞬时匹配；最大匹配数量优先；枚举完工阈值后用匈牙利优化加性成本|原SIPP验证后提交|',
        '|hga|保留gate的低负载支路；将最多2个完整匈牙利种子放入联合GA，替换部分随机个体|与gate相同的完整SIPP预演和实际后端|','',
        '匈牙利种子采用两种分轮匹配：预计耗时、瞬时F估计。分轮更新虚拟车辆可用时刻、位置及货架锁；任务数可以超过车数。种子与锚点、其他种子去重，可能少于2个。GA继续允许换车、换序及跨区接单，未将车辆归属锁死，也未在GA每一代重新运行匈牙利。','',
        '两个GA组均种群12、最多16代、192次代理评分、6次完整SIPP预演。匈牙利种子不额外调用SIPP；额外匹配计算计入CPU。实际代理评分数会因重复个体不同而变化。纯匈牙利按自身需要运行，不人为消耗同等预算。每窗口CPU上限600秒、墙钟900秒，2个隔离进程。','',
        '## 主实验结果','',
        '以下F改善为：同窗口先对种子取均值，计算相对gate的下降百分比，再对4个窗口取平均。正数更好。它仅用于方法比较，不进入评价函数。','']
    for split,title in (('development','开发：4个既有窗口，每组种子0'),('validation','验证：4个未测试窗口，每组种子0、1')):
        g=s['groups'][split]
        lines += [f'### {title}','','|方案|平均F|配对F改善|改善/退化窗口|T|R|D|CPU秒/窗口|','|---|---:|---:|---:|---:|---:|---:|---:|']
        for arm in p['treatments']:
            a=g['aggregates'][arm];c=g['comparisons'][arm]
            lines.append(f"|{names[arm]}|{a['F']:.6f}|{c['mean_paired_gain_percent']:+.3f}%|{c['improved']}/{c['worsened']}|{a['T']:.2f}|{a['R']:.2f}|{a['D']:.2f}|{a['cpu']:.2f}|")
        lines += ['','|窗口|滚动匈牙利的F改善|混合初始化的F改善|','|---|---:|---:|']
        for a,b in zip(g['comparisons']['hungarian']['cases'],g['comparisons']['hga']['cases']):
            lines.append(f"|{a['case']}|{a['gain_percent']:+.3f}%|{b['gain_percent']:+.3f}%|")
        lines += ['']
    g=s['groups']['validation']['aggregates'];base=g['gate']
    lines += ['### 验证成本变化分解','','正数增加成本，负数降低成本。三项F贡献相加等于平均F的绝对变化，不是逐窗口相对改善的平均值。','',
        '|方案|ΔT|ΔR|ΔD|T项对F贡献|R项对F贡献|D项对F贡献|CPU均值变化|','|---|---:|---:|---:|---:|---:|---:|---:|']
    for arm in ('hungarian','hga'):
        a=g[arm];dt=a['T']-base['T'];dr=a['R']-base['R'];dd=a['D']-base['D']
        lines.append(f"|{names[arm]}|{dt:+.2f}|{dr:+.2f}|{dd:+.2f}|{.5*dt/900:+.6f}|{.3*dr/900:+.6f}|{.2*dd/5400:+.6f}|{100*(a['cpu']/base['cpu']-1):+.2f}%|")
    lines += ['',
        'CPU时间为仿真执行及独立评分阶段，不含进程启动、输入建模与结果写盘。CPU单列，未加入仿真物理时钟或F。因此不能把计算节省直接当作订单交付耗时下降；如需评价真实在线决策延迟，必须另建实验。','',
        '## 精确最优参照回归','',
        '沿用此前已证明最优的4个缩减两车静态实例，核对整数模型导出哈希、最优目标与下界一致性，并重新检查最优轨迹。三组在相同微型实例上重新执行。没有重新调用CP-SAT。参照文件中上一轮其他算法的历史轨迹不计入本轮对照。','',
        '|实例|已证明最优F|原GA差距|滚动匈牙利差距|混合初始化差距|','|---|---:|---:|---:|---:|']
    for case in ('cross_out','mixed','layers','mixed_burst'):
        rows={r['profile']:r for r in s['micro'] if r['case']==case}
        lines.append(f"|{case}|{rows['gate']['F_optimal']:.8f}|{max(0,rows['gate']['gap_percent']):.3f}%|{max(0,rows['hungarian']['gap_percent']):.3f}%|{max(0,rows['hga']['gap_percent']):.3f}%|")
    lines += ['',
        '微型例只用于机制回归，不能证明六车动态问题全局最优。匈牙利对每一轮固定成本矩阵的精确性，不等于整个多任务序列、共享通道和动态请求问题的精确性。','',
        '## 匹配成本与F的关系','',
        '统一F=0.5T/900+0.3R/900+0.2D/5400。T为最后订单完成时刻；R为平均发布到完成；D包含所有移动、待命重定位和最终返库。固定大型62×47、6车、5层、1格/秒。F可以超过1，新窗口的绝对F不能与上一轮不同窗口直接比较。P90、空驶和交通等待同步保存，不额外添加权重。','',
        '本轮纯匈牙利不只是最小化总路程：先求最大可匹配数，再枚举固定边预测的完工阈值，在阈值内最小化R和D的加性近似，最后比较含T的瞬时成本。这能精确求解该估计问题；车辆相互阻塞、未选择订单的后续顺序及未知请求仍不在这一轮矩阵内。已有累计等待作为常数，不因当前只选部分任务就重复惩罚较老订单。所有实际执行仍由SIPP和独立验解器约束。','',
        '混合组只更换初始个体的来源，未额外加一次最终匈牙利重分配。若种子改善个例但总体不稳定，只能说明这套初始化及预算组合尚未稳定胜出，不能宣称所有匈牙利与GA混合方式都无效。','',
        '## 输入与实验边界','',
        '来源WEPA/slapstack，固定提交da6280a8f8be1010eae64264c69a90258a288173；原始请求哈希caab14a69aa34734f3ceb04f6c595f712b7dc4a1ee65adbe92268a16a7159432。请求类型、到达时间与SKU来自原数据，地图、服务和速度来自本模型，未提供原厂实际AGV行程成本。库存由请求前缀账本重建，假定窗口前操作已完成。','',
        '保持35—65单、2—5 SKU、入出库各至少5单及库存约束。所有满足这些条件的新日期已在此前实验用过，因此本轮排除既有窗口及开发日期，按时间顺序选择4个不同来源日期的新窗口。日期曾用于其他窗口，不声称新日期外部验证。data/input-selection.json保存排除表和输入选择审计，可用verify_input.py及相同原始文件重建。','',
        '|验证窗口|任务数|入库/出库|SKU数|','|---|---:|---:|---:|']
    for c in p['cases']:
        if c['case'] not in p['validation']:continue
        k=Counter(j['kind'] for j in c['tasks'])
        lines.append(f"|{c['case']}|{len(c['tasks'])}|{k['delivery']}/{k['retrieval']}|{len(c['initial'])}|")
    lines += ['',
        '分析单位是4个来源日期；两种子不是两个独立场景。纯匈牙利为确定性策略，种子重复主要检查一致性。样本不足以声称普遍显著改进，未覆盖其他地图、车辆数、层数或所有突发模式。','',
        '## 机制与核验','',
        '|组别|GA搜索次数|完整候选预演数|生成的独特匈牙利种子数|种子内部匈牙利调用数|滚动匈牙利批次数|','|---|---:|---:|---:|---:|---:|']
    for arm in p['treatments']:
        a=s['activity'][arm]
        lines.append(f"|{names[arm]}|{a['searches']}|{a['previews']}|{a['unique_seeds']}|{a['seed_matching_solves']}|{a['rolling_batches']}|")
    lines += ['',
        f"全部{s['executions']}次主运行、12份新微型轨迹及4份既有最优参照轨迹独立复核，共{s['independently_revalidated']}份。4个开发控制组与之前完整物理轨迹一致，191个基线文件未改。墙钟超预算记录{s['wall_budget_overruns']}。完整发布还会重跑30项单元/回归测试，并从包外工作目录重放默认入口。",'',
        '## 可复现入口','',
        '`python run_main.py --case wepa-day40-bin3885 --profile hga --output my-result.json`。不指定profile时运行本轮按预先规则保留的默认。输出文件必须不存在。三个正式profile是gate、hungarian、hga；旧配置保留仅用于历史回归。','',
        '完整轨迹与原始日志位于results/development和results/validation；汇总为results/summary.json及comparison.csv。未上传GitHub。']
    (ROOT/'docs/结果报告.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(ROOT/'docs/结果报告.md')


if __name__=='__main__':main()
