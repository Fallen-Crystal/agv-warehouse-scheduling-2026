"""Reconstruct selected unused days from pinned raw requests and exclusion audit."""
import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path
from paths import ROOT, sha


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--raw',type=Path,required=True)
    args=parser.parse_args()
    protocol=json.loads((ROOT/'data/protocol.json').read_text(encoding='utf-8'))
    audit=json.loads((ROOT/'data/input-selection.json').read_text(encoding='utf-8'))
    if sha(args.raw/'2_orders.json') != audit['source_sha256'] or sha(args.raw/'3_initial_fill_lvl.json') != audit['initial_stock_sha256']:
        raise ValueError('Pinned source hash mismatch')
    rows=json.loads((args.raw/'2_orders.json').read_text(encoding='utf-8'))
    stock=Counter({int(k):v for k,v in json.loads((args.raw/'3_initial_fill_lvl.json').read_text()).items()})
    groups=defaultdict(list)
    for row_id,row in enumerate(rows):groups[row[2]//900].append((row_id,row))
    excluded=set(audit['excluded_days']); selected=[]
    for bucket in sorted(groups):
        entries=groups[bucket]; day=bucket//96
        kinds=Counter(row[0] for _,row in entries)
        skus=sorted({row[1] for _,row in entries})
        qualifies=(day not in excluded and f'wepa-day{day}-bin{bucket}' not in audit['excluded_cases']
            and 35<=len(entries)<=65 and 2<=len(skus)<=5
            and len(kinds)==2 and min(kinds.values())>=5 and all(stock[s]>=0 for s in skus)
            and 0<=sum(stock[s] for s in skus)<=900)
        if qualifies:
            ledger={s:stock[s]+sum((1 if row[0]=='delivery' else -1) for _,row in entries if row[1]==s) for s in skus}
            if min(ledger.values())>=0:
                tasks=[]
                for jid,(row_id,row) in enumerate(entries):
                    tasks.append(dict(id=jid,source_row=row_id,kind=row[0],sku=row[1],release=row[2]-bucket*900,
                        source_time=row[2],source_dock=row[3],batch=row[4],week=row[5]))
                selected.append(dict(case=f'wepa-day{day}-bin{bucket}',source_day=day,source_bin=bucket,
                    start_seconds=bucket*900,end_seconds=(bucket+1)*900,close_at=900,
                    initial={str(s):stock[s] for s in skus},tasks=tasks))
                excluded.add(day)
                if len(selected)==4:break
        for _,row in entries:stock[row[1]]+=1 if row[0]=='delivery' else -1
    expected=[c for c in protocol['cases'] if c['case'] in protocol['validation']]
    if expected!=selected:raise ValueError('Input-only selection or prefix inventory differs')
    print(json.dumps(dict(input_only_selection_reproduced=True,raw_rows=len(rows),cases=[c['case'] for c in selected])))


if __name__=='__main__':main()
