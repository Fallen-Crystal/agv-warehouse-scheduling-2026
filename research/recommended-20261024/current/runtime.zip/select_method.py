"""Freeze development choice before any validation performance is read."""
import json
from statistics import mean
from paths import ROOT,hashes


def main():
    target=ROOT/'results/selection.json'
    if target.exists():raise ValueError('Selection already frozen')
    if (ROOT/'results/validation').exists():raise ValueError('Validation already started')
    before=json.loads((ROOT/'results/development/phase-before.json').read_text())
    after=json.loads((ROOT/'results/development/phase-after.json').read_text())
    if before['source']!=hashes() or not after['source_unchanged']:raise ValueError('Source drift')
    p=json.loads((ROOT/'data/protocol.json').read_text())
    rows=json.loads((ROOT/'results/development/runs.json').read_text())
    if len(rows)!=12 or not all(r['valid'] for r in rows):raise ValueError('Incomplete or invalid development')
    ranked=[]
    for arm in p['treatments']:
        r=[x for x in rows if x['profile']==arm]
        ranked.append(dict(profile=arm,F=mean(x['F'] for x in r),cpu=mean(x['cpu'] for x in r)))
    ranked.sort(key=lambda r:(r['F'],r['cpu'],r['profile']))
    record=dict(selected=ranked[0]['profile'],ranked=ranked,source=hashes(),validation_read=False,
        criterion='Minimum mean development F; CPU and profile name break ties; validation must confirm paired mean improvement')
    target.write_text(json.dumps(record,indent=2),encoding='utf-8');print(json.dumps(record['ranked']))


if __name__=='__main__':main()
