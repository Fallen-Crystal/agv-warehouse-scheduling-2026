"""Regress three new arms against four previously certified two-car optima."""
import json
from paths import ROOT,hashes,sha
from exact.fixtures import make
from improved.execute import run
from objective import LinearObjective,checked_score


def check_references():
    rows=json.loads((ROOT/'data/micro-reference/runs.json').read_text());count=0
    for row in rows:
        rec=json.loads((ROOT/f"data/micro-reference/{row['case']}.json").read_text())
        if not row['optimal'] or not rec['proof']['optimal'] or rec['proof']['objective_integer']!=rec['proof']['bound_integer']:
            raise ValueError('Reference is not certified optimal')
        if sha(ROOT/f"data/micro-reference/{row['case']}.pbtxt")!=rec['proof']['exported_model_sha256']:
            raise ValueError('Reference model export changed')
        model=make(row['case']);obj=LinearObjective(vehicles=2)
        if checked_score(model,rec['reference'],obj)!=rec['proof']['audit']:raise ValueError('Reference physics differs')
        count+=1
    return rows,count


def main():
    refs,_=check_references();results=[];obj=LinearObjective(vehicles=2)
    for ref in refs:
        for profile in ('gate','hungarian','hga'):
            model=make(ref['case']);result=run(model,profile,seed=0,objective=obj)
            score=checked_score(model,result,obj)
            results.append(dict(case=ref['case'],profile=profile,F=score['F_linear_v2'],
                F_optimal=ref['F_reference'],gap_percent=100*(score['F_linear_v2']/ref['F_reference']-1),
                result=result,scoring=score))
    record=dict(source=hashes(),rows=results,scope='Four known reduced static two-car optima; no new exact solve or six-car certificate')
    (ROOT/'results/micro-regression.json').write_text(json.dumps(record),encoding='utf-8')
    print(json.dumps([{k:r[k] for k in ('case','profile','F','gap_percent')} for r in results]))


if __name__=='__main__':main()
