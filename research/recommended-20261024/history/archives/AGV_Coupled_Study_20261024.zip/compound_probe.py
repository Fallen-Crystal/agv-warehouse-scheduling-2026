"""Secondary generic compound-move pilot on the diagnosed four-job instance.

No exact solution is supplied to candidate generation or selection. The optimum
is read only afterwards for evaluation. This pilot is NOT a main validation arm.
"""
import json
from paths import ROOT,hashes,sha
from exact_extra import expanded
from improved.forecast import snapshot,rollout
from improved.proxy import MixedCosts
from improved.policy import plan_from_prediction
from improved.targeted import neighborhoods
from wepa.kernel import World
from wepa.search import values
from objective import LinearObjective


def main():
    model,_=expanded('four_mixed');w=World(model);w.publish_and_complete();view=snapshot(w)
    obj=LinearObjective(vehicles=2);anchor,_=rollout(view)
    order,owners=plan_from_prediction(anchor,set(view.tasks)-view.assigned)
    costs=MixedCosts(view,anchor);proposals=[];seen=set()
    for o,a,kind in neighborhoods(costs,order,owners):
        if kind!='target_exchange':continue
        changed=[j for j in o if a[j]!=owners[j]]
        if len(changed)!=2:continue
        i,j=map(o.index,changed);o=list(o);o[i],o[j]=o[j],o[i]
        key=tuple(o),tuple(a[j] for j in o)
        if key in seen:continue
        seen.add(key);estimate=costs.estimate_joint(o,a)
        proposals.append((obj.score(estimate),o,a,'owner_exchange_and_priority_swap'))
        if len(proposals)>=48:break
    proposals.sort(key=lambda x:(x[0],tuple(x[1]),tuple(x[2][j] for j in x[1])))
    if not proposals:raise ValueError('No generic compound candidate')
    estimate,o,a,kind=proposals[0];trial,usage=rollout(view,(o,a))
    old=obj.score(values(anchor));new=obj.score(values(trial)) if trial is not None else None
    # Optimum is used only to evaluate the finished pilot, never for ranking.
    exact=json.loads((ROOT/'results/exact-extra/four_mixed.json').read_text())
    record=dict(secondary_diagnostic_only=True,main_validation_arm=False,used_exact_as_input=False,
        proposals=len(proposals),proxy_evaluations=costs.evaluations,full_previews=2,
        anchor_F=old,candidate_F=new,predicted_proxy_F=estimate,order=o,owners=a,kind=kind,
        improvement_percent=100*(old-new)/old if new is not None else None,
        attains_proven_micro_optimum=new is not None and abs(new-exact['row']['F_reference'])<1e-12,
        usage=usage,source=hashes(),script_sha256=sha(__file__),
        scope='Post-diagnosis four-job static pilot only; no untouched real-data evaluation',
        candidate_records=trial.records if trial is not None else None)
    (ROOT/'results/compound-pilot.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in record.items() if k not in ('source','candidate_records')}))


if __name__=='__main__':main()
