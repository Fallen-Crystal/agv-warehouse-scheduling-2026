"""Verified default, or an explicitly selected fixed-protocol experimental arm."""
import argparse
import json
import subprocess
import sys
from paths import ROOT,hashes,verify_baseline


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--case',required=True);parser.add_argument('--seed',type=int,default=0)
    parser.add_argument('--profile',choices=('gate','lns','coord','coupled'))
    parser.add_argument('--output',required=True);args=parser.parse_args()
    s=json.loads((ROOT/'results/summary.json').read_text())
    if s['source']!=hashes():raise ValueError('Algorithm or protocol changed after audit')
    verify_baseline();profile=args.profile or s['recommended']
    raise SystemExit(subprocess.call([sys.executable,str(ROOT/'run_trial.py'),'--case',args.case,
        '--profile',profile,'--seed',str(args.seed),'--output',args.output]))


if __name__=='__main__':main()
