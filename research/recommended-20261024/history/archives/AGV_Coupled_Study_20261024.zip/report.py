"""Report each intervention and its interaction, with raw negative cases."""
import json
from paths import ROOT


def main():
    s=json.loads((ROOT/'results/summary.json').read_text());v=s['groups']['validation']
    labels={'gate':'原方案','lns':'订单瓶颈邻域','coord':'两车局部协调','coupled':'两者结合'}
    lines=['# 订单搜索、路径协调与小规模最优参照（2026-10-24）','',
        '本轮实现并测试第二、三、四项建议。上一轮未胜出的开放流待命终点不并入本轮。评价、仓库地图、车数、层数、库存、层序、待命与最终返库均保持原规则。','',
        '## 采用决定','',
        f"开发集预选为 `{s['selected_before_validation']}`，最终默认保持/采用 `{s['recommended']}`。验证后没有调整算法或按最好种子重新挑方案。四组的所有对照和退化场景都保留。",'',
        'F 仍为 `0.5*T/900 + 0.3*R/900 + 0.2*D/5400`，用于大型 62×47 地图、6 车、5 层、900 秒请求窗口。T 为最后订单完成时间，R 为平均订单耗时，D 包括全部实际移动及最终返库。分数不含对照算法作分母。','']
    for split,title in [('development','旧开发窗口，种子 0'),('validation','新来源日验证，每场景种子 0/1')]:
        g=s['groups'][split]
        lines+=['## '+title,'','|方案|平均F|T秒|R秒|D格|累计CPU秒/窗口|逐场景配对改善|',
            '|---|---:|---:|---:|---:|---:|---:|']
        for arm in labels:
            a=g['aggregates'][arm];gain=g['comparisons'][arm]['mean_paired_gain_percent']
            lines.append(f"|{labels[arm]}|{a['F']:.6f}|{a['T']:.2f}|{a['R']:.2f}|{a['D']:.2f}|{a['cpu']:.2f}|{gain:.3f}%|")
        lines+=['','正改善表示 F 下降，负数表示退化。先在场景内平均种子，再按 4 个来源日等权平均；改善百分比是逐场景比值的平均，不是平均 F 的比值。','']
        lines+=['|窗口|订单邻域改善|路径协调改善|结合改善|','|---|---:|---:|---:|']
        for i,c in enumerate(g['comparisons']['gate']['cases']):
            gains=[g['comparisons'][arm]['cases'][i]['gain_percent'] for arm in ('lns','coord','coupled')]
            lines.append(f"|{c['case']}|{gains[0]:.3f}%|{gains[1]:.3f}%|{gains[2]:.3f}%|")
        lines+=['']
    lines+=['## 两项作用及相互影响','',
        '采用 2×2 对照分别计算订单搜索主效应、路径协调主效应和交互项。此处以成本变化计，负数有利；交互项为 `(结合 - 订单 - 路径 + 原方案)/原方案`，不能把两项单独收益直接相加。样本少，不报告显著性。','',
        '|数据组|订单主效应（成本%）|路径主效应（成本%）|交互成本%|','|---|---:|---:|---:|']
    for split in ('development','validation'):
        a=s['groups'][split]['factorial_average']
        lines.append(f"|{split}|{a['order_cost_effect_percent']:.3f}|{a['path_cost_effect_percent']:.3f}|{a['interaction_cost_percent']:.3f}|")
    lines+=['','## 实际实现与预算','',
        '订单邻域将原来的 192 次联合 GA 代理评估分成 144 次 GA 加至多 48 次瓶颈邻域评估。目标包括最晚完成车辆的尾部任务、长接货任务，尝试车辆转移、重插入和交换。总完整试排仍最多 6 次，给局部候选预留 1 次。它借鉴大邻域修复思想，未实现自适应算子学习，不能称为完整 ALNS。',
        '', '路径协调只处理同一时刻刚分配的两辆车，交换 SIPP 规划优先级；若多段行程衔接不安全，尝试 2/8 秒起步延迟。其余车辆的路径、已执行前缀、任务分配和货位均固定。候选要通过全车预约检查及同一 F 的完整已知任务预测，严格更低才原子替换。每窗口最多 4 次、间隔至少 64 秒，每次附加最多 1100 次路径调用。不是完整 CBS/MAPF-LNS，也没有改成蚁群底层路径搜索。',
        '', '订单搜索预算相同，路径协调有明确的附加计算预算，所以同时报告 CPU。并行运行使用两个隔离进程，按来源日分块、固定随机顺序；运行时间仅为工程描述，不据此宣称显著提速。',
        '', '协调结果通过实际路径与预约状态反馈给下一次派单；协调试排不递归调用协调器，是有限的一层预测，不保证订单和路径共同全局最优。','',
        '|方案|协调尝试|接受替换|瓶颈候选完整试排|已知任务预测中改善次数|','|---|---:|---:|---:|---:|']
    for arm in labels:
        a=s['activity'][arm]
        lines.append(f"|{labels[arm]}|{a['coord_attempts']}|{a['coord_accepted']}|{a['target_previews']}|{a['known_work_target_improvements']}|")
    lines+=['','以上次数是机制活动记录。预测中接受改进不等于真实后续订单下 F 下降；最终结论只按完整轨迹评判。','',
        '## 两车精确参照','',
        '预定 4 个微型仓库案例包含共享卸货口、交叉通道、入出库混合与 3 层货架。CP-SAT 联合决定任务归属、开始与服务时间、四邻接离散轨迹，并约束顶点/对向冲突、持续装卸、货架锁、层序、库存、专属停车位、端口只能装卸及最终返库。',
        '', '精确模型不限制为原执行器的固定 SIPP 后备路径策略，允许集中协调空车动作；首单分配前不得提前空车预定位。它是缩减物理模型的最优参照，不是对固定 SIPP 策略的穷举。微型几何显式定义与检查，不声称符合主地图生成器的完整布局规格，主场景地图校验未被修改或关闭。',
        '', '工作时域上界由已有可行解和正的 T 系数推导。最后工作完成之后，返库移动成本在完整两车联合状态图上用最短路精确求解，从而避免用任意短时域截断冒充最优。只在 OPTIMAL 且目标等于求解下界时报告范围内最优。导出的整数模型和 SHA256 均保存，最优轨迹再经原独立验解器核验。','',
        '|案例|订单数|状态|原方案相对最优差距|订单邻域差距|路径协调差距|结合差距|',
        '|---|---:|---|---:|---:|---:|---:|']
    for row in s['exact']:
        gaps=[max(0,row['profiles'][arm]['gap_percent']) if row['profiles'][arm]['gap_percent'] is not None else None for arm in labels]
        text=[f'{g:.3f}%' if g is not None else '未证明' for g in gaps]
        n=2 if row['case'] in ('cross_out','mixed') else 3
        lines.append('|'+ '|'.join([row['case'],str(n),row['status'],*text])+'|')
    lines+=['', '这 4 例都很小，即使均达到最优也不能证明 6 车真实动态场景接近最优。两车尺度与六车尺度不同，不把微型 F 的绝对值与主实验相比较。','']
    if s['secondary_exact']:
        lines+=['### 补充压力参照','',
            '看到预设微型例全部达到最优后，额外增加两例 4 单问题，分别为双货架连续出库和混合出入库层序。它们是补充诊断，未用于算法调参，也不冒称最初预设的验证数据。','',
            '|案例|状态|原方案差距|订单邻域差距|路径协调差距|结合差距|','|---|---|---:|---:|---:|---:|']
        for row in s['secondary_exact']:
            gaps=[row['profiles'][arm]['gap_percent'] for arm in labels]
            text=[f'{g:.3f}%' if g is not None else '未证明' for g in gaps]
            lines.append('|'+ '|'.join([row['case'],row['status'],*text])+'|')
        lines+=['']
    pilot=s['compound_pilot']
    lines+=['## 补充诊断：为什么简单修复没有找到四单最优方案','',
        '该段属于看过小例后的诊断和原型试验，不属于事前四组主验证。主代码和冻结数据未改变，未将此小例收益拼进真实数据平均值。',
        '', '给原 SIPP 输入精确解的车辆归属并枚举顺序后，它能够实现该例最优成本。这是使用已知答案的诊断，不是可部署算法，说明该例的差距并非原 SIPP 完全无法实现该路径。',
        '', '对同一小例的 GA 候选作全量被动检查：实际只产生 77 个不同编码，未生成最优组合；原本的 192 是上限，并不意味着每次都会形成 192 个不同候选。在这例中，代理对外部最优候选的估计正确，却没有搜索到它。此结论只针对该例，不能概括所有主场景。',
        '', '据此先试了换车加单次优先级交换，预测与实际路由衔接仍有差异，成本反而上升；负面记录保留。随后扩展为换车加邻接顺序扰动，对候选做实际 SIPP 反馈。候选生成不输入精确答案，但设计是在该小例诊断之后进行，所以不是独立泛化验证。',
        '', f"第二版共 {pilot['proposals']} 个复合候选、{pilot['full_previews']} 次完整试排，在原执行器中将 F 从 {pilot['anchor_F']:.9f} 降到 {pilot['candidate_F']:.9f}，相对原方案降低 {pilot['improvement_percent']:.3f}%，达到该四单例已证明的最优值。T 从 32 降到 30，R 从 22 增到 22.5，D 从 48 增到 50；整体 F 下降，未用单项指标否定整体改进。",'',
        '这给出了后续更明确的方向：需要同时改变相互影响的几项决策，而不是把单独换车、单独重排当成充分搜索。该原型保留在 compound_probe_v2.py，尚未移植为默认生产策略，也没有在本轮已消耗的验证窗口上调参后再冒称未见验证。','']
    if s['wall_budget_overruns']:
        lines+=['## 运行监测异常','',
            f"有 {len(s['wall_budget_overruns'])} 条原始记录的 wall 超过配置的 900 秒，而进程 CPU 仍在预算内。父进程的超时看护在这些记录中没有形成严格的实际墙钟上限。未确定具体原因，不把长等待归因于算法；原始记录保留，不用较快复跑替换它们。",'',
            '因此本轮不以 wall 得出速度结论。F 仍从完整物理轨迹计算；订单评估次数、路径调用上限和进程 CPU 另行检查。时间异常会作为执行监测限制随结果交付。','']
        if s['outlier_replay']:
            repeat=s['outlier_replay']
            lines += [f"对其中第 62 日 lns 种子 1 同配置复跑，路径、记录、派单、搜索日志及 T/R/D 精确一致；原 wall {repeat['original_wall']:.2f} 秒，复跑 wall {repeat['repeat_wall']:.2f} 秒，CPU 分别 {repeat['original_cpu']:.2f}/{repeat['repeat_cpu']:.2f} 秒。原结果未被复跑替换。",'']
    lines+=['## 核验与适用范围','',
        f"本轮完整主实验 {s['executions']} 次，重新独立核验主轨迹 {s['main_traces_revalidated']} 份、微型参照及其算法对照 {s['micro_traces_revalidated']} 份。旧开发窗口的 gate 路径、派单、任务记录及 T/R/D 与此前冻结版精确一致；冻结基线 {s['baseline_files_unchanged']} 个文件未改变。",'',
        '新验证使用此前未用的来源日 61/62/66/69，按输入条件选择完整 900 秒窗口，每组每场景两个种子。只有 4 个来源日独立场景，不能把 32 次执行说成 32 个独立场景。真实数据仍是请求驱动的课程模型映射，起始库存由源请求前缀台账推算，不是原仓库实测 WIP。', '',
        '所有 raw traces、CPU/wall、负面结果、2×2 交互项、整数模型、最优下界和输入选择审计都已保存。未在本轮扩展到其他地图、车数、层数或全部业务场景，不宣称动态全局最优，也未调整 F 权重制造改善。', '',
        '订单对照检验的是“144 次 GA＋48 次指定邻域”这一整组资源分配，不能把其负结果解释为所有大邻域算法都无效。路径对照只检验有限双车优先级/时序调整，不能据此否定更强的 CBS、MAPF-LNS 或联合轨迹规划。','',
        '明细：results/comparison.csv；四组完整轨迹：results/development 与 results/validation；小规模整数模型及证书：results/exact-final 与 results/exact-extra。文献与实现边界见 docs/实验设计.md。','']
    (ROOT/'docs/结果报告.md').write_text('\n'.join(lines),encoding='utf-8')
    print(json.dumps({'recommended':s['recommended'],'report':'docs/结果报告.md'}))


if __name__=='__main__':main()
