"""Full physical rechecks and paired 2x2 effects; never drop bad outcomes."""
import csv
import json
from statistics import mean
from paths import ROOT,hashes,verify_baseline,sha
from objective import LinearObjective,checked_score
from wepa.data import build
from exact.fixtures import make


def main():
    p=json.loads((ROOT/'data/protocol.json').read_text());obj=LinearObjective(**p['objective'])
    case_map={c['case']:c for c in p['cases']};all_rows=[];groups={};counts={};regression=[]
    for split in ('development','validation'):
        directory=ROOT/'results'/split
        before=json.loads((directory/'phase-before.json').read_text());after=json.loads((directory/'phase-after.json').read_text())
        if before['source']!=hashes() or not after['source_unchanged']:raise ValueError('Phase source drift')
        rows=json.loads((directory/'runs.json').read_text());by_case={}
        if len(rows)!=len(p[split])*4*(1 if split=='development' else 2):raise ValueError('Missing fixed-protocol runs')
        for row in rows:
            if not row['valid']:raise ValueError('An invalid run disqualifies its arm; do not average it away')
            trace=json.loads((ROOT/row['trace']).read_text(encoding='utf-8'))
            if trace['implementation_sha256']!=hashes():raise ValueError('Trace code identity mismatch')
            model=build(case_map[row['case']],**p['configuration']);sc=checked_score(model,trace['result'],obj)
            if sc!=trace['scoring'] or abs(sc['F_linear_v2']-row['F'])>1e-12:raise ValueError('Physical F changed')
            profile=row['profile'];activity=counts.setdefault(profile,dict(coord_attempts=0,coord_accepted=0,
                coord_router_calls=0,target_previews=0,known_work_target_improvements=0))
            logs=trace['result']['coordination_log']
            if len(logs)>4 or any(b['time']-a['time']<64 for a,b in zip(logs,logs[1:])):raise ValueError('Coordination event budget exceeded')
            for log in logs:
                if log.get('route_calls',0)>1100:raise ValueError('Coordination routing budget exceeded')
                if log['accepted'] and not log['score']<log['base_score']-1e-12:raise ValueError('Accepted non-improvement')
                activity['coord_attempts']+=1;activity['coord_accepted']+=log['accepted']
                activity['coord_router_calls']+=log.get('route_calls',0)
            for log in trace['result']['search_log']:
                if 'previews' not in log:continue
                if log['previews']>6 or log['proxy_evaluations']>192:raise ValueError('Order search budget exceeded')
                best=log['base_score']
                for trial in log['candidates']:
                    if trial['usage']['route_calls']>512:raise ValueError('Preview path budget exceeded')
                    if trial['kind'].startswith('repair_target'):
                        activity['target_previews']+=1
                        if trial['score'] is not None and trial['score']<best-1e-12:activity['known_work_target_improvements']+=1
                    if trial['score'] is not None:best=min(best,trial['score'])
            if split=='development' and profile=='gate':
                old=json.loads((ROOT/f"data/control-reference/{row['case']}-gate-s0.json").read_text())['result']
                exact=all(old[k]==trace['result'][k] for k in ('paths','labels','records','decisions','T','R','D','final_stock'))
                if not exact:raise ValueError('Control no longer matches selected previous implementation')
                regression.append(dict(case=row['case'],exact_physical_replay=True))
            by_case.setdefault(row['case'],{}).setdefault(profile,[]).append(row)
            all_rows.append(dict(split=split,**row))
        aggregates={};comparisons={};effects=[]
        for profile in ('gate','lns','coord','coupled'):
            aggregates[profile]={k:mean(mean(r[k] for r in by_case[c][profile]) for c in p[split])
                for k in ('F','J','T','R','D','cpu','wall','p90','empty_distance','traffic_wait')}
            pairs=[]
            for c in p[split]:
                control=by_case[c]['gate'];trial=by_case[c][profile]
                if sorted(r['seed'] for r in control)!=sorted(r['seed'] for r in trial):raise ValueError('Unpaired seeds')
                base=mean(r['F'] for r in control);new=mean(r['F'] for r in trial)
                pairs.append(dict(case=c,gate=base,F=new,gain_percent=100*(base-new)/base))
            comparisons[profile]=dict(cases=pairs,mean_paired_gain_percent=mean(r['gain_percent'] for r in pairs),
                improved_cases=sum(r['gain_percent']>1e-10 for r in pairs),worsened_cases=sum(r['gain_percent'] < -1e-10 for r in pairs))
        for c in p[split]:
            vals={arm:mean(r['F'] for r in by_case[c][arm]) for arm in ('gate','lns','coord','coupled')}
            effects.append(dict(case=c,order_cost_effect_percent=100*((vals['lns']-vals['gate'])+(vals['coupled']-vals['coord']))/(2*vals['gate']),
                path_cost_effect_percent=100*((vals['coord']-vals['gate'])+(vals['coupled']-vals['lns']))/(2*vals['gate']),
                interaction_cost_percent=100*(vals['coupled']-vals['lns']-vals['coord']+vals['gate'])/vals['gate']))
        groups[split]=dict(aggregates=aggregates,comparisons=comparisons,factorial_effects=effects,
            factorial_average={k:mean(e[k] for e in effects) for k in effects[0] if k!='case'})
    exact_rows=json.loads((ROOT/'results/exact-final/runs.json').read_text());exact_audited=0
    for row in exact_rows:
        record=json.loads((ROOT/f"results/exact-final/{row['case']}.json").read_text(encoding='utf-8'))
        if record['source']!=hashes():raise ValueError('Exact model source differs')
        if sha(ROOT/f"results/exact-final/{row['case']}.pbtxt")!=record['proof']['exported_model_sha256']:raise ValueError('Integer model export changed')
        m=make(row['case']);o=LinearObjective(vehicles=2)
        for arm,data in record['heuristics'].items():
            if checked_score(m,data['result'],o)!=data['scoring']:raise ValueError('Micro heuristic replay mismatch')
            exact_audited+=1
        if record['reference'] is not None:
            if checked_score(m,record['reference'],o)!=record['proof']['audit']:raise ValueError('Exact replay mismatch')
            exact_audited+=1
        if row['optimal'] and abs(row['objective_integer']-row['bound_integer'])>1e-9:raise ValueError('Optimality status inconsistent with bound')
    secondary=[]
    extra_dir=ROOT/'results/exact-extra'
    if (extra_dir/'runs.json').exists():
        secondary=json.loads((extra_dir/'runs.json').read_text())
        for row in secondary:
            rec=json.loads((extra_dir/f"{row['case']}.json").read_text())
            if rec['source']!=hashes() or rec['script_sha256']!=sha(ROOT/'exact_extra.py'):raise ValueError('Secondary exact source changed')
            if sha(extra_dir/f"{row['case']}.pbtxt")!=rec['proof']['exported_model_sha256']:raise ValueError('Secondary integer model changed')
            m=make(rec['fixture']['base']);m['tasks']=rec['fixture']['tasks']
            for job in m['tasks']:job['port']=tuple(job['port'])
            o=LinearObjective(vehicles=2)
            for arm,data in rec['heuristics'].items():
                if checked_score(m,data['result'],o)!=data['scoring']:raise ValueError('Secondary heuristic replay failed')
                exact_audited+=1
            if rec['reference'] is not None:
                if checked_score(m,rec['reference'],o)!=rec['proof']['audit']:raise ValueError('Secondary exact replay failed')
                exact_audited+=1
            if row['optimal'] and abs(row['objective_integer']-row['bound_integer'])>1e-9:raise ValueError('Secondary optimality mismatch')
    selection=json.loads((ROOT/'results/selection.json').read_text())
    if selection['source']!=hashes():raise ValueError('Source changed after development selection')
    selected=selection['selected'];gain=groups['validation']['comparisons'][selected]['mean_paired_gain_percent']
    recommended=selected if selected!='gate' and gain>0 else 'gate'
    pilot=json.loads((ROOT/'results/compound-pilot-v2.json').read_text())
    if pilot['source']!=hashes() or pilot['script_sha256']!=sha(ROOT/'compound_probe_v2.py'):raise ValueError('Compound pilot source drift')
    pm=make('mixed_burst');pm['tasks']=json.loads((ROOT/'results/exact-extra/four_mixed.json').read_text())['fixture']['tasks']
    for job in pm['tasks']:job['port']=tuple(job['port'])
    if checked_score(pm,pilot['candidate'],LinearObjective(vehicles=2))!=pilot['scoring']:raise ValueError('Compound pilot replay mismatch')
    wall_outliers=[dict(case=r['case'],profile=r['profile'],seed=r['seed'],wall=r['wall'],cpu=r['cpu'])
        for r in all_rows if r['wall']>p['limits']['wall_seconds']]
    replay_path=ROOT/'results/replay/wepa-day62-bin6004-lns-s1.json';replay_check=None
    if replay_path.exists():
        repeated=json.loads(replay_path.read_text());original=json.loads((ROOT/'results/validation/traces'/replay_path.name).read_text())
        model=build(case_map[repeated['row']['case']],**p['configuration'])
        if repeated['implementation_sha256']!=hashes() or checked_score(model,repeated['result'],obj)!=repeated['scoring']:
            raise ValueError('Outlier repeat failed independent verification')
        equal=all(repeated['result'][k]==original['result'][k] for k in
            ('paths','labels','records','decisions','search_log','coordination_log','T','R','D','final_stock'))
        if not equal:raise ValueError('Wall-time outlier is not reproducible')
        replay_check=dict(case=repeated['row']['case'],profile='lns',seed=1,exact_physical_replay=True,
            original_wall=original['row']['wall'],repeat_wall=repeated['row']['wall'],
            original_cpu=original['row']['cpu'],repeat_cpu=repeated['row']['cpu'],original_retained=True)
    summary=dict(executions=len(all_rows),independently_revalidated=len(all_rows)+exact_audited+1+bool(replay_check),
        main_traces_revalidated=len(all_rows),micro_traces_revalidated=exact_audited,
        exact_cases=len(exact_rows),exact_optimal_cases=sum(r['optimal'] for r in exact_rows),
        exact=exact_rows,secondary_exact=secondary,groups=groups,activity=counts,control_regression=regression,
        selected_before_validation=selected,recommended=recommended,source=hashes(),
        compound_pilot={k:v for k,v in pilot.items() if k not in ('candidate','candidate_records','previews','source')},
        wall_budget_overruns=wall_outliers,
        outlier_replay=replay_check,
        baseline_files_unchanged=verify_baseline(),validation_retuning=False,
        scope='Four new source-day validation clusters, two seeds per arm; reduced static two-car exact certificates are a separate scope.')
    (ROOT/'results/summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    with (ROOT/'results/comparison.csv').open('w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(all_rows[0]));writer.writeheader();writer.writerows(all_rows)
    print(json.dumps({k:v for k,v in summary.items() if k not in ('source','groups','exact')},ensure_ascii=False))
    print(json.dumps(groups,ensure_ascii=False))


if __name__=='__main__':main()
