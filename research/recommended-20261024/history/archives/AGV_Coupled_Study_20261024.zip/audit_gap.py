"""Diagnostic oracle assignment: can original SIPP realize the micro optimum?

Never used in the main algorithm. The exact answer supplies owners only to
separate a missed task plan from an unattainable fixed-routing strategy.
"""
from itertools import permutations
import json
from paths import ROOT,hashes,sha
from exact_extra import expanded
from exact.joint import as_result
from wepa.kernel import World
from wepa.search import owned_batch
from objective import LinearObjective,checked_score


def main():
    exact=json.loads((ROOT/'results/exact-extra/four_mixed.json').read_text())
    owners={r['task']:r['vehicle'] for r in exact['reference']['records']}
    obj=LinearObjective(vehicles=2);attempts=[];best=None
    for order in permutations(sorted(owners)):
        model,_=expanded('four_mixed');world=World(model)
        while world.time<=500:
            world.publish_and_complete()
            if world.done:break
            if any(r is None for r in world.active) and world.ready():
                pairs=owned_batch(world,order,owners)
                if pairs:world.decisions.append(dict(time=world.time,pairs=pairs,visible_ids=sorted(world.visible)))
            world.advance()
        if not world.done:
            attempts.append(dict(order=order,valid=False));continue
        result=as_result(model,world.history,world.records,obj)
        result['method']='diagnostic-exact-owners-original-sipp'
        result['labels']=world.labels;result['decisions']=world.decisions
        scoring=checked_score(model,result,obj)
        attempts.append(dict(order=order,valid=True,F=scoring['F_linear_v2']))
        if best is None or scoring['F_linear_v2']<best['scoring']['F_linear_v2']-1e-12:
            best=dict(order=order,owners=owners,result=result,scoring=scoring)
    target=ROOT/'results/exact-gap-diagnostic.json'
    output=dict(oracle_diagnostic_only=True,used_in_main_policy=False,case='four_mixed',
        exact_F=exact['row']['F_reference'],baseline_F=exact['row']['profiles']['gate']['F'],
        best=best,attempts=attempts,source=hashes(),script_sha256=sha(__file__),
        original_sipp_attains_exact=abs(best['scoring']['F_linear_v2']-exact['row']['F_reference'])<1e-12)
    target.write_text(json.dumps(output),encoding='utf-8')
    print(json.dumps({k:v for k,v in output.items() if k not in ('best','attempts','source')}))
    print(json.dumps({'best_order':best['order'],'best_F':best['scoring']['F_linear_v2']}))


if __name__=='__main__':main()
