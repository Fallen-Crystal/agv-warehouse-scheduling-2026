"""Verify the copied release, dependencies explicit, and retain every result."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile
from paths import ROOT,hashes,sha,verify_baseline


def main():
    outputs=ROOT.parent.parent/'outputs';target=outputs/'agv-coupled-study-20261024'
    archive=outputs/'AGV_Coupled_Study_20261024.zip'
    if target.exists() or archive.exists():raise ValueError('Refuse to overwrite a release')
    summary=json.loads((ROOT/'results/summary.json').read_text())
    if summary['source']!=hashes():raise ValueError('Source drift since final audit')
    previous=outputs/'AGV_Open_Forecast_20261024.zip'
    old_hash='054169b71bdcfc8515a6bf984581e6646accda3b854f776433b8cd4cee323f5d'
    if sha(previous)!=old_hash:raise ValueError('Previous release changed')
    verify_baseline()
    shutil.copytree(ROOT,target,ignore=shutil.ignore_patterns('__pycache__','*.pyc','exact-deps','.ruff_cache'))
    env=dict(os.environ,PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONPATH',None)
    # Code runs from the copied artifact. Only the declared optional third-party
    # solver dependency is supplied from its isolated local installation.
    bootstrap="import sys,unittest;sys.path.insert(0,"+repr(str(ROOT/'exact-deps'))+");unittest.main(module=None,argv=['unittest','test_coupled','test_boundary','test_variants','-v'])"
    log=outputs/'coupled-delivered-tests.log'
    with log.open('w',encoding='utf-8') as stream:
        proc=subprocess.run([sys.executable,'-c',bootstrap],cwd=target,env=env,stdout=stream,
            stderr=subprocess.STDOUT,timeout=180)
    text=log.read_text(encoding='utf-8')
    if proc.returncode or 'Ran 22 tests' not in text or not text.rstrip().endswith('OK'):
        raise ValueError('Packaged tests failed; see '+str(log))
    with (outputs/'coupled-delivered-audit.log').open('w',encoding='utf-8') as stream:
        proc=subprocess.run([sys.executable,'analyze.py'],cwd=target,env=env,
            stdout=stream,stderr=subprocess.STDOUT,timeout=180)
    if proc.returncode or json.loads((target/'results/summary.json').read_text())!=summary:
        raise ValueError('Packaged physical audit does not reproduce source summary')
    smoke=outputs/'coupled-delivered-smoke.json'
    with (outputs/'coupled-delivered-smoke.log').open('w',encoding='utf-8') as stream:
        proc=subprocess.run([sys.executable,str(target/'run_main.py'),'--case','wepa-day45-bin4335',
            '--output',str(smoke)],cwd=outputs,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=180)
    if proc.returncode:raise ValueError('External-CWD primary entry failed')
    actual=json.loads(smoke.read_text())
    expected=json.loads((target/f"results/development/traces/wepa-day45-bin4335-{summary['recommended']}-s0.json").read_text())
    if not all(actual['result'][k]==expected['result'][k] for k in ('paths','labels','records','decisions','search_log','coordination_log','T','R','D','final_stock')) or actual['scoring']!=expected['scoring']:
        raise ValueError('Copied default does not replay exactly')
    record=dict(tests_passed=22,raw_test_log=text,packaged_physical_rechecks=summary['independently_revalidated'],
        external_cwd_entry_exact=True,optional_solver_dependency='ortools==9.15.6755',
        dependency_not_bundled=True,no_inherited_pythonpath=True)
    (target/'results/delivery-verification.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
    manifest={p.relative_to(target).as_posix():sha(p) for p in sorted(target.rglob('*')) if p.is_file()}
    (target/'MANIFEST.sha256.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(target.rglob('*')):
            if p.is_file():z.write(p,p.relative_to(target).as_posix())
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:raise ValueError('ZIP CRC failure')
        for name,digest in manifest.items():
            if hashlib.sha256(z.read(name)).hexdigest()!=digest:raise ValueError('Payload hash mismatch')
    if sha(previous)!=old_hash:raise ValueError('Previous archive was modified')
    receipt=dict(archive=str(archive),directory=str(target),archive_sha256=sha(archive),
        bytes=archive.stat().st_size,files=len(manifest)+1,recommended=summary['recommended'],
        primary_executions=summary['executions'],independently_revalidated=summary['independently_revalidated'],
        primary_exact_optimal=summary['exact_optimal_cases'],secondary_exact_statuses=[r['status'] for r in summary['secondary_exact']],
        targeted_tests=22,baseline_files_unchanged=verify_baseline(),original_archive_unchanged=True,
        external_cwd_entry_exact=True,zip_crc_verified=True,payload_hashes_verified=True,
        wall_budget_overruns=summary['wall_budget_overruns'],github_uploaded=False)
    (outputs/'AGV_Coupled_Study_20261024.receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    print(json.dumps(receipt),flush=True)


if __name__=='__main__':main()
