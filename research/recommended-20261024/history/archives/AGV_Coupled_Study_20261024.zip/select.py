"""Freeze the development ranking before opening fresh validation results."""
import json
from statistics import mean
from paths import ROOT,hashes,sha,verify_baseline


def main():
    target=ROOT/'results/selection.json'
    if target.exists() or (ROOT/'results/validation').exists():raise ValueError('Selection must precede validation')
    before=json.loads((ROOT/'results/development/phase-before.json').read_text())
    after=json.loads((ROOT/'results/development/phase-after.json').read_text())
    if before['source']!=hashes() or not after['source_unchanged']:raise ValueError('Development source drift')
    rows=json.loads((ROOT/'results/development/runs.json').read_text());rank=[]
    for profile in ('gate','lns','coord','coupled'):
        arm=[r for r in rows if r['profile']==profile]
        valid=len(arm)==4 and all(r['valid'] for r in arm)
        rank.append(dict(profile=profile,valid=valid,mean_F=mean(r['F'] for r in arm) if valid else None,
            mean_cpu=mean(r['cpu'] for r in arm) if valid else None))
    eligible=sorted((r for r in rank if r['valid']),key=lambda r:(r['mean_F'],r['mean_cpu'],r['profile']))
    if not eligible:raise ValueError('No valid reference arm')
    selected=eligible[0]['profile'];control=next(r for r in rank if r['profile']=='gate')
    if not control['valid']:raise ValueError('Control invalid')
    if eligible[0]['mean_F']>=control['mean_F']-1e-12:selected='gate'
    record=dict(selected=selected,ranking=rank,source=hashes(),baseline_files=verify_baseline(),
        validation_opened_at_selection=False,selection_rule_sha256=sha(ROOT/'data/selection-rule.json'))
    target.write_text(json.dumps(record,indent=2),encoding='utf-8');print(json.dumps(record))


if __name__=='__main__':main()
