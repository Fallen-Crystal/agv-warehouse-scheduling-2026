"""Audit all generated proposals on a solved four-job case; diagnostic only."""
import json
from paths import ROOT,hashes,sha
from exact_extra import expanded
from improved.forecast import snapshot,rollout
from improved.policy import plan_from_prediction
from improved.proxy import MixedCosts
from improved.genetic import candidates
from wepa.kernel import World
from wepa.search import values
from objective import LinearObjective


def main():
    m,_=expanded('four_mixed');w=World(m);w.publish_and_complete();v=snapshot(w)
    obj=LinearObjective(vehicles=2);base,_=rollout(v)
    pending=set(v.tasks)-v.assigned;order,owners=plan_from_prediction(base,pending)
    costs=MixedCosts(v,base)
    generated,activity=candidates(costs,order,owners,objective=obj,soft=True,
        seed=sum(pending),budget=192,generations=16)
    output=[];formal=[]
    for rank,(o,a,kind) in enumerate(generated,1):
        initial=o==order and a==owners
        if not initial and len(formal)<5:formal.append(rank)
        trial,usage=rollout(v,(o,a))
        score=obj.score(values(trial)) if trial is not None else None
        output.append(dict(rank=rank,proxy=costs.estimate_joint(o,a),order=o,owners=a,
            physical_F=score,usage=usage,anchor_duplicate=initial))
    record=json.loads((ROOT/'results/exact-gap-diagnostic.json').read_text())
    oracle=record['best'];costs.allowance=10**6
    oracle_proxy=obj.score(costs.estimate_joint(oracle['order'],{int(j):k for j,k in oracle['owners'].items()}))
    best=min((r for r in output if r['physical_F'] is not None),key=lambda r:r['physical_F'])
    formal_score=min([obj.score(values(base))]+[r['physical_F'] for r in output if r['rank'] in formal and r['physical_F'] is not None])
    result=dict(diagnostic_only=True,used_in_main_policy=False,case='four_mixed',source=hashes(),
        script_sha256=sha(__file__),activity=activity,formal_ranks=formal,formal_best_F=formal_score,
        best_generated_physical_F=best['physical_F'],best_generated_proxy_rank=best['rank'],
        exact_F=record['exact_F'],oracle_proxy_F=oracle_proxy,
        generated_candidates_better_proxy_than_oracle=sum(obj.score(r['proxy'])<oracle_proxy-1e-12 for r in output),
        candidates=output)
    (ROOT/'results/proxy-gap-diagnostic.json').write_text(json.dumps(result),encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ('source','candidates','activity')}))


if __name__=='__main__':main()
