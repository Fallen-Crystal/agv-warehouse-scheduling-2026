"""Joint small-instance certificates, with full traces and fixed-scope gaps."""
import argparse
import json
import sys
import time
from paths import ROOT,hashes
from exact.fixtures import make,NAMES
from exact.joint import solve
from improved.execute import run
from objective import LinearObjective,checked_score


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seconds',type=int,default=120)
    parser.add_argument('--names',default=','.join(NAMES))
    parser.add_argument('--phase',default='exact')
    args=parser.parse_args();directory=ROOT/'results'/args.phase;directory.mkdir(exist_ok=False)
    frozen=hashes();rows=[]
    for name in args.names.split(','):
        m=make(name);obj=LinearObjective(vehicles=2)
        candidates={}
        for profile in ('gate','lns','coord','coupled'):
            t=time.perf_counter();r=run(m,profile,seed=0,objective=obj);sc=checked_score(m,r,obj)
            candidates[profile]=dict(result=r,scoring=sc,cpu_wall=time.perf_counter()-t)
        best=min(candidates.values(),key=lambda r:r['scoring']['F_linear_v2'])['result']
        print('SOLVE '+name,flush=True)
        proof,result=solve(m,obj,best,seconds=args.seconds,model_path=directory/f'{name}.pbtxt')
        reference=proof['objective_integer']/proof['coefficient_scale'] if proof['objective_integer'] is not None else None
        row=dict(case=name,**{k:v for k,v in proof.items() if k not in ('audit','response_stats','model_stats')},
            F_reference=reference,profiles={p:dict(F=v['scoring']['F_linear_v2'],
                gap_percent=100*(v['scoring']['F_linear_v2']/reference-1) if reference is not None and proof['optimal'] else None)
                for p,v in candidates.items()})
        record=dict(row=row,proof=proof,reference=result,heuristics=candidates,source=frozen,
            fixture=dict(name=name,scope='synthetic reduced map; same layer/service/collision/port/inventory rules'))
        (directory/f'{name}.json').write_text(json.dumps(record,ensure_ascii=False),encoding='utf-8')
        rows.append(row);print(json.dumps(row),flush=True)
        (directory/'runs.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    if frozen!=hashes():raise ValueError('Source changed during exact solve')
    print(json.dumps({'cases':len(rows),'optimal':sum(r['optimal'] for r in rows)}),flush=True)


if __name__=='__main__':main()
