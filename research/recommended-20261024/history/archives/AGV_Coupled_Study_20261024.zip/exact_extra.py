"""Secondary four-job stress references, added after the four primary micros.

This does not change any main experiment algorithm or tune against validation.
The added workload definition and this script's hash are stored with each solve.
"""
import json
import time
from paths import ROOT,hashes,sha
from exact.fixtures import make
from exact.joint import solve
from improved.execute import run
from objective import LinearObjective,checked_score


def expanded(name):
    base='layers' if name=='four_out' else 'mixed_burst'
    model=make(base)
    kind,sku=('retrieval',20) if name=='four_out' else ('delivery',30)
    model['tasks'].append(dict(id=3,kind=kind,sku=sku,release=0,
        port=model['scene'].stations[0 if kind=='delivery' else 1]))
    model['case']='micro-'+name
    return model,base


def main():
    directory=ROOT/'results/exact-extra';directory.mkdir(exist_ok=False)
    frozen=hashes();identity=sha(__file__);rows=[]
    for name in ('four_out','four_mixed'):
        model,base=expanded(name);obj=LinearObjective(vehicles=2);heuristics={}
        for profile in ('gate','lns','coord','coupled'):
            result=run(model,profile,seed=0,objective=obj)
            heuristics[profile]=dict(result=result,scoring=checked_score(model,result,obj))
        incumbent=min(heuristics.values(),key=lambda h:h['scoring']['F_linear_v2'])['result']
        print('SOLVE EXTRA '+name,flush=True)
        proof,result=solve(model,obj,incumbent,seconds=120,model_path=directory/f'{name}.pbtxt')
        reference=proof['objective_integer']/proof['coefficient_scale'] if proof['objective_integer'] is not None else None
        row=dict(case=name,status=proof['status'],optimal=proof['optimal'],F_reference=reference,
            objective_integer=proof['objective_integer'],bound_integer=proof['bound_integer'],
            profiles={arm:dict(F=h['scoring']['F_linear_v2'],gap_percent=max(0,100*(h['scoring']['F_linear_v2']/reference-1))
                if reference is not None and proof['optimal'] else None) for arm,h in heuristics.items()})
        record=dict(row=row,proof=proof,reference=result,heuristics=heuristics,source=frozen,
            fixture=dict(base=base,tasks=model['tasks'],name=name,secondary_stress=True),script_sha256=identity)
        (directory/f'{name}.json').write_text(json.dumps(record),encoding='utf-8')
        rows.append(row);(directory/'runs.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
        print(json.dumps(row),flush=True)
    if hashes()!=frozen or sha(__file__)!=identity:raise ValueError('Source drift during secondary exact solve')


if __name__=='__main__':main()
