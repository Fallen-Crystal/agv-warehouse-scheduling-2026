import itertools
import ast
import random
import unittest

from common import BASE, ROOT, read, sha
from bounds import hungarian, cardinality_costs, lower_bound
from wepa.data import build


class AuditTests(unittest.TestCase):
    def test_cp_source_preserved_and_bounds_not_primal_claims(self):
        original = ROOT / "results/source-snapshot/cp_bound.py"
        self.assertEqual(
            ast.dump(
                ast.parse(original.read_text(encoding="utf-8")),
                include_attributes=False,
            ),
            ast.dump(
                ast.parse((ROOT / "cp_bound.py").read_text(encoding="utf-8")),
                include_attributes=False,
            ),
        )
        rows = read(ROOT / "results/cp-bounds.json")
        self.assertEqual(len(rows), 3)
        for row in rows:
            self.assertEqual(row["source_sha256"], sha(original))
            self.assertTrue(row["real_incumbent_embedded"])
            self.assertLessEqual(row["lower_bound"], row["best_real_incumbent"] + 1e-10)
            self.assertIn(row["status"], ("FEASIBLE", "OPTIMAL", "UNKNOWN"))

    def test_probe_prefixes_and_offline_claim_scope(self):
        probes = read(ROOT / "results/probes.json")
        self.assertEqual(len(probes), 3)
        self.assertTrue(all(r["prefix_matches_formal"] for r in probes))
        for p in probes:
            self.assertTrue(
                all(c["usage"]["route_calls"] <= 512 for c in p["candidates"])
            )
        offline = read(ROOT / "results/offline.json")
        self.assertEqual(len(offline), 3)
        self.assertTrue(
            all(r["knows_future"] and not r["online_algorithm"] for r in offline)
        )

    def test_assignment_matches_exhaustive_small_matrices(self):
        rng = random.Random(24)
        for n in range(1, 6):
            for _ in range(4):
                a = [[rng.randrange(30) for _ in range(n)] for _ in range(n)]
                expected = min(
                    sum(a[i][p[i]] for i in range(n))
                    for p in itertools.permutations(range(n))
                )
                self.assertEqual(hungarian(a)[0], expected)

    def test_cardinality_matching_all_sizes_against_enumeration(self):
        rng = random.Random(13)
        for left, right in ((3, 2), (4, 3), (5, 4)):
            for _ in range(4):
                a = [[rng.randrange(20) for _ in range(right)] for _ in range(left)]
                expected = []
                for k in range(1, right + 1):
                    expected.append(
                        min(
                            sum(a[i][j] for i, j in zip(rows, cols))
                            for rows in itertools.combinations(range(left), k)
                            for cols in itertools.permutations(range(right), k)
                        )
                    )
                self.assertEqual(cardinality_costs(a), expected)

    def test_bounds_and_fixed_binding_predictions_on_all_formal_validation(self):
        protocol = read(BASE / "data/simple-protocol.json")
        for case in protocol["cases"]:
            if case["case"] not in protocol["validation"]:
                continue
            lb = lower_bound(build(case))
            for row in read(BASE / "results/validation/runs.json"):
                if row["case"] != case["case"]:
                    continue
                result = read(BASE / row["trace"])["result"]
                self.assertTrue(all(lb[k] <= result[k] + 1e-9 for k in ("T", "R", "D")))
                for r in result["records"]:
                    if r["task"] in lb["initial_fixed_slots"]:
                        self.assertEqual(
                            lb["initial_fixed_slots"][r["task"]], r["slot"]
                        )

    def test_exact_proof_scope_and_scores(self):
        exact = read(ROOT / "results/exact.json")
        self.assertEqual(len(exact), 9)
        for c in exact:
            self.assertEqual(c["source_batch_size"], 33)
            self.assertTrue(c["source_subset"])
            self.assertTrue(
                all(r["F"] + 1e-12 >= c["exact"]["F"] for r in c["results"])
            )
            if c["tasks"] <= 8:
                self.assertGreater(c["exact"]["legal_permutations_crosschecked"], 0)

    def test_all_new_replays_independently_validate(self):
        from wepa.check import validate

        cases = {
            c["case"]: c for c in read(BASE / "data/simple-protocol.json")["cases"]
        }
        count = 0
        for path in (ROOT / "results/exact-traces").glob("*.json"):
            doc = read(path)
            self.assertTrue(
                validate(build(doc["case"], vehicles=1), doc["result"])["valid"]
            )
            count += 1
        self.assertEqual(count, 54)
        for path in (ROOT / "results/offline-traces").glob("*.json"):
            doc = read(path)
            self.assertTrue(
                validate(build(cases[doc["row"]["case"]]), doc["result"])["valid"]
            )

    def test_prior_delivery_unchanged(self):
        for name, digest in read(BASE / "MANIFEST.sha256.json").items():
            self.assertEqual(sha(BASE / name), digest, name)


if __name__ == "__main__":
    unittest.main()
