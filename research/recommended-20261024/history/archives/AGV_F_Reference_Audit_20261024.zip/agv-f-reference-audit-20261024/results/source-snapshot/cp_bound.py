"""Clairvoyant routing/scheduling relaxation: solver bound, not a real trajectory."""

import math
import sys
from collections import defaultdict
from fractions import Fraction
from pathlib import Path

from common import BASE, ROOT, read, write, sha
from bounds import lower_bound, RelaxedGeometry
from wepa.data import build

sys.path.insert(0,str(ROOT.parent/'agv-audit-deps'))
from ortools.sat.python import cp_model  # noqa: E402
import ortools  # noqa: E402


def solve(case,seconds=120):
    model=build(case);lb=lower_bound(model)
    rows=[r for r in read(BASE/'results/validation/runs.json') if r['case']==case['case'] and r['valid']]
    ref=next(r for r in rows if r['method']=='fcfs')
    incumbent=min(rows,key=lambda r:r['F'])
    actual=read(BASE/incumbent['trace'])['result']
    jobs=model['tasks']; n=len(jobs); m=model['vehicles']; horizon=2*ref['T']+2
    fractions=(Fraction(1,2*ref['T']),Fraction(3,10*round(n*ref['R'])),Fraction(1,5*ref['D']))
    scale=math.lcm(*(v.denominator for v in fractions))
    ai,bi,ci=[int(v*scale) for v in fractions]
    cp=cp_model.CpModel()
    p=[cp.new_int_var(j['release'],horizon,f'p{i}') for i,j in enumerate(jobs)]
    q=[cp.new_int_var(j['release'],horizon,f'q{i}') for i,j in enumerate(jobs)]
    end=[cp.new_int_var(j['release'],horizon,f'end{i}') for i,j in enumerate(jobs)]
    spans=[];ports=defaultdict(list);bays=defaultdict(list)
    fixed=lb['initial_fixed_slots'];slots=model['slots']
    for i,j in enumerate(jobs):
        ps,ds,loaded=lb['pickup_service_lb'][i],lb['drop_service_lb'][i],lb['loaded_per_job'][i]
        cp.add(q[i]>=p[i]+ps+loaded)
        cp.add(end[i]>=q[i]+ds)
        cp.add(end[i]>=p[i]+lb['processing_lb'][i])
        cp.add(end[i]>=lb['individual_completion_lb'][i])
        duration=cp.new_int_var(0,horizon,f'duration{i}')
        cp.add(duration==end[i]-p[i])
        spans.append(cp.new_interval_var(p[i],duration,end[i],f'job{i}'))
        port_start=p[i] if j['kind']=='delivery' else q[i]
        ports[tuple(j['port'])].append(cp.new_fixed_size_interval_var(port_start,1,f'port{i}'))
        if j['id'] in fixed:
            slot=slots[fixed[j['id']]]
            if j['kind']=='retrieval':
                bays[slot['bay']].append(cp.new_fixed_size_interval_var(p[i],ps,f'bay{i}'))
            else:bays[slot['bay']].append(cp.new_interval_var(p[i],duration,end[i],f'bay{i}'))
    cp.add_cumulative(spans,[1]*n,m)
    for intervals in list(ports.values())+list(bays.values()):cp.add_no_overlap(intervals)
    for i,j in enumerate(jobs):
        if j['id'] not in fixed:continue
        a=slots[fixed[j['id']]]
        for k,other in enumerate(jobs):
            if k==i or other['id'] not in fixed:continue
            b=slots[fixed[other['id']]]
            if a['bay']!=b['bay'] or j['kind']!=other['kind']:continue
            if j['kind']=='retrieval' and a['level']>b['level']:
                cp.add(p[k]>=p[i]+lb['pickup_service_lb'][i])
            elif j['kind']=='delivery' and a['level']<b['level']:
                cp.add(p[k]>=end[i])
    geometry=RelaxedGeometry(model['scene']);homes=model['scene'].homes[:m]
    pickup=lb['pickup_sets'];drop=lb['drop_sets']
    arcs=[];arc_vars={};distance_terms=[];before_end=[]
    def arc(a,b,cost):
        v=cp.new_bool_var(f'arc{a}_{b}');arcs.append((a,b,v));arc_vars[a,b]=v
        distance_terms.append(cost*v)
        if b:before_end.append(cost*v)
        return v
    for j in range(n):
        start=geometry.between(homes,pickup[j]);back=geometry.between(drop[j],homes)
        cp.add(p[j]>=start).only_enforce_if(arc(0,j+1,start))
        arc(j+1,0,back)
    for i in range(n):
        for j in range(n):
            if i==j:continue
            d=geometry.between(drop[i],pickup[j])
            cp.add(p[j]>=end[i]+d).only_enforce_if(arc(i+1,j+1,d))
    cp.add_multiple_circuit(arcs)
    cp.add(sum(arc_vars[0,j+1] for j in range(n))<=m)
    t=cp.new_int_var(lb['T'],horizon,'T');cp.add_max_equality(t,end)
    d=cp.new_int_var(lb['D'],5*ref['D']+1,'D')
    cp.add(d==sum(lb['loaded_per_job'])+sum(distance_terms))
    flow=sum(end[i]-j['release'] for i,j in enumerate(jobs))
    cp.add(flow>=math.ceil(lb['R']*n-1e-9))
    cp.add(sum(end[i]-p[i] for i in range(n))+sum(before_end)<=m*t)
    expression=ai*t+bi*flow+ci*d
    upper=Fraction(incumbent['T'],2*ref['T'])+Fraction(3*round(incumbent['R']*n),10*round(ref['R']*n))+Fraction(incumbent['D'],5*ref['D'])
    cp.add(expression<=int(upper*scale))
    cp.minimize(expression)
    by_id={j['id']:i for i,j in enumerate(jobs)}
    chosen=set();embedding_p={};embedding_q={};embedding_e={}
    for k in range(m):
        route=sorted((r for r in actual['records'] if r['vehicle']==k),key=lambda r:r['assigned_at'])
        if route:
            indices=[by_id[r['task']]+1 for r in route]
            chosen.update(zip([0]+indices,indices+[0]))
        for r in route:
            i=by_id[r['task']];embedding_p[i]=r['pickup_arrival'];embedding_q[i]=r['drop_arrival'];embedding_e[i]=r['end']
            cp.add_hint(p[i],embedding_p[i]);cp.add_hint(q[i],embedding_q[i]);cp.add_hint(end[i],embedding_e[i])
    for key,v in arc_vars.items():cp.add_hint(v,int(key in chosen))
    cp.add_hint(t,actual['T'])
    # Test a complete real incumbent embedding in a separate fixed model.
    check=cp.clone()
    for i in range(n):
        check.add(p[i]==embedding_p[i]);check.add(q[i]==embedding_q[i]);check.add(end[i]==embedding_e[i])
    for key,v in arc_vars.items():check.add(v==int(key in chosen))
    verifier=cp_model.CpSolver();verifier.parameters.max_time_in_seconds=15;verifier.parameters.num_search_workers=1
    status=verifier.solve(check)
    if status not in (cp_model.OPTIMAL,cp_model.FEASIBLE):raise ValueError('Real incumbent not embeddable: '+verifier.status_name(status))
    solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=seconds;solver.parameters.num_search_workers=1
    solver.parameters.random_seed=24;solver.parameters.log_search_progress=True
    logs=[];solver.log_callback=logs.append;solver.parameters.log_to_stdout=False
    status=solver.solve(cp)
    logpath=ROOT/'results'/(case['case']+'-cp.log');logpath.write_text(''.join(logs),encoding='utf-8')
    raw_bound=solver.best_objective_bound
    safe_bound=math.floor(raw_bound-max(1,abs(raw_bound)*1e-14))/scale
    bound=max(lb['F'] if 'F' in lb else sum(w*lb[k]/ref[k] for w,k in zip((.5,.3,.2),('T','R','D'))),safe_bound)
    if status in (cp_model.MODEL_INVALID,cp_model.INFEASIBLE):raise ValueError(solver.status_name(status))
    assert bound<=float(upper)+1e-8
    result=dict(case=case['case'],status=solver.status_name(status),seconds=solver.wall_time,solver_version=ortools.__version__,
                lower_bound=bound,best_real_incumbent=float(upper),incumbent_method=incumbent['method'],incumbent_router=incumbent['router'],incumbent_seed=incumbent['seed'],
                relative_gap_upper_bound_pct=100*(float(upper)/bound-1),raw_integer_bound=raw_bound,objective_scale=scale,
                real_incumbent_embedded=True,relaxations=['clairvoyant arrivals','no grid traffic conflicts','minimum incoming and loaded distances independently',
                    'one anonymous depot, free home assignment','initial or single-direction-SKU fixed slots only; other jobs relaxed',
                    'shelf lock begins at pickup service rather than dispatch','service durations minimum over relaxed slot choices'],
                source_sha256=sha(Path(__file__)),formal_reference={k:ref[k] for k in ('T','R','D')})
    if status in (cp_model.OPTIMAL,cp_model.FEASIBLE):
        result['best_relaxed_F']=solver.objective_value/scale
        result['selected_arcs']=[list(key) for key,v in arc_vars.items() if solver.value(v)]
        result['pickup_times']=[solver.value(v) for v in p]
    return result


def main():
    protocol=read(BASE/'data/simple-protocol.json');results=[]
    for case in protocol['cases']:
        if case['case'] not in protocol['validation']:continue
        value=solve(case);results.append(value)
        print(value['case'],value['status'],value['lower_bound'],value.get('best_relaxed_F'),flush=True)
        write(ROOT/'results/cp-bounds.json',results)


if __name__=='__main__':main()
