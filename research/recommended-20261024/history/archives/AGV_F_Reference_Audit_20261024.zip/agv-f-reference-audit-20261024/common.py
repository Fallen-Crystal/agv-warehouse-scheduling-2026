import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = ROOT / "baseline"
sys.path[:0] = [str(BASE), str(BASE / "src")]


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write(path, value):
    Path(path).write_text(
        json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def score(metrics, reference):
    return sum(
        w * metrics[k] / reference[k] for w, k in zip((0.5, 0.3, 0.2), ("T", "R", "D"))
    )
