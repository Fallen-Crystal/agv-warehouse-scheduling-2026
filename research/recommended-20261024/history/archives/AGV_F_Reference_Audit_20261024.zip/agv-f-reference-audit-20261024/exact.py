"""Global optimality only for the stated one-car, closed static outbound class."""

from fractions import Fraction
from functools import lru_cache
from math import lcm
from unittest.mock import patch

from common import BASE, ROOT, read, write
from wepa.data import build
from wepa.kernel import World
from wepa.search import owned_batch
from wepa.check import validate
from simple.runner import run
from agv.planning.astar import Router


def objective(result, reference):
    return (
        Fraction(result["T"], 2 * reference["T"])
        + Fraction(
            3 * sum(r["end"] for r in result["records"]),
            10 * sum(r["end"] for r in reference["records"]),
        )
        + Fraction(result["D"], 5 * reference["D"])
    )


def solve(model, reference):
    if (
        model["vehicles"] != 1
        or model["close_at"] != 0
        or any(j["release"] != 0 or j["kind"] != "retrieval" for j in model["tasks"])
    ):
        raise ValueError("Exact scope requires one car, static closed outbound only")
    w = World(model)
    w.publish_and_complete()
    jobs = model["tasks"]
    n = len(jobs)
    if len(w.bound) != n:
        raise ValueError("All static jobs must be initially bound")
    slots = [model["slots"][w.bound[j["id"]]] for j in jobs]
    router = Router(model["scene"])
    home = model["scene"].homes[0]
    ends = [tuple(j["port"]) for j in jobs] + [home]
    predecessors = []
    for i, s in enumerate(slots):
        if any(
            q["bay"] == s["bay"]
            and q["level"] > s["level"]
            and q["id"] in model["occupied"]
            and q["id"] not in set(w.bound.values())
            for q in model["slots"]
        ):
            raise ValueError("Unrequested upper stock prevents execution")
        predecessors.append(
            sum(
                1 << k
                for k, q in enumerate(slots)
                if q["bay"] == s["bay"] and q["level"] > s["level"]
            )
        )
    distances = {}
    for last, pos in enumerate(ends):
        for k, j in enumerate(jobs):
            distances[last, k] = int(
                min(
                    router.distance(pos, p, 0) + router.distance(p, tuple(j["port"]), 0)
                    for p in slots[k]["points"]
                )
            )
    back = [int(router.distance(p, home, 0)) for p in ends]
    a = Fraction(1, 2 * reference["T"])
    b = Fraction(3, 10 * sum(r["end"] for r in reference["records"]))
    c = Fraction(1, 5 * reference["D"])
    scale = lcm(a.denominator, b.denominator, c.denominator)
    ai, bi, ci = (int(x * scale) for x in (a, b, c))
    choices = {}

    @lru_cache(None)
    def dp(mask, last):
        if mask == (1 << n) - 1:
            return ci * back[last]
        options = []
        for k, j in enumerate(jobs):
            if mask >> k & 1 or predecessors[k] & mask != predecessors[k]:
                continue
            d = distances[last, k]
            duration = d + 2 * slots[k]["level"] + 1
            options.append(
                (
                    (ai + bi * (n - mask.bit_count())) * duration
                    + ci * d
                    + dp(mask | 1 << k, k),
                    j["id"],
                    k,
                )
            )
        if not options:
            raise ValueError("No feasible exact continuation")
        best = min(options)
        choices[mask, last] = best[2]
        return best[0]

    numerator = dp(0, n)
    mask, last, order = 0, n, []
    while mask != (1 << n) - 1:
        k = choices[mask, last]
        order.append(jobs[k]["id"])
        mask, last = mask | 1 << k, k
    # Independent direct evaluation of every legal permutation for n<=8.
    enumerated = 0
    brute = None
    if n <= 8:

        def visit(mask, last, t, completion_sum, distance):
            nonlocal brute, enumerated
            if mask == (1 << n) - 1:
                value = ai * t + bi * completion_sum + ci * (distance + back[last])
                brute = value if brute is None else min(brute, value)
                enumerated += 1
                return
            for k in range(n):
                if mask >> k & 1 or predecessors[k] & mask != predecessors[k]:
                    continue
                d = distances[last, k]
                end = t + d + 2 * slots[k]["level"] + 1
                visit(mask | 1 << k, k, end, completion_sum + end, distance + d)

        visit(0, n, 0, 0, 0)
        assert brute == numerator
    return dict(
        order=order,
        F=float(Fraction(numerator, scale)),
        numerator=numerator,
        denominator=scale,
        states=dp.cache_info().currsize,
        legal_permutations_crosschecked=enumerated,
        global_scope="one-car closed static outbound, original map/WMS/layer/service/terminal/final-return rules",
    )


class FixedPolicy:
    def __init__(self, order):
        self.order, self.logs = order, []

    def action(self, world):
        return owned_batch(world, self.order, {j: 0 for j in self.order})


def main():
    p = read(BASE / "data/simple-protocol.json")
    all_results = []
    trace_folder = ROOT / "results/exact-traces"
    trace_folder.mkdir(exist_ok=False)
    for original in p["cases"]:
        if original["case"] not in p["validation"]:
            continue
        batch = None
        for j in original["tasks"]:
            if j["kind"] == "retrieval":
                group = [
                    q
                    for q in original["tasks"]
                    if q["kind"] == "retrieval"
                    and (q["release"], q["batch"], q["week"])
                    == (j["release"], j["batch"], j["week"])
                ]
                if len(group) == 33:
                    batch = group
                    break
        if batch is None:
            raise ValueError("Predeclared batch missing")
        for n in (4, 8, 12):
            case = dict(
                original,
                case=original["case"] + f"-static-onecar-{n}",
                close_at=0,
                tasks=[dict(j, release=0) for j in batch[:n]],
            )
            model = build(case, vehicles=1)
            ref = run(model, "fcfs")
            validate(model, ref)
            exact = solve(model, ref)
            with patch(
                "simple.runner.SimplePolicy", return_value=FixedPolicy(exact["order"])
            ):
                optimal = run(model, "simple_ga")
            optimal["method"] = "exact_dp"
            validate(model, optimal)
            assert objective(optimal, ref) == Fraction(
                exact["numerator"], exact["denominator"]
            )
            rows = []
            for method in ("fcfs", "eta", "simple_ga", "soft_ga", "adaptive_ga"):
                r = ref if method == "fcfs" else run(model, method, seed=0)
                audit = validate(model, r)
                value = objective(r, ref)
                assert value >= Fraction(exact["numerator"], exact["denominator"])
                row = dict(
                    method=method,
                    F=float(value),
                    gap_to_proven_optimum_pct=100 * (float(value) / exact["F"] - 1),
                    T=r["T"],
                    R=r["R"],
                    D=r["D"],
                )
                rows.append(row)
                write(
                    trace_folder / (case["case"] + "-" + method + ".json"),
                    dict(case=case, row=row, result=r, audit=audit),
                )
            write(
                trace_folder / (case["case"] + "-exact.json"),
                dict(
                    case=case,
                    proof=exact,
                    result=optimal,
                    audit=validate(model, optimal),
                ),
            )
            record = dict(
                case=case["case"],
                origin=original["case"],
                source_rows=[j["source_row"] for j in case["tasks"]],
                tasks=n,
                source_batch_size=33,
                source_subset=True,
                release_shift=batch[0]["release"],
                fleet_changed_from=6,
                exact=exact,
                results=rows,
            )
            all_results.append(record)
            print(
                case["case"],
                exact["F"],
                [(x["method"], round(x["gap_to_proven_optimum_pct"], 3)) for x in rows],
                flush=True,
            )
    write(ROOT / "results/exact.json", all_results)


if __name__ == "__main__":
    main()
