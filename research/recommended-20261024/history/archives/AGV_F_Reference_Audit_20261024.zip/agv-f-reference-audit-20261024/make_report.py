from statistics import mean
from common import ROOT, read, write


def main():
    bounds = read(ROOT / "results/cp-bounds.json")
    exact = read(ROOT / "results/exact.json")
    probes = read(ROOT / "results/probes.json")
    locks = read(ROOT / "results/lock-diagnostics.json")
    offline = read(ROOT / "results/offline.json")
    source = read(ROOT / "results/source-audit.json")
    assert len(bounds) == len(probes) == len(offline) == 3 and len(exact) == 9
    lbtable = [
        "|原完整窗口|有效下界L|目前最好真实可行值U|L与U间距尚未证明消除|",
        "|---|---:|---:|---|",
    ]
    for row in bounds:
        lbtable.append(
            f"|{row['case']}|{row['lower_bound']:.6f}|{row['best_real_incumbent']:.6f}|求解器状态{row['status']}，未证明最优|"
        )
    small = [
        "|来源日期|缩减订单数|同子问题FCFS F|可证明最优F|简化/软分区/旧GA最优差距|",
        "|---|---:|---:|---:|---|",
    ]
    for row in exact:
        ga = [
            r
            for r in row["results"]
            if r["method"] in ("simple_ga", "soft_ga", "adaptive_ga")
        ]
        small.append(
            f"|{row['origin']}|{row['tasks']}|1|{row['exact']['F']:.6f}|"
            + "/".join(f"{r['gap_to_proven_optimum_pct']:.3f}%" for r in ga)
            + "|"
        )
    pt = [
        "|原窗口|探针时刻|待分配任务|抽检完整方案|最好方案的代理排名|前两名限额漏掉的可见预测改善|代理与实际排序逆序率|",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for p in probes:
        pt.append(
            f"|{p['case']}|{p['time']}|{p['pending']}|{len(p['candidates'])}|{p['best_sampled_proxy_rank']}|"
            f"{p['missed_visible_improvement_pct']:.4f}%|{100 * p['discordance_rate']:.2f}%|"
        )
    lt = [
        "|原窗口|出库锁累计步数|其中前往取货等非装卸占比|入库锁累计步数|其中非货架装卸占比|",
        "|---|---:|---:|---:|---:|",
    ]
    for r in locks:
        a, b = r["bay_lock"]["retrieval"], r["bay_lock"]["delivery"]
        lt.append(
            f"|{r['case']}|{a['summed_bay_lock_steps']}|{100 * a['non_service_share']:.1f}%|"
            f"{b['summed_bay_lock_steps']}|{100 * b['non_service_share']:.1f}%|"
        )
    ot = [
        "|窗口|松弛模型已找到的成本|原规则SIPP解码后真实F|是否优于原最好可行方案|",
        "|---|---:|---:|---|",
    ]
    for r in offline:
        cp = next(c for c in bounds if c["case"] == r["case"])
        ot.append(
            f"|{r['case']}|{cp['best_relaxed_F']:.6f}|{r['F']:.6f}|{'是' if r['F'] < r['compared_to_best_existing'] else '否'}|"
        )
    report = f"""# F参照、真实数据与改进空间核查

## 已确定的结论

1. 当前输入是**真实托盘请求驱动、布局和作业参数按课程模型设定的仿真**。源请求的时间是到达时间，不是运输时长或完成时间。所用公开原始文件没有逐车实际轨迹、逐单实测完成时刻和空载/载货实际里程，不能据此算出一个与本模型公平可比的“原厂F”。
2. **F=0.94不能单独判好坏。** 九个缩减静态单车子问题的可证明最优F为{min(r["exact"]["F"] for r in exact):.6f}～{max(r["exact"]["F"] for r in exact):.6f}，三种GA均达到各自最优。对于这些子问题，要求0.8会超出可达范围。这不证明原6车动态场景也已接近最优。
3. 原完整动态窗口已经有有效下界，但**尚未证明全局最优值，也未证明现有方案接近最优**。第66日窗口下界超过0.8，因此0.80在该窗口不可达；另外两例的界还较松。
4. 候选排序与完整试排存在可观测差异，前两名限额在一个预定探针点漏掉约0.68%的可见预测改善。货架锁还覆盖了大量非装卸时段，需要复核其业务含义。这两项有具体证据，但本轮没有完成分别改变它们的因果消融，不能断言哪项是主要原因。

## 真实数据到底提供什么

作者说明及本地原文件核对：WEPA提供原仓库网格图、初始SKU库存数量、订单流。订单六字段是类别、SKU、到达秒数、码头、批次、周次，共{source["orders"]}条，全部记录均为六字段。原场景是堆垛仓，原布局/层数/出入口与本模型不同。[作者固定版本数据说明](https://raw.githubusercontent.com/malerinc/slapstack/da6280a8f8be1010eae64264c69a90258a288173/README.md)。

|信息|当前原始文件是否提供|能否直接作为本模型的最优参照|
|---|---|---|
|订单到达时间、类别、SKU、批次、码头|提供，有作者字段说明|用于驱动需求；不是执行绩效|
|原仓库布局、初始各SKU数量|提供|布局不同；数量字典也不是逐货位库存位置|
|逐车执行轨迹、真实完成时刻、真实取送/空驶里程|所用原始文件没有|不能直接计算原厂T/R/D及同口径F|
|本项目车速、5层作业时间、货位、停车、终端规则|课程模型设定|应保持各对照一致，后续可用额外观测校准|

从原图可以计算某种最短网格距离，但缺少每单实际货位、路线和车辆执行状态，它不等于原厂实测里程。即便以后获得原厂绩效记录，历史调度也未必最优；它用于比较实际业务收益，不能代替最优值证明。

窗口初始库存由源请求前缀台账推算，假设此前请求均完成，不是该时刻原厂现场WIP/库存位置的测量。所有图与时间映射、选定SKU、固定6车和最终返库约定，应在报告中明确。

## 正确的三个参照

|参照|回答的问题|目前情况|
|---|---|---|
|实测历史方案|是否优于实际业务运行|缺少所需执行日志，不能比较|
|同条件基准算法|相对简单规则改善多少|已有同图、同任务、同规则的FCFS/ETA对照|
|同条件精确最优/有效下界|距离最好可能值还有多少|小子问题有精确最优；大场景只有界，未闭合|

所有F沿用`0.5T/T_ref+0.3R/R_ref+0.2D/D_ref`，同一实例以原FCFS+SIPP为分母。没有为得到更低数值调整权重或更换基准。不同实例各自的分母不同，所以小问题和大问题的F不能直接当成同一个目标阈值。

## 原大场景的最优区间

{chr(10).join(lbtable)}

每一行满足`L ≤ F*_offline ≤ U`。U是本例所有已执行方案/种子的最好可行值，是逐例的求解上界，不是一种固定算法在验证集的平均成绩。L使用放松条件以及全部未来订单信息，通常无法直接实现。**不能说算法一定能降到L，也不能把(U-L)全解释成算法可消除的损失。**

三个窗口平均下界约{mean(r["lower_bound"] for r in bounds):.6f}，逐例最好可行值的平均约{mean(r["best_real_incumbent"] for r in bounds):.6f}。这是仍然较宽的区间，不足以判定完整场景的理想F。三例CP-SAT各单线程限时120秒，状态均非最优证书；求解器的松弛可行成本没有冒充下界。

## 小规模可证明最优参照

取原三个日期首个33托盘出库批次的前4/8/12单，保留SKU、码头、初始库存和原地图货位映射，变成1车、静态、发布时间0、关闭0的控制子问题。这会缩减批次，不称作完整真实批次。每例以自己的FCFS参照归一化。

{chr(10).join(small)}

Held-Karp式动态规划覆盖所有合法顺序，保持原货架层序、装卸时间、终端、最短合法网格路和最终返库。4/8单再由完整合法顺序穷举校对。最优路径回放与三种GA、FCFS、ETA共54份新轨迹均独立验解；9例精确F与原执行的有理数成本完全相等。结论仅适用于所定义的单车静态出库子问题。

## 为什么高级算法可能降不动：已有的诊断证据

### 候选排序与试排限额

三个探针均在预先规定的首个“待分配至少6单且有空车”的时刻，原策略此前的动作与正式记录一致。各抽检16个既有GA候选（前8、中间4、末尾4），未提交这些探针方案。

{chr(10).join(pt)}

逆序率是在被抽检且完成的候选对中、排除评分并列后，代理排序与实际试排排序相反的比例。第69日更好的可见方案落在代理第3名，而正式每轮只允许初始方案加至多两个候选试排。这个局部事实支持改进候选评价/筛选，不保证整段动态订单流F也会相应下降。

### 货架格被提前锁住

当前内核出库锁从`assigned_at`到`pickup_end`，入库锁从`assigned_at`到`end`。因此同格后续层的任务在前一辆车还在前往取货/送货时也可能无法派出。它比仅要求“实际装卸不能同时发生”更保守。

{chr(10).join(lt)}

以上为各订单锁占用的累计构成，不是系统墙钟时间，也不是可直接省掉的延误。库存预订、行驶碰撞和层序依然需要遵守。该项应单独复核原业务规则，不能把放宽模型后的改善算成原模型纯算法收益。本轮原锁规则完全保留。

### 低估成本的路线不能直接当真实效果

CP松弛得到的顺序/分车另用原库存、原货架锁和SIPP作一次真实解码。它已知未来，仍不是线上调度器；实际解码会改变时间及部分安排。

{chr(10).join(ot)}

这3个负面结果保留：它们说明松弛成本和落地执行成本之间有明显差异，不能将低估的路程矩阵成本直接作为实验效果，也不能据此说CP-SAT不适用。这里的CP模型本来只用于求下界，不是完整物理规划器。

## 后续顺序

1. 保留现有真实订单输入，正确表述空间和服务时间的模型映射。
2. 优先统一候选预测与真实执行口径，测试自适应试排或更准确代理；不要先盲目增加GA代数、蚂蚁数或换权重。
3. 把“只限制同时装卸”与“派单后整个过程锁定”作为独立规则复核；需要验证可提前安排路径但仍禁止同时取同格不同层的方案。修改后必须建立新模型版本、独立验解和配对实验。
4. 继续用有界求解参照逐步缩小大场景的U-L。不能以目前0.94认定已经最优，也不能以一个宽松下界承诺0.8。

完整证明范围见[下界与精确参照的证明范围](下界与精确参照的证明范围.md)。CP-SAT状态含义参见[官方文档](https://developers.google.com/optimization/cp/cp_solver)；`FEASIBLE`只表示找到可行方案。

所有原始JSON、下界、精确分数、探针、负例和求解日志位于`results/`。诊断首次运行中的Python元组/JSON列表比较差异已规范化，首次失败日志仍保留；没有因此更换探针点、候选或算法。
"""
    (ROOT / "docs/F参照与优化空间核查.md").write_text(report, encoding="utf-8")
    write(
        ROOT / "results/summary.json",
        dict(
            source_orders=source["orders"],
            exact_cases=len(exact),
            exact_min_F=min(r["exact"]["F"] for r in exact),
            exact_max_F=max(r["exact"]["F"] for r in exact),
            all_three_GA_exact_on_small_cases=True,
            original_full_optimum_proven=False,
            average_full_lower_bound=mean(r["lower_bound"] for r in bounds),
            average_best_known_feasible=mean(r["best_real_incumbent"] for r in bounds),
            lower_bound_cases=[
                dict(case=r["case"], L=r["lower_bound"], U=r["best_real_incumbent"])
                for r in bounds
            ],
            original_plant_F_available=False,
            offline_negative_results_retained=len(offline),
        ),
    )
    print("Report and summary written")


if __name__ == "__main__":
    main()
