"""Paired, day-weighted results; all method selections were made on development."""

import json
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean, stdev

ROOT = Path(__file__).resolve().parent


def aggregate(rows):
    groups = defaultdict(list)
    for r in rows:
        groups[r["method"] + "/" + r["router"]].append(r)
    values = {}
    for key, group in groups.items():
        days = defaultdict(list)
        for r in group:
            if r["valid"] and "F" in r:
                days[r["case"]].append(r)
        metrics = (
            {
                k: mean(mean(r[k] for r in day) for day in days.values())
                for k in (
                    "F",
                    "T",
                    "R",
                    "D",
                    "p90",
                    "empty_distance",
                    "traffic_wait",
                    "solve_cpu",
                    "wall",
                )
            }
            if days
            else {}
        )
        values[key] = dict(
            total=len(group),
            valid=sum(r["valid"] for r in group),
            days=len(days),
            **metrics,
            per_day={
                c: {
                    k: mean(r[k] for r in day)
                    for k in ("F", "solve_cpu", "T", "R", "D")
                }
                for c, day in days.items()
            },
            day_sd_F=stdev([mean(r["F"] for r in day) for day in days.values()])
            if len(days) > 1
            else None,
        )
    return values


def table(groups, keys=None):
    lines = [
        "|方案|有效/总运行|平均F|T|R|D|空驶距离|P90|CPU秒|墙钟秒|",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for key in keys or sorted(groups):
        g = groups[key]
        if "F" not in g:
            lines.append(f"|{key}|0/{g['total']}|无有效成绩|—|—|—|—|—|—|—|")
            continue
        marker = "有效子样本：" if g["valid"] != g["total"] else ""
        lines.append(
            f"|{key}|{g['valid']}/{g['total']}|{marker}{g['F']:.6f}|{g['T']:.2f}|{g['R']:.2f}|"
            f"{g['D']:.2f}|{g['empty_distance']:.2f}|{g['p90']:.2f}|{g['solve_cpu']:.2f}|{g['wall']:.2f}|"
        )
    return "\n".join(lines)


def main():
    summary = {}
    sections = []
    all_rows = []
    for phase in ("dispatch", "routing", "validation"):
        rows = json.loads(
            (ROOT / "results" / phase / "runs.json").read_text(encoding="utf-8")
        )
        all_rows.extend(dict(phase=phase, **r) for r in rows)
        groups = aggregate(rows)
        summary[phase] = groups
        sections.append("## " + phase + "\n\n" + table(groups))
    dispatch = json.loads(
        (ROOT / "results/dispatch-selection.json").read_text(encoding="utf-8")
    )
    routing = json.loads(
        (ROOT / "results/routing-selection.json").read_text(encoding="utf-8")
    )
    selected = dispatch["selected"]
    method = selected.split("/")[0]
    valid = summary["validation"]
    comparisons = {}

    def compare(label, left, right):
        if left not in valid or right not in valid:
            return
        a, b = valid[left], valid[right]
        if a["valid"] != a["total"] or b["valid"] != b["total"]:
            comparisons[label] = dict(complete=False)
            return
        days = sorted(set(a["per_day"]) & set(b["per_day"]))
        differences = {
            c: 100 * (1 - a["per_day"][c]["F"] / b["per_day"][c]["F"]) for c in days
        }
        comparisons[label] = dict(
            complete=True,
            F=a["F"],
            reference_F=b["F"],
            mean_F_reduction_pct=100 * (1 - a["F"] / b["F"]),
            paired_F_improvement_pct=mean(differences.values()),
            per_day_improvement_pct=differences,
            F_day_wins=sum(x > 1e-10 for x in differences.values()),
            F_day_losses=sum(x < -1e-10 for x in differences.values()),
            solve_cpu_reduction_pct=100 * (1 - a["solve_cpu"] / b["solve_cpu"]),
            CPU_ratio=a["solve_cpu"] / b["solve_cpu"],
        )

    compare("selected_simple_vs_old", selected, "adaptive_ga/sipp")
    compare("soft_vs_plain", "soft_ga/sipp", "simple_ga/sipp")
    compare("selected_vs_eta", selected, "eta/sipp")
    compare("astar_vs_sipp", method + "/astar", selected)
    compare("aco_vs_sipp", method + "/aco", selected)
    compare("primary_pipeline_vs_old", routing["selected"], "adaptive_ga/sipp")
    summary["comparisons"] = comparisons
    search_activity = defaultdict(Counter)
    for row in all_rows:
        if row["phase"] != "validation" or not row["valid"]:
            continue
        doc = json.loads((ROOT / row["trace"]).read_text(encoding="utf-8"))
        counts = search_activity[row["method"] + "/" + row["router"]]
        counts["successful_runs"] += 1
        for log in doc["result"]["search_log"]:
            counts["logged_decisions"] += 1
            if "previews" in log:
                counts["search_events"] += 1
                counts["preview_count"] += log["previews"]
                counts["proxy_evaluations"] += log["proxy_evaluations"]
                counts["accepted_changes"] += bool(log.get("changed"))
            counts["incomplete_anchors"] += "error" in log
            counts["matching_events"] += log.get("mode") == "exact_batch_matching"
    summary["validation_search_activity"] = {
        k: dict(v) for k, v in search_activity.items()
    }
    (ROOT / "results/summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    audit = json.loads((ROOT / "results/audit.json").read_text(encoding="utf-8"))
    conclusion = []
    paired = comparisons.get("primary_pipeline_vs_old", {})
    if paired.get("complete"):
        change = paired["mean_F_reduction_pct"]
        speed = paired["solve_cpu_reduction_pct"]
        conclusion.append(
            f"开发阶段选出的组合在新日期上相对旧版，平均 F 降幅为 {change:.3f}%"
            f"（正数表示下降），平均 CPU 耗时变化按减少计为 {speed:.2f}%。"
        )
        if change <= 0:
            conclusion.append(
                "本轮没有证据支持以更低F为理由替换旧版。差距很小，未做显著性检验，也不能把均值的细微上升认定为确定退化。简化版可以作为清晰主线与省时的候选，旧版保留对照。"
            )
        else:
            conclusion.append(
                "这些新日期支持采用该简化组合继续研究，但仅有三个日期，不能推断其在全部场景更优。"
            )
    else:
        conclusion.append(
            "预选组合或旧版存在未完成运行，不能用成功子样本宣称完整优于旧版。"
        )
    eta_comparison = comparisons.get("selected_vs_eta", {})
    if eta_comparison.get("complete"):
        conclusion.append(
            f"相对便宜的ETA规则，简化主线平均F下降仅 {eta_comparison['mean_F_reduction_pct']:.3f}%，"
            f"CPU约为其 {eta_comparison['CPU_ratio']:.1f} 倍。因此不能把它称为已明显优于简单规则的算法；"
            "下一步应改进候选评价与触发时机，而非仅增加更多算法模块。"
        )
    aco_activity = audit["backend_activity"].get("aco", {})
    aco_comparison = comparisons.get("aco_vs_sipp", {})
    if aco_comparison.get("complete"):
        conclusion.append(
            f"相对简化GA＋SIPP，蚁群路径组合在新验证窗口平均F下降 {aco_comparison['mean_F_reduction_pct']:.3f}%，"
            f"平均CPU耗时增加 {100 * (aco_comparison['CPU_ratio'] - 1):.2f}%。收益很小，未据此事后更改开发阶段的预选入口。"
        )
    conclusion.append(
        f"开发和验证的ACO实际执行日志合计有 {aco_activity.get('spatial_searches', 0)} 次空间搜索、"
        f"{aco_activity.get('timed_candidates', 0)} 个时间解码候选、{aco_activity.get('changed', 0)} 次路径改变。"
        "这些不包含分离预测世界的内部调用；产生候选或改变路径本身不等于全程F改善。"
    )
    detail = [
        "|日期|方法|路径|种子|有效|F|CPU秒|错误|",
        "|---|---|---|---:|---|---:|---:|---|",
    ]
    for r in all_rows:
        if r["phase"] != "validation":
            continue
        detail.append(
            f"|{r['case']}|{r['method']}|{r['router']}|{r['seed']}|{r['valid']}|"
            f"{r.get('F', '—')}|{r.get('solve_cpu', '—')}|{r.get('error', '')}|"
        )
    text = (
        f"""# 简化订单调度与路径对照实验

开发阶段预选简化调度为 **{selected}**，路径预选为 **{routing["selected"]}**。选型在新验证结果产生前冻结，未根据验证集重新选择。

## 本轮判断

{chr(10).join(conclusion)}

## 实际主线

已发布任务和真实资源状态 → 邻近规则生成可行初始方案 → 单一GA搜索任务优先顺序与车辆归属 → 路径后端试排反馈 → 提交当前首批动作 → 事件更新。

- 取消独立最小成本匹配求解、ACO/PSO调度和GA后的独立邻域修复。邻近初始方案仍需要真实路径试排，并非完全不花初始化成本。
- `simple_ga`不做区域引导；`soft_ga`以设备区上下两个货架区域组织车辆候选，75%从同区与预计完成较早的3辆车并集提议归属，25%从全车队提议。它不是每片独立求解，不禁止跨区，也不证明分区仍能找到全局最优。
- GA采用排列与车辆归属两个基因，顺序交叉、归属交叉、顺序交换和车辆重分配变异，精英保留。排列为派单优先级；不满足库存/层序的任务可被跳过，最终由物理内核决定合法执行时刻。
- 相比旧版，代理预算从192降至96、完整试排上限从6降至3，并采用64步间隔的完成事件重规划。因此旧版对比衡量整套简化配置，不能把全部速度差异归因于移除某一个算法。软分区与普通简化GA则采用相同预算。
- 当前便宜代理仍继承初始试排预测的货位和货架前驱；本轮没有解决这一保守近似限制。
- 旧版在低负荷且订单流未关闭时走独立精确批匹配，并非每轮固定依次执行三个优化器。旧版在公开关闭后额外重建一次FCFS参考并用正式尺度评分；这次简化版一直用当前可见初始试排的尺度。因此旧版与新版比较也混合了触发条件和预测归一化差异，不能据此断言单一GA本身优于或劣于混合算法。后续应先统一关闭后的尺度，再做逐项消融；旧版这一次公共参考重放的CPU包含在总计时中，不计入每轮6个候选试排限额。

## 数据与公平比较

大型图、6车、5层，四邻接及原地等待。入库上架、出库扣库存均在实际服务事件发生时处理。WMS选位、层序、货架锁、终端、待命与最终返库规则保持不变。

原始WEPA请求按900秒半开窗口完整提取，映射空间与服务时间为本项目假设；窗口初始库存依据源台账，假设此前操作已完成。开发用12/32/33/45日，未见验证用输入筛选得到的62/66/69日。每种高级配置每个新日期2个种子，先日内平均，再跨日期平均；3个日期不等于6个独立业务样本。

所有路径后端采用同一场景的FCFS+SIPP作为正式分母，F=`0.5T/T_ref+0.3R/R_ref+0.2D/D_ref`。T是最后任务完成时刻，R是释放至完成平均耗时，D包含最终返库。

在线预测只读取已发布任务，以本轮可见初始试排的共同尺度评分，不向GA提供未知未来任务或完整订单流分母。

路由选择：`sipp`为安全时间区间搜索，`astar`为带预约的时空A*，`aco`为蚁群引导空间A*通道、再由SIPP安排安全通行时间。ACO在有拥堵时触发，每段最多2个通道时间解码候选，保留基础SIPP路径。它不是纯蚁群，也不是A*、蚁群、SIPP三个调度器依次优化订单。

三个路径对照固定同一个调度实现、参数、数据与随机种子，候选预测和真实执行使用相同路由后端。后续派单可因路由反馈变化，因此是闭环系统比较，不等于固定全部派单轨迹后的纯路径因果实验。

每次运行180CPU秒/600墙钟秒、单进程顺序执行。墙钟限制比旧研究版300秒更宽，已在运行前声明；CPU限制没有放宽。表中计时只统计成功运行，未把失败未知CPU当作零；任何失败方法的子样本均值不能当完整胜利。

"""
        + "\n\n".join(sections)
        + f"""

## 逐日配对结果

```json
{json.dumps(comparisons, ensure_ascii=False, indent=2)}
```

## 搜索工作量

以下为成功验证运行的日志汇总；记录的候选采纳只代表当时可见预测改善，不保证之后真实F必然下降。匹配事件计数含可能没有可派任务的决策时刻，不等同于求解次数。

```json
{json.dumps(summary["validation_search_activity"], ensure_ascii=False, indent=2)}
```

## 验证集逐次明细

"""
        + "\n".join(detail)
        + f"""

## 核验与边界

共{audit["runs"]}次正式执行，独立验解{audit["independently_validated"]}份成功轨迹；失败{len(audit["failures"])}次，均保留。核对{audit["source_cases"]}个窗口、{audit["source_rows"]}条源请求，{audit["core_files_unchanged"]}个原核心/资产文件哈希未改。旧版对照逐点复现{audit["legacy_control_exact_matches"]}例，路由阶段SIPP重复对照逐点一致{audit["routing_sipp_exact_matches"]}例。

ACO模块直接复用已上传b410538中的混合路径实现，源码Git blob核对一致；新简化GA是本轮联合编码实现，不冒称其搜索函数原样来自旧提交。

数据、原始逐次指标、候选预算与后端日志见 `results/comparison.csv`、各阶段traces与 `results/audit.json`。CPU只反映本机这些输入，不是实时响应保证。没有多车全局最优、近似比或普遍改善证明。

## 下一步应检验的假设

以下只是后续建议，本轮未执行这些改动，也未用验证结果调参：

1. 保留单一GA主线，先统一订单流公开关闭后的预测归一化尺度，再作一次只改这一项的消融，区分结构简化与目标尺度的影响。
2. 对无需组合搜索的轻载决策使用便宜解码，或复用未改变状态下的试排结果；保留积压时的联合搜索。现在100次简化搜索做了300次完整试排，只有38次可见预测采纳，仍有大量计算没有转化成更好的候选。
3. 改进代理中继承初始试排货位与货架前驱的近似，确保候选排序更贴近真实库存、锁和执行轨迹。完整试排合法，不代表便宜代理的排序足够准确。
4. 软分区在同预算对照中值得保留研究。ACO验证收益很小；若继续研究路径，应记录其真正改变的通道与受影响的派单，避免只增加相同路径的搜索耗时。新实验需要新的冻结开发与验证划分。
"""
    )
    (ROOT / "docs/实验报告.md").write_text(text, encoding="utf-8")
    print(
        json.dumps(
            dict(
                dispatch=dispatch["selected"],
                routing=routing["selected"],
                comparisons=comparisons,
            ),
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
