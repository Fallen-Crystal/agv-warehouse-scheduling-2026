"""Replay the frozen primary pipeline from a clean copy and unrelated cwd."""

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    target = ROOT.parent / "agv-simple-clean-replay-20261024"
    if target.exists():
        raise FileExistsError("Keep prior replay evidence")
    target.mkdir()
    for folder in ("src", "wepa", "adaptive", "simple", "data"):
        shutil.copytree(
            ROOT / folder,
            target / folder,
            ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
        )
    for filename in ("run_main.py", "run_simple.py"):
        shutil.copy2(ROOT / filename, target / filename)
    (target / "results").mkdir()
    shutil.copy2(
        ROOT / "results/routing-selection.json",
        target / "results/routing-selection.json",
    )
    protocol = json.loads(
        (ROOT / "data/simple-protocol.json").read_text(encoding="utf-8")
    )
    selected = json.loads(
        (ROOT / "results/routing-selection.json").read_text(encoding="utf-8")
    )["selected"]
    case = protocol["validation"][0]
    method, router = selected.split("/")
    rows = json.loads(
        (ROOT / "results/validation/runs.json").read_text(encoding="utf-8")
    )
    row = next(
        r
        for r in rows
        if (r["case"], r["method"], r["router"], r["seed"]) == (case, method, router, 0)
    )
    assert row["valid"]
    expected = json.loads((ROOT / row["trace"]).read_text(encoding="utf-8"))
    result_path = target / "replay.json"
    env = {k: v for k, v in os.environ.items() if k != "PYTHONPATH"}
    env["PYTHONUTF8"] = "1"
    command = [
        sys.executable,
        str(target / "run_main.py"),
        "--case",
        case,
        "--seed",
        "0",
        "--output",
        str(result_path),
    ]
    completed = subprocess.run(
        command,
        cwd=ROOT.parent.parent,
        env=env,
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=600,
    )
    (ROOT / "results/clean-replay.log").write_text(
        completed.stdout + completed.stderr, encoding="utf-8"
    )
    assert completed.returncode == 0, completed.stderr
    actual = json.loads(result_path.read_text(encoding="utf-8"))
    keys = ("paths", "records", "T", "R", "D", "final_stock", "decisions")
    assert actual["row"]["valid"] and actual["audit"]["valid"]
    assert all(actual["result"][key] == expected["result"][key] for key in keys)
    receipt = dict(
        case=case,
        selected=selected,
        seed=0,
        exact_match=True,
        matched_fields=list(keys),
        independent_valid=True,
        cwd=str(ROOT.parent.parent),
        clean_directory=str(target),
        inherited_pythonpath=False,
    )
    (ROOT / "results/clean-replay.json").write_text(
        json.dumps(receipt, indent=2), encoding="utf-8"
    )
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
