"""Revalidate every successful trajectory, backend, source row and frozen choice."""

import csv
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT), str(ROOT / "src")]
from study import hashes, sha  # noqa: E402
from wepa.data import build  # noqa: E402
from wepa.check import validate  # noqa: E402


def main():
    protocol = json.loads(
        (ROOT / "data/simple-protocol.json").read_text(encoding="utf-8")
    )
    source = hashes()
    digest = sha(ROOT / "data/simple-protocol.json")
    cases = {c["case"]: c for c in protocol["cases"]}
    raw = json.loads((ROOT / "data/raw/2_orders.json").read_text(encoding="utf-8"))
    assert sha(ROOT / "data/raw/2_orders.json") == protocol["source_sha256"]
    ledger = Counter(
        {
            int(k): v
            for k, v in json.loads(
                (ROOT / "data/raw/3_initial_fill_lvl.json").read_text(encoding="utf-8")
            ).items()
        }
    )
    outbound = Counter((r[4], r[5]) for r in raw if r[0] == "retrieval")
    cursor = source_rows = 0
    for c in sorted(cases.values(), key=lambda c: c["start_seconds"]):
        while cursor < len(raw) and raw[cursor][2] < c["start_seconds"]:
            r = raw[cursor]
            ledger[r[1]] += 1 if r[0] == "delivery" else -1
            cursor += 1
        assert all(ledger[int(k)] == v for k, v in c["initial"].items())
        expected = [
            i
            for i in range(cursor, len(raw))
            if c["start_seconds"] <= raw[i][2] < c["end_seconds"]
        ]
        assert expected == [j["source_row"] for j in c["tasks"]]
        batches = Counter(
            (j["batch"], j["week"]) for j in c["tasks"] if j["kind"] == "retrieval"
        )
        assert all(outbound[k] == v for k, v in batches.items())
        for j in c["tasks"]:
            assert tuple(raw[j["source_row"]]) == tuple(
                j[k]
                for k in ("kind", "sku", "source_time", "source_dock", "batch", "week")
            )
            assert j["release"] == j["source_time"] - c["start_seconds"]
        source_rows += len(c["tasks"])
    manifest = json.loads(
        (ROOT / "data/core-source-manifest.json").read_text(encoding="utf-8")
    )
    manifest = manifest.get("files", manifest)
    core = 0
    for name, expected in manifest.items():
        if not isinstance(expected, str):
            continue
        path = ROOT / name
        if not path.exists():
            path = ROOT / "src" / name
        assert path.exists() and sha(path) == expected, name
        core += 1
    prior = ROOT / "data/prior-mixed-contract"
    assert sha(ROOT / "wepa/data.py") == sha(prior / "data.py.txt")
    assert sha(ROOT / "wepa/check.py") == sha(prior / "check.py.txt")
    # Archived kernel predates forecast hooks, so compare the physical AST nodes.
    import ast

    def physical(path):
        return {
            n.name: ast.dump(n, include_attributes=False)
            for n in ast.parse(path.read_text(encoding="utf-8")).body
            if isinstance(n, (ast.ClassDef, ast.FunctionDef))
            and n.name in ("World", "batch", "decide")
        }

    assert physical(ROOT / "wepa/kernel.py") == physical(prior / "kernel.py.txt")
    old_choice = json.loads(
        (ROOT / "data/prior-adaptive-selection.json").read_text(encoding="utf-8")
    )
    assert old_choice["methods"][0] == "adaptive_ga"
    upstream = json.loads(
        (ROOT / "data/upstream-b410538-tree.json").read_text(encoding="utf-8")
    )
    blobs = {e["path"]: e["sha"] for e in upstream["tree"] if e["type"] == "blob"}
    data = (ROOT / "src/agv/planning/hybrid_routes.py").read_bytes()
    assert (
        hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        == blobs["src/agv/planning/hybrid_routes.py"]
    )
    rows = []
    failures = []
    checked = legacy_matches = routing_matches = 0
    backend_activity = {}
    development = []
    for phase in ("dispatch", "routing", "validation"):
        folder = ROOT / "results" / phase
        frozen = json.loads((folder / "freeze.json").read_text(encoding="utf-8"))
        assert frozen["source_hashes"] == source and frozen["protocol_sha256"] == digest
        group = json.loads((folder / "runs.json").read_text(encoding="utf-8"))
        assert len(group) == len(frozen["configs"])
        assert {(r["case"], r["method"], r["router"], r["seed"]) for r in group} == set(
            map(tuple, frozen["configs"])
        )
        if phase == "dispatch":
            development = group
        reference = group if phase != "routing" else development
        refs = {
            r["case"]: r
            for r in reference
            if r["valid"] and r["method"] == "fcfs" and r["router"] == "sipp"
        }
        for r in group:
            rows.append(dict(phase=phase, **r))
            if not r["valid"]:
                failures.append(dict(phase=phase, **r))
                continue
            doc = json.loads((ROOT / r["trace"]).read_text(encoding="utf-8"))
            assert doc["case"] == cases[r["case"]]
            assert all(
                doc["config"][k] == r[k] for k in ("case", "method", "router", "seed")
            )
            result = doc["result"]
            assert result["routing_backend"] == r["router"]
            assert validate(build(cases[r["case"]]), result)["valid"]
            for k in ("T", "R", "D", "p90", "empty_distance", "traffic_wait"):
                assert result[k] == r[k]
            assert (
                abs(
                    r["F"]
                    - sum(
                        w * r[k] / refs[r["case"]][k]
                        for w, k in zip((0.5, 0.3, 0.2), ("T", "R", "D"))
                    )
                )
                < 1e-12
            )
            for log in result["search_log"]:
                if "visible_ids" in log:
                    assert log["visible_ids"] == sorted(
                        j["id"]
                        for j in cases[r["case"]]["tasks"]
                        if j["release"] <= log["time"]
                    )
                if r["method"] in ("simple_ga", "soft_ga"):
                    if "previews" in log:
                        assert (
                            log["optimizer"] == "ga" and log["backend"] == r["router"]
                        )
                        assert log["previews"] <= 3 and log["proxy_evaluations"] <= 96
                        assert log["score"] <= 1.0 + 1e-12
                    for usage in [log.get("anchor_usage"), log.get("usage")] + [
                        v["usage"] for v in log.get("candidates", [])
                    ]:
                        if usage:
                            assert (
                                usage["backend"] == r["router"]
                                and usage["route_calls"] <= 512
                            )
                else:
                    assert (
                        log.get("previews", 0) <= 6
                        and log.get("proxy_evaluations", 0) <= 192
                    )
            activity = backend_activity.setdefault(r["router"], Counter())
            activity.update(result.get("routing_diagnostics", {}))
            checked += 1
            if phase == "dispatch" and r["method"] == "adaptive_ga":
                old = json.loads(
                    (
                        ROOT
                        / "data/prior-adaptive-traces"
                        / f"{r['case']}-adaptive_ga-s0.json"
                    ).read_text(encoding="utf-8")
                )["result"]
                assert all(
                    old[k] == result[k]
                    for k in ("paths", "records", "T", "R", "D", "final_stock")
                )
                legacy_matches += 1
            if phase == "routing" and r["router"] == "sipp":
                previous = next(
                    x
                    for x in development
                    if x["case"] == r["case"] and x["method"] == r["method"]
                )
                old = json.loads(
                    (ROOT / previous["trace"]).read_text(encoding="utf-8")
                )["result"]
                assert all(
                    old[k] == result[k] for k in ("paths", "records", "T", "R", "D")
                )
                routing_matches += 1
    for name in ("dispatch", "routing"):
        selected = json.loads(
            (ROOT / "results" / (name + "-selection.json")).read_text(encoding="utf-8")
        )
        assert (
            selected["source_hashes"] == source
            and selected["protocol_sha256"] == digest
        )
        assert selected["selected"] == min(
            selected["scores"],
            key=lambda k: (selected["scores"][k]["F"], selected["scores"][k]["cpu"]),
        )
    fields = [
        "phase",
        "case",
        "method",
        "router",
        "seed",
        "valid",
        "F",
        "T",
        "R",
        "D",
        "p90",
        "empty_distance",
        "traffic_wait",
        "solve_cpu",
        "wall",
        "error",
    ]
    with (ROOT / "results/comparison.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
    report = dict(
        runs=len(rows),
        independently_validated=checked,
        failures=failures,
        source_cases=len(cases),
        source_rows=source_rows,
        core_files_unchanged=core,
        legacy_control_exact_matches=legacy_matches,
        routing_sipp_exact_matches=routing_matches,
        backend_activity={k: dict(v) for k, v in backend_activity.items()},
        source_hashes=source,
        protocol_sha256=digest,
    )
    (ROOT / "results/audit.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )
    print(
        json.dumps({k: v for k, v in report.items() if k != "source_hashes"}, indent=2)
    )


if __name__ == "__main__":
    main()
