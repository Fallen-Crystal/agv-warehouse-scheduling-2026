# 数据来源与映射

原始数据来自作者公开仓库 [malerinc/slapstack](https://github.com/malerinc/slapstack)，固定提交 `da6280a8f8be1010eae64264c69a90258a288173` 的WEPAStacks用例。原始文件和源仓库README、MIT许可文件位于 `raw/`，原订单文件SHA256为 `caab14a69aa34734f3ceb04f6c595f712b7dc4a1ee65adbe92268a16a7159432`。本轮没有执行第三方仓库程序。

论文：Pfrommer et al., *SLAPStack: A Simulation Framework and a Large-Scale Benchmark Use Case for Autonomous Block Stacking Warehouses*, ICCL 2022, LNCS 13557, pp.291–305, DOI [10.1007/978-3-031-16579-5_20](https://doi.org/10.1007/978-3-031-16579-5_20)。

源记录字段为 `[kind, sku, absolute_seconds, dock, batch, week]`，每条为一个托盘请求。`delivery`映射为入库，`retrieval`映射为出库。900秒窗口保持半开区间内全部记录；同一时刻的出库批次不截断，跨窗口的入库生产批次不能称作完整保留的生产批次。每个窗口是独立有限实验，不意味着连续运营中每15分钟返库。

源订单流、SKU、初始库存台账保留；空间货位、出入口数量映射、每步速度、货架层数、服务时间为课程模型。入库和出库的库存变化由真实执行完成事件驱动，不在发布订单时凭空增加库存。

`protocol.json`为基础研究的6个窗口协议，`meta-protocol.json`为2026-10-23高级算法移植研究使用的9个窗口及时间分割。后续日期仅依据源数据数量、SKU数量、初始容量和业务类型条件筛选，不依据任何算法结果挑选。

2026-10-23研究的第二阶段以 `adaptive-protocol.json` 再加入第54/58/61日三个窗口，共12个窗口609条源请求。第45日已被此前查看，在该阶段转为开发/低负荷回归；不能将它继续称为未见验证。该阶段新验证均至少包含5条入库和5条出库，没有找到满足其余过滤条件的更晚入库占比至少85%的日期。

`prior-mixed-contract/`和`prior-control-traces/`是上轮模型与对照执行的审计副本，不提供给调度策略。`upstream-b410538-tree.json`是已上传算法提交的Git对象清单，仅用于来源核验。

本次简化调度与路径对照使用 `simple-protocol.json`：开发为第12/32/33/45日；新验证为按输入条件筛出的第62/66/69日。第54/58/61日已在旧研究中使用，因此没有再次作为本轮未见验证。三个新日期均有入库与出库，其源行、窗口边界、初始库存前缀台账由 `audit.py` 独立核对。
