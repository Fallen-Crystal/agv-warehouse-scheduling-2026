import unittest
from adaptive.policy import public_reference
from adaptive.runner import run
from wepa.check import validate
from wepa.data import build
from wepa.kernel import World, run as original_run
from wepa.search import snapshot
from test_mixed import case, task


class AdaptiveTests(unittest.TestCase):
    def test_stock_and_independent_validation(self):
        model = build(
            case([task(0, "retrieval"), task(1, "delivery", 5)], initial=0),
            size="medium",
            vehicles=2,
        )
        for method in ("matching", "adaptive_ga", "adaptive_hybrid"):
            result = run(model, method)
            self.assertTrue(validate(model, result)["valid"])

    def test_public_initial_inventory_reconstruction(self):
        model = build(
            case([task(0, "retrieval"), task(1, "delivery", 20)]),
            size="medium",
            vehicles=2,
        )
        w = World(model)
        for _ in range(150):
            w.publish_and_complete()
            from adaptive.policy import matching

            matching(w)
            w.advance()
        w.publish_and_complete()
        reference = public_reference(snapshot(w), model["close_at"])
        expected = original_run(model, "fcfs")
        self.assertEqual(reference, tuple(expected[k] for k in ("T", "R", "D")))

    def test_future_prefix_and_causal_closed_scales(self):
        a = build(
            case([task(0, "retrieval"), task(1, "delivery", 200)]),
            size="medium",
            vehicles=2,
        )
        b = build(
            case([task(0, "retrieval"), task(1, "delivery", 300)]),
            size="medium",
            vehicles=2,
        )
        for method in ("adaptive_ga", "adaptive_hybrid"):
            x, y = run(a, method, seed=8), run(b, method, seed=8)
            self.assertEqual(
                [d for d in x["decisions"] if d["time"] < 200],
                [d for d in y["decisions"] if d["time"] < 200],
            )
            self.assertFalse(
                any(
                    log.get("exact_closed_scales", False)
                    for log in x["search_log"]
                    if log["time"] < a["close_at"]
                )
            )

    def test_reference_during_inflight_physical_stock_changes(self):
        data = dict(
            case="inflight-reference", close_at=0, initial={"10": 3, "20": 0},
            tasks=[task(0, "retrieval"), dict(task(1, "delivery"), sku=20)],
        )
        model = build(data, size="medium", vehicles=2)
        expected = original_run(model, "fcfs")
        reference = tuple(expected[k] for k in ("T", "R", "D"))
        w = World(model)
        w.publish_and_complete()
        from adaptive.policy import matching

        self.assertEqual(len(matching(w)), 2)
        self.assertEqual(public_reference(snapshot(w), 0), reference)
        checkpoints = sorted({r["pickup_end"] for r in w.records} | {r["end"] for r in w.records})
        for when in checkpoints:
            while w.time < when:
                w.advance()
                w.publish_and_complete()
            self.assertEqual(public_reference(snapshot(w), 0), reference)


if __name__ == "__main__":
    unittest.main()
