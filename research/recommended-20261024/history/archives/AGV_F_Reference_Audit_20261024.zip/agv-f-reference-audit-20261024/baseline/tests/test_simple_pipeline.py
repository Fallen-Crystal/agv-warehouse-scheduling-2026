import unittest
from copy import deepcopy

from simple.routing import make_router
from simple.shadow import snapshot, rollout
from simple.runner import run
from wepa.check import validate
from wepa.data import build
from wepa.kernel import World
from test_mixed import case, task
from agv.warehouse.scenarios import Scenario


class SimplePipelineTests(unittest.TestCase):
    def model(self):
        return build(
            case([task(0, "retrieval"), task(1, "delivery", 20)]),
            size="medium",
            vehicles=2,
        )

    def test_snapshot_removes_future_and_keeps_routing_backend(self):
        for kind in ("sipp", "astar", "aco"):
            w = World(self.model())
            w.route_kind, w.route_seed = kind, 3
            w.router = make_router(w.scene, kind, 3)
            w.publish_and_complete()
            v = snapshot(w)
            self.assertEqual(set(v.tasks), {0})
            self.assertEqual(v.route_kind, kind)
            self.assertEqual(v.model["close_at"], 0)
            self.assertIsNot(v.router.stats, w.router.stats)

    def test_all_route_controls_are_physically_valid(self):
        model = self.model()
        for kind in ("sipp", "astar", "aco"):
            result = run(model, "soft_ga", kind, seed=3)
            self.assertTrue(validate(model, result)["valid"])
            self.assertEqual(result["routing_backend"], kind)
            self.assertEqual(set(result["completed"]), {0, 1})

    def test_rollout_does_not_mutate_world(self):
        w = World(self.model())
        w.route_kind, w.route_seed = "astar", 0
        w.router = make_router(w.scene, "astar", 0)
        w.publish_and_complete()
        before = deepcopy((w.stock, w.records, w.plans, w.time))
        predicted, usage = rollout(w)
        self.assertIsNotNone(predicted)
        self.assertEqual(before, (w.stock, w.records, w.plans, w.time))
        self.assertLessEqual(usage["route_calls"], 512)

    def test_physical_stock_waits_for_putaway(self):
        model = build(
            case([task(0, "retrieval"), task(1, "delivery", 5)], initial=0),
            size="medium",
            vehicles=2,
        )
        r = run(model, "soft_ga", "sipp", seed=1)
        validate(model, r)
        records = {x["task"]: x for x in r["records"]}
        self.assertGreaterEqual(records[0]["assigned_at"], records[1]["end"])

    def test_future_arrival_does_not_change_past_actions(self):
        a = build(
            case([task(0, "retrieval"), task(1, "delivery", 200)]),
            size="medium",
            vehicles=2,
        )
        b = build(
            case([task(0, "retrieval"), task(1, "delivery", 300)]),
            size="medium",
            vehicles=2,
        )
        x, y = run(a, "soft_ga", seed=4), run(b, "soft_ga", seed=4)
        self.assertEqual(
            [d for d in x["decisions"] if d["time"] < 200],
            [d for d in y["decisions"] if d["time"] < 200],
        )

    def test_advanced_policy_has_only_ga_and_fixed_budgets(self):
        data = case([task(j, "retrieval") for j in range(5)], initial=5)
        r = run(build(data, size="medium", vehicles=2), "soft_ga", seed=9)
        logs = [x for x in r["search_log"] if "previews" in x]
        self.assertTrue(logs)
        for log in logs:
            self.assertLessEqual(log["previews"], 3)
            self.assertLessEqual(log["proxy_evaluations"], 96)
            self.assertEqual(log["optimizer"], "ga")
            self.assertTrue(
                all(x["kind"] in ("ga", "incumbent") for x in log["candidates"])
            )

    def test_reproducible_seed(self):
        m = self.model()
        a, b = run(m, "soft_ga", seed=1), run(m, "soft_ga", seed=1)
        self.assertEqual(a["paths"], b["paths"])
        self.assertEqual(a["records"], b["records"])

    def test_congested_aco_candidates_respect_actual_reservations(self):
        scene = Scenario(5, 3, set(), set(), [(0, 1)], [], horizon=30)
        router = make_router(scene, "aco", 8)
        vertices = {(1, (1, 1)), (2, (1, 1))}
        edges = set()
        path = router.leg((0, 1), (4, 1), 0, 0, vertices, edges, service=2)
        self.assertIsNotNone(path)
        self.assertGreater(router.diagnostics["spatial_searches"], 0)
        self.assertLessEqual(router.diagnostics["timed_candidates"], 2)
        self.assertEqual(path[-3:], [(4, 1)] * 3)
        for time, point in enumerate(path):
            self.assertNotIn((time, point), vertices)
        self.assertTrue(
            all(
                abs(a[0] - b[0]) + abs(a[1] - b[1]) <= 1 for a, b in zip(path, path[1:])
            )
        )


if __name__ == "__main__":
    unittest.main()
