import unittest
from copy import deepcopy

from wepa.check import validate
from wepa.data import build
from wepa.kernel import World, run


def case(tasks, initial=1):
    return dict(case="micro", close_at=max((j["release"] for j in tasks), default=0),
                initial={"10": initial}, tasks=tasks)


def task(jid, kind, release=0):
    return dict(id=jid, source_row=jid, kind=kind, sku=10, release=release,
                source_time=release, source_dock=1, batch=jid, week=1)


class MixedTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.model = build(case([task(0, "retrieval"), task(1, "delivery", 30)]), size="medium", vehicles=2)
        cls.result = run(cls.model, "fcfs")
        validate(cls.model, cls.result)

    def test_valid_mixed(self):
        self.assertTrue(validate(self.model, self.result)["valid"])

    def test_stock_waits_for_putaway(self):
        m = build(case([task(0, "retrieval"), task(1, "delivery", 5)], initial=0), size="medium", vehicles=2)
        r = run(m, "eta")
        validate(m, r)
        rec = {x["task"]: x for x in r["records"]}
        self.assertGreaterEqual(rec[0]["assigned_at"], rec[1]["end"])

    def test_publication_does_not_make_stock(self):
        m = build(case([task(0, "delivery"), task(1, "retrieval")], initial=0), size="medium", vehicles=2)
        w = World(m)
        w.publish_and_complete()
        self.assertEqual(len(w.stock), 0)
        self.assertEqual([j["id"] for j in w.ready()], [0])

    def test_no_future_release(self):
        w = World(self.model)
        w.publish_and_complete()
        self.assertEqual(set(w.visible), {0})

    def test_shortage_is_not_valid(self):
        m = build(case([task(0, "retrieval")], initial=0), size="medium", vehicles=1)
        r = run(m, "fcfs", max_time=5)
        self.assertFalse(r["valid"])
        with self.assertRaises(ValueError):
            validate(m, r)

    def test_duplicate_assignment_rejected(self):
        w = World(self.model)
        w.publish_and_complete()
        j = w.ready()[0]
        proposal = w.trip(0, j)
        w.commit(0, j, proposal)
        with self.assertRaises(ValueError):
            w.commit(0, j, proposal)

    def test_fractional_coordinates_rejected(self):
        r = deepcopy(self.result)
        r["paths"][0][0] = [0.5, 2]
        with self.assertRaisesRegex(ValueError, "integers"):
            validate(self.model, r)

    def test_diagonal_or_teleport_rejected(self):
        r = deepcopy(self.result)
        r["paths"][0][1] = self.model["scene"].homes[0]
        r["paths"][0][2] = (8, 8)
        with self.assertRaises(ValueError):
            validate(self.model, r)

    def test_collision_rejected(self):
        r = deepcopy(self.result)
        r["paths"][1][1] = r["paths"][0][1]
        with self.assertRaises(ValueError):
            validate(self.model, r)

    def test_duplicate_record_rejected(self):
        r = deepcopy(self.result)
        r["records"].append(dict(r["records"][0]))
        with self.assertRaises(ValueError):
            validate(self.model, r)

    def test_wrong_service_rejected(self):
        r = deepcopy(self.result)
        r["records"][0]["pickup_end"] += 1
        with self.assertRaises(ValueError):
            validate(self.model, r)

    def test_cross_side_rejected(self):
        r = deepcopy(self.result)
        r["records"][0]["pickup"] = (2, 2)
        with self.assertRaises(ValueError):
            validate(self.model, r)

    def test_wrong_stock_rejected(self):
        r = deepcopy(self.result)
        r["final_stock"] = []
        with self.assertRaises(ValueError):
            validate(self.model, r)

    def test_trailing_parking_rejected(self):
        r = deepcopy(self.result)
        r["time"] += 1
        for p, states in zip(r["paths"], r["labels"]):
            p.append(p[-1])
            states.append("standby")
        with self.assertRaisesRegex(ValueError, "trailing parking"):
            validate(self.model, r)

    def test_map_and_parking_fixed_across_fleets(self):
        other = build(case([task(0, "retrieval"), task(1, "delivery", 30)]), size="medium", vehicles=8)
        self.assertEqual(self.model["scene"].blocked, other["scene"].blocked)
        self.assertEqual(self.model["scene"].homes, other["scene"].homes)
        self.assertEqual(self.model["slots"], other["slots"])

    def test_future_tasks_do_not_change_early_decisions(self):
        c1 = case([task(0, "retrieval"), task(1, "delivery", 200)])
        c2 = case([task(0, "retrieval"), task(1, "delivery", 300)])
        r1 = run(build(c1, size="medium", vehicles=2), "joint")
        r2 = run(build(c2, size="medium", vehicles=2), "joint")
        self.assertEqual([d for d in r1["decisions"] if d["time"] < 200],
                         [d for d in r2["decisions"] if d["time"] < 200])

    def test_capacity_reserved_before_dispatch(self):
        m = build(case([], initial=0), size="medium", vehicles=2)
        m["tasks"] = [dict(task(i, "delivery"), port=m["inlets"][0])
                      for i in range(len(m["slots"]) + 1)]
        w = World(m)
        w.publish_and_complete()
        self.assertEqual(len(w.in_reserved), len(m["slots"]))
        self.assertEqual(len(w.bound), len(m["slots"]))

    def test_duplicate_physical_slot_rejected(self):
        m = deepcopy(self.model)
        m["slots"].append(dict(m["slots"][0], id=len(m["slots"])))
        with self.assertRaisesRegex(ValueError, "Duplicate physical"):
            validate(m, self.result)

    def test_no_final_return_rejected(self):
        r = deepcopy(self.result)
        r["paths"][0][-1] = next(self.model["scene"].neighbors(self.model["scene"].homes[0]))
        with self.assertRaises(ValueError):
            validate(self.model, r)

    def test_empty_distance_recomputed(self):
        r = deepcopy(self.result)
        r["empty_distance"] += 1
        with self.assertRaisesRegex(ValueError, "empty distance"):
            validate(self.model, r)

    def test_only_upper_occupied_layer_ready(self):
        m = build(case([task(i, "retrieval") for i in range(3)], initial=5), size="medium", vehicles=2)
        w = World(m)
        w.publish_and_complete()
        for j in w.ready():
            slot = w.slots[w.bound[j["id"]]]
            self.assertFalse(any(q["bay"] == slot["bay"] and q["level"] > slot["level"]
                                 and q["id"] in w.stock for q in w.slots))

    def test_no_transit_through_other_port(self):
        for k, path in enumerate(self.result["paths"]):
            authorized = set()
            for r in self.result["records"]:
                if r["vehicle"] != k:
                    continue
                j = self.model["tasks"][r["task"]]
                lo, hi = ((r["pickup_arrival"], r["pickup_end"]) if j["kind"] == "delivery"
                          else (r["drop_arrival"], r["end"]))
                authorized.update((t, j["port"]) for t in range(lo, hi + 1))
            self.assertTrue(all(p not in self.model["scene"].stations or (t, p) in authorized
                                for t, p in enumerate(path)))


if __name__ == "__main__":
    unittest.main()
