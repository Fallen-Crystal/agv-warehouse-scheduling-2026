import unittest
from copy import deepcopy

from wepa.check import validate
from wepa.data import build
from wepa.kernel import World, run
from wepa.search import METHODS, owned_batch, rollout, snapshot, values
from test_mixed import case, task


class SearchTests(unittest.TestCase):
    def model(self):
        return build(
            case([task(0, "retrieval"), task(1, "delivery", 40)], initial=1),
            size="medium",
            vehicles=2,
        )

    def test_advanced_methods_stock_and_final_return(self):
        for method in METHODS:
            with self.subTest(method=method):
                result = run(self.model(), method, seed=7)
                self.assertTrue(validate(self.model(), result)["valid"])
                self.assertTrue(result["search_log"])

    def test_snapshot_future_is_absent(self):
        world = World(self.model())
        world.publish_and_complete()
        view = snapshot(world)
        self.assertEqual(set(view.tasks), {0})
        self.assertEqual({j["id"] for j in view.model["tasks"]}, {0})
        self.assertEqual(view.model["close_at"], 0)
        view.stock.clear()
        self.assertTrue(world.stock)

    def test_rollout_never_mutates_real_state(self):
        world = World(self.model())
        world.publish_and_complete()
        before = deepcopy(
            (world.stock, world.bound, world.plans, world.records, world.time)
        )
        prediction, pairs = rollout(world)
        self.assertIsNotNone(prediction)
        self.assertTrue(pairs)
        self.assertEqual(
            before, (world.stock, world.bound, world.plans, world.records, world.time)
        )

    def test_first_action_matches_preview(self):
        world = World(self.model())
        world.publish_and_complete()
        prediction, _ = rollout(world)
        records = prediction.records
        plan = (
            [r["task"] for r in records],
            {r["task"]: r["vehicle"] for r in records},
        )
        _, first = rollout(world, plan)
        self.assertEqual(owned_batch(world, *plan), first)

    def test_bound_preserves_improving_candidate(self):
        world = World(self.model())
        world.publish_and_complete()
        prediction, _ = rollout(world)
        records = prediction.records
        plan = (
            [r["task"] for r in records],
            {r["task"]: r["vehicle"] for r in records},
        )
        bounded, _ = rollout(world, plan, values(prediction), incumbent=1.01)
        self.assertIsNotNone(bounded)
        self.assertEqual(values(prediction), values(bounded))
        pruned, _ = rollout(world, plan, values(prediction), incumbent=0.1)
        self.assertIsNone(pruned)

    def test_forecast_event_jumps_match_tick_execution(self):
        jobs = [
            dict(
                task(i, "retrieval" if i % 2 == 0 else "delivery"),
                sku=10 if i < 3 else 20,
            )
            for i in range(6)
        ]
        data = dict(
            case="equivalence", close_at=0, initial={"10": 6, "20": 6}, tasks=jobs
        )
        world = World(build(data, size="medium", vehicles=2))
        world.publish_and_complete()
        fast, _ = rollout(world)
        slow, _ = rollout(world, fast=False)
        self.assertEqual(fast.records, slow.records)
        self.assertEqual(values(fast), values(slow))
        plan = (
            [r["task"] for r in fast.records],
            {r["task"]: r["vehicle"] for r in fast.records},
        )
        a, _ = rollout(world, plan)
        b, _ = rollout(world, plan, fast=False)
        self.assertEqual(a.records, b.records)
        self.assertEqual(values(a), values(b))

    def test_fast_ready_matches_reference_every_tick(self):
        model = self.model()
        world = World(model)
        for _ in range(200):
            world.publish_and_complete()
            self.assertEqual(world.ready(), snapshot(world).ready())
            if world.ready():
                from wepa.kernel import batch

                batch(world, "eta")
            world.advance()

    def test_no_stock_until_putaway_all_advanced(self):
        for method in METHODS:
            model = build(
                case([task(0, "retrieval"), task(1, "delivery", 5)], initial=0),
                size="medium",
                vehicles=2,
            )
            result = run(model, method)
            validate(model, result)
            records = {r["task"]: r for r in result["records"]}
            self.assertGreaterEqual(records[0]["assigned_at"], records[1]["end"])

    def test_seed_determinism_and_future_prefix(self):
        for method in ("ga", "aco", "pso", "hybrid"):
            first = self.model()
            second = self.model()
            second["tasks"][1]["release"] = 70
            second["close_at"] = 70
            a, b = run(first, method, seed=4), run(second, method, seed=4)
            self.assertEqual(
                [d for d in a["decisions"] if d["time"] < 40],
                [d for d in b["decisions"] if d["time"] < 40],
            )
            self.assertEqual(a["paths"], run(first, method, seed=4)["paths"])

    def test_multi_job_budgets_and_precedence(self):
        jobs = [
            dict(
                task(i, "retrieval" if i % 2 == 0 else "delivery"),
                sku=10 if i < 3 else 20,
            )
            for i in range(6)
        ]
        data = dict(case="multi", close_at=0, initial={"10": 6, "20": 6}, tasks=jobs)
        model = build(data, size="medium", vehicles=2)
        for method in METHODS:
            result = run(model, method, seed=9)
            validate(model, result)
            for log in result["search_log"]:
                self.assertLessEqual(log.get("previews", 0), 6)
                self.assertLessEqual(log.get("proxy_evaluations", 0), 192)


if __name__ == "__main__":
    unittest.main()
