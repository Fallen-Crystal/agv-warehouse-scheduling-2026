"""Run the single pipeline selected on development, from any working directory."""

import argparse
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", required=True)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    selection = json.loads(
        (ROOT / "results/routing-selection.json").read_text(encoding="utf-8")
    )
    # Development selection is immutable; held-out performance never changes it.
    method, router = selection["selected"].split("/")
    command = [
        sys.executable,
        str(ROOT / "run_simple.py"),
        "--case",
        args.case,
        "--method",
        method,
        "--router",
        router,
        "--seed",
        str(args.seed),
        "--output",
        str(Path(args.output).resolve()),
    ]
    raise SystemExit(subprocess.call(command))


if __name__ == "__main__":
    main()
