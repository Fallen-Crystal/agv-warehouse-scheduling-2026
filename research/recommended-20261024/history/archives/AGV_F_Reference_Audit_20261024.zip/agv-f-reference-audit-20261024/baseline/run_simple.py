"""Portable CLI; the dispatch and routing choices have separate explicit flags."""

import argparse
import json
import os
import sys
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT), str(ROOT / "src")]
from simple.runner import run  # noqa: E402
from wepa.data import build  # noqa: E402
from wepa.check import validate  # noqa: E402


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--case", required=True)
    p.add_argument(
        "--method",
        choices=("simple_ga", "soft_ga", "adaptive_ga", "eta", "fcfs"),
        default="soft_ga",
    )
    p.add_argument("--router", choices=("sipp", "astar", "aco"), default="sipp")
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--cpu", type=int, default=180)
    p.add_argument("--protocol", default="data/simple-protocol.json")
    p.add_argument("--output", required=True)
    args = p.parse_args()
    path = Path(args.output)
    if path.exists():
        raise ValueError("Refuse to overwrite trace")
    cpu, wall = time.process_time(), time.perf_counter()
    stop = threading.Event()

    def guard():
        while not stop.wait(0.25):
            if time.process_time() - cpu > args.cpu:
                os._exit(124)

    threading.Thread(target=guard, daemon=True).start()
    protocol = json.loads((ROOT / args.protocol).read_text(encoding="utf-8"))
    case = next(c for c in protocol["cases"] if c["case"] == args.case)
    model = build(case)
    start = time.process_time()
    result = run(model, args.method, args.router, args.seed)
    elapsed = time.process_time() - start
    audit = validate(model, result) if result["valid"] else dict(valid=False)
    stop.set()
    row = dict(
        case=args.case,
        method=args.method,
        router=args.router,
        seed=args.seed,
        valid=result["valid"] and audit["valid"],
        solve_cpu=elapsed,
        total_cpu=time.process_time() - cpu,
        wall=time.perf_counter() - wall,
        tasks=len(case["tasks"]),
        **{
            k: result[k]
            for k in ("T", "R", "D", "p90", "empty_distance", "traffic_wait")
        },
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as f:
        json.dump(
            dict(config=vars(args), case=case, row=row, result=result, audit=audit), f
        )
    print(json.dumps(row), flush=True)


if __name__ == "__main__":
    main()
