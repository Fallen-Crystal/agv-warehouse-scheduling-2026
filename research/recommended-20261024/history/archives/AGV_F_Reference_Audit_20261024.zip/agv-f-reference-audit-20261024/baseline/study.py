"""Input-only temporal split, fixed sequential studies and pre-test selection."""

import argparse
import hashlib
import json
import os
import random
import subprocess
import sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def hashes():
    paths = [
        p
        for folder in ("simple", "wepa", "adaptive")
        for p in (ROOT / folder).glob("*.py")
    ]
    paths += [ROOT / "run_simple.py", ROOT / "study.py"]
    return {p.relative_to(ROOT).as_posix(): sha(p) for p in sorted(paths)}


def prepare():
    target = ROOT / "data/simple-protocol.json"
    if target.exists():
        return json.loads(target.read_text(encoding="utf-8"))
    previous = json.loads(
        (ROOT / "data/adaptive-protocol.json").read_text(encoding="utf-8")
    )
    development = list(previous["development"])
    selected = [c for c in previous["cases"] if c["case"] in development]
    raw = json.loads((ROOT / "data/raw/2_orders.json").read_text(encoding="utf-8"))
    stock = Counter(
        {
            int(k): v
            for k, v in json.loads(
                (ROOT / "data/raw/3_initial_fill_lvl.json").read_text(encoding="utf-8")
            ).items()
        }
    )
    bins = defaultdict(list)
    for i, r in enumerate(raw):
        bins[r[2] // 900].append((i, r))
    days = set()
    validation = []
    for bucket, entries in bins.items():
        skus = sorted({r[1] for _, r in entries})
        kinds = Counter(r[0] for _, r in entries)
        day = bucket // 96
        if (
            day > 61
            and day not in days
            and 35 <= len(entries) <= 65
            and 2 <= len(skus) <= 5
            and len(kinds) == 2
            and min(kinds.values()) >= 5
            and sum(stock[s] for s in skus) <= 900
        ):
            name = f"wepa-day{day}-bin{bucket}"
            selected.append(
                dict(
                    case=name,
                    source_day=day,
                    source_bin=bucket,
                    start_seconds=bucket * 900,
                    end_seconds=(bucket + 1) * 900,
                    close_at=900,
                    initial={str(s): stock[s] for s in skus},
                    tasks=[
                        dict(
                            id=j,
                            source_row=i,
                            kind=r[0],
                            sku=r[1],
                            release=r[2] - bucket * 900,
                            source_time=r[2],
                            source_dock=r[3],
                            batch=r[4],
                            week=r[5],
                        )
                        for j, (i, r) in enumerate(entries)
                    ],
                )
            )
            validation.append(name)
            days.add(day)
            if len(validation) == 3:
                break
        for _, r in entries:
            stock[r[1]] += 1 if r[0] == "delivery" else -1
    if len(validation) != 3:
        raise ValueError("Insufficient untouched input windows")
    protocol = dict(
        version="simple-routing-20261024-v1",
        cases=selected,
        development=development,
        validation=validation,
        source_sha256=previous["source_sha256"],
        configuration=dict(size="large", vehicles=6, layers=5),
        seeds=[0, 1],
        selection="lowest valid development F, all cases complete; CPU tie-break; no validation reselection",
        reference="same-scene FCFS + SIPP for every router",
        source_rules="900sec complete half-open windows, source prefix ledger, earlier operations assumed complete",
        budget=dict(
            proxy=96,
            previews=3,
            route_calls_per_preview=512,
            population=12,
            generations=8,
            cpu=180,
            wall=600,
        ),
        routing=dict(
            sipp="safe-interval + reservations",
            astar="time-space A* + reservations",
            aco="ACO-guided spatial A* + SIPP timing, two timed corridor candidates/leg",
        ),
        soft_regions="two shelf regions; local+nearest3 owner proposals75%, global owner proposals25%; no hard region ban",
        note="Days54/58/61 already consumed; first new eligible days62/66/69 are held out. Routing comparison is closed-loop, not fixed-dispatch replay.",
    )
    target.write_text(json.dumps(protocol, indent=2), encoding="utf-8")
    return protocol


def worker(config, folder):
    case, method, router, seed = config
    name = f"{case}-{method}-{router}-s{seed}"
    path = folder / "traces" / (name + ".json")
    cmd = [
        sys.executable,
        str(ROOT / "run_simple.py"),
        "--case",
        case,
        "--method",
        method,
        "--router",
        router,
        "--seed",
        str(seed),
        "--cpu",
        "180",
        "--output",
        str(path),
    ]
    try:
        proc = subprocess.run(
            cmd,
            cwd=ROOT,
            env=dict(os.environ, PYTHONUTF8="1"),
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=600,
        )
        (folder / "logs" / (name + ".txt")).write_text(
            proc.stdout + proc.stderr, encoding="utf-8"
        )
        if proc.returncode == 0:
            row = json.loads(path.read_text(encoding="utf-8"))["row"]
            row["trace"] = path.relative_to(ROOT).as_posix()
            return row
        return dict(
            case=case,
            method=method,
            router=router,
            seed=seed,
            valid=False,
            error="CPU budget" if proc.returncode == 124 else "worker error",
            returncode=proc.returncode,
        )
    except subprocess.TimeoutExpired as exc:
        (folder / "logs" / (name + ".txt")).write_text(str(exc), encoding="utf-8")
        return dict(
            case=case,
            method=method,
            router=router,
            seed=seed,
            valid=False,
            error="wall budget",
        )


def select(rows, keys, cases):
    scores = {}
    for key in keys:
        group = [r for r in rows if (r["method"], r["router"]) == key]
        if len(group) == len(cases) and all(r["valid"] and "F" in r for r in group):
            scores["/".join(key)] = dict(
                F=sum(r["F"] for r in group) / len(group),
                cpu=sum(r["solve_cpu"] for r in group) / len(group),
            )
    ranked = sorted(scores, key=lambda k: (scores[k]["F"], scores[k]["cpu"]))
    if not ranked:
        raise ValueError("No valid development candidate")
    return dict(
        selected=ranked[0],
        scores=scores,
        source_hashes=hashes(),
        protocol_sha256=sha(ROOT / "data/simple-protocol.json"),
    )


def main():
    p = argparse.ArgumentParser()
    p.add_argument("phase", choices=("prepare", "dispatch", "routing", "validation"))
    args = p.parse_args()
    protocol = prepare()
    if args.phase == "prepare":
        print(
            json.dumps(
                {k: protocol[k] for k in ("development", "validation", "budget")}
            )
        )
        return
    dispatch = None
    routing = None
    if args.phase != "dispatch":
        dispatch = json.loads(
            (ROOT / "results/dispatch-selection.json").read_text(encoding="utf-8")
        )
        assert dispatch["source_hashes"] == hashes()
    if args.phase == "dispatch":
        configs = [
            (c, m, "sipp", 0)
            for c in protocol["development"]
            for m in ("fcfs", "eta", "adaptive_ga", "simple_ga", "soft_ga")
        ]
    elif args.phase == "routing":
        method = dispatch["selected"].split("/")[0]
        configs = [
            (c, method, r, 0)
            for c in protocol["development"]
            for r in ("sipp", "astar", "aco")
        ]
    else:
        routing = json.loads(
            (ROOT / "results/routing-selection.json").read_text(encoding="utf-8")
        )
        assert routing["source_hashes"] == hashes()
        method = dispatch["selected"].split("/")[0]
        configs = [
            (c, m, "sipp", s)
            for c in protocol["validation"]
            for m in ("adaptive_ga", "simple_ga", "soft_ga")
            for s in (0, 1)
        ]
        configs += [
            (c, m, "sipp", 0) for c in protocol["validation"] for m in ("fcfs", "eta")
        ]
        configs += [
            (c, method, r, s)
            for c in protocol["validation"]
            for r in ("astar", "aco")
            for s in (0, 1)
        ]
    random.Random(
        20261024 + ("dispatch", "routing", "validation").index(args.phase)
    ).shuffle(configs)
    folder = ROOT / "results" / args.phase
    folder.mkdir(exist_ok=False)
    (folder / "traces").mkdir()
    (folder / "logs").mkdir()
    frozen = dict(
        source_hashes=hashes(),
        protocol_sha256=sha(ROOT / "data/simple-protocol.json"),
        configs=configs,
        dispatch_selection=dispatch,
        routing_selection=routing,
    )
    (folder / "freeze.json").write_text(json.dumps(frozen, indent=2), encoding="utf-8")
    rows = []
    for config in configs:
        row = worker(config, folder)
        rows.append(row)
        with (folder / "rows.jsonl").open("a", encoding="utf-8") as f:
            f.write(json.dumps(row) + "\n")
        print(json.dumps(row), flush=True)
    reference_rows = (
        rows
        if args.phase != "routing"
        else json.loads(
            (ROOT / "results/dispatch/runs.json").read_text(encoding="utf-8")
        )
    )
    refs = {
        r["case"]: r
        for r in reference_rows
        if r["valid"] and r["method"] == "fcfs" and r["router"] == "sipp"
    }
    for row in rows:
        if row["valid"] and row["case"] in refs:
            row["F"] = sum(
                w * row[k] / refs[row["case"]][k]
                for w, k in zip((0.5, 0.3, 0.2), ("T", "R", "D"))
            )
    (folder / "runs.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
    if args.phase == "dispatch":
        selection = select(
            rows, [("simple_ga", "sipp"), ("soft_ga", "sipp")], protocol["development"]
        )
    elif args.phase == "routing":
        method = dispatch["selected"].split("/")[0]
        selection = select(
            rows,
            [(method, r) for r in ("sipp", "astar", "aco")],
            protocol["development"],
        )
    else:
        print("VALIDATION COMPLETE", sum(r["valid"] for r in rows), "/", len(rows))
        return
    (ROOT / "results" / (args.phase + "-selection.json")).write_text(
        json.dumps(selection, indent=2), encoding="utf-8"
    )
    print("SELECTED", json.dumps(selection), flush=True)


if __name__ == "__main__":
    main()
