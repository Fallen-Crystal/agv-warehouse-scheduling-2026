"""Create a new portable directory and independently check every archived byte."""

import hashlib
import json
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUTPUTS = ROOT.parent.parent / "outputs"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    audit = json.loads((ROOT / "results/audit.json").read_text(encoding="utf-8"))
    replay = json.loads(
        (ROOT / "results/clean-replay.json").read_text(encoding="utf-8")
    )
    assert audit["runs"] == 68 and replay["exact_match"]
    target = OUTPUTS / "agv-simple-routing-20261024"
    archive = OUTPUTS / "AGV_Simple_Routing_20261024.zip"
    if target.exists() or archive.exists():
        raise FileExistsError("Refuse to overwrite delivered results")
    target.mkdir(parents=True)
    folders = ("src", "wepa", "adaptive", "simple", "data", "docs", "results", "tests")
    for folder in folders:
        shutil.copytree(
            ROOT / folder,
            target / folder,
            ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".ruff_cache"),
        )
    for filename in (
        "README.md",
        "NOTICE.md",
        "run_main.py",
        "run_simple.py",
        "study.py",
        "audit.py",
        "report.py",
        "package_study.py",
        "clean_replay.py",
    ):
        shutil.copy2(ROOT / filename, target / filename)
    files = {
        p.relative_to(target).as_posix(): sha(p)
        for p in sorted(target.rglob("*"))
        if p.is_file()
    }
    (target / "MANIFEST.sha256.json").write_text(
        json.dumps(files, indent=2), encoding="utf-8"
    )
    with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path in sorted(target.rglob("*")):
            if path.is_file():
                z.write(path, path.relative_to(OUTPUTS).as_posix())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(files) + 1
        for name, digest in files.items():
            assert sha(target / name) == digest
            assert (
                hashlib.sha256(z.read(target.name + "/" + name)).hexdigest() == digest
            )
    receipt = dict(
        directory=str(target),
        archive=str(archive),
        files=len(files),
        archive_sha256=sha(archive),
        bytes=archive.stat().st_size,
        zip_crc_verified=True,
        archived_hashes_verified=True,
    )
    (OUTPUTS / "AGV_Simple_Routing_20261024.receipt.json").write_text(
        json.dumps(receipt, indent=2), encoding="utf-8"
    )
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
