"""Portable audit bundle with old delivery and new proof scopes kept separate."""

import json
import shutil
import subprocess
import sys
import os
import zipfile
from common import ROOT, sha, write


def main():
    parent = ROOT.parent.parent / "outputs"
    target = parent / "agv-f-reference-audit-20261024"
    archive = parent / "AGV_F_Reference_Audit_20261024.zip"
    if target.exists() or archive.exists():
        raise FileExistsError("Refuse to overwrite delivery")
    shutil.copytree(
        ROOT,
        target,
        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".ruff_cache"),
    )
    env = {k: v for k, v in os.environ.items() if k != "PYTHONPATH"}
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONUTF8"] = "1"
    check = subprocess.run(
        [sys.executable, "-m", "unittest", "test_audit", "-q"],
        cwd=target,
        env=env,
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    (target / "results/delivered-tests.log").write_text(
        check.stdout + check.stderr, encoding="utf-8"
    )
    assert check.returncode == 0, check.stderr
    files = {
        p.relative_to(target).as_posix(): sha(p)
        for p in sorted(target.rglob("*"))
        if p.is_file()
    }
    write(target / "MANIFEST.sha256.json", files)
    with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in sorted(target.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(parent).as_posix())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        import hashlib

        for name, h in files.items():
            assert sha(target / name) == h
            assert hashlib.sha256(z.read(target.name + "/" + name)).hexdigest() == h
    receipt = dict(
        archive=str(archive),
        directory=str(target),
        sha256=sha(archive),
        bytes=archive.stat().st_size,
        files=len(files),
        delivered_tests_passed=8,
        full_new_replays_revalidated=57,
        old_formal_validation_trajectories_checked=36,
        zip_crc_and_hashes_verified=True,
        original_full_optimum_claimed=False,
    )
    write(parent / "AGV_F_Reference_Audit_20261024.receipt.json", receipt)
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
