"""Admissible, explicitly relaxed lower bounds; never a feasible optimum claim."""

from collections import defaultdict, deque
import heapq
from math import ceil

from common import BASE, ROOT, read, write, score
from wepa.data import build
from wepa.kernel import World


def hungarian(cost):
    """Integer square assignment; task subtours deliberately remain permitted."""
    n = len(cost)
    u, v, p, way = [0] * (n + 1), [0] * (n + 1), [0] * (n + 1), [0] * (n + 1)
    for i in range(1, n + 1):
        p[0], j0 = i, 0
        minimum, used = [float("inf")] * (n + 1), [False] * (n + 1)
        while True:
            used[j0] = True
            i0, delta, j1 = p[j0], float("inf"), 0
            for j in range(1, n + 1):
                if not used[j]:
                    cur = cost[i0 - 1][j - 1] - u[i0] - v[j]
                    if cur < minimum[j]:
                        minimum[j], way[j] = cur, j0
                    if minimum[j] < delta:
                        delta, j1 = minimum[j], j
            for j in range(n + 1):
                if used[j]:
                    u[p[j]] += delta
                    v[j] -= delta
                else:
                    minimum[j] -= delta
            j0 = j1
            if p[j0] == 0:
                break
        while True:
            j1 = way[j0]
            p[j0] = p[j1]
            j0 = j1
            if j0 == 0:
                break
    pairs = [(p[j] - 1, j - 1) for j in range(1, n + 1)]
    return sum(cost[i][j] for i, j in pairs), pairs


def cardinality_costs(matrix):
    """Min-cost rectangular matching for every cardinality 1..n."""
    left, right = len(matrix), len(matrix[0])
    size = left + right + 2
    source = size - 2
    sink = size - 1
    graph = [[] for _ in range(size)]

    def add(a, b, cost):
        graph[a].append([b, len(graph[b]), 1, cost])
        graph[b].append([a, len(graph[a]) - 1, 0, -cost])

    for i in range(left):
        add(source, i, 0)
        for j in range(right):
            if matrix[i][j] < 10**9:
                add(i, left + j, matrix[i][j])
    for j in range(right):
        add(left + j, sink, 0)
    potential = [0] * size
    total = 0
    values = []
    for _ in range(right):
        distance = [float("inf")] * size
        distance[source] = 0
        parent = {}
        queue = [(0, source)]
        while queue:
            d, a = heapq.heappop(queue)
            if d != distance[a]:
                continue
            for k, (b, reverse, capacity, cost) in enumerate(graph[a]):
                child = d + cost + potential[a] - potential[b]
                if capacity and child < distance[b]:
                    distance[b] = child
                    parent[b] = (a, k)
                    heapq.heappush(queue, (child, b))
        if sink not in parent:
            raise ValueError("Insufficient matching capacity")
        for i, d in enumerate(distance):
            if d < float("inf"):
                potential[i] += d
        a = sink
        while a != source:
            previous, k = parent[a]
            edge = graph[previous][k]
            total += edge[3]
            edge[2] -= 1
            graph[a][edge[1]][2] += 1
            a = previous
        values.append(total)
    return values


class RelaxedGeometry:
    """Remove traffic, terminal-transit and foreign-home restrictions only."""

    def __init__(self, scene):
        self.scene, self.cache = scene, {}

    def distances(self, sources):
        key = tuple(sorted(set(map(tuple, sources))))
        if key not in self.cache:
            distance = {p: 0 for p in key}
            queue = deque(key)
            while queue:
                p = queue.popleft()
                for q in self.scene.neighbors(p):
                    if q not in distance:
                        distance[q] = distance[p] + 1
                        queue.append(q)
            self.cache[key] = distance
        return self.cache[key]

    def between(self, a, b):
        distance = self.distances(a)
        return min(distance.get(tuple(p), float("inf")) for p in b)


def lower_bound(model):
    jobs, slots, m = model["tasks"], model["slots"], model["vehicles"]
    world = World(model)
    world.publish_and_complete()
    fixed = dict(world.bound)
    kinds = defaultdict(set)
    bay_skus = defaultdict(set)
    for j in jobs:
        kinds[j["sku"]].add(j["kind"])
    for s in slots:
        bay_skus[s["bay"]].add(s["sku"])
    for sku, directions in kinds.items():
        if len(directions) != 1 or any(
            len(bay_skus[s["bay"]]) != 1 for s in slots if s["sku"] == sku
        ):
            continue
        kind = next(iter(directions))
        available = [
            s
            for s in slots
            if s["sku"] == sku
            and ((s["id"] in model["occupied"]) == (kind == "retrieval"))
        ]
        available.sort(
            key=lambda s: (s["bay"], -s["level"] if kind == "retrieval" else s["level"])
        )
        requests = sorted(
            (j for j in jobs if j["sku"] == sku), key=lambda j: (j["release"], j["id"])
        )
        if len(available) < len(requests):
            continue
        for j, s in zip(requests, available):
            fixed[j["id"]] = s["id"]
    geometry = RelaxedGeometry(model["scene"])
    options, pickup, drop, loaded, processing, earliest, ps_min, ds_min = (
        {},
        [],
        [],
        [],
        [],
        [],
        [],
        [],
    )
    for job in jobs:
        available = (
            [slots[fixed[job["id"]]]]
            if job["id"] in fixed
            else [s for s in slots if s["sku"] == job["sku"]]
        )
        choices = []
        for slot in available:
            for point in slot["points"]:
                if job["kind"] == "delivery":
                    a, b, ps, ds = job["port"], point, 1, 2 * slot["level"]
                else:
                    a, b, ps, ds = point, job["port"], 2 * slot["level"], 1
                d = geometry.between([a], [b])
                start = geometry.between(model["scene"].homes[:m], [a])
                choices.append(
                    (
                        tuple(a),
                        tuple(b),
                        ps,
                        ds,
                        d,
                        max(job["release"], start) + d + ps + ds,
                    )
                )
        options[job["id"]] = choices
        pickup.append({c[0] for c in choices})
        drop.append({c[1] for c in choices})
        loaded.append(min(c[4] for c in choices))
        processing.append(min(c[2] + c[3] + c[4] for c in choices))
        earliest.append(min(c[5] for c in choices))
        ps_min.append(min(c[2] for c in choices))
        ds_min.append(min(c[3] for c in choices))
    # Fixed t=0 outbound bay chains are binding in the real physical WMS.
    chains = defaultdict(list)
    for i, job in enumerate(jobs):
        if job["id"] in fixed and job["kind"] == "retrieval":
            chains[slots[fixed[job["id"]]]["bay"]].append(i)
    for indices in chains.values():
        last_pick = 0
        for i in sorted(indices, key=lambda i: -slots[fixed[jobs[i]["id"]]]["level"]):
            last_pick = max(last_pick, jobs[i]["release"]) + ps_min[i]
            earliest[i] = max(earliest[i], last_pick + loaded[i] + ds_min[i])
    homes = [{tuple(p)} for p in model["scene"].homes[:m]]
    starts, ends = pickup + homes, drop + homes
    n = len(jobs)
    costs = []
    for i in range(n + m):
        costs.append(
            [
                10**9 if i == j and i < n else geometry.between(ends[i], starts[j])
                for j in range(n + m)
            ]
        )

    def work_matching(indices):
        # At most m first group tasks have approach movement before its release.
        # Grant m free incoming legs. Every later group task on each car has a
        # predecessor ending after that release. Its approach is interval work.
        matrix = [[costs[i][j] + processing[j] for j in indices] for i in range(n + m)]
        matrix += [[processing[j] for j in indices] for _ in range(m)]
        return cardinality_costs(matrix)

    groups = defaultdict(list)
    for i, job in enumerate(jobs):
        groups[job["release"]].append(i)
    flow_lb = 0
    for release, indices in groups.items():
        p = sorted(processing[i] for i in indices)
        prefix = 0
        necessary = []
        work = work_matching(indices)
        e = sorted(earliest[i] - release for i in indices)
        for k, value in enumerate(p, 1):
            prefix += value
            necessary.append(
                max(
                    e[k - 1],
                    value,
                    ceil(prefix / m),
                    ceil(k / m) * p[0],
                    ceil(work[k - 1] / m),
                )
            )
        flow_lb += max(sum(earliest[i] - release for i in indices), sum(necessary))
    t_lb = max(earliest, default=0)
    for release in groups:
        tail = [i for i, j in enumerate(jobs) if j["release"] >= release]
        t_lb = max(t_lb, release + ceil(work_matching(tail)[-1] / m))
    empty_lb, pairs = hungarian(costs)
    d_lb = sum(loaded) + empty_lb
    return dict(
        T=t_lb,
        R=flow_lb / max(1, n),
        D=d_lb,
        loaded_distance=sum(loaded),
        empty_assignment_lb=empty_lb,
        initial_fixed_slots=fixed,
        processing_lb=processing,
        individual_completion_lb=earliest,
        loaded_per_job=loaded,
        pickup_service_lb=ps_min,
        drop_service_lb=ds_min,
        pickup_sets=[sorted(p) for p in pickup],
        drop_sets=[sorted(p) for p in drop],
        empty_assignment=pairs,
        relaxations=[
            "free future information",
            "variable same-SKU slots for not-yet-bound jobs",
            "no stock/traffic waits except fixed initial outbound service chain",
            "all free cells including terminals/homes traversable",
            "empty movement assignment permits subtours and depot exchange",
            "m free prepositions per release group; exact cardinality matching relaxes subsequent incoming work",
            "component minima need not be jointly attainable",
        ],
    )


def main():
    protocol = read(BASE / "data/simple-protocol.json")
    rows = read(BASE / "results/validation/runs.json")
    results = []
    for case in protocol["cases"]:
        if case["case"] not in protocol["validation"]:
            continue
        lb = lower_bound(build(case))
        ref = next(
            r for r in rows if r["case"] == case["case"] and r["method"] == "fcfs"
        )
        lb["F"] = score(lb, ref)
        candidates = []
        for row in rows:
            if row["case"] != case["case"] or not row["valid"]:
                continue
            assert all(lb[k] <= row[k] + 1e-9 for k in ("T", "R", "D", "F")), (
                case["case"],
                row,
                lb,
            )
            candidates.append(
                dict(
                    method=row["method"],
                    router=row["router"],
                    seed=row["seed"],
                    F=row["F"],
                    gap_upper_bound_pct=100 * (row["F"] / lb["F"] - 1),
                    potential_reduction_upper_bound_pct=100 * (1 - lb["F"] / row["F"]),
                )
            )
        results.append(
            dict(
                case=case["case"],
                tasks=len(case["tasks"]),
                lower_bound=lb,
                candidates=candidates,
                reference={k: ref[k] for k in ("T", "R", "D")},
            )
        )
        print(case["case"], lb["F"], flush=True)
    write(ROOT / "results/lower-bounds.json", results)


if __name__ == "__main__":
    main()
