"""Post-hoc diagnosis only: never commit probe candidates or retune a method."""

import json
from common import BASE, ROOT, read, write
from wepa.data import build
from wepa.kernel import World
from wepa.proxy import MixedCosts
from wepa.search import values, rank_score
from simple.policy import SimplePolicy
from simple.genetic import candidates
from simple.routing import make_router
from simple.shadow import snapshot, rollout


def main():
    protocol = read(BASE / "data/simple-protocol.json")
    reports = []
    for case in protocol["cases"]:
        if case["case"] not in protocol["validation"]:
            continue
        w = World(build(case))
        w.route_kind, w.route_seed = "sipp", 0
        w.router = make_router(w.scene)
        policy = SimplePolicy("soft_ga", 0)
        while w.time < 10000:
            w.publish_and_complete()
            free = any(r is None for r in w.active)
            ready = w.ready()
            if free and ready and len(set(w.visible) - w.assigned) >= 6:
                break
            if free and ready:
                pairs = policy.action(w)
                if pairs:
                    w.decisions.append(
                        dict(time=w.time, pairs=pairs, visible_ids=sorted(w.visible))
                    )
            w.advance()
        else:
            raise ValueError("No predeclared probe state")
        formal = read(
            BASE / f"results/validation/traces/{case['case']}-soft_ga-sipp-s0.json"
        )["result"]
        assert json.loads(json.dumps(w.decisions)) == [
            d for d in formal["decisions"] if d["time"] < w.time
        ]
        view = snapshot(w)
        base, usage = rollout(view)
        if base is None:
            raise ValueError("No complete visible anchor")
        pending = set(view.tasks) - view.assigned
        records = sorted(
            (r for r in base.records if r["task"] in pending),
            key=lambda r: (r["assigned_at"], r["vehicle"], r["task"]),
        )
        order = [r["task"] for r in records]
        owners = {r["task"]: r["vehicle"] for r in records}
        costs = MixedCosts(view, base)
        plans, activity = candidates(
            costs, order, owners, soft=True, seed=view.time + sum(order)
        )
        count = len(plans)
        indices = sorted(
            set(
                list(range(min(8, count)))
                + list(range(count // 2, min(count, count // 2 + 4)))
                + list(range(max(0, count - 4), count))
            )
        )
        real_scale = values(base)
        proxy_scale = costs.estimate_joint(order, owners)
        details = []
        for index in indices:
            o, a, kind = plans[index]
            predicted = costs.estimate_joint(o, a)
            trial, used = rollout(view, (o, a))
            details.append(
                dict(
                    proxy_rank=index + 1,
                    order=o,
                    owners=a,
                    proxy_score=rank_score(predicted, proxy_scale),
                    proxy_common_scale=rank_score(predicted, real_scale),
                    complete=trial is not None,
                    physical_score=rank_score(values(trial), real_scale)
                    if trial
                    else None,
                    usage=used,
                )
            )
        complete = [d for d in details if d["complete"]]
        pairs = discordant = ties = 0
        for i, a in enumerate(complete):
            for b in complete[i + 1 :]:
                if (
                    abs(a["proxy_score"] - b["proxy_score"]) < 1e-10
                    or abs(a["physical_score"] - b["physical_score"]) < 1e-10
                ):
                    ties += 1
                    continue
                pairs += 1
                discordant += (a["proxy_score"] - b["proxy_score"]) * (
                    a["physical_score"] - b["physical_score"]
                ) < 0
        best = (
            min(complete, key=lambda d: (d["physical_score"], d["proxy_rank"]))
            if complete
            else None
        )
        top_two = [d for d in complete if d["proxy_rank"] <= 2]
        top_score = min([1.0] + [d["physical_score"] for d in top_two])
        full_score = min([1.0] + [d["physical_score"] for d in complete])
        record = dict(
            case=case["case"],
            time=w.time,
            pending=len(pending),
            visible=len(view.tasks),
            prefix_matches_formal=True,
            actual_publisher_closed=w.closed,
            anchor_usage=usage,
            activity=activity,
            candidate_count=count,
            selected_ranks=[i + 1 for i in indices],
            candidates=details,
            best_sampled_proxy_rank=best["proxy_rank"] if best else None,
            best_visible_score=full_score,
            top_two_or_anchor_score=top_score,
            missed_visible_improvement_pct=100 * (1 - full_score / top_score),
            ranking_pairs=pairs,
            discordant_pairs=discordant,
            tied_pairs=ties,
            discordance_rate=discordant / pairs if pairs else None,
            scope="one predeclared visible-state probe; no new dispatch or final-stream improvement claim",
        )
        reports.append(record)
        print(
            case["case"],
            record["time"],
            record["best_sampled_proxy_rank"],
            record["missed_visible_improvement_pct"],
            flush=True,
        )
    write(ROOT / "results/probes.json", reports)


if __name__ == "__main__":
    main()
