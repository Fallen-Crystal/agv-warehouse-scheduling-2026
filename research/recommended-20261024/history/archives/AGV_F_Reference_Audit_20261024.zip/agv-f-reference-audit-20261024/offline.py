"""One CP incumbent per case, physically redecoded; explicitly uses future jobs."""

from unittest.mock import patch

from common import BASE, ROOT, read, write, score
from wepa.data import build
from wepa.check import validate
from wepa.search import owned_batch
from simple.runner import run
from agv.planning.astar import Router
from bounds import hungarian


class Plan:
    def __init__(self, order, owners):
        self.order, self.owners, self.logs = order, owners, []

    def action(self, world):
        return owned_batch(world, self.order, self.owners)


def main():
    protocol = read(BASE / "data/simple-protocol.json")
    cases = {c["case"]: c for c in protocol["cases"]}
    results = []
    folder = ROOT / "results/offline-traces"
    folder.mkdir(exist_ok=False)
    for cp in read(ROOT / "results/cp-bounds.json"):
        if "selected_arcs" not in cp:
            continue
        case = cases[cp["case"]]
        model = build(case)
        n = len(case["tasks"])
        m = model["vehicles"]
        arcs = cp["selected_arcs"]
        next_node = {a: b for a, b in arcs if a != 0}
        routes = []
        for first in sorted(b for a, b in arcs if a == 0):
            route = []
            current = first
            while current != 0:
                route.append(current - 1)
                current = next_node[current]
                if len(route) > n:
                    raise ValueError("Non-depot subtour")
            routes.append(route)
        assert sorted(i for r in routes for i in r) == list(range(n))
        from bounds import lower_bound

        lb = lower_bound(model)
        router = Router(model["scene"])
        costs = []
        for k in range(m):
            home = model["scene"].homes[k]
            row = []
            for route in routes:
                row.append(
                    int(
                        min(
                            router.distance(home, tuple(p), k)
                            for p in lb["pickup_sets"][route[0]]
                        )
                        + min(
                            router.distance(tuple(p), home, k)
                            for p in lb["drop_sets"][route[-1]]
                        )
                    )
                )
            row.extend([0] * (m - len(routes)))
            costs.append(row)
        _, pairs = hungarian(costs)
        owners = {}
        for car, route in pairs:
            if route < len(routes):
                for i in routes[route]:
                    owners[model["tasks"][i]["id"]] = car
        indices = sorted(range(n), key=lambda i: (cp["pickup_times"][i], i))
        order = [model["tasks"][i]["id"] for i in indices]
        with patch("simple.runner.SimplePolicy", return_value=Plan(order, owners)):
            result = run(model, "simple_ga")
        result["method"] = "offline_cp_plan_sipp_decode"
        audit = validate(model, result) if result["valid"] else {"valid": False}
        value = score(result, cp["formal_reference"]) if audit["valid"] else None
        row = dict(
            case=cp["case"],
            valid=audit["valid"],
            F=value,
            T=result["T"],
            R=result["R"],
            D=result["D"],
            knows_future=True,
            online_algorithm=False,
            compared_to_best_existing=cp["best_real_incumbent"],
            improvement_over_best_existing_pct=100
            * (1 - value / cp["best_real_incumbent"])
            if value
            else None,
            scope="one deterministic SIPP decoding of solver best relaxed plan; not its claimed relaxed F",
        )
        write(
            folder / (case["case"] + ".json"),
            dict(row=row, order=order, owners=owners, result=result, audit=audit),
        )
        results.append(row)
        print(row, flush=True)
    write(ROOT / "results/offline.json", results)


if __name__ == "__main__":
    main()
