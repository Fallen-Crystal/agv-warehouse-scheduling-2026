"""Split forecast travel at task completion to inspect the final-return proxy."""

import json
from unittest.mock import patch

from paths import ROOT, BASE
from diagnose import replay_prefix
from objective import LinearObjective
from v2.policy import LinearPolicy
from v2.shadow import snapshot, rollout
from wepa.data import build
from wepa.search import values
from wepa.shadow import ShadowWorld


def main():
    protocol = json.loads((ROOT / "data/protocol.json").read_text(encoding="utf-8"))
    case = next(c for c in protocol["cases"] if c["case"] == "wepa-day45-bin4335")
    recorded = json.loads((BASE / "results/linear/traces/wepa-day45-bin4335-soft_ga-sipp-s0.json").read_text())["result"]
    w = replay_prefix(build(case, **protocol["configuration"]), recorded, 521)
    view = snapshot(w)
    objective = LinearObjective(**protocol["objective"])
    policy = LinearPolicy(seed=0, objective=objective)
    policy.search(view)
    parts = []
    # Disable only the forecast acceleration to retain every forecast path tick.
    with patch.object(ShadowWorld, "jump_quiet", return_value=False):
        for kind, plan in (("eta_anchor", None), ("chosen_ga", policy.plan)):
            trial, usage = rollout(view, plan)
            t, flow, distance = values(trial)
            local_t = t - view.time
            before_finish = sum(a != b for path in trial.history
                                for a, b in zip(path[:local_t + 1], path[1:local_t + 1]))
            tail = sum(a != b for path in trial.history
                       for a, b in zip(path[local_t:], path[local_t + 1:]))
            if distance != view.past_moves + before_finish + tail:
                raise ValueError("Forecast distance decomposition differs")
            parts.append(dict(kind=kind, T=t, R=flow, D=distance,
                              past_distance=view.past_moves,
                              distance_until_last_visible_completion=before_finish,
                              distance_after_visible_completion=tail,
                              prediction_end=trial.time, usage=usage))
    a,b=parts
    output=dict(case=case["case"],time=521,prefix_exact=True,parts=parts,
                saved_distance_until_visible_completion=a["distance_until_last_visible_completion"]-b["distance_until_last_visible_completion"],
                saved_tail_return_distance=a["distance_after_visible_completion"]-b["distance_after_visible_completion"],
                scope="Diagnostic only: both forecasts close the visible prefix; actual stream still has 15 unreleased jobs")
    (ROOT / "results/forecast-tail-probe.json").write_text(json.dumps(output,indent=2),encoding="utf-8")
    print(json.dumps(output),flush=True)


if __name__=="__main__":
    main()
