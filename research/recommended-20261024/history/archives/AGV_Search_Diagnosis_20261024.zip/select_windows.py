"""Reproduce the input-only held-out selection from the pinned source files."""

import argparse
from collections import Counter,defaultdict
import hashlib
import json
from pathlib import Path

from paths import ROOT


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--raw',type=Path,required=True,
                   help='Folder containing original 2_orders.json and 3_initial_fill_lvl.json')
    args=p.parse_args()
    protocol=json.loads((ROOT/'data/protocol.json').read_text(encoding='utf-8'))
    source=args.raw/'2_orders.json'
    if hashlib.sha256(source.read_bytes()).hexdigest()!=protocol['source_sha256']:
        raise ValueError('Pinned raw source differs')
    rows=json.loads(source.read_text(encoding='utf-8'))
    stock=Counter({int(k):v for k,v in json.loads((args.raw/'3_initial_fill_lvl.json').read_text()).items()})
    bins=defaultdict(list)
    for i,row in enumerate(rows):
        bins[row[2]//900].append((i,row))
    selected=[]
    days=set()
    for bucket,entries in bins.items():
        day=bucket//96
        kinds=Counter(r[0] for _,r in entries)
        skus=sorted({r[1] for _,r in entries})
        if (day>69 and day not in days and 35<=len(entries)<=65 and 2<=len(skus)<=5
            and len(kinds)==2 and min(kinds.values())>=5
            and 0<=sum(stock[s] for s in skus)<=900 and all(stock[s]>=0 for s in skus)):
            tasks=[dict(id=j,source_row=i,kind=r[0],sku=r[1],release=r[2]-bucket*900,
                        source_time=r[2],source_dock=r[3],batch=r[4],week=r[5])
                   for j,(i,r) in enumerate(entries)]
            ledger=Counter({s:stock[s] for s in skus})
            for t in tasks:
                ledger[t['sku']]+=1 if t['kind']=='delivery' else -1
            if all(v>=0 for v in ledger.values()):
                selected.append(dict(case=f'wepa-day{day}-bin{bucket}',source_day=day,
                    source_bin=bucket,start_seconds=bucket*900,end_seconds=(bucket+1)*900,
                    close_at=900,initial={str(s):stock[s] for s in skus},tasks=tasks))
                days.add(day)
                if len(selected)==4:
                    break
        for _,r in entries:
            stock[r[1]]+=1 if r[0]=='delivery' else -1
    expected=[c for c in protocol['cases'] if c['case'] in protocol['validation']]
    if selected!=expected:
        raise ValueError('Input-only selection differs from frozen cases')
    print(json.dumps(dict(input_only_selection_verified=True,cases=protocol['validation'])))


if __name__=='__main__':
    main()
