"""New-objective optimal references for six explicitly reduced static cases."""

from fractions import Fraction
import json
from unittest.mock import patch

from paths import ROOT
from exact_reference import solve
from improved.execute import run
from objective import LinearObjective, checked_score
from wepa.data import build
from wepa.search import owned_batch


class FixedPolicy:
    def __init__(self, order):
        self.order, self.logs = order, []

    def action(self, world):
        return owned_batch(world, self.order, {j:0 for j in self.order})


def rational_score(result, objective):
    n=len(result['records'])
    return (Fraction(str(objective.weights[0]))*result['T']/Fraction(str(objective.scales[0]))
        +Fraction(str(objective.weights[1]))*sum(r['end'] for r in result['records'])/(n*Fraction(str(objective.scales[1])))
        +Fraction(str(objective.weights[2]))*result['D']/Fraction(str(objective.scales[2])))


def main():
    protocol=json.loads((ROOT/'data/protocol.json').read_text(encoding='utf-8'))
    selection=json.loads((ROOT/'results/selection.json').read_text(encoding='utf-8'))
    selected=selection['selected']
    objective=LinearObjective(vehicles=1)
    records=[]
    traces=ROOT/'results/exact-traces'
    traces.mkdir(exist_ok=False)
    for original in protocol['cases'][:3]:
        group=None
        for j in original['tasks']:
            if j['kind']!='retrieval': continue
            g=[t for t in original['tasks'] if t['kind']=='retrieval' and
               (t['release'],t['batch'],t['week'])==(j['release'],j['batch'],j['week'])]
            if len(g)==33:
                group=g; break
        if group is None:
            raise ValueError('Expected source batch missing')
        for n in (4,8):
            case=dict(original,case=original['case']+f'-onecar-static-{n}',close_at=0,
                      tasks=[dict(t,release=0) for t in group[:n]])
            model=build(case,vehicles=1)
            exact=solve(model,objective)
            with patch('improved.execute.ResearchPolicy',return_value=FixedPolicy(exact['order'])):
                best=run(model,'gate',objective=objective)
            if rational_score(best,objective)!=Fraction(exact['numerator'],exact['denominator']):
                raise ValueError('Exact route does not realize exact objective')
            all_rows=[]
            for profile,result in [('exact_dp',best)]+[(p,run(model,p,objective=objective))
                                                    for p in ('eta','simple',selected)]:
                score=checked_score(model,result,objective)
                value=rational_score(result,objective)
                if value<Fraction(exact['numerator'],exact['denominator']):
                    raise ValueError('Heuristic contradicts the exact reference')
                row=dict(profile=profile,F=float(value),
                         gap_percent=100*(float(value)/exact['F']-1),
                         T=result['T'],R=result['R'],D=result['D'])
                all_rows.append(row)
                target=traces/f'{case["case"]}-{profile}.json'
                target.write_text(json.dumps(dict(case=case,result=result,scoring=score,
                                                  row=row,proof=exact if profile=='exact_dp' else None)),encoding='utf-8')
            records.append(dict(case=case['case'],origin=original['case'],
                                source_batch_size=33,subset_size=n,vehicles=1,
                                release_set_to_zero=True,proof=exact,rows=all_rows))
            (ROOT/'results/exact.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
            print(json.dumps(records[-1]),flush=True)


if __name__=='__main__':
    main()
