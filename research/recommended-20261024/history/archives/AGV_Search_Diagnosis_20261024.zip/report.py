"""Audit all evidence and report development and untouched validation separately."""

import csv
from collections import defaultdict
import io
import json
from statistics import mean

from paths import ROOT, BASE, hashes, sha, verify_baseline
from objective import LinearObjective, checked_score
from wepa.data import build


def read(p):
    return json.loads(p.read_text(encoding="utf-8"))


def grouped(rows):
    groups=defaultdict(list)
    for row in rows:
        groups[row['case'],row['profile']].append(row)
    keys=('F','J','T','R','D','cpu','p90','empty_distance','traffic_wait')
    return {key:{k:mean(r[k] for r in values) for k in keys}
            for key,values in groups.items()}


def summarize(rows,cases,profiles):
    groups=grouped(rows)
    result={}
    for profile in profiles:
        result[profile]={k:mean(groups[c,profile][k] for c in cases)
                         for k in ('F','J','T','R','D','cpu','p90','empty_distance','traffic_wait')}
    return result,groups


def comparisons(groups,cases,profile,reference):
    values=[dict(case=c,gain_percent=100*(groups[c,reference]['F']-groups[c,profile]['F'])/groups[c,reference]['F'])
            for c in cases]
    return dict(mean_paired_gain_percent=mean(r['gain_percent'] for r in values),
                worse_cases=[r['case'] for r in values if r['gain_percent'] < -1e-10],
                paired=values)


def main():
    protocol=read(ROOT/'data/protocol.json')
    selection=read(ROOT/'results/selection.json')
    selected=selection['selected']
    if selection['source']!=hashes():
        raise ValueError('Selected implementation changed after freeze')
    dev=read(ROOT/'results/dev-components/runs.json')+read(ROOT/'results/dev-guided/runs.json')
    val=read(ROOT/'results/validation/runs.json')
    if len(dev)!=24 or len(val)!=24 or not all(r['valid'] for r in dev+val):
        raise ValueError('All planned executions are required; no dropping failures')
    cached=read(BASE/'results/linear/runs.json')
    base=[]
    for r in cached:
        profile='simple' if r['method']=='soft_ga' else r['method']
        base.append(dict(r,profile=profile,F=r['F_linear_v2'],J=r['J_equivalent_seconds'],cpu=r['solve_cpu']))
    all_dev=base+dev
    profiles=[r['profile'] for r in selection['rankings']]+['eta','fcfs']
    ds,dg=summarize(all_dev,protocol['development'],profiles)
    vs,vg=summarize(val,protocol['validation'],('simple',selected,'eta','fcfs'))
    audited=[]
    for phase in ('baseline-replay','dev-components','dev-guided','validation'):
        before=read(ROOT/f'results/{phase}/phase-before.json')
        snapshot_name='components' if phase in ('baseline-replay','dev-components') else 'selected'
        for name,expected in before['source'].items():
            if sha(ROOT/'results/source-phases'/snapshot_name/name)!=expected:
                raise ValueError('Historical phase source snapshot differs')
        for row in read(ROOT/f'results/{phase}/runs.json'):
            data=read(ROOT/row['trace'])
            if data['implementation_sha256']!=before['source']:
                raise ValueError('Execution source differs from phase freeze')
            model=build(data['case'],**protocol['configuration'])
            score=checked_score(model,data['result'],LinearObjective(**protocol['objective']))
            if score!=data['scoring'] or score['F_linear_v2']!=row['F']:
                raise ValueError('Physical metrics or fitness mismatch')
            audited.append(row['trace'])
    exact=read(ROOT/'results/exact.json')
    exact_traces=[]
    for path in sorted((ROOT/'results/exact-traces').glob('*.json')):
        data=read(path)
        score=checked_score(build(data['case'],vehicles=1),data['result'],LinearObjective(vehicles=1))
        if score!=data['scoring']:
            raise ValueError('Exact-case trace audit differs')
        exact_traces.append(path.relative_to(ROOT).as_posix())
    counts=dict(development_new_executions=24,baseline_reproduction=1,
                validation_executions=24,validation_scenarios=4,validation_advanced_seeds=2,
                small_exact_scenarios=6,small_exact_executions=len(exact_traces),
                physically_revalidated=len(audited)+len(exact_traces),
                baseline_files_unchanged=verify_baseline(),source_unchanged_since_selection=True)
    comparisons_dev={r:comparisons(dg,protocol['development'],selected,r) for r in ('simple','eta','fcfs')}
    comparisons_val={r:comparisons(vg,protocol['validation'],selected,r) for r in ('simple','eta','fcfs')}
    output=dict(selected=selected,objective=protocol['objective'],development=ds,
                validation=vs,development_comparisons=comparisons_dev,
                validation_comparisons=comparisons_val,counts=counts,
                exact=exact,selection_changed_after_validation=False,
                optimality_claim='Only the explicitly reduced one-car closed static cases; no full dynamic optimum claim')
    (ROOT/'results/summary.json').write_text(json.dumps(output,indent=2),encoding='utf-8')
    (ROOT/'results/revalidation.json').write_text(json.dumps(dict(physical=audited,exact=exact_traces),indent=2),encoding='utf-8')
    stream=io.StringIO(newline='')
    fields=['split','case','profile','seed','F','J','T','R','D','p90','empty_distance','traffic_wait','cpu']
    writer=csv.DictWriter(stream,fields,extrasaction='ignore',lineterminator='\n')
    writer.writeheader()
    writer.writerows(dict(r,split='development') for r in all_dev)
    writer.writerows(dict(r,split='validation') for r in val)
    (ROOT/'results/comparison.csv').write_text(stream.getvalue(),encoding='utf-8-sig')
    lines=['# 简化版诊断与改善报告（2026-10-24）','',
           '## 结论与范围','',
           f'按开发集预先选择并冻结的方案为`{selected}`：订单流尚未关闭且低负载时即时匹配；积压时采用扩预算的联合GA（订单顺序＋车辆归属）与SIPP完整试排。验证后未重新挑方案。',
           '评价公式、地图、库存、层序、待命、最终返库和独立验解规则保持不变。全部比较使用独立线性目标，不含任何算法作分母。',
           '', '## 已定位的问题','',
           '1. 简化同时压缩了GA评估与完整试排预算。wide只放宽这组资源限制，在四个开发窗口中的前三个改善，末例不变。此对照证明该预算组整体有影响，尚未把代数与试排个数的独立作用完全分开。',
           '2. 简化删除了低负载分支。精确重放第45日时刻521：两辆车空闲，算法仍等待到522才空闲的另一辆车。可见任务预测认为T从605降至604、距离从1324降至1286格，但实际还有15单未出现。预测局部改进不能保证后续动态状态更好。恢复即时匹配使该窗口F从0.646266降至0.643380，但仍略差于ETA的0.642782；没有伪称完全消除退化。',
           '3. 简单增加环节未必改善。恢复旧顺序GA＋修复框架、多初始解、局部扰动种群都实际执行；总体未胜过开发集选中的方案，负面结果完整保留。restored只恢复旧框架的匹配、顺序GA、邻域修复三项，保持本轮共同的64步完成触发并统一新目标，不是原旧版所有逻辑的逐字节重跑。',
           '4. 对第12/33日首个大批量决策各抽检12个既有候选，本轮没有发现截断外更好的候选。不能把候选代理排序错误直接定为主因，也不能凭两次抽检证明排序在所有场景都准确。',
           '5. 有空车和可立即执行任务却未派单的时刻，在原四个窗口分别为102/105/31/1。等待本身允许且可能有益；这些是机会记录，不是可直接消除的延误。',
           '', '## 开发集：四个既有窗口，种子0','',
           '|方案|平均F|T秒|R秒|D格|累计计算CPU秒/窗口|',
           '|---|---:|---:|---:|---:|---:|']
    for name in profiles:
        a=ds[name]
        lines.append(f'|{name}|{a["F"]:.6f}|{a["T"]:.2f}|{a["R"]:.2f}|{a["D"]:.2f}|{a["cpu"]:.2f}|')
    lines += ['', 'simple/ETA/FCFS开发集物理轨迹来自逐字节保留的上一版，simple另有一次完整精确复现。历史CPU与新阶段CPU仅作粗略参考；新窗口重新执行全部对照。',
              '', '## 新窗口验证：先在场景内平均两个种子，再按四个场景等权平均','',
              '|方案|平均F|T秒|R秒|D格|累计计算CPU秒/窗口|',
              '|---|---:|---:|---:|---:|---:|']
    for name,a in vs.items():
        lines.append(f'|{name}|{a["F"]:.6f}|{a["T"]:.2f}|{a["R"]:.2f}|{a["D"]:.2f}|{a["cpu"]:.2f}|')
    lines += ['', '|新窗口|相对简化版改善|相对ETA改善|相对FCFS改善|',
              '|---|---:|---:|---:|']
    for c in protocol['validation']:
        gains=[next(x['gain_percent'] for x in comparisons_val[r]['paired'] if x['case']==c)
               for r in ('simple','eta','fcfs')]
        lines.append(f'|{c}|{gains[0]:.3f}%|{gains[1]:.3f}%|{gains[2]:.3f}%|')
    lines += ['', '上述百分比是同场景成本之比的逐例平均，不与不同分母的旧F比较。每个先进方法是8次运行，但独立验证场景只有4个，不能说成24个未见场景。',
              f'相对简化版平均逐例改善：{comparisons_val["simple"]["mean_paired_gain_percent"]:.3f}%；相对ETA：{comparisons_val["eta"]["mean_paired_gain_percent"]:.3f}%；相对FCFS：{comparisons_val["fcfs"]["mean_paired_gain_percent"]:.3f}%。',
              f'相对简化版退化窗口：{", ".join(comparisons_val["simple"]["worse_cases"]) or "无"}；相对ETA退化窗口：{", ".join(comparisons_val["eta"]["worse_cases"]) or "无"}。',
              '不报告小样本统计显著性，不承诺未来订单流都改善；计算耗时为整窗口仿真累计CPU，不是每次派单的响应延迟，也不是实际AGV运行时间。',
              '', '## 新目标下的小规模精确检查','',
              '六个缩减静态单车问题的DP最优顺序均以原内核实际回放；全部合法排列交叉核对。简化版和选定版本均达到这六例最优。部分4单例只有一个合法顺序，不构成困难搜索证据。',
              '这说明基础实现能在所述小问题正确求解，不证明完整6车动态混合任务接近最优；原单车证明和新匹配的固定边精确性也不能扩展成多车路径全局证书。',
              '', '## 未改动及未解决','',
              '货架格提前锁定规则、原路径协调、通道宽度仍保持原样；没有证据把地图空白格宽度认定为主要原因。原货架锁比只锁装卸时段更保守，仍需独立建模讨论，不能把放宽规则混进算法收益。',
              '主实验仍局限大型地图、6车、5层、15分钟真实请求窗口；其他地图/车队规模未在本轮复测。库存是源请求前缀台账推算，不是原厂WIP测量。',
              '轻负载的默认匹配仍是固定预计边成本的即时指派。试验中的linear_matching纳入当前F取舍，但其完整guided_gate方案未胜开发集最佳，因此未按验证结果替换。',
              '完整试排仍对已知任务作有限需求预测。实际后续订单会改变车辆位置和预约状态，这是已经复现的局部风险；本轮没有单独改变预测终止条件作因果对照，因此不能认定它已解释全部剩余差距。',
              '扩大搜索在新窗口的收益小于开发集，且累计计算成本更高。结论应是得到一个有改善但仍有限的研究候选，不是已经获得满意的全局最优调度器。',
              '', '## 核验与文件','',
              f'新增完整执行共{counts["development_new_executions"]+counts["baseline_reproduction"]+counts["validation_executions"]+counts["small_exact_executions"]}次，已交付轨迹再次独立重验{counts["physically_revalidated"]}份；完整动态问题均只报告可行结果。',
              '逐项数据见results/comparison.csv；分阶段源码与哈希见results/source-phases及各phase-before.json；选择依据见results/selection.json；诊断探针见results/*probe*.json。',
              '文献借鉴与实现边界见docs/文献与借鉴边界.md；原基线目录完整保留，所有原文件哈希一致。','']
    (ROOT/'docs/诊断与改进报告.md').write_text('\n'.join(lines),encoding='utf-8')
    print(json.dumps(dict(selected=selected,validation=vs,comparisons=comparisons_val,counts=counts),ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
