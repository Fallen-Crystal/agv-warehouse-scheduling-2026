"""Revalidate traces and separate physical-objective results from comparisons."""

import csv
import io
import json
from statistics import mean

from bootstrap import ROOT, implementation_hashes, verify_engine
from objective import LinearObjective, checked_score
from wepa.data import build


def main():
    protocol = json.loads((ROOT / "data/protocol.json").read_text(encoding="utf-8"))
    cases = {c["case"]: c for c in protocol["cases"]}
    objective = LinearObjective(**protocol["objective"])
    runs = json.loads((ROOT / "results/linear/runs.json").read_text(encoding="utf-8"))
    if len(runs) != 12 or not all(r["valid"] for r in runs):
        raise ValueError("The complete predeclared twelve valid runs are required")
    frozen = json.loads((ROOT / "results/linear/implementation-before.json").read_text(encoding="utf-8"))
    if frozen != implementation_hashes():
        raise ValueError("Changed implementation")
    models = {name: build(case, **protocol["configuration"]) for name, case in cases.items()}
    validated = []
    for row in runs:
        data = json.loads((ROOT / row["trace"]).read_text(encoding="utf-8"))
        score = checked_score(models[row["case"]], data["result"], objective)
        if score != data["scoring"] or data["implementation_sha256"] != frozen:
            raise ValueError("Recorded score or implementation differs")
        if row["F_linear_v2"] != score["F_linear_v2"]:
            raise ValueError("Summary score differs")
        validated.append(row["trace"])
    controls = {r["case"]: r for r in runs if r["method"] == "fcfs"}
    eta = {r["case"]: r for r in runs if r["method"] == "eta"}
    for row in runs:
        ref = controls[row["case"]]
        row["improvement_vs_fcfs_percent"] = 100 * (ref["F_linear_v2"] - row["F_linear_v2"]) / ref["F_linear_v2"]
        ref = eta[row["case"]]
        row["improvement_vs_eta_percent"] = 100 * (ref["F_linear_v2"] - row["F_linear_v2"]) / ref["F_linear_v2"]
    groups = {}
    for method in protocol["methods"]:
        rows = [r for r in runs if r["method"] == method]
        groups[method] = {k: mean(r[k] for r in rows) for k in (
            "T", "R", "D", "F_linear_v2", "J_equivalent_seconds", "solve_cpu",
            "improvement_vs_fcfs_percent", "improvement_vs_eta_percent")}
    summary = dict(objective=objective.to_dict(), objective_sha256=objective.fingerprint,
                   mean_over_equal_weight_development_cases=groups,
                   executions=12, independently_revalidated=len(validated),
                   source_unchanged=implementation_hashes() == frozen,
                   unchanged_engine_files=verify_engine(),
                   all_valid=True, new_heldout_evidence=False, algorithm_reselected=False,
                   seed_count=1)
    (ROOT / "results/summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    (ROOT / "results/revalidation.json").write_text(json.dumps(dict(validated=validated), indent=2), encoding="utf-8")
    fields = ["case", "method", "seed", "T", "R", "D", "F_linear_v2", "J_equivalent_seconds",
              "improvement_vs_fcfs_percent", "improvement_vs_eta_percent", "p90", "empty_distance", "traffic_wait", "solve_cpu"]
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, fields, extrasaction="ignore")
    writer.writeheader()
    writer.writerows(runs)
    (ROOT / "results/comparison.csv").write_text(buffer.getvalue(), encoding="utf-8-sig")
    lines = ["# 线性目标迁移复核报告", "", "## 范围与结论边界", "",
             "本轮固定独立线性目标，复用4个开发窗口，每例FCFS、ETA、软分区GA各执行一次，均使用SIPP与种子0。12次执行全部完成，并由独立验解重建指标、复算评分。",
             "这是目标接口迁移复核，不是新留出测试，不是最优性证明；未调整权重、尺度或预算，未根据结果更换默认算法。",
             "", "`F_linear_v2 = 0.5T/900 + 0.3R/900 + 0.2D/5400`；`J = 900 F_linear_v2`。FCFS的F不再固定为1。",
             "", "## 四个窗口等权平均", "",
             "|算法|总完成时间T（秒）|平均订单耗时R（秒）|总距离D（格）|新F|等效成本J（秒）|平均计算秒数|",
             "|---|---:|---:|---:|---:|---:|---:|"]
    for method, r in groups.items():
        lines.append(f'|{method}|{r["T"]:.2f}|{r["R"]:.2f}|{r["D"]:.2f}|{r["F_linear_v2"]:.6f}|{r["J_equivalent_seconds"]:.2f}|{r["solve_cpu"]:.2f}|')
    lines += ["", "## 每个窗口的完整对照", "",
              "|窗口|算法|T|R|D|新F|相对FCFS改善|相对ETA改善|",
              "|---|---|---:|---:|---:|---:|---:|---:|"]
    for r in runs:
        lines.append(f'|{r["case"]}|{r["method"]}|{r["T"]}|{r["R"]:.3f}|{r["D"]}|{r["F_linear_v2"]:.6f}|{r["improvement_vs_fcfs_percent"]:.3f}%|{r["improvement_vs_eta_percent"]:.3f}%|')
    ga = groups["soft_ga"]
    worse_fcfs = [r["case"] for r in runs if r["method"] == "soft_ga" and r["improvement_vs_fcfs_percent"] < -1e-10]
    worse_eta = [r["case"] for r in runs if r["method"] == "soft_ga" and r["improvement_vs_eta_percent"] < -1e-10]
    lines += ["", "## 如何解释", "",
              f'软分区GA的平均逐例改善率为：相对FCFS {ga["improvement_vs_fcfs_percent"]:.3f}%，相对ETA {ga["improvement_vs_eta_percent"]:.3f}%。这与“两个方法平均F之比”的统计量不同；表中明确使用逐例配对比例再平均。',
              f'相对FCFS退化窗口：{", ".join(worse_fcfs) or "无"}；相对ETA退化窗口：{", ".join(worse_eta) or "无"}。',
              "负面结果完整保留。搜索基于ETA可行初始解、有限候选和滚动预测，不能保证整段真实执行优于FCFS或ETA；某次预测更好也不构成未来全局保证。",
              "只有一个种子和4个已用开发窗口，不报告统计显著性、泛化性、近似比或显著算法突破。",
              "", "## 实现检查", "",
              "- 代理排序、物理试排、单调下界剪枝、最终计分使用同一版本的固定目标；可行初始解不作为分母。",
              "- 保留96个代理评估、3次试排、每次512次路由调用限制。",
              f'- {summary["unchanged_engine_files"]}个原内核与运行依赖文件逐字节保持一致。执行前后实现和协议SHA256一致。',
              "- 最终评分前必须通过原独立验解。12条交付轨迹再次完整复核成功。",
              "- 三类路由、动态信息隔离、目标一致性和复现检查的详细测试日志见results/unit-tests.log。",
              "", "## 后续实验", "",
              "先确认该目标的业务取舍：主实验T减少1秒等价于15格总里程，R减少1秒等价于9格。若认可，固定协议后再开展算法消融、更多种子和未用订单窗口验证。",
              "旧的最优值/下界针对含FCFS分母的目标，不能沿用；需要针对新目标重新计算。新F数值低于旧F不代表任何收益。",
              "对照算法仅用于本报告的改善率列，独立评分函数不读取这些成绩。", ""]
    (ROOT / "docs/迁移复核报告.md").write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
