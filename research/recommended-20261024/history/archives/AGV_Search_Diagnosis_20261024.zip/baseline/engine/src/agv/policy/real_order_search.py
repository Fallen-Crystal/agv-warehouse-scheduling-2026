"""Optional history-aware visible-work search; no future reference denominator."""

from copy import deepcopy

from agv.planning.joint_meta import search
from agv.planning.joint_orders import JointCosts, neighbors
from agv.policy.f_portfolio import PortfolioSearch
from agv.policy.f_search import BatchDriver
from agv.policy.joint_orders import JointOrderPolicy, OwnedDriver
from agv.policy.routing_contract import RoutingOracle
from agv.warehouse.scenarios import Scenario


def visible_values(observation, prediction, past_moves):
    """Recombine observed completed history and a detached visible prediction."""
    completed = observation["completed_flow_times"]
    count = len(completed) + prediction["visible_task_count"]
    return (
        prediction["predicted_T"],
        (sum(completed) + prediction["flow_sum"]) / max(1, count),
        past_moves + prediction["additional_moves"],
    )


class _Priority:
    pure_empty_decisions = True

    def __init__(self, driver, priority):
        self.driver, self.priority = driver, priority

    def __call__(self, obs):
        return sorted(self.driver(obs), key=lambda pair: self.priority.index(pair[0]))


class RealOrderSearch(JointOrderPolicy):
    """Portfolio anchor plus bounded actual-SIPP neighborhood search.

    history: one pass with completed-history cost recombination.
    repair: two true-preview passes, recentering on the accepted plan.
    ensemble: rematching, neighborhoods, ACO/PSO and reservation priorities.
    All use at most candidate_budget extra true previews. Proxy work differs.
    """

    def __init__(
        self,
        *,
        world_factory,
        mode="repair",
        candidate_budget=8,
        optimizer_seed=0,
        reference_estimator=None,
    ):
        if mode not in ("history", "repair", "ensemble", "reference"):
            raise ValueError("Unknown real-demand search mode")
        if mode == "reference" and reference_estimator is None:
            raise ValueError("Released-only reference callback required")
        super().__init__(
            world_factory=world_factory,
            mode="assignment",
            candidate_budget=candidate_budget,
            optimizer_seed=optimizer_seed,
        )
        self.mode = mode
        self.past_moves, self.previous_time, self.previous_positions = 0, None, None
        self.reference_estimator, self.reference_scales, self.known_jobs = (
            reference_estimator,
            None,
            {},
        )

    def action(self, obs):
        for job in list(obs.get("pending", [])) + [
            v["active_task"] for v in obs["vehicles"] if v.get("active_task")
        ]:
            self.known_jobs[job["id"]] = deepcopy(job)
        # The sole runner observes every executed tick. Shadow rollouts invoke
        # stateless candidate drivers, never this stateful real-policy instance.
        positions = [tuple(v["position"]) for v in obs["vehicles"]]
        if self.previous_time is not None and obs["time"] != self.previous_time:
            if obs["time"] != self.previous_time + 1:
                raise ValueError("History odometer requires consecutive real observations")
            distances = [
                abs(a[0] - b[0]) + abs(a[1] - b[1])
                for a, b in zip(self.previous_positions, positions)
            ]
            if any(d > 1 for d in distances):
                raise ValueError("Observed motion violates four-neighbor ticks")
            self.past_moves += sum(distances)
        self.previous_time, self.previous_positions = obs["time"], positions
        return super().action(obs)

    def _search(self, obs):
        anchor = PortfolioSearch(world_factory=self.factory, optimizer_seed=self.seed)
        anchor.action(obs)
        incumbent = anchor.driver
        if incumbent is None:
            from agv.policy.joint_orders import _Fallback

            incumbent = _Fallback()
        oracle = RoutingOracle(obs, world_factory=self.factory, max_previews=self.budget + 1)
        base = oracle.evaluate(incumbent)
        self.driver = incumbent
        log = dict(
            time=obs["time"],
            mode=self.mode,
            baseline_decisions=anchor.decisions,
            candidates=[],
            past_moves=self.past_moves,
            completed_count=len(obs["completed_flow_times"]),
            score_scope="observed history plus visible workload, not unknown future F",
        )
        if not base.valid_complete:
            log["reason"] = "anchor_incomplete"
            self.decisions.append(log)
            return
        scales = [max(1, v) for v in visible_values(obs, base.data, self.past_moves)]
        if self.mode == "reference" and obs["order_stream_closed"]:
            if self.reference_scales is None:
                self.reference_scales = tuple(
                    self.reference_estimator(obs, deepcopy(self.known_jobs))
                )
            scales = self.reference_scales
            log["score_scope"] = (
                "exact final F after the observed publisher close; all tasks already released"
            )
        costs = JointCosts(obs, Scenario.from_observation_map(obs["map"], obs["horizon"]))
        pending = {j["id"] for j in obs["pending"]}
        seed = self.seed * 1000003 + obs["time"] + sum(pending)
        best = sum(
            w * v / s
            for w, v, s in zip(
                (0.5, 0.3, 0.2), visible_values(obs, base.data, self.past_moves), scales
            )
        )
        chosen, seen, proxy_evaluations = base, set(), 0
        rounds = 2 if self.mode in ("repair", "reference") else 1
        for round_index in range(rounds):
            records = sorted(
                (r for r in chosen.data["assignments"] if r["task_id"] in pending),
                key=lambda r: (r["assigned_at"], r["vehicle"], r["task_id"]),
            )
            order = [r["task_id"] for r in records]
            owners = {r["task_id"]: r["vehicle"] for r in records}
            if set(order) != pending:
                raise ValueError("Visible anchor lacks pending assignments")
            seen.add(("owned", tuple(order), tuple(sorted(owners.items()))))
            plans = neighbors(order, owners, len(obs["vehicles"]), seed=seed + round_index * 101)
            proxy_scales = [max(1, v) for v in costs.estimate_joint(order, owners)]
            ranked = sorted(
                plans,
                key=lambda p: (
                    sum(
                        w * v / s
                        for w, v, s in zip(
                            (0.5, 0.3, 0.2), costs.estimate_joint(p[0], p[1]), proxy_scales
                        )
                    ),
                    tuple(p[0]),
                    tuple(p[1][j] for j in p[0]),
                ),
            )
            proxy_evaluations += len(plans)
            drivers = [(kind, o, a, OwnedDriver(o, a)) for o, a, kind in ranked]
            if self.mode == "ensemble":
                drivers = [("rematch", order, {}, BatchDriver(costs, order))] + drivers[:3]
                for method in ("aco", "pso"):
                    proposals, stats = search(
                        costs, order, owners, method=method, seed=seed, budget=192
                    )
                    proxy_evaluations += stats["unique_evaluations"]
                    novel = [
                        (o, a, kind)
                        for o, a, kind in proposals
                        if ("owned", tuple(o), tuple(sorted(a.items()))) not in seen
                    ]
                    drivers.extend((kind, o, a, OwnedDriver(o, a)) for o, a, kind in novel[:1])
                cars = [v["id"] for v in obs["vehicles"]]
                for priority in (list(reversed(cars)), cars[1:] + cars[:1]):
                    drivers.append(
                        ("priority" + str(priority), order, {}, _Priority(self.driver, priority))
                    )
            allowance = self.budget // 2 if rounds == 2 and round_index == 0 else self.budget
            used = 0
            for kind, order, owners, driver in drivers:
                key = kind if not owners else "owned", tuple(order), tuple(sorted(owners.items()))
                if key in seen:
                    continue
                if used >= allowance or oracle.previews >= self.budget + 1:
                    break
                seen.add(key)
                used += 1
                prediction = oracle.evaluate(driver)
                values = (
                    visible_values(obs, prediction.data, self.past_moves)
                    if prediction.valid_complete
                    else None
                )
                score = (
                    sum(w * v / s for w, v, s in zip((0.5, 0.3, 0.2), values, scales))
                    if values is not None
                    else None
                )
                log["candidates"].append(
                    dict(round=round_index, kind=kind, valid=values is not None, score=score)
                )
                if score is not None and score < best - 1e-12:
                    best, self.driver, chosen = score, driver, prediction
        self.expected = {r["task_id"]: r for r in chosen.data["assignments"]}
        log.update(
            score=best,
            previews=oracle.previews,
            proxy_evaluations=proxy_evaluations,
            route_calls=oracle.route_calls,
            expanded=oracle.expanded,
        )
        self.decisions.append(log)
