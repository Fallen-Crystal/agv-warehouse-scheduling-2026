"""Research compositions for the real-demand panel; share the existing runner."""

from agv.policy.real_order_search import RealOrderSearch
from agv.registry import SolverSpec
from agv.runner.path_research import path_world_type
from agv.runner.path_research import run as previous_run
from agv.runner.run import run as execute


def released_reference(observation, known_jobs):
    """Reconstruct a reference only after every task has publicly arrived.

    This callable closes over no original Scenario or real Environment. Its
    sole inputs are an observation and the policy's accumulated released jobs.
    """
    from agv.evaluation.objective import reference_context
    from agv.policy.forecast import _task
    from agv.warehouse.scenarios import Scenario

    if observation["order_stream_closed"] is not True:
        raise ValueError("Cannot access a full-stream reference before observed close")
    released_ids = {j["id"] for j in observation["pending"]}
    released_ids.update(r["task_id"] for r in observation["completed"])
    released_ids.update(v["active_task"]["id"] for v in observation["vehicles"] if v["active_task"])
    if set(known_jobs) != released_ids or any(
        j["release"] > observation["time"] for j in known_jobs.values()
    ):
        raise ValueError("Reference input must contain exactly the observed released jobs")
    scene = Scenario.from_observation_map(observation["map"], observation["horizon"])
    scene.tasks = [_task(known_jobs[jid]) for jid in sorted(known_jobs)]
    scene.order_stream_end = observation["stream_closed_at"]
    scene.check()
    reference = reference_context(scene)
    if not reference["available"]:
        raise ValueError("Released-only reference execution failed")
    return reference["time"], reference["response"], reference["distance"]


def run(scene, *, method="repair", optimizer_seed=0, candidate_budget=8):
    if method in ("portfolio", "assignment", "aco", "pso", "greedy"):
        return previous_run(
            scene,
            route="sipp",
            orders=method,
            optimizer_seed=optimizer_seed,
            candidate_budget=candidate_budget,
        )
    factory = path_world_type("sipp", seed=optimizer_seed)
    policy = RealOrderSearch(
        world_factory=factory,
        mode=method,
        optimizer_seed=optimizer_seed,
        candidate_budget=candidate_budget,
        reference_estimator=released_reference if method == "reference" else None,
    )
    result = execute(
        SolverSpec(router="sipp"),
        scene,
        world_factory=factory,
        action=policy.action,
        on_assignment=policy.on_assignment,
    )
    result["path_research"] = dict(
        orders=method,
        route="sipp",
        optimizer_seed=optimizer_seed,
        decisions=policy.decisions,
        commit_feedback=policy.commit_feedback,
    )
    return result
