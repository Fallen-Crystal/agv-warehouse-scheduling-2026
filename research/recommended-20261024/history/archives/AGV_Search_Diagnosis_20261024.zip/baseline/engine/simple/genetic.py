"""One joint GA: sequence plus owner genes; no separate matching or repair."""

import random
from math import isfinite
from wepa.search import rank_score


def candidates(costs, order, owners, *, soft=False, seed=0, budget=96):
    rng = random.Random(seed)
    costs.allowance = budget
    cars = len(costs.obs["vehicles"])
    scales = costs.estimate_joint(order, owners)
    pools = {}
    for j in order:
        job = costs.jobs[j]
        options = []
        target_region = costs.slots[j]["shelf"][1] >= costs.world.scene.height / 2
        local = []
        for k, v in enumerate(costs.obs["vehicles"]):
            active = costs.world.active[k]
            position = active["drop"] if active else v["position"]
            available = (
                max(costs.world.time, active["end"]) if active else costs.world.time
            )
            distance = costs.details(k, position, job)[0]
            options.append((available + distance, k))
            if (position[1] >= costs.world.scene.height / 2) == target_region:
                local.append(k)
        pools[j] = sorted(set(local) | {k for _, k in sorted(options)[:3]})
    evaluated = {}

    def evaluate(item):
        o, a = item
        key = tuple(o), tuple(a[j] for j in o)
        if key not in evaluated:
            if len(evaluated) >= budget:
                return float("inf")
            values = costs.estimate_joint(o, a)
            score = rank_score(values, scales)
            evaluated[key] = (score, (list(o), dict(a), "ga"))
        return evaluated[key][0]

    def random_owner(j):
        choices = pools[j] if soft and rng.random() < 0.75 else list(range(cars))
        return rng.choice(choices)

    population = [(list(order), dict(owners))]
    for _ in range(11):
        o = list(order)
        rng.shuffle(o)
        population.append((o, {j: random_owner(j) for j in o}))
    for _ in range(8):
        population.sort(
            key=lambda x: (evaluate(x), tuple(x[0]), tuple(x[1][j] for j in x[0]))
        )
        next_population = [(list(o), dict(a)) for o, a in population[:2]]
        while len(next_population) < 12:
            left = min(rng.sample(population, min(3, len(population))), key=evaluate)
            right = min(rng.sample(population, min(3, len(population))), key=evaluate)
            n = len(order)
            if n > 1:
                lo, hi = sorted(rng.sample(range(n + 1), 2))
                segment = left[0][lo:hi]
                rest = [j for j in right[0] if j not in segment]
                o = rest[:lo] + segment + rest[lo:]
            else:
                o = list(order)
            a = {j: (left[1][j] if rng.random() < 0.5 else right[1][j]) for j in o}
            if len(o) > 1 and rng.random() < 0.7:
                i, j = rng.sample(range(len(o)), 2)
                o[i], o[j] = o[j], o[i]
            if o and rng.random() < 0.8:
                j = rng.choice(o)
                a[j] = random_owner(j)
            next_population.append((o, a))
        population = next_population
        if len(evaluated) >= budget:
            break
    for item in population:
        evaluate(item)
    plans = [v for v in evaluated.values() if isfinite(v[0])]
    plans.sort(key=lambda v: (v[0], tuple(v[1][0]), tuple(v[1][1][j] for j in v[1][0])))
    return [p for _, p in plans], dict(
        proxy_evaluations=costs.evaluations,
        candidates=len(evaluated),
        pools={str(j): v for j, v in pools.items()} if soft else {},
    )
