from agv.planning.astar import Router
from agv.planning.sipp import SafeIntervalRouter
from agv.planning.hybrid_routes import HybridRouter

BACKENDS = ("sipp", "astar", "aco")


def make_router(scene, kind="sipp", seed=0, cache=None, stats=None):
    if kind == "sipp":
        router = SafeIntervalRouter(scene)
    elif kind == "astar":
        router = Router(scene)
    elif kind == "aco":
        router = HybridRouter(
            scene, method="aco", timing="sipp", seed=seed, candidate_budget=2
        )
    else:
        raise ValueError("Unknown routing backend")
    if cache is not None:
        router.cache = cache
        if hasattr(router, "base"):
            router.base.cache = cache
    if stats is not None:
        router.stats = dict(stats)
    return router
