"""Single-GA dispatch with optional soft regions and interchangeable routers."""
