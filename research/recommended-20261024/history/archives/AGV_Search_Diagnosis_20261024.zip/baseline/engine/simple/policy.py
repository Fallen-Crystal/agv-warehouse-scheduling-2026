from simple.shadow import snapshot, rollout
from simple.genetic import candidates
from wepa.proxy import MixedCosts
from wepa.search import owned_batch, values, rank_score
from wepa.kernel import batch


class SimplePolicy:
    def __init__(self, method="soft_ga", seed=0):
        if method not in ("simple_ga", "soft_ga"):
            raise ValueError("Unknown simple policy")
        self.method, self.seed = method, seed
        self.plan, self.seen, self.logs = None, set(), []
        self.last_search, self.last_completed, self.closed_seen = -10000, set(), False

    def action(self, world):
        pending = set(world.visible) - world.assigned
        changed = (
            world.completed != self.last_completed
            and world.time - self.last_search >= 64
            and len(pending) > 1
        )
        if (
            self.plan is None
            or set(world.visible) - self.seen
            or (world.closed and not self.closed_seen)
            or changed
        ):
            self.search(snapshot(world))
            self.seen = set(world.visible)
            self.last_completed = set(world.completed)
            self.last_search, self.closed_seen = world.time, world.closed
        return (
            owned_batch(world, *self.plan)
            if self.plan is not None
            else batch(world, "eta")
        )

    def search(self, view):
        old = self.plan
        baseline, usage = rollout(view)
        if baseline is None:
            self.plan = None
            self.logs.append(
                dict(
                    time=view.time,
                    error="visible_anchor_incomplete",
                    visible_ids=sorted(view.visible),
                    usage=usage,
                )
            )
            return
        pending = set(view.tasks) - view.assigned
        records = sorted(
            (r for r in baseline.records if r["task"] in pending),
            key=lambda r: (r["assigned_at"], r["vehicle"], r["task"]),
        )
        order = [r["task"] for r in records]
        owners = {r["task"]: r["vehicle"] for r in records}
        assert set(order) == pending
        self.plan = order, owners
        scales, best, used = values(baseline), 1.0, 1
        previews, seen = [], {(tuple(order), tuple(owners[j] for j in order))}
        if old is not None and pending <= set(old[0]):
            o = [j for j in old[0] if j in pending]
            a = {j: old[1][j] for j in o}
            key = tuple(o), tuple(a[j] for j in o)
            if key not in seen:
                seen.add(key)
                trial, u = rollout(view, (o, a), scales, best)
                used += 1
                score = rank_score(values(trial), scales) if trial is not None else None
                previews.append(dict(kind="incumbent", score=score, usage=u))
                if score is not None and score < best - 1e-12:
                    best, self.plan = score, (o, a)
        costs = MixedCosts(view, baseline)
        plans, activity = candidates(
            costs,
            order,
            owners,
            soft=self.method == "soft_ga",
            seed=self.seed * 1000003 + view.time + sum(order),
        )
        for o, a, kind in plans:
            if used >= 3:
                break
            key = tuple(o), tuple(a[j] for j in o)
            if key in seen:
                continue
            seen.add(key)
            trial, u = rollout(view, (o, a), scales, best)
            used += 1
            score = rank_score(values(trial), scales) if trial is not None else None
            previews.append(dict(kind=kind, score=score, usage=u))
            if score is not None and score < best - 1e-12:
                best, self.plan = score, (o, a)
        self.logs.append(
            dict(
                time=view.time,
                optimizer="ga",
                method=self.method,
                backend=view.route_kind,
                previews=used,
                proxy_evaluations=activity["proxy_evaluations"],
                visible_ids=sorted(view.visible),
                score=best,
                base_score=1.0,
                changed=best < 1.0 - 1e-12,
                anchor_usage=usage,
                candidates=previews,
                soft_region=self.method == "soft_ga",
                regions=2,
                global_owner_proposal_probability=0.25
                if self.method == "soft_ga"
                else 1.0,
            )
        )
