"""Visible-only rolling GA/ACO/PSO and joint-repair search with SIPP feedback."""

from math import isfinite

from agv.planning.joint_meta import search as meta_search
from agv.planning.joint_orders import neighbors
from agv.planning.order_search import OrderCosts
from agv.planning.sipp import SafeIntervalRouter

from wepa.kernel import World, batch
from wepa.proxy import MixedCosts
from wepa.shadow import ShadowWorld

METHODS = ("ga", "aco", "pso", "repair", "hybrid")


def snapshot(world, fast=True):
    """Detached policy input: no unreleased task or true stream-end metadata."""
    w = object.__new__(ShadowWorld if fast else World)
    w.scene, w.slots = world.scene, world.slots
    w.router = SafeIntervalRouter(world.scene)
    w.router.cache = world.router.cache
    w.router.stats = dict(world.router.stats)
    w.tasks = {j: dict(job) for j, job in world.visible.items()}
    w.visible = dict(w.tasks)
    w.model = {"close_at": world.time, "tasks": list(w.tasks.values())}
    w.plans = [list(p) for p in world.plans]
    w.history = [[p[0]] for p in w.plans]
    w.labels = [[] for _ in w.plans]
    w.records = list(world.records)
    w.active = list(world.active)
    for field in ("stock", "completed", "assigned", "processed_pickups"):
        setattr(w, field, set(getattr(world, field)))
    for field in ("out_reserved", "in_reserved", "bound", "locks"):
        setattr(w, field, dict(getattr(world, field)))
    w.time, w.closed = world.time, True
    w.decisions, w.holds, w.routing_failures = [], 0, 0
    w.past_moves = world.past_moves
    return w


def owned_batch(world, order, owners):
    pairs = []
    for jid in order:
        if jid in world.assigned or world.active[owners[jid]] is not None:
            continue
        job = next((j for j in world.ready() if j["id"] == jid), None)
        if job is None:
            continue
        k = owners[jid]
        proposal = world.trip(k, job)
        if proposal is None:
            world.routing_failures += 1
            continue
        world.commit(k, job, proposal)
        pairs.append((k, jid))
    return pairs


def rollout(base, plan=None, scales=None, incumbent=1.0, *, fast=True):
    w = snapshot(base, fast=fast)
    route_start = w.router.stats["calls"]
    leg = w.router.leg

    class QueryBudget(Exception):
        pass

    def limited_leg(*args, **kwargs):
        if w.router.stats["calls"] - route_start >= 512:
            raise QueryBudget()
        return leg(*args, **kwargs)

    w.router.leg = limited_leg
    limit = w.time + max(1000, len(w.tasks) * (w.scene.width + w.scene.height + 30) * 3)
    first = []
    while w.time <= limit:
        w.publish_and_complete()
        if w.done:
            return w, first
        if scales is not None:
            fixed = {r["task"]: r["end"] for r in w.records}
            # Lower bounds apply to this visible rollout, never unseen demand.
            unfinished = set(w.tasks) - set(fixed)
            lower_t = max(list(fixed.values()) + ([w.time] if unfinished else [0]))
            lower_r = sum(
                fixed.get(j, w.time) - job["release"] for j, job in w.tasks.items()
            ) / max(1, len(w.tasks))
            lower_d = w.past_moves + sum(
                w.router.distance(p[0], w.scene.homes[k], k)
                for k, p in enumerate(w.plans)
            )
            if rank_score((lower_t, lower_r, lower_d), scales) >= incumbent - 1e-12:
                return None, first
        if any(r is None for r in w.active) and w.ready():
            try:
                pairs = batch(w, "eta") if plan is None else owned_batch(w, *plan)
            except QueryBudget:
                return None, first
            if w.time == base.time:
                first = pairs
        if not fast or not w.jump_quiet():
            w.advance()
    return None, first


def values(world):
    return (
        max((r["end"] for r in world.records), default=0),
        sum(r["end"] - world.tasks[r["task"]]["release"] for r in world.records)
        / max(1, len(world.tasks)),
        world.past_moves,
    )


def rank_score(v, scales):
    return sum(
        weight * x / max(1, scale)
        for weight, x, scale in zip((0.5, 0.3, 0.2), v, scales)
    )


def proposals(costs, order, owners, method, seed, budget=192):
    """Reuse original algorithms; only the mixed-flow cost adapter is new."""
    costs.allowance = budget
    if method == "ga":
        # Original tournament/order-crossover/swap-mutation implementation.
        ranked = OrderCosts.search(costs, seed=seed, population=12, generations=10)
        return [(o, costs.owners(o), "ga") for o in ranked]
    if method in ("aco", "pso"):
        return meta_search(
            costs, order, owners, method=method, seed=seed, budget=budget
        )[0]
    plans = neighbors(
        order, owners, len(costs.obs["vehicles"]), seed=seed, limit=budget - 1
    )
    scales = costs.estimate_joint(order, owners)
    return sorted(
        plans,
        key=lambda p: (
            rank_score(costs.estimate_joint(p[0], p[1]), scales),
            tuple(p[0]),
            tuple(p[1][j] for j in p[0]),
        ),
    )


class SearchPolicy:
    def __init__(self, method, seed=0, previews=6):
        if method not in METHODS or previews < 2:
            raise ValueError("Unsupported search method or budget")
        self.method, self.seed, self.previews = method, seed, previews
        self.plan, self.seen, self.logs = None, set(), []

    def action(self, world):
        visible = set(world.visible)
        if self.plan is None or visible - self.seen:
            # Search is passed an explicitly sanitized copy, never the real model.
            self._search(snapshot(world))
            self.seen = visible
        if self.plan is None:
            return batch(world, "eta")
        return owned_batch(world, *self.plan)

    def _search(self, w):
        base, _ = rollout(w)
        if base is None:
            self.logs.append(
                dict(time=w.time, method=self.method, error="anchor_incomplete")
            )
            self.plan = None
            return
        pending = set(w.tasks) - w.assigned
        records = sorted(
            (r for r in base.records if r["task"] in pending),
            key=lambda r: (r["assigned_at"], r["vehicle"], r["task"]),
        )
        order = [r["task"] for r in records]
        owners = {r["task"]: r["vehicle"] for r in records}
        if set(order) != pending:
            raise ValueError("Anchor is missing visible work")
        self.plan = order, owners
        if not order:
            return
        scales = values(base)
        best, used, log = 1.0, 1, []
        seed = self.seed * 1000003 + w.time + sum(order)
        groups = (
            ("ga", "aco", "pso", "repair")
            if self.method == "hybrid"
            else (self.method,)
        )
        candidates = []
        proxy_evaluations = 0
        for group in groups:
            costs = MixedCosts(w, base)
            quota = (
                36
                if self.method == "hybrid"
                else 96
                if self.method == "repair"
                else 192
            )
            candidate = proposals(costs, order, owners, group, seed, quota)
            proxy_evaluations += costs.evaluations
            candidates.append(candidate)
        # Round-robin preserves representation of each hybrid proposal mechanism.
        plans = [
            group[i]
            for i in range(max(map(len, candidates), default=0))
            for group in candidates
            if i < len(group)
        ]
        seen = {(tuple(order), tuple(owners[j] for j in order))}
        chosen = base
        phase_limit = self.previews - (
            2 if self.method == "repair" else 1 if self.method == "hybrid" else 0
        )
        for o, a, kind in plans:
            key = tuple(o), tuple(a[j] for j in o)
            if key in seen:
                continue
            if used >= phase_limit:
                break
            seen.add(key)
            trial, _ = rollout(w, (o, a), scales, best)
            used += 1
            score = rank_score(values(trial), scales) if trial is not None else None
            log.append(dict(kind=kind, valid=trial is not None, score=score))
            if score is not None and isfinite(score) and score < best - 1e-12:
                best, chosen, self.plan = score, trial, (o, a)
        if self.method in ("repair", "hybrid") and used < self.previews:
            # Second pass is centered on the accepted full rollout, as in the
            # previous real-order repair; it never alters committed active jobs.
            selected = sorted(
                (r for r in chosen.records if r["task"] in pending),
                key=lambda r: (r["assigned_at"], r["vehicle"], r["task"]),
            )
            o = [r["task"] for r in selected]
            a = {r["task"]: r["vehicle"] for r in selected}
            costs = MixedCosts(w, chosen)
            for seq, assignment, kind in proposals(
                costs, o, a, "repair", seed + 101, 96 if self.method == "repair" else 48
            ):
                key = tuple(seq), tuple(assignment[j] for j in seq)
                if key in seen:
                    continue
                if used >= self.previews:
                    break
                seen.add(key)
                trial, _ = rollout(w, (seq, assignment), scales, best)
                used += 1
                score = rank_score(values(trial), scales) if trial is not None else None
                log.append(
                    dict(kind="second_" + kind, valid=trial is not None, score=score)
                )
                if score is not None and isfinite(score) and score < best - 1e-12:
                    best, chosen, self.plan = score, trial, (seq, assignment)
            proxy_evaluations += costs.evaluations
        self.logs.append(
            dict(
                time=w.time,
                method=self.method,
                visible_ids=sorted(w.tasks),
                previews=used,
                score=best,
                candidates=log,
                proxy_evaluations=proxy_evaluations,
                changed=chosen is not base,
                selected_order=self.plan[0],
                owners=self.plan[1],
            )
        )
