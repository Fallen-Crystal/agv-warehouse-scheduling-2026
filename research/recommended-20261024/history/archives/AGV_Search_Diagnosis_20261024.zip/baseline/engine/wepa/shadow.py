"""Equivalent ready checks and quiet event jumps for detached forecasts only."""

from wepa.kernel import World


class ShadowWorld(World):
    def publish_and_complete(self):
        self._ready_at = None
        return super().publish_and_complete()

    def commit(self, vehicle, job, proposal):
        super().commit(vehicle, job, proposal)
        self._ready_at = None

    def ready(self):
        if getattr(self, "_ready_at", None) == self.time:
            return self._ready_jobs
        top, lower = {}, {}
        for sid in self.stock:
            s = self.slots[sid]
            top[s["bay"]] = max(top.get(s["bay"], 0), s["level"])
        for sid in self.in_reserved:
            s = self.slots[sid]
            lower[s["bay"]] = min(lower.get(s["bay"], s["level"]), s["level"])
        jobs = []
        for j in self.visible.values():
            jid = j["id"]
            if jid in self.assigned or jid not in self.bound:
                continue
            s = self.slots[self.bound[jid]]
            if self.locks.get(s["bay"], 0) > self.time:
                continue
            if j["kind"] == "retrieval":
                if top.get(s["bay"], 0) > s["level"]:
                    continue
            elif lower.get(s["bay"], s["level"]) < s["level"]:
                continue
            jobs.append(j)
        self._ready_at, self._ready_jobs = self.time, jobs
        return jobs

    def jump_quiet(self):
        # Idle cars with a nontrivial suffix can choose a hold on any tick.
        # Those periods always retain the exact ordinary one-tick executor.
        if self.closed and len(self.completed) == len(self.tasks):
            delta = max(len(p) - 1 for p in self.plans)
        elif all(r is not None or len(p) == 1 for r, p in zip(self.active, self.plans)):
            events = [
                t
                for r in self.active
                if r is not None
                for t in (r["pickup_end"], r["end"])
                if t > self.time
            ]
            delta = min(events) - self.time if events else 0
        else:
            return False
        if delta <= 1:
            return False
        for k, p in enumerate(self.plans):
            end = min(delta, len(p) - 1)
            self.past_moves += sum(a != b for a, b in zip(p[:end], p[1 : end + 1]))
            self.plans[k] = p[end:]
            self.history[k].append(self.plans[k][0])
        self.time += delta
        return True
