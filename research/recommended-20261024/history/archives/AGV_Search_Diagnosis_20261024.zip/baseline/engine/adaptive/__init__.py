"""Second transfer round: workload matching and public-close exact scoring."""
