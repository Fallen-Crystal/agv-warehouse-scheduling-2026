"""Reuse uploaded batch matching and metaheuristics with a causal workload gate."""

from math import isfinite
from agv.planning.f_search import match_batch
from wepa.kernel import run
from wepa.proxy import MixedCosts
from wepa.search import owned_batch, proposals, rank_score, rollout, snapshot, values


def matching(world):
    cars = [
        dict(id=k, position=p[0])
        for k, p in enumerate(world.plans)
        if world.active[k] is None
    ]
    jobs = world.ready()
    pairs = match_batch(cars, jobs, lambda v, j: world.estimate(v["id"], j))
    accepted = []
    for k, jid in pairs:
        job = next((j for j in world.ready() if j["id"] == jid), None)
        if job is None:
            continue
        proposal = world.trip(k, job)
        if proposal is not None:
            world.commit(k, job, proposal)
            accepted.append((k, jid))
    return accepted


def public_reference(view, closed_at):
    """Reconstruct initial stock using only observed physical events after close."""
    counts = {sid: int(sid in view.stock) for sid in range(len(view.slots))}
    for r in view.records:
        job = view.tasks[r["task"]]
        if job["kind"] == "retrieval" and r["pickup_end"] <= view.time:
            counts[r["slot"]] += 1
        elif job["kind"] == "delivery" and r["end"] <= view.time:
            counts[r["slot"]] -= 1
    if any(x not in (0, 1) for x in counts.values()):
        raise ValueError("Invalid public inventory reconstruction")
    model = dict(
        scene=view.scene,
        slots=view.slots,
        occupied={s for s, v in counts.items() if v},
        tasks=list(view.tasks.values()),
        vehicles=len(view.plans),
        close_at=closed_at,
    )
    reference = run(model, "fcfs")
    if not reference["valid"]:
        raise ValueError("Observed closed reference is incomplete")
    return tuple(reference[k] for k in ("T", "R", "D"))


class AdaptivePolicy:
    def __init__(self, method, seed=0):
        if method not in ("matching", "adaptive_ga", "adaptive_hybrid"):
            raise ValueError("Unknown adaptive method")
        self.method, self.seed = method, seed
        self.plan, self.seen, self.logs = None, set(), []
        self.closed_seen = False
        self.reference = None
        self.last_search = -100000
        self.last_completed = set()

    def action(self, world):
        pending = set(world.visible) - world.assigned
        free = sum(r is None for r in world.active)
        if self.method == "matching" or (not world.closed and len(pending) <= free):
            self.plan = None
            self.logs.append(
                dict(
                    time=world.time,
                    mode="exact_batch_matching",
                    visible_ids=sorted(world.visible),
                    pending=len(pending),
                )
            )
            return matching(world)
        closure = world.closed and not self.closed_seen
        changed_completion = (
            world.closed
            and world.completed != self.last_completed
            and world.time - self.last_search >= 32
            and len(pending) > 1
        )
        if (
            self.plan is None
            or set(world.visible) - self.seen
            or closure
            or changed_completion
        ):
            view = snapshot(world)
            if world.closed and self.reference is None:
                # The closure time is public only once the publisher has closed.
                self.reference = public_reference(view, world.model["close_at"])
            self.search(view)
            self.seen = set(world.visible)
            self.closed_seen = world.closed
            self.last_completed = set(world.completed)
            self.last_search = world.time
        return (
            owned_batch(world, *self.plan) if self.plan is not None else matching(world)
        )

    def search(self, view):
        previous = self.plan
        base, _ = rollout(view)
        if base is None:
            self.plan = None
            self.logs.append(dict(time=view.time, error="anchor_incomplete"))
            return
        pending = set(view.tasks) - view.assigned
        scales = self.reference or values(base)
        used = 1
        if previous is not None and pending <= set(previous[0]):
            old_order = [j for j in previous[0] if j in pending]
            old_plan = (old_order, {j: previous[1][j] for j in old_order})
            old, _ = rollout(view, old_plan)
            used += 1
            if old is not None and rank_score(values(old), scales) < rank_score(
                values(base), scales
            ):
                base = old
        records = sorted(
            (r for r in base.records if r["task"] in pending),
            key=lambda r: (r["assigned_at"], r["vehicle"], r["task"]),
        )
        order = [r["task"] for r in records]
        owners = {r["task"]: r["vehicle"] for r in records}
        self.plan = order, owners
        best = rank_score(values(base), scales)
        first_score = best
        seed = self.seed * 1000003 + view.time + sum(order)
        groups = (
            ("ga",) if self.method == "adaptive_ga" else ("ga", "aco", "pso", "repair")
        )
        proposal_lists = []
        proxy_count = 0
        for group in groups:
            costs = MixedCosts(view, base)
            plans = proposals(costs, order, owners, group, seed, 144 // len(groups))
            proxy_count += costs.evaluations
            proposal_lists.append(plans)
        plans = [
            p[i]
            for i in range(max(map(len, proposal_lists), default=0))
            for p in proposal_lists
            if i < len(p)
        ]
        seen = {(tuple(order), tuple(owners[j] for j in order))}
        log = []
        chosen = base
        for o, a, kind in plans:
            key = tuple(o), tuple(a[j] for j in o)
            if key in seen:
                continue
            if used >= 5:
                break
            seen.add(key)
            trial, _ = rollout(view, (o, a), scales, best)
            used += 1
            score = rank_score(values(trial), scales) if trial is not None else None
            log.append(dict(kind=kind, score=score, valid=trial is not None))
            if score is not None and isfinite(score) and score < best - 1e-12:
                best, self.plan, chosen = score, (o, a), trial
        costs = MixedCosts(view, chosen)
        for o, a, kind in proposals(costs, *self.plan, "repair", seed + 101, 48):
            key = tuple(o), tuple(a[j] for j in o)
            if key in seen:
                continue
            if used >= 6:
                break
            seen.add(key)
            trial, _ = rollout(view, (o, a), scales, best)
            used += 1
            score = rank_score(values(trial), scales) if trial is not None else None
            log.append(
                dict(kind="repair_" + kind, score=score, valid=trial is not None)
            )
            if score is not None and isfinite(score) and score < best - 1e-12:
                best, self.plan = score, (o, a)
        proxy_count += costs.evaluations
        self.logs.append(
            dict(
                time=view.time,
                method=self.method,
                previews=used,
                proxy_evaluations=proxy_count,
                visible_ids=sorted(view.visible),
                score=best,
                base_score=first_score,
                changed=best < first_score - 1e-12,
                exact_closed_scales=self.reference is not None,
                candidates=log,
            )
        )
