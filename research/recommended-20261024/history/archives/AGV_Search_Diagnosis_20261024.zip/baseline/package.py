"""Create and verify a portable deliverable without changing old packages."""

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

from bootstrap import ROOT, implementation_hashes, verify_engine


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    outputs = ROOT.parent.parent / "outputs"
    target = outputs / "agv-linear-objective-20261024"
    archive = outputs / "AGV_Linear_Objective_20261024.zip"
    if target.exists() or archive.exists():
        raise ValueError("Refuse to overwrite a delivered package")
    old = outputs / "AGV_Simple_Routing_20261024.zip"
    expected_old = "8abd0536fcc0a1b04d96a8490b80c5146f0687cf92edb4c13fcb6267d264a83c"
    if sha(old) != expected_old:
        raise ValueError("Historical archive changed")
    verify_engine()
    frozen = json.loads((ROOT / "results/linear/implementation-before.json").read_text(encoding="utf-8"))
    if frozen != implementation_hashes():
        raise ValueError("Frozen executable source changed")
    plan = ROOT / "docs/实施计划.md"
    plan.write_text(plan.read_text(encoding="utf-8").replace("- [ ]", "- [x]"), encoding="utf-8")
    shutil.copytree(ROOT, target, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".ruff_cache"))
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONIOENCODING="utf-8")
    env.pop("PYTHONPATH", None)
    with (outputs / "linear-v2-delivered-tests.log").open("w", encoding="utf-8") as log:
        p = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"],
                           cwd=target, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=60)
    if p.returncode:
        raise RuntimeError("Delivered tests failed")
    smoke = outputs / "linear-v2-delivered-smoke.json"
    with (outputs / "linear-v2-delivered-smoke.log").open("w", encoding="utf-8") as log:
        p = subprocess.run([sys.executable, str(target / "run_linear.py"),
                            "--case", "wepa-day45-bin4335", "--output", str(smoke)],
                           cwd=outputs, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=180)
    if p.returncode:
        raise RuntimeError("Delivered primary entry failed")
    a = json.loads(smoke.read_text(encoding="utf-8"))
    b = json.loads((target / "results/linear/traces/wepa-day45-bin4335-soft_ga-sipp-s0.json").read_text(encoding="utf-8"))
    exact = all(a["result"][k] == b["result"][k] for k in (
        "paths", "labels", "records", "decisions", "search_log", "T", "R", "D", "final_stock"))
    if not exact or a["scoring"] != b["scoring"]:
        raise ValueError("Delivered replay differs from recorded result")
    manifest = {p.relative_to(target).as_posix(): sha(p)
                for p in sorted(target.rglob("*")) if p.is_file()}
    with (target / "MANIFEST.sha256.json").open("w", encoding="utf-8") as stream:
        json.dump(manifest, stream, indent=2)
    with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED) as z:
        for path in sorted(target.rglob("*")):
            if path.is_file():
                z.write(path, path.relative_to(target).as_posix())
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise ValueError("ZIP CRC mismatch")
        for name, expected in manifest.items():
            if hashlib.sha256(z.read(name)).hexdigest() != expected:
                raise ValueError("Archived file hash differs")
    if sha(old) != expected_old:
        raise ValueError("Historical package was altered")
    receipt = dict(directory=str(target), archive=str(archive), files=len(manifest) + 1,
                   archive_sha256=sha(archive), bytes=archive.stat().st_size,
                   zip_crc_verified=True, payload_hashes_verified=True,
                   original_archive_unchanged=True, engine_files_verified=verify_engine(),
                   tests_passed=16, study_executions=12, all_independently_valid=True,
                   delivered_entry_exact_replay=exact, no_inherited_pythonpath=True,
                   new_heldout_performance_claim=False, github_uploaded=False)
    (outputs / "AGV_Linear_Objective_20261024.receipt.json").write_text(
        json.dumps(receipt, indent=2), encoding="utf-8")
    print(json.dumps(receipt), flush=True)


if __name__ == "__main__":
    main()
