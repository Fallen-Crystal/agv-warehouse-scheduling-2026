"""Algorithms scored with the independent linear physical objective."""
