"""Run a frozen physical-objective experiment without any reference algorithm."""

import argparse
import json
import os
from pathlib import Path
import threading
import time

from bootstrap import ROOT, implementation_hashes, verify_engine
from objective import LinearObjective, checked_score
from v2.runner import run
from wepa.data import build


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", required=True)
    parser.add_argument("--method", choices=("soft_ga", "simple_ga", "eta", "fcfs"), default="soft_ga")
    parser.add_argument("--router", choices=("sipp", "astar", "aco"), default="sipp")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    target = Path(args.output).resolve()
    if target.exists():
        raise ValueError("Refuse to overwrite an experiment trace")
    protocol = json.loads((ROOT / "data/protocol.json").read_text(encoding="utf-8"))
    verify_engine()
    hashes = implementation_hashes()
    case = next(c for c in protocol["cases"] if c["case"] == args.case)
    objective = LinearObjective(**protocol["objective"])
    model = build(case, **protocol["configuration"])
    cpu, wall = time.process_time(), time.perf_counter()
    stop = threading.Event()

    def guard():
        while not stop.wait(0.25):
            if time.process_time() - cpu > protocol["budget"]["cpu"]:
                os._exit(124)

    threading.Thread(target=guard, daemon=True).start()
    result = run(model, args.method, args.router, args.seed, objective=objective)
    try:
        score = checked_score(model, result, objective)
    except ValueError as error:
        score = dict(audit=dict(valid=False, error=str(error)),
                     F_linear_v2=None, J_equivalent_seconds=None)
    stop.set()
    row = dict(case=args.case, method=args.method, router=args.router, seed=args.seed,
               valid=result["valid"] and score["audit"]["valid"],
               solve_cpu=time.process_time() - cpu, wall=time.perf_counter() - wall,
               tasks=len(case["tasks"]),
               **{k: result[k] for k in ("T", "R", "D", "p90", "empty_distance", "traffic_wait")},
               F_linear_v2=score["F_linear_v2"],
               J_equivalent_seconds=score["J_equivalent_seconds"],
               objective_sha256=objective.fingerprint)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("x", encoding="utf-8") as stream:
        json.dump(dict(config=vars(args), case=case, row=row, result=result, scoring=score,
                       implementation_sha256=hashes),
                  stream, ensure_ascii=False)
    if implementation_hashes() != hashes:
        raise ValueError("Implementation changed during execution")
    print(json.dumps(row), flush=True)
    if not row["valid"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
