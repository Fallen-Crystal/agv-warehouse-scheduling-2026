import unittest

import bootstrap  # noqa: F401
from objective import LinearObjective


class ObjectiveTests(unittest.TestCase):
    def test_physical_equivalent_seconds(self):
        o = LinearObjective()
        values = (1000, 300, 5400)
        self.assertAlmostEqual(o.equivalent_seconds(values), 500 + 90 + 180)
        self.assertAlmostEqual(o.score(values), 770 / 900)
        self.assertEqual(o.scales, (900, 900, 5400))

    def test_strictly_increasing_in_every_metric(self):
        o = LinearObjective()
        base = [1000, 300, 5000]
        for i in range(3):
            changed = list(base)
            changed[i] += 1
            self.assertGreater(o.score(changed), o.score(base))

    def test_zero_and_no_artificial_upper_bound(self):
        o = LinearObjective()
        self.assertEqual(o.score((0, 0, 0)), 0)
        self.assertGreater(o.score((5000, 5000, 10000)), 1)

    def test_unit_conversion_preserves_objective(self):
        seconds = LinearObjective()
        two_seconds = LinearObjective(seconds_per_step=2, speed_cells_per_second=0.5)
        # Same physical trip in cells of twice the physical length: D is halved.
        self.assertEqual(seconds.score((1000, 300, 5400)),
                         two_seconds.score((500, 150, 2700)))

    def test_rejects_bad_parameters_and_metrics(self):
        for args in (dict(horizon_seconds=0), dict(vehicles=True),
                     dict(vehicles=1.5), dict(speed_cells_per_second=-1),
                     dict(seconds_per_step=float("nan")), dict(weights=(0.5, 0.5)),
                     dict(weights=(0.5, -0.3, 0.8)), dict(weights=(1, 1, 1))):
            with self.assertRaises(ValueError):
                LinearObjective(**args)
        for values in ((1, -1, 1), (float("inf"), 1, 1),
                       (True, 1, 1), (1, 1)):
            with self.assertRaises(ValueError):
                LinearObjective().score(values)

    def test_reference_algorithms_are_not_score_inputs(self):
        o = LinearObjective()
        config = o.to_dict()
        self.assertFalse(any(x in str(config).lower() for x in ("fcfs", "eta", "reference")))
        score = o.score((900, 100, 4000))
        unrelated_algorithm_result = {"T": 90000, "R": 80000, "D": 70000}
        self.assertTrue(unrelated_algorithm_result)
        self.assertEqual(score, o.score((900, 100, 4000)))

    def test_configuration_has_stable_identity(self):
        a = LinearObjective()
        b = LinearObjective(**a.to_dict())
        self.assertEqual(a.fingerprint, b.fingerprint)
        self.assertNotEqual(a.fingerprint, LinearObjective(horizon_seconds=1800).fingerprint)


if __name__ == "__main__":
    unittest.main()
