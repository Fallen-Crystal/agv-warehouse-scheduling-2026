from copy import deepcopy
import unittest
from unittest.mock import patch

import bootstrap  # noqa: F401
from objective import LinearObjective, checked_score
from v2.policy import LinearPolicy
from v2.runner import run
from v2.shadow import snapshot, rollout
from wepa.check import validate
from wepa.data import build
from wepa.kernel import World
from wepa.search import values


def task(j, kind="retrieval", release=0):
    return dict(id=j, source_row=j, kind=kind, sku=10, release=release,
                source_time=release, source_dock=1, batch=j, week=1)


def model(tasks=None, initial=5):
    tasks = tasks if tasks is not None else [task(0), task(1), task(2, "delivery", 20)]
    data = dict(case="objective-interface-micro", initial={"10": initial},
                close_at=max((t["release"] for t in tasks), default=0), tasks=tasks)
    return build(data, size="medium", vehicles=2)


class PipelineTests(unittest.TestCase):
    def test_fixed_objective_reaches_proxy_rollout_and_final_score(self):
        m = model()
        obj = LinearObjective(vehicles=2, weights=(0.1, 0.7, 0.2))
        with patch("wepa.search.rank_score", side_effect=AssertionError("Legacy score called")):
            r = run(m, objective=obj, seed=3)
        score = checked_score(m, r, obj)
        self.assertTrue(score["audit"]["valid"])
        self.assertEqual(score["F_linear_v2"], obj.score(tuple(r[k] for k in ("T", "R", "D"))))
        logs = [x for x in r["search_log"] if "previews" in x]
        self.assertTrue(logs)
        for log in logs:
            self.assertEqual(log["objective_sha256"], obj.fingerprint)
            self.assertEqual(log["fixed_scales"], list(obj.scales))
            self.assertLessEqual(log["previews"], 3)
            self.assertLessEqual(log["proxy_evaluations"], 96)
            self.assertLessEqual(log["score"], log["base_score"] + 1e-12)
            self.assertNotEqual(log["base_score"], 1.0)

    def test_full_rollout_pruning_uses_same_objective(self):
        w = World(model([task(0), task(1)]))
        w.publish_and_complete()
        obj = LinearObjective(vehicles=2)
        prediction, _ = rollout(w)
        expected = obj.score(values(prediction))
        repeated, usage = rollout(w, objective=obj, incumbent=expected + 1)
        self.assertIsNotNone(repeated)
        self.assertEqual(prediction.records, repeated.records)
        self.assertEqual(values(prediction), values(repeated))
        pruned, reason = rollout(w, objective=obj, incumbent=0)
        self.assertIsNone(pruned)
        self.assertEqual(reason["reason"], "bound_pruned")

    def test_all_route_backends_are_independently_valid(self):
        for router in ("sipp", "astar", "aco"):
            with self.subTest(router=router):
                m = model()
                r = run(m, router=router, seed=2)
                self.assertTrue(checked_score(m, r, LinearObjective(vehicles=2))["audit"]["valid"])

    def test_no_future_task_enters_policy_snapshot_or_past_actions(self):
        a, b = model([task(0), task(1, "delivery", 200)]), model([task(0), task(1, "delivery", 300)])
        w = World(a)
        w.publish_and_complete()
        view = snapshot(w)
        self.assertEqual(set(view.tasks), {0})
        self.assertEqual(view.model["close_at"], 0)
        x, y = run(a, seed=4), run(b, seed=4)
        self.assertEqual([d for d in x["decisions"] if d["time"] < 200],
                         [d for d in y["decisions"] if d["time"] < 200])

    def test_checked_score_rejects_changed_metrics_or_incomplete_execution(self):
        m = model()
        r = run(m, "eta")
        for key in ("T", "R", "D"):
            changed = deepcopy(r)
            changed[key] += 1
            with self.assertRaises(ValueError):
                checked_score(m, changed, LinearObjective(vehicles=2))
        changed = deepcopy(r)
        changed["valid"] = False
        with self.assertRaises(ValueError):
            checked_score(m, changed, LinearObjective(vehicles=2))

    def test_fleet_or_executor_speed_mismatch_is_not_silently_scored(self):
        m = model()
        r = run(m, "eta")
        with self.assertRaises(ValueError):
            checked_score(m, r, LinearObjective(vehicles=6))
        with self.assertRaises(ValueError):
            checked_score(m, r, LinearObjective(vehicles=2, speed_cells_per_second=2))

    def test_seed_replays_exactly(self):
        m = model()
        x, y = run(m, seed=5), run(m, seed=5)
        for key in ("paths", "records", "decisions", "search_log", "T", "R", "D"):
            self.assertEqual(x[key], y[key])

    def test_empty_demand_scores_zero(self):
        m = model([], initial=0)
        r = run(m)
        self.assertTrue(validate(m, r)["valid"])
        self.assertEqual(checked_score(m, r, LinearObjective(vehicles=2))["F_linear_v2"], 0)

    def test_initial_feasible_plan_is_not_a_denominator(self):
        w = World(model([task(0), task(1)]))
        w.route_kind, w.route_seed = "sipp", 0
        w.publish_and_complete()
        view = snapshot(w)
        base, _ = rollout(view)
        obj = LinearObjective(vehicles=2)
        policy = LinearPolicy(objective=obj)
        policy.search(view)
        self.assertEqual(policy.logs[-1]["base_score"], obj.score(values(base)))


if __name__ == "__main__":
    unittest.main()
