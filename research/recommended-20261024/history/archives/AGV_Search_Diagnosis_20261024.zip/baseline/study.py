"""Fixed development-case migration checks, not a new held-out selection study."""

import argparse
import json
import subprocess
import sys

from bootstrap import ROOT, implementation_hashes, verify_engine


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--run", action="store_true")
    args = p.parse_args()
    if not args.run:
        p.error("Use --run for the predeclared twelve development executions")
    protocol = json.loads((ROOT / "data/protocol.json").read_text(encoding="utf-8"))
    out = ROOT / "results/linear"
    out.mkdir(parents=True, exist_ok=True)
    frozen = implementation_hashes()
    freeze_path = out / "implementation-before.json"
    with freeze_path.open("x", encoding="utf-8") as f:
        json.dump(frozen, f, indent=2)
    runs = []
    for case in protocol["development"]:
        for method in protocol["methods"]:
            trace = out / "traces" / f"{case}-{method}-sipp-s0.json"
            log = out / "logs" / f"{case}-{method}-sipp-s0.log"
            log.parent.mkdir(exist_ok=True)
            if implementation_hashes() != frozen:
                raise RuntimeError("Frozen implementation drift")
            command = [sys.executable, str(ROOT / "run_linear.py"), "--case", case,
                       "--method", method, "--output", str(trace)]
            print(f"START {case} {method}", flush=True)
            with log.open("x", encoding="utf-8") as f:
                proc = subprocess.run(command, stdout=f, stderr=subprocess.STDOUT,
                                      timeout=protocol["budget"]["wall"], cwd=ROOT)
            if proc.returncode or not trace.exists():
                runs.append(dict(case=case, method=method, valid=False,
                                 exit_code=proc.returncode, log=log.relative_to(ROOT).as_posix()))
            else:
                data = json.loads(trace.read_text(encoding="utf-8"))
                row = dict(data["row"], trace=trace.relative_to(ROOT).as_posix())
                if data["implementation_sha256"] != frozen:
                    raise RuntimeError("Trace source differs from frozen source")
                runs.append(row)
                print(json.dumps(row), flush=True)
            (out / "runs.json").write_text(json.dumps(runs, indent=2), encoding="utf-8")
    if implementation_hashes() != frozen:
        raise RuntimeError("Implementation changed after the study")
    (out / "integrity.json").write_text(json.dumps(dict(
        implementation_unchanged=True, engine_files_verified=verify_engine(),
        all_valid=all(r["valid"] for r in runs), executions=len(runs)), indent=2), encoding="utf-8")
    if not all(r["valid"] for r in runs):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
