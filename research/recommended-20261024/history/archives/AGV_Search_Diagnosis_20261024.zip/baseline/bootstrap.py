"""Portable imports for the versioned, byte-preserved execution dependencies."""

import sys
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT), str(ROOT / "engine"), str(ROOT / "engine/src")]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_engine():
    manifest = json.loads((ROOT / "data/engine-manifest.json").read_text(encoding="utf-8"))
    for name, expected in manifest.items():
        if sha(ROOT / "engine" / name) != expected:
            raise ValueError("Changed physical/search dependency: " + name)
    return len(manifest)


def implementation_hashes():
    files = [ROOT / name for name in ("bootstrap.py", "objective.py", "run_linear.py")]
    files += sorted((ROOT / "v2").glob("*.py"))
    files += [ROOT / "data/protocol.json", ROOT / "data/engine-manifest.json"]
    return {p.relative_to(ROOT).as_posix(): sha(p) for p in files}
