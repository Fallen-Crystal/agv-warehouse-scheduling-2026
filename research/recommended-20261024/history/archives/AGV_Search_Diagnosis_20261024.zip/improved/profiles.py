"""Predeclared interventions; no warehouse or objective changes."""

PROFILES = {
    "simple": dict(proxy=96, previews=3, generations=8, gate=False, anchor=False, repair=0),
    "wide": dict(proxy=192, previews=6, generations=16, gate=False, anchor=False, repair=0),
    "gate": dict(proxy=192, previews=6, generations=16, gate=True, anchor=False, repair=0),
    "anchor": dict(proxy=192, previews=6, generations=16, gate=False, anchor=True, repair=0),
    "restored": dict(proxy=144, previews=6, generations=10, gate=True, anchor=False, repair=48),
    "guided": dict(proxy=192, previews=6, generations=16, gate=False, anchor=False, repair=0, local_seeds=True),
    "guided_gate": dict(proxy=192, previews=6, generations=16, gate=True, anchor=False, repair=0, local_seeds=True, linear_matching=True),
}
