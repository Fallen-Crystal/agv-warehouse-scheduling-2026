"""Original instantaneous minimum-cost batch assignment, with real SIPP commit."""

from agv.planning.f_search import match_batch


def matching(world):
    cars = [dict(id=k, position=p[0]) for k, p in enumerate(world.plans)
            if world.active[k] is None]
    jobs = world.ready()
    pairs = match_batch(cars, jobs, lambda v, j: world.estimate(v["id"], j))
    accepted = []
    for k, jid in pairs:
        job = next((j for j in world.ready() if j["id"] == jid), None)
        if job is None:
            continue
        proposal = world.trip(k, job)
        if proposal is not None:
            world.commit(k, job, proposal)
            accepted.append((k, jid))
    return accepted
