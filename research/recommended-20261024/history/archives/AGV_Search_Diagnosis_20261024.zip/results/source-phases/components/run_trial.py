"""One isolated fixed-objective dispatch run, with full raw trajectory."""

import argparse
import json
import os
from pathlib import Path
import threading
import time

from paths import ROOT, hashes, verify_baseline
from objective import LinearObjective, checked_score
from improved.execute import run
from improved.profiles import PROFILES
from wepa.data import build


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--case", required=True)
    p.add_argument("--profile", choices=tuple(PROFILES) + ("eta", "fcfs"), required=True)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--output", required=True)
    args = p.parse_args()
    target = Path(args.output).resolve()
    if target.exists():
        raise ValueError("Refuse to overwrite an experiment")
    protocol = json.loads((ROOT / "data/protocol.json").read_text(encoding="utf-8"))
    verify_baseline()
    frozen = hashes()
    case = next(c for c in protocol["cases"] if c["case"] == args.case)
    objective = LinearObjective(**protocol["objective"])
    model = build(case, **protocol["configuration"])
    cpu, wall, stop = time.process_time(), time.perf_counter(), threading.Event()

    def guard():
        while not stop.wait(0.25):
            if time.process_time() - cpu > protocol["limits"]["cpu_seconds"]:
                os._exit(124)

    threading.Thread(target=guard, daemon=True).start()
    result = run(model, args.profile, args.seed, objective=objective)
    try:
        score = checked_score(model, result, objective)
    except ValueError as error:
        score = dict(audit=dict(valid=False, error=str(error)),
                     F_linear_v2=None, J_equivalent_seconds=None)
    stop.set()
    row = dict(case=args.case, profile=args.profile, seed=args.seed,
               valid=result["valid"] and score["audit"]["valid"],
               cpu=time.process_time() - cpu, wall=time.perf_counter() - wall,
               **{k: result[k] for k in ("T", "R", "D", "p90", "empty_distance", "traffic_wait")},
               F=score["F_linear_v2"], J=score["J_equivalent_seconds"],
               tasks=len(case["tasks"]), objective_sha256=objective.fingerprint)
    if hashes() != frozen:
        raise ValueError("Implementation changed during execution")
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("x", encoding="utf-8") as stream:
        json.dump(dict(config=vars(args), row=row, case=case, result=result, scoring=score,
                       implementation_sha256=frozen), stream, ensure_ascii=False)
    print(json.dumps(row), flush=True)
    if not row["valid"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
