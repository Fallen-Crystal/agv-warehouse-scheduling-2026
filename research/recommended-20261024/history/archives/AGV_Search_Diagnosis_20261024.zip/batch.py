"""Sequential, frozen-phase dispatch experiments; preserves every failure."""

import argparse
import json
from pathlib import Path
import subprocess
import sys

from paths import ROOT, hashes, verify_baseline


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--phase", required=True)
    p.add_argument("--split", choices=("development", "validation"), default="development")
    p.add_argument("--profiles", required=True)
    p.add_argument("--seeds", default="0")
    p.add_argument("--cases")
    args = p.parse_args()
    protocol = json.loads((ROOT / "data/protocol.json").read_text(encoding="utf-8"))
    cases = args.cases.split(",") if args.cases else protocol[args.split]
    profiles = args.profiles.split(",")
    seeds = [int(s) for s in args.seeds.split(",")]
    directory = ROOT / "results" / args.phase
    directory.mkdir(exist_ok=False)
    frozen = hashes()
    (directory / "phase-before.json").write_text(json.dumps(dict(
        args=vars(args), source=frozen, cases=cases, profiles=profiles, seeds=seeds,
        baseline_files=verify_baseline()), indent=2), encoding="utf-8")
    runs = []
    for case in cases:
        for profile in profiles:
            for seed in ([0] if profile in ("eta", "fcfs") else seeds):
                target = directory / "traces" / f"{case}-{profile}-s{seed}.json"
                log = directory / "logs" / f"{case}-{profile}-s{seed}.log"
                log.parent.mkdir(exist_ok=True)
                print(f"START {case} {profile} {seed}", flush=True)
                if hashes() != frozen:
                    raise RuntimeError("Source changed within a phase")
                with log.open("x", encoding="utf-8") as stream:
                    try:
                        proc = subprocess.run([sys.executable, str(ROOT / "run_trial.py"),
                            "--case", case, "--profile", profile, "--seed", str(seed),
                            "--output", str(target)], cwd=ROOT, stdout=stream,
                            stderr=subprocess.STDOUT, timeout=protocol["limits"]["wall_seconds"])
                        code = proc.returncode
                    except subprocess.TimeoutExpired:
                        code = 125
                if code or not target.exists():
                    row = dict(case=case, profile=profile, seed=seed, valid=False,
                               exit_code=code, log=log.relative_to(ROOT).as_posix())
                else:
                    data = json.loads(target.read_text(encoding="utf-8"))
                    if data["implementation_sha256"] != frozen:
                        raise RuntimeError("Trace source differs from frozen phase")
                    row = dict(data["row"], trace=target.relative_to(ROOT).as_posix())
                runs.append(row)
                print(json.dumps(row), flush=True)
                (directory / "runs.json").write_text(json.dumps(runs, indent=2), encoding="utf-8")
    if hashes() != frozen:
        raise RuntimeError("Source changed after phase")
    (directory / "phase-after.json").write_text(json.dumps(dict(
        source_unchanged=True, baseline_files=verify_baseline(),
        all_valid=all(r["valid"] for r in runs), executions=len(runs)), indent=2), encoding="utf-8")
    if not all(r["valid"] for r in runs):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
