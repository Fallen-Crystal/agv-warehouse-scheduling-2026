"""Passive, prefix-matched diagnostics; never commits a new online policy."""

import json

from paths import ROOT, BASE
from objective import LinearObjective
from v2.policy import LinearPolicy
from v2.genetic import candidates
from v2.shadow import snapshot, rollout
from wepa.data import build
from wepa.kernel import World
from wepa.proxy import MixedCosts
from wepa.search import values


def replay_prefix(model, recorded, target):
    w = World(model)
    w.route_kind, w.route_seed = "sipp", 0
    actions = {d["time"]: d for d in recorded["decisions"]}
    while True:
        w.publish_and_complete()
        if w.time == target:
            break
        if w.time in actions:
            for k, jid in actions[w.time]["pairs"]:
                job = w.visible[jid]
                proposal = w.trip(k, job)
                if proposal is None:
                    raise ValueError("Original prefix no longer executable")
                w.commit(k, job, proposal)
        w.advance()
    if w.history != [list(map(tuple, p[:target + 1])) for p in recorded["paths"]]:
        raise ValueError("Trace prefix differs")
    if w.records != [
        {k: tuple(v) if k in ("pickup", "drop") else v for k, v in r.items()}
        for r in recorded["records"] if r["assigned_at"] < target
    ]:
        raise ValueError("Physical records before probe differ")
    return w


def main():
    protocol = json.loads((ROOT / "data/protocol.json").read_text(encoding="utf-8"))
    objective = LinearObjective(**protocol["objective"])
    cases = {c["case"]: c for c in protocol["cases"]}
    name = "wepa-day45-bin4335"
    recorded = json.loads((BASE / f"results/linear/traces/{name}-soft_ga-sipp-s0.json").read_text())["result"]
    w = replay_prefix(build(cases[name], **protocol["configuration"]), recorded, 521)
    view = snapshot(w)
    policy = LinearPolicy(seed=0, objective=objective)
    policy.search(view)
    anchor, _ = rollout(view)
    chosen, _ = rollout(view, policy.plan)
    original_log = next(x for x in recorded["search_log"] if x["time"] == 521)
    if policy.logs[-1]["score"] != original_log["score"]:
        raise ValueError("Probe did not reproduce original decision score")
    av, cv = values(anchor), values(chosen)
    low = dict(case=name, time=521, prefix_exact=True,
               visible_ids=sorted(view.visible), pending=sorted(set(view.tasks) - view.assigned),
               free_vehicles=[k for k, r in enumerate(view.active) if r is None],
               busy_until={str(k):r["end"] for k, r in enumerate(view.active) if r is not None},
               chosen_order=policy.plan[0], chosen_owners=policy.plan[1],
               anchor_values=av, chosen_values=cv,
               anchor_terms=objective.terms(av), chosen_terms=objective.terms(cv),
               predicted_improvement_percent=100*(objective.score(av)-objective.score(cv))/objective.score(av),
               forecast_has_future_jobs=False,
               true_remaining_unpublished_jobs=len(cases[name]["tasks"])-len(view.visible),
               actual_full_window_F=objective.score(tuple(recorded[k] for k in ("T","R","D"))))
    (ROOT / "results/low-load-probe.json").write_text(json.dumps(low, indent=2), encoding="utf-8")
    print(json.dumps(low), flush=True)
    results = []
    for name in ("wepa-day12-bin1164", "wepa-day33-bin3229"):
        recorded = json.loads((BASE / f"results/linear/traces/{name}-soft_ga-sipp-s0.json").read_text())["result"]
        original = next(l for l in recorded["search_log"] if "previews" in l
                        and len(set(l["visible_ids"])-{r["task"] for r in recorded["records"] if r["assigned_at"]<l["time"]})>=6)
        target = original["time"]
        w = replay_prefix(build(cases[name], **protocol["configuration"]), recorded, target)
        view = snapshot(w)
        anchor, usage = rollout(view)
        pending = set(view.tasks) - view.assigned
        rec = sorted((r for r in anchor.records if r["task"] in pending),
                     key=lambda r:(r["assigned_at"],r["vehicle"],r["task"]))
        order=[r["task"] for r in rec]
        owners={r["task"]:r["vehicle"] for r in rec}
        costs = MixedCosts(view, anchor)
        plans, activity = candidates(costs,order,owners,objective=objective,soft=True,
                                      seed=target+sum(order))
        n=len(plans)
        ranks=sorted(set(list(range(min(6,n)))+list(range(max(0,n//2-1),min(n,n//2+2)))+list(range(max(0,n-3),n))))
        probe=[]
        for rank in ranks:
            o,a,kind=plans[rank]
            trial,u=rollout(view,(o,a))
            probe.append(dict(proxy_rank=rank+1,proxy=costs.values[(tuple(o),tuple(a[j] for j in o))],
                              physical_score=objective.score(values(trial)) if trial is not None else None,
                              usage=u, same_as_anchor=(o==order and a==owners)))
        valid=[x for x in probe if x["physical_score"] is not None]
        winner=min(valid,key=lambda x:x["physical_score"])
        # Formal two-preview policy excludes a duplicate of the ETA initial plan.
        formal_ranks=[]
        for i,(o,a,_) in enumerate(plans):
            if o==order and a==owners: continue
            formal_ranks.append(i+1)
            if len(formal_ranks)==2: break
        formal=[x["physical_score"] for x in valid if x["proxy_rank"] in formal_ranks]
        current=min([objective.score(values(anchor))]+formal)
        item=dict(case=name,time=target,prefix_exact=True,pending=len(pending),
                  activity=activity,anchor_score=objective.score(values(anchor)),
                  formal_candidate_ranks=formal_ranks,sampled=probe,
                  best_sampled_proxy_rank=winner["proxy_rank"],
                  best_sampled_physical_score=winner["physical_score"],
                  sampled_gain_beyond_formal_percent=100*(current-winner["physical_score"])/current,
                  committed=False)
        results.append(item)
        print(json.dumps({k:v for k,v in item.items() if k not in ("sampled","activity")}),flush=True)
    (ROOT / "results/ranking-probes.json").write_text(json.dumps(results,indent=2),encoding="utf-8")


if __name__=="__main__":
    main()
