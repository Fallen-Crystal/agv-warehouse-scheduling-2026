"""Count legal immediate opportunities skipped by the recorded dispatcher."""

import json

from paths import ROOT, BASE
from wepa.data import build
from wepa.kernel import World


def audit(model, result):
    w=World(model)
    actions={d["time"]:d for d in result["decisions"]}
    opportunities=[]
    while w.time<=result["time"]:
        w.publish_and_complete()
        if w.time==result["time"]:
            break
        if w.time in actions:
            for k,jid in actions[w.time]["pairs"]:
                job=w.visible[jid]
                proposal=w.trip(k,job)
                if proposal is None:
                    raise ValueError("Recorded action no longer feasible")
                w.commit(k,job,proposal)
        else:
            free=[k for k,r in enumerate(w.active) if r is None]
            ready=w.ready()
            possible=next(((k,j["id"]) for j in ready for k in free if w.trip(k,j) is not None),None)
            if possible is not None:
                opportunities.append(dict(time=w.time,free_vehicles=free,
                                          ready_tasks=[j["id"] for j in ready],example=possible))
        w.advance()
    if w.history != [list(map(tuple,p)) for p in result["paths"]]:
        raise ValueError("Replay differs while observing waits")
    return dict(exact_replay=True,skipped_immediate_opportunity_ticks=len(opportunities),
                observations=opportunities,
                interpretation="A legal immediate trip existed but no order was committed at this tick; not a proof that waiting increases global cost")


def main():
    protocol=json.loads((ROOT/'data/protocol.json').read_text(encoding='utf-8'))
    cases={c['case']:c for c in protocol['cases']}
    results=[]
    for name in protocol['development']:
        data=json.loads((BASE/f'results/linear/traces/{name}-soft_ga-sipp-s0.json').read_text())
        stats=audit(build(cases[name],**protocol['configuration']),data['result'])
        results.append(dict(case=name,**stats))
        print(json.dumps(dict(case=name,count=stats['skipped_immediate_opportunity_ticks'])),flush=True)
    (ROOT/'results/dispatch-wait-audit.json').write_text(json.dumps(results,indent=2),encoding='utf-8')


if __name__=='__main__':
    main()
