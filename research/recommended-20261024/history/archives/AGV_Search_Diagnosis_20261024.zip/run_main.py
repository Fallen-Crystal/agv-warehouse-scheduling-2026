"""Run the development-selected version without any validation reselection."""

import argparse
import json
from pathlib import Path
import subprocess
import sys

from paths import ROOT, hashes


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--case',required=True)
    p.add_argument('--seed',type=int,default=0)
    p.add_argument('--output',required=True)
    args=p.parse_args()
    selection=json.loads((ROOT/'results/selection.json').read_text(encoding='utf-8'))
    if selection['source']!=hashes():
        raise ValueError('Selected source differs from the pre-validation freeze')
    raise SystemExit(subprocess.call([sys.executable,str(ROOT/'run_trial.py'),
        '--case',args.case,'--profile',selection['selected'],'--seed',str(args.seed),
        '--output',str(Path(args.output).resolve())]))


if __name__=='__main__':
    main()
