"""Exact reference ONLY for one-car closed static outbound subproblems."""

from fractions import Fraction
from functools import lru_cache
from math import lcm

import paths  # noqa: F401
from wepa.kernel import World
from agv.planning.astar import Router


def solve(model, objective):
    if (
        model["vehicles"] != 1
        or model["close_at"] != 0
        or any(j["release"] != 0 or j["kind"] != "retrieval" for j in model["tasks"])
    ):
        raise ValueError("Exact scope requires one car, static closed outbound only")
    w = World(model)
    w.publish_and_complete()
    jobs = model["tasks"]
    n = len(jobs)
    if len(w.bound) != n:
        raise ValueError("All static jobs must be initially bound")
    slots = [model["slots"][w.bound[j["id"]]] for j in jobs]
    router = Router(model["scene"])
    home = model["scene"].homes[0]
    ends = [tuple(j["port"]) for j in jobs] + [home]
    predecessors = []
    for i, s in enumerate(slots):
        if any(
            q["bay"] == s["bay"]
            and q["level"] > s["level"]
            and q["id"] in model["occupied"]
            and q["id"] not in set(w.bound.values())
            for q in model["slots"]
        ):
            raise ValueError("Unrequested upper stock prevents execution")
        predecessors.append(
            sum(
                1 << k
                for k, q in enumerate(slots)
                if q["bay"] == s["bay"] and q["level"] > s["level"]
            )
        )
    distances = {}
    for last, pos in enumerate(ends):
        for k, j in enumerate(jobs):
            distances[last, k] = int(
                min(
                    router.distance(pos, p, 0) + router.distance(p, tuple(j["port"]), 0)
                    for p in slots[k]["points"]
                )
            )
    back = [int(router.distance(p, home, 0)) for p in ends]
    a = Fraction(str(objective.weights[0])) / Fraction(str(objective.scales[0]))
    b = Fraction(str(objective.weights[1])) / (n * Fraction(str(objective.scales[1])))
    c = Fraction(str(objective.weights[2])) / Fraction(str(objective.scales[2]))
    scale = lcm(a.denominator, b.denominator, c.denominator)
    ai, bi, ci = (int(x * scale) for x in (a, b, c))
    choices = {}

    @lru_cache(None)
    def dp(mask, last):
        if mask == (1 << n) - 1:
            return ci * back[last]
        options = []
        for k, j in enumerate(jobs):
            if mask >> k & 1 or predecessors[k] & mask != predecessors[k]:
                continue
            d = distances[last, k]
            duration = d + 2 * slots[k]["level"] + 1
            options.append(
                (
                    (ai + bi * (n - mask.bit_count())) * duration
                    + ci * d
                    + dp(mask | 1 << k, k),
                    j["id"],
                    k,
                )
            )
        if not options:
            raise ValueError("No feasible exact continuation")
        best = min(options)
        choices[mask, last] = best[2]
        return best[0]

    numerator = dp(0, n)
    mask, last, order = 0, n, []
    while mask != (1 << n) - 1:
        k = choices[mask, last]
        order.append(jobs[k]["id"])
        mask, last = mask | 1 << k, k
    # Independent direct evaluation of every legal permutation for n<=8.
    enumerated = 0
    brute = None
    if n <= 8:

        def visit(mask, last, t, completion_sum, distance):
            nonlocal brute, enumerated
            if mask == (1 << n) - 1:
                value = ai * t + bi * completion_sum + ci * (distance + back[last])
                brute = value if brute is None else min(brute, value)
                enumerated += 1
                return
            for k in range(n):
                if mask >> k & 1 or predecessors[k] & mask != predecessors[k]:
                    continue
                d = distances[last, k]
                end = t + d + 2 * slots[k]["level"] + 1
                visit(mask | 1 << k, k, end, completion_sum + end, distance + d)

        visit(0, n, 0, 0, 0)
        assert brute == numerator
    return dict(
        order=order,
        F=float(Fraction(numerator, scale)),
        numerator=numerator,
        denominator=scale,
        states=dp.cache_info().currsize,
        legal_permutations_crosschecked=enumerated,
        global_scope="one-car closed static outbound, original map/WMS/layer/service/terminal/final-return rules",
    )

