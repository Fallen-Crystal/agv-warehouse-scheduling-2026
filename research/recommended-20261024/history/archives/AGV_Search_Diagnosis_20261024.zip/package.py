"""Verify and package the complete diagnosis, including negative experiments."""

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

from paths import ROOT, hashes, sha, verify_baseline


def main():
    outputs=ROOT.parent.parent/'outputs'
    target=outputs/'agv-search-diagnosis-20261024'
    archive=outputs/'AGV_Search_Diagnosis_20261024.zip'
    if target.exists() or archive.exists():
        raise ValueError('Refuse to overwrite a deliverable')
    summary=json.loads((ROOT/'results/summary.json').read_text(encoding='utf-8'))
    selection=json.loads((ROOT/'results/selection.json').read_text(encoding='utf-8'))
    if selection['source']!=hashes() or not summary['counts']['source_unchanged_since_selection']:
        raise ValueError('Selection source drift')
    old=outputs/'AGV_Linear_Objective_20261024.zip'
    expected='77669ba794891298c1560d2c6bf02885205ca46b6f5a9e81ae38e9cbed3d9ff6'
    if sha(old)!=expected:
        raise ValueError('Previous archive changed')
    verify_baseline()
    shutil.copytree(ROOT,target,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.ruff_cache'))
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8')
    env.pop('PYTHONPATH',None)
    with (outputs/'search-diagnosis-delivered-tests.log').open('w',encoding='utf-8') as stream:
        proc=subprocess.run([sys.executable,'-m','unittest','test_variants','-v'],cwd=target,
                            env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=180)
    if proc.returncode:
        raise ValueError('Delivered unit verification failed')
    smoke=outputs/'search-diagnosis-delivered-smoke.json'
    with (outputs/'search-diagnosis-delivered-smoke.log').open('w',encoding='utf-8') as stream:
        proc=subprocess.run([sys.executable,str(target/'run_main.py'),'--case','wepa-day45-bin4335',
                             '--output',str(smoke)],cwd=outputs,env=env,stdout=stream,
                            stderr=subprocess.STDOUT,timeout=180)
    if proc.returncode:
        raise ValueError('Delivered main entry failed')
    reproduced=json.loads(smoke.read_text(encoding='utf-8'))
    recorded=json.loads((target/'results/dev-components/traces/wepa-day45-bin4335-gate-s0.json').read_text(encoding='utf-8'))
    exact=all(reproduced['result'][k]==recorded['result'][k] for k in (
        'paths','labels','records','decisions','search_log','T','R','D','final_stock'))
    if not exact or reproduced['scoring']!=recorded['scoring']:
        raise ValueError('Packaged main entry does not reproduce selected policy')
    manifest={p.relative_to(target).as_posix():sha(p) for p in sorted(target.rglob('*')) if p.is_file()}
    (target/'MANIFEST.sha256.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for path in sorted(target.rglob('*')):
            if path.is_file():z.write(path,path.relative_to(target).as_posix())
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:raise ValueError('ZIP CRC error')
        for name,digest in manifest.items():
            if hashlib.sha256(z.read(name)).hexdigest()!=digest:raise ValueError('Payload hash error')
    if sha(old)!=expected:raise ValueError('Historical archive was modified')
    receipt=dict(directory=str(target),archive=str(archive),files=len(manifest)+1,
                 archive_sha256=sha(archive),bytes=archive.stat().st_size,
                 selected=selection['selected'],zip_crc_verified=True,payload_hashes_verified=True,
                 original_archive_unchanged=True,baseline_files_unchanged=verify_baseline(),
                 physical_traces_independently_revalidated=summary['counts']['physically_revalidated'],
                 targeted_tests_passed=7,delivered_entry_exact_replay=True,
                 no_inherited_pythonpath=True,validation_reselection=False,github_uploaded=False)
    (outputs/'AGV_Search_Diagnosis_20261024.receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    print(json.dumps(receipt),flush=True)


if __name__=='__main__':
    main()
