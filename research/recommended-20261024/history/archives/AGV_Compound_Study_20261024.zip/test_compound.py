import unittest
from copy import deepcopy
import paths
from exact.fixtures import make
from improved.compound import compound_neighbors
from improved.execute import run
from improved.forecast import rollout,snapshot
from improved.policy import plan_from_prediction
from improved.proxy import MixedCosts
from objective import LinearObjective,checked_score
from wepa.kernel import World


def four_mixed():
    m=make('mixed_burst')
    m['tasks'].append(dict(id=3,kind='delivery',sku=30,release=0,port=m['scene'].stations[0]))
    m['case']='micro-four_mixed'
    return m


class CompoundTests(unittest.TestCase):
    def test_neighbors_preserve_jobs_and_change_ownership(self):
        w=World(four_mixed());w.publish_and_complete();v=snapshot(w);p,_=rollout(v)
        o,a=plan_from_prediction(p,set(v.tasks)-v.assigned);c=MixedCosts(v,p)
        proposals=compound_neighbors(c,o,a)
        self.assertEqual(proposals,compound_neighbors(c,o,a));self.assertTrue(proposals)
        self.assertLessEqual(len(proposals),48);seen=set()
        for order,owners,_ in proposals:
            self.assertEqual(sorted(o),sorted(order));self.assertEqual(set(owners),set(o))
            self.assertTrue(any(owners[j]!=a[j] for j in o))
            self.assertTrue(all(0<=k<2 for k in owners.values()))
            key=tuple(order),tuple(owners[j] for j in order)
            self.assertNotIn(key,seen);seen.add(key)
        self.assertEqual(compound_neighbors(c,o,a,limit=1),proposals[:1])
        self.assertEqual(compound_neighbors(c,o,a,limit=0),[])

    def test_pure_compound_recovers_proven_micro_optimum(self):
        m=four_mixed();obj=LinearObjective(vehicles=2)
        old=checked_score(m,run(m,'gate',objective=obj),obj)['F_linear_v2']
        r=run(m,'compound_only',objective=obj)
        new=checked_score(m,r,obj)['F_linear_v2']
        self.assertAlmostEqual(old,0.030444444444444444)
        self.assertAlmostEqual(new,1070/36000)
        self.assertLess(new,old)

    def test_full_executor_budgets_and_feasibility(self):
        from improved.profiles import PROFILES
        for arm in ('compound','compound_only'):
            for name in ('layers','mixed_burst','cross_out'):
                m=make(name);obj=LinearObjective(vehicles=2);r=run(m,arm,objective=obj)
                self.assertTrue(checked_score(m,r,obj)['audit']['valid'])
                for log in r['search_log']:
                    if 'previews' in log:
                        self.assertLessEqual(log['previews'],6)
                        self.assertLessEqual(log['proxy_evaluations'],PROFILES[arm]['proxy']+48)
                        self.assertLessEqual(log['score'],log['base_score']+1e-12)

    def test_repeat_trace_exact(self):
        m=four_mixed()
        for arm in ('compound','compound_only'):
            a=run(m,arm,seed=2,objective=LinearObjective(vehicles=2))
            b=run(m,arm,seed=2,objective=LinearObjective(vehicles=2))
            for key in ('paths','records','decisions','search_log','T','R','D'):
                self.assertEqual(a[key],b[key])

    def test_no_future_order_leakage(self):
        from test_variants import model
        for arm in ('compound','compound_only'):
            a,b=run(model(200),arm,seed=2),run(model(300),arm,seed=2)
            self.assertEqual([d for d in a['decisions'] if d['time']<200],
                             [d for d in b['decisions'] if d['time']<200])

    def test_source_anchor_not_mutated(self):
        w=World(four_mixed());w.publish_and_complete();v=snapshot(w);p,_=rollout(v)
        o,a=plan_from_prediction(p,set(v.tasks)-v.assigned);old=deepcopy((o,a))
        compound_neighbors(MixedCosts(v,p),o,a)
        self.assertEqual((o,a),old)

    def test_single_owner_queue_has_transfer_reorder_fallback(self):
        w=World(four_mixed());w.publish_and_complete();v=snapshot(w);p,_=rollout(v)
        o,_=plan_from_prediction(p,set(v.tasks)-v.assigned);a={j:0 for j in o}
        neighbors=compound_neighbors(MixedCosts(v,p),o,a)
        self.assertTrue(neighbors)
        self.assertTrue(all(kind=='compound_transfer_reorder' for _,_,kind in neighbors))
        self.assertTrue(any(order!=o for order,_,_ in neighbors))
        self.assertTrue(all(sum(owners[j]!=a[j] for j in o)==1 for _,owners,_ in neighbors))


if __name__=='__main__':unittest.main()
