"""Frozen blocked randomized run order, with two isolated worker processes."""
import argparse
from concurrent.futures import ThreadPoolExecutor,as_completed
import json
import random
import subprocess
import sys
from paths import ROOT,hashes,verify_baseline


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase',required=True)
    parser.add_argument('--split',choices=('development','validation'),default='development')
    parser.add_argument('--profiles',default='gate,lns,coord,coupled')
    parser.add_argument('--seeds',default='0');parser.add_argument('--jobs',type=int,default=2)
    args=parser.parse_args()
    p=json.loads((ROOT/'data/protocol.json').read_text());frozen=hashes()
    directory=ROOT/'results'/args.phase;directory.mkdir(exist_ok=False)
    profiles=args.profiles.split(',');seeds=list(map(int,args.seeds.split(',')));layout=[];rng=random.Random(173)
    for case in p[args.split]:
        block=[(case,profile,seed) for profile in profiles for seed in seeds]
        rng.shuffle(block);layout.extend(block)
    (directory/'phase-before.json').write_text(json.dumps(dict(args=vars(args),source=frozen,
        cases=p[args.split],profiles=profiles,seeds=seeds,layout=layout,
        baseline_files=verify_baseline(),randomization_seed=173),indent=2),encoding='utf-8')

    def worker(index,item):
        case,profile,seed=item
        target=directory/'traces'/f'{case}-{profile}-s{seed}.json'
        log=directory/'logs'/f'{case}-{profile}-s{seed}.log';log.parent.mkdir(exist_ok=True)
        if hashes()!=frozen:raise ValueError('Source changed before run')
        print(f'START {case} {profile} {seed}',flush=True)
        with log.open('x',encoding='utf-8') as stream:
            try:
                proc=subprocess.run([sys.executable,'-u',str(ROOT/'run_trial.py'),'--case',case,
                    '--profile',profile,'--seed',str(seed),'--output',str(target)],cwd=ROOT,
                    stdout=stream,stderr=subprocess.STDOUT,timeout=p['limits']['wall_seconds'])
                code=proc.returncode
            except subprocess.TimeoutExpired:code=125
        if code or not target.exists():
            row=dict(case=case,profile=profile,seed=seed,valid=False,exit_code=code,log=log.relative_to(ROOT).as_posix())
        else:
            record=json.loads(target.read_text(encoding='utf-8'))
            if record['implementation_sha256']!=frozen:raise ValueError('Trace has source drift')
            row=dict(record['row'],trace=target.relative_to(ROOT).as_posix())
        return index,row

    rows={}
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        futures=[pool.submit(worker,i,item) for i,item in enumerate(layout)]
        for future in as_completed(futures):
            index,row=future.result();rows[index]=row
            print(json.dumps(row),flush=True)
            (directory/'runs.json').write_text(json.dumps([rows[k] for k in sorted(rows)],indent=2),encoding='utf-8')
    if hashes()!=frozen:raise ValueError('Source changed during phase')
    valid=all(r['valid'] for r in rows.values())
    (directory/'phase-after.json').write_text(json.dumps(dict(source_unchanged=True,
        all_valid=valid,executions=len(rows),baseline_files=verify_baseline()),indent=2),encoding='utf-8')
    if not valid:raise SystemExit(1)


if __name__=='__main__':main()
