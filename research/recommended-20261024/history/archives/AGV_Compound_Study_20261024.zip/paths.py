"""Imports and evidence identity for isolated dispatch experiments."""

import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
BASE = ROOT / "baseline"
sys.path[:0] = [str(ROOT), str(BASE), str(BASE / "engine"), str(BASE / "engine/src")]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_baseline():
    manifest = json.loads((ROOT / "data/baseline-manifest.json").read_text(encoding="utf-8"))
    for name, expected in manifest.items():
        if sha(BASE / name) != expected:
            raise ValueError("Frozen baseline differs: " + name)
    return len(manifest)


def hashes():
    files = sorted((ROOT / "improved").glob("*.py"))
    files += sorted((ROOT / "exact").glob("*.py"))
    files += [ROOT / p for p in ("paths.py", "run_trial.py", "data/protocol.json")]
    return {p.relative_to(ROOT).as_posix(): sha(p) for p in files}
