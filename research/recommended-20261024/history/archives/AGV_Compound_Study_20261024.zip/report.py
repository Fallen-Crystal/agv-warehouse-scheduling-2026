"""Build the human-readable report only from audited saved results."""
import json
from collections import Counter
from paths import ROOT


def main():
    s=json.loads((ROOT/'results/summary.json').read_text());p=json.loads((ROOT/'data/protocol.json').read_text())
    selection=json.loads((ROOT/'results/selection.json').read_text())
    names={'gate':'原方案 GA＋SIPP','compound':'GA＋同时换车与重排＋SIPP','compound_only':'仅复合邻域＋SIPP'}
    lines=['# 同时换车与重排：六车真实请求实验','',
        '本轮完成12次开发运行、24次验证运行，共36次。评价公式、地图、库存和运行规则均未修改。验证使用未测试过的900秒请求窗口，但来源日期曾用于其他实验，不能称为新日期外部验证。','',
        f"开发阶段预先选定：**{names[s['selected_before_validation']]}**。按预定采用规则，默认保持/推荐：**{names[s['recommended']]}**。",'',
        '## 结果','',
        '“F改善”是同日期窗口先对随机种子取均值，再计算相对原方案的下降百分比，最后对4个日期取均值。它只是方法比较，不进入评价函数。正数表示改善，负数表示退化。','']
    for split,title in (('development','开发集：4个已用窗口，种子0'),('validation','验证集：4个新窗口，每组2个种子')):
        group=s['groups'][split];lines += [f'### {title}','','|方案|平均F|F改善|改善/退化窗口|平均T|平均R|平均D|CPU秒/窗口|','|---|---:|---:|---:|---:|---:|---:|---:|']
        for arm in p['treatments']:
            r=group['aggregates'][arm];c=group['comparisons'][arm]
            lines.append(f"|{names[arm]}|{r['F']:.6f}|{c['mean_paired_gain_percent']:+.3f}%|{c['improved']}/{c['worsened']}|{r['T']:.2f}|{r['R']:.2f}|{r['D']:.2f}|{r['cpu']:.2f}|")
        lines += ['','|窗口|GA＋复合动作的F改善|仅复合邻域的F改善|','|---|---:|---:|']
        for a,b in zip(group['comparisons']['compound']['cases'],group['comparisons']['compound_only']['cases']):
            lines.append(f"|{a['case']}|{a['gain_percent']:+.3f}%|{b['gain_percent']:+.3f}%|")
        lines += ['']
    validation=s['groups']['validation']['aggregates'];base=validation['gate']
    lines += ['## 综合F的变化来自哪里','',
        '下表为验证集均值相对原方案的变化，正数增加成本，负数减少成本。三项F贡献相加等于平均F的绝对变化（不同于逐窗口相对改善百分比）。','',
        '|方案|ΔT|ΔR|ΔD|T项对F贡献|R项对F贡献|D项对F贡献|','|---|---:|---:|---:|---:|---:|---:|']
    for arm in ('compound','compound_only'):
        new=validation[arm];dt=new['T']-base['T'];dr=new['R']-base['R'];dd=new['D']-base['D']
        lines.append(f"|{names[arm]}|{dt:+.2f}|{dr:+.2f}|{dd:+.2f}|{.5*dt/900:+.6f}|{.3*dr/900:+.6f}|{.2*dd/5400:+.6f}|")
    lines += ['', '## 微型最优回归','',
        '重新运行此前四单混合两车实例。既有CP-SAT证明及其最优轨迹保存于 data/micro-reference.json，本轮复用证据并独立重验轨迹，没有重新调用求解器。','',
        '|方案|F|T|R|D|相对已证明最优值的差距|','|---|---:|---:|---:|---:|---:|']
    for r in s['micro']:
        lines.append(f"|{names[r['profile']]}|{r['F']:.8f}|{r['T']}|{r['R']:.2f}|{r['D']}|{r['optimality_gap_percent']:.3f}%|")
    lines += ['',
        '三组比较的是完整的预算分配方案。compound把部分GA预算及预演名额留给复合邻居，因此不能把组间差异全部归因于复合算子本身；compound_only同时移除了GA。两组的回归结果可用于决定是否采用，不能独立证明哪个子步骤导致效果。','',
        '两个复合动作方案都能在该已知实例达到1070/36000的最优F，较原方案降低2.372%。该实例用于机制回归，不能作为新的泛化证据，也不能证明六车动态问题全局最优。','',
        '## 清晰的算法主线','',
        '1. 只接收当前已发布订单。在线低负载时沿用即时匹配；其他时刻进入订单搜索。',
        '2. 原方案用联合GA搜索任务的车辆归属与执行优先顺序。compound方案把代理估价预算从192拆为144次GA和最多48个复合邻居；compound_only取消GA，仅搜索复合邻居。',
        '3. 复合邻居同时改变车辆归属和优先顺序：交换两单的车辆及顺序，再试一次相邻顺序扰动；无跨车交换可用时，改用换车与插入顺序组合。多个种子轮转生成，避免预算耗在第一对订单。',
        '4. 静态代理成本只用于候选排序。最多6次完整可见任务SIPP预演比较同一F，预测严格改善才采用。已执行及已分配任务不重新绑定。',
        '5. 实际仿真继续接收新订单并重新决策。批次间安全待命，真正关闭订单流且完成全部任务后最终返库。独立检查器重验最终完整轨迹。','',
        '本轮未启用上一轮局部多车路径协调器，路径后端仍为原SIPP，以免将调度和路径变化混在一起。不是新的蚁群或粒子群组合，也不是完整ALNS。','',
        '## 评价口径','',
        '`F=0.5T/900+0.3R/900+0.2D/5400`。T是最后订单完成时刻，R是平均发布到完成耗时，D包含所有实际移动及最终返库。保持6车、速度1格/秒、大型62×47地图、5层。权重和物理尺度不变，不含任何其他算法的得分作为分母。F不是完成率，可以超过1；新窗口负载不同，不能直接与上一轮不同窗口的平均F比较。P90、空驶、交通等待和CPU成本同步报告于 results/comparison.csv；它们未另加惩罚权重。','',
        '## 数据与验证边界','',
        '来源为WEPA/slapstack真实入出库请求（固定提交 da6280a8f8be1010eae64264c69a90258a288173），2_orders.json校验值 caab14a69aa34734f3ceb04f6c595f712b7dc4a1ee65adbe92268a16a7159432。请求时间、类型与SKU来自数据，地理位置、车速、服务时长来自课程仓库模型；原始数据未提供可直接对比的实际AGV行程时间、里程或F。窗口库存由历史请求前缀账本重建，假定此前操作已经完成，不是实测在途库存。','',
        '原先计划4个未用日期，但输入筛选在任何算法运行前发现符合原资格的日期已经全部用过。因此保持35—65单、2—5 SKU、两种任务各至少5单等输入规则，排除开发日期和既有窗口，依时间顺序选取4个不同来源日期的新窗口。修订及完整排除清单保存在 data/input-selection.json。未读取算法分数来挑窗口；验证未调参。日期之间曾被开发过程间接了解，因此证据强度低于新日期验证；还需另一份数据或更长时期做外部验证。','',
        '|验证窗口|总任务|入库/出库|SKU数|','|---|---:|---:|---:|']
    for c in p['cases']:
        if c['case'] not in p['validation']:continue
        counts=Counter(t['kind'] for t in c['tasks'])
        lines.append(f"|{c['case']}|{len(c['tasks'])}|{counts['delivery']}/{counts['retrieval']}|{len(c['initial'])}|")
    lines += ['',
        '统计单位是4个来源日期，不把24次运行当24个独立场景。仅复合邻域不含GA的随机搜索，两种子重复主要用于一致性检查，并不增加独立场景数。样本不足以声称普遍显著改善。未覆盖其他地图、车数、层数或全部突发负载。','',
        '## 机制与检查','',
        '完整SIPP预演改善仅指当前已知任务预测，不能保证实际动态全程F改善。未知后续到单、代理的交通与货位预测误差、局部邻域的覆盖限制仍可能造成退化。','',
        '|方案|触发完整搜索次数|复合候选完整预演数|其中改善已知任务预测的次数|','|---|---:|---:|---:|']
    for arm in p['treatments']:
        a=s['activity'][arm];lines.append(f"|{names[arm]}|{a['searches']}|{a['compound_previews']}|{a['compound_forecast_improvements']}|")
    lines += ['',f"全部{s['executions']}次主运行和4份微型/最优参照轨迹通过独立复核；191个冻结基线文件未修改。4个开发窗口的原方案轨迹与上一轮逐项一致。算法在开发与验证间未修改。",'',
        f"墙钟超预算记录：{len(s['wall_budget_overruns'])}。CPU秒为仿真及独立评分累计时间；不同运行负载会影响计算耗时，不能仅据单次墙钟判断算法速度。",'',
        '## 使用与后续','',
        '默认入口 run_main.py 根据本轮开发选择与验证采用规则运行；可显式选择 --profile compound 或 compound_only。完整实现、协议、轨迹、日志、各指标和回归测试均在本包。未上传GitHub。','',
        '若复合动作未在开发和验证同时胜出，应保留为候选算子而非直接替换默认。下一步可单独研究怎样围绕当前GA最优候选分配复合搜索预算，以及开放订单流的预测边界；必须另立协议，不在本轮验证集上反复调参后宣称新验证收益。','']
    (ROOT/'docs/结果报告.md').write_text('\n'.join(lines),encoding='utf-8')
    print(ROOT/'docs/结果报告.md')


if __name__=='__main__':main()
