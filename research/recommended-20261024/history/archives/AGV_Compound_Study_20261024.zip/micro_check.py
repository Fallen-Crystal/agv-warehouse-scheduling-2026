"""Physical regression against one previously certified optimum, no new solve."""
import json
from paths import ROOT,hashes,sha
from test_compound import four_mixed
from improved.execute import run
from objective import LinearObjective,checked_score


def main():
    proof_path=ROOT/'data/micro-reference.json'
    reference=json.loads(proof_path.read_text())
    if not reference['row']['optimal'] or reference['proof']['objective_integer']!=reference['proof']['bound_integer']:
        raise ValueError('Reference has no exact optimality certificate')
    m=four_mixed();obj=LinearObjective(vehicles=2)
    # JSON coordinates can be lists; physical validator normalizes them.
    if checked_score(m,reference['reference'],obj)!=reference['proof']['audit']:
        raise ValueError('Old reference does not match current physical fixture')
    optimum=reference['row']['F_reference'];rows=[]
    for arm in ('gate','compound','compound_only'):
        result=run(m,arm,seed=0,objective=obj);score=checked_score(m,result,obj)
        rows.append(dict(profile=arm,F=score['F_linear_v2'],T=result['T'],R=result['R'],D=result['D'],
            optimality_gap_percent=100*(score['F_linear_v2']/optimum-1),result=result,scoring=score))
    record=dict(source=hashes(),proof_sha256=sha(proof_path),F_optimal=optimum,
        reference_physically_revalidated=True,new_solver_run=False,rows=rows,
        scope='Known reduced static two-car regression only; does not establish real-data optimality')
    (ROOT/'results/micro-regression.json').write_text(json.dumps(record),encoding='utf-8')
    print(json.dumps([dict(profile=r['profile'],F=r['F'],gap=r['optimality_gap_percent']) for r in rows]))


if __name__=='__main__':main()
