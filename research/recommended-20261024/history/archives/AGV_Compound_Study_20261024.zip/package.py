"""Verify a standalone copied release before creating its immutable ZIP."""
import hashlib,json,os,shutil,subprocess,sys,zipfile
from paths import ROOT,hashes,sha,verify_baseline


def main():
    out=ROOT.parent.parent/'outputs';target=out/'agv-compound-study-20261024'
    archive=out/'AGV_Compound_Study_20261024.zip'
    if target.exists() or archive.exists():raise ValueError('Refuse to overwrite a release')
    summary=json.loads((ROOT/'results/summary.json').read_text())
    if summary['source']!=hashes():raise ValueError('Identity changed after audit')
    old=out/'AGV_Coupled_Study_20261024.zip';oldhash='99f00db5f108227c034fcb59b8aac02ec4a8edbe978fb1f00c5ef1a979edb7ee'
    if sha(old)!=oldhash:raise ValueError('Prior delivery changed')
    shutil.copytree(ROOT,target,ignore=shutil.ignore_patterns('__pycache__','*.pyc','exact-deps'))
    env=dict(os.environ,PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONPATH',None)
    dependency=ROOT.parent/'agv-coupled-study-20261024/exact-deps'
    bootstrap="import sys,unittest;sys.path.insert(0,"+repr(str(dependency))+");unittest.main(module=None,argv=['unittest','test_compound','test_coupled','test_boundary','test_variants','-v'])"
    testlog=target/'results/delivered-tests.log'
    with testlog.open('w',encoding='utf-8') as f:
        result=subprocess.run([sys.executable,'-c',bootstrap],cwd=target,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
    log=testlog.read_text()
    if result.returncode or 'Ran 29 tests' not in log or not log.rstrip().endswith('OK'):raise ValueError('Delivered tests failed')
    with (target/'results/delivered-audit.log').open('w',encoding='utf-8') as f:
        result=subprocess.run([sys.executable,'analyze.py'],cwd=target,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
    if result.returncode or json.loads((target/'results/summary.json').read_text())!=summary:raise ValueError('Delivered physical audit differs')
    smoke=out/'compound-delivered-smoke.json'
    with (out/'compound-delivered-smoke.log').open('w',encoding='utf-8') as f:
        result=subprocess.run([sys.executable,str(target/'run_main.py'),'--case','wepa-day45-bin4335',
            '--output',str(smoke)],cwd=out,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
    if result.returncode:raise ValueError('External working-directory entry failed')
    actual=json.loads(smoke.read_text());expected=json.loads((target/f"results/development/traces/wepa-day45-bin4335-{summary['recommended']}-s0.json").read_text())
    if actual['scoring']!=expected['scoring'] or any(actual['result'][k]!=expected['result'][k] for k in
        ('paths','labels','records','decisions','search_log','coordination_log','T','R','D','final_stock')):raise ValueError('Default replay differs')
    (target/'results/delivery-verification.json').write_text(json.dumps(dict(tests_passed=29,
        independently_revalidated=summary['independently_revalidated'],external_cwd_exact_replay=True,
        no_inherited_pythonpath=True,solver_optional_and_not_bundled=True),indent=2),encoding='utf-8')
    manifest={p.relative_to(target).as_posix():sha(p) for p in sorted(target.rglob('*')) if p.is_file()}
    (target/'MANIFEST.sha256.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(target.rglob('*')):
            if p.is_file():z.write(p,p.relative_to(target).as_posix())
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:raise ValueError('ZIP CRC failed')
        for name,digest in manifest.items():
            if hashlib.sha256(z.read(name)).hexdigest()!=digest:raise ValueError('ZIP payload hash mismatch')
    if sha(old)!=oldhash:raise ValueError('Prior archive changed')
    receipt=dict(archive=str(archive),directory=str(target),archive_sha256=sha(archive),
        files=len(manifest)+1,bytes=archive.stat().st_size,main_executions=summary['executions'],
        independently_revalidated=summary['independently_revalidated'],tests_passed=29,
        baseline_files_unchanged=verify_baseline(),recommended=summary['recommended'],
        external_cwd_exact_replay=True,zip_crc_verified=True,payload_hashes_verified=True,
        prior_archive_unchanged=True,github_uploaded=False)
    (out/'AGV_Compound_Study_20261024.receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    print(json.dumps(receipt),flush=True)


if __name__=='__main__':main()
