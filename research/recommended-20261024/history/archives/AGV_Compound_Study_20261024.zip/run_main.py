"""Audited default or explicit compound-search experimental arm."""
import argparse,json,subprocess,sys
from paths import ROOT,hashes,verify_baseline


def main():
    p=argparse.ArgumentParser();p.add_argument('--case',required=True)
    p.add_argument('--profile',choices=('gate','compound','compound_only'))
    p.add_argument('--seed',type=int,default=0);p.add_argument('--output',required=True)
    a=p.parse_args();s=json.loads((ROOT/'results/summary.json').read_text())
    if s['source']!=hashes():raise ValueError('Source differs from audited study')
    verify_baseline()
    raise SystemExit(subprocess.call([sys.executable,str(ROOT/'run_trial.py'),'--case',a.case,
        '--profile',a.profile or s['recommended'],'--seed',str(a.seed),'--output',a.output]))


if __name__=='__main__':main()
