"""Independent physical audit and paired comparisons, retaining all outcomes."""
import csv,json
from statistics import mean
from paths import ROOT,hashes,sha,verify_baseline
from objective import LinearObjective,checked_score
from wepa.data import build
from test_compound import four_mixed


def main():
    p=json.loads((ROOT/'data/protocol.json').read_text());obj=LinearObjective(**p['objective'])
    cases={c['case']:c for c in p['cases']};groups={};all_rows=[];activity={};regression=[]
    for split in ('development','validation'):
        directory=ROOT/'results'/split
        before=json.loads((directory/'phase-before.json').read_text());after=json.loads((directory/'phase-after.json').read_text())
        if before['source']!=hashes() or not after['source_unchanged']:raise ValueError('Phase identity differs')
        rows=json.loads((directory/'runs.json').read_text())
        expected={(c,a,s) for c in p[split] for a in p['treatments'] for s in ([0] if split=='development' else [0,1])}
        if {(r['case'],r['profile'],r['seed']) for r in rows}!=expected or len(rows)!=len(expected):raise ValueError('Missing/duplicate runs')
        by_case={}
        for row in rows:
            if not row['valid']:raise ValueError('Invalid run; arm disqualified, do not average it away')
            trace=json.loads((ROOT/row['trace']).read_text())
            if trace['implementation_sha256']!=hashes():raise ValueError('Trace identity differs')
            score=checked_score(build(cases[row['case']],**p['configuration']),trace['result'],obj)
            if score!=trace['scoring'] or abs(score['F_linear_v2']-row['F'])>1e-12:raise ValueError('Independent physical score differs')
            if any(row[k]!=trace['result'][k] for k in ('T','R','D','p90','empty_distance','traffic_wait')):
                raise ValueError('Reported metrics differ from checked trajectory')
            act=activity.setdefault(row['profile'],dict(searches=0,compound_previews=0,compound_forecast_improvements=0,proxy_evaluations=0,previews=0))
            for log in trace['result']['search_log']:
                if 'previews' not in log:continue
                cap=48 if row['profile']=='compound_only' else 192
                if log['previews']>6 or log['proxy_evaluations']>cap:raise ValueError('Search budget exceeded')
                if log['score']>log['base_score']+1e-12:raise ValueError('Accepted worse known-work prediction')
                act['searches']+=1;act['proxy_evaluations']+=log['proxy_evaluations'];act['previews']+=log['previews']
                best=log['base_score']
                for candidate in log['candidates']:
                    if candidate['usage']['route_calls']>512:raise ValueError('Preview router budget exceeded')
                    value=candidate['score']
                    if candidate['kind'].startswith('repair_compound'):
                        act['compound_previews']+=1
                        if value is not None and value<best-1e-12:act['compound_forecast_improvements']+=1
                    if value is not None:best=min(best,value)
            if split=='development' and row['profile']=='gate':
                prior=json.loads((ROOT/f"data/control-reference/{row['case']}-gate-s0.json").read_text())
                if not all(prior['result'][k]==trace['result'][k] for k in ('paths','labels','records','decisions','T','R','D','final_stock')):
                    raise ValueError('Control physical replay changed')
                regression.append(dict(case=row['case'],exact_physical_replay=True))
            by_case.setdefault(row['case'],{}).setdefault(row['profile'],[]).append(row)
            all_rows.append(dict(split=split,**row))
        aggregates={};comparisons={}
        for arm in p['treatments']:
            aggregates[arm]={key:mean(mean(r[key] for r in by_case[c][arm]) for c in p[split])
                for key in ('F','J','T','R','D','cpu','wall','p90','empty_distance','traffic_wait')}
            paired=[]
            for case in p[split]:
                original=by_case[case]['gate'];trial=by_case[case][arm]
                if sorted(r['seed'] for r in original)!=sorted(r['seed'] for r in trial):raise ValueError('Unpaired seeds')
                base=mean(r['F'] for r in original);new=mean(r['F'] for r in trial)
                paired.append(dict(case=case,gate=base,F=new,gain_percent=100*(base-new)/base,
                    seed_pairs=[dict(seed=r['seed'],gain_percent=100*(next(x['F'] for x in original if x['seed']==r['seed'])-r['F'])/next(x['F'] for x in original if x['seed']==r['seed'])) for r in sorted(trial,key=lambda x:x['seed'])]))
            comparisons[arm]=dict(cases=paired,mean_paired_gain_percent=mean(r['gain_percent'] for r in paired),
                improved=sum(r['gain_percent']>1e-10 for r in paired),worsened=sum(r['gain_percent']< -1e-10 for r in paired))
        groups[split]=dict(aggregates=aggregates,comparisons=comparisons)
    selection=json.loads((ROOT/'results/selection.json').read_text())
    if selection['source']!=hashes() or selection['validation_read']:raise ValueError('Invalid pre-validation selection')
    selected=selection['selected'];gain=groups['validation']['comparisons'][selected]['mean_paired_gain_percent']
    recommended=selected if selected!='gate' and gain>0 else 'gate'
    micro=json.loads((ROOT/'results/micro-regression.json').read_text())
    if micro['source']!=hashes():raise ValueError('Micro source differs')
    reference_path=ROOT/'data/micro-reference.json'
    reference=json.loads(reference_path.read_text())
    if sha(reference_path)!=micro['proof_sha256'] or not reference['row']['optimal']:
        raise ValueError('Prior optimal reference identity differs')
    if reference['proof']['objective_integer']!=reference['proof']['bound_integer']:
        raise ValueError('Prior optimum bound differs')
    if checked_score(four_mixed(),reference['reference'],LinearObjective(vehicles=2))!=reference['proof']['audit']:
        raise ValueError('Prior optimal reference physical recheck failed')
    for r in micro['rows']:
        if checked_score(four_mixed(),r['result'],LinearObjective(vehicles=2))!=r['scoring']:raise ValueError('Micro recheck failed')
    summary=dict(executions=len(all_rows),independently_revalidated=len(all_rows)+4,groups=groups,activity=activity,
        selected_before_validation=selected,recommended=recommended,source=hashes(),baseline_files_unchanged=verify_baseline(),
        control_regression=regression,validation_retuning=False,validation_scope=p['validation_scope'],
        wall_budget_overruns=[{k:r[k] for k in ('case','profile','seed','wall','cpu')} for r in all_rows if r['wall']>p['limits']['wall_seconds']],
        micro=[{k:r[k] for k in ('profile','F','T','R','D','optimality_gap_percent')} for r in micro['rows']],
        caution='Four reused-date clusters of new windows; no fresh-date external evidence, no production optimality guarantee')
    (ROOT/'results/summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    with (ROOT/'results/comparison.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(all_rows[0]));writer.writeheader();writer.writerows(all_rows)
    print(json.dumps(dict(executions=summary['executions'],recommended=recommended,groups=groups,activity=activity),ensure_ascii=False))


if __name__=='__main__':main()
