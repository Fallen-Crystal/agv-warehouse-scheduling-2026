"""Write an evidence-bounded report, including unchanged and worse outcomes."""
from collections import Counter
import json
from paths import ROOT


def main():
    s=json.loads((ROOT/'results/summary.json').read_text(encoding='utf-8'))
    p=json.loads((ROOT/'data/protocol.json').read_text(encoding='utf-8'))
    lines=['# 动态预测边界修改与实验结果（2026-10-24）','',
        '本轮只修改已知任务预测的终点，未修改实际执行内核、仓库规则、评价公式、任务搜索预算或底层 SIPP。对照 gate 是上一轮已选定的方案，处理 open_gate 在订单流开放时预测到安全待命固定点，关闭时仍预测最终返库。','',
        '## 结果与采用决定','',
        f"按事前判据，主入口推荐 `{s['recommended']}`。新来源日的平均逐场景 F 改善为 {s['groups']['validation']['mean_paired_gain_percent']:.3f}%；正数表示降低成本，负数表示变差。没有调整权重、地图、车辆数或根据验证结果追加候选。",'',
        '开放流的预测更贴近中途待命规则，不意味着能预测未知订单，也不保证完整场景成本下降。若未胜出，修改作为可显式启用的研究候选保留，原策略继续作为默认。','',
        '## 评价及配对口径','',
        '`F = 0.5*T/900 + 0.3*R/900 + 0.2*D/5400`。T 是最后任务完成时间，R 是订单出现到完成的平均耗时，D 是全部真实移动，包含最终返库。仅独立验解通过的完整场景获得 F。内部开放流预测分数不是最终 F，不能把其较低数值当作实验收益。','',
        '固定大型 62×47 地图、6 车、5 层、900 秒请求窗口、0/1 随机种子。每场景先平均种子，再按来源日等权平均；百分比是逐场景配对比值的平均。4 个新来源日不是 8 个独立场景，不报告统计显著性或全局最优。','']
    for split,title in [('development','既有开发窗口：种子 0'),('validation','新来源日验证：每场景种子 0/1')]:
        g=s['groups'][split]
        lines += ['## '+title,'','|方案|平均F|T秒|R秒|D格|P90秒|CPU秒/窗口|',
            '|---|---:|---:|---:|---:|---:|---:|']
        for name,a in g['aggregates'].items():
            lines.append(f"|{name}|{a['F']:.6f}|{a['T']:.2f}|{a['R']:.2f}|{a['D']:.2f}|{a['p90']:.2f}|{a['cpu']:.2f}|")
        lines += ['','|窗口|gate F|open_gate F|配对改善|','|---|---:|---:|---:|']
        for c in g['cases']:
            lines.append(f"|{c['case']}|{c['gate']:.6f}|{c['open_gate']:.6f}|{c['gain_percent']:.3f}%|")
        lines += ['',f"平均逐场景改善 {g['mean_paired_gain_percent']:.3f}%，改善 {g['improved_cases']} 例，退化 {g['worsened_cases']} 例；其余相同。",'']
    terminal=Counter(); failures=Counter(); changed=Counter()
    for split in ('development','validation'):
        for trace in (ROOT/'results'/split/'traces').glob('*.json'):
            data=json.loads(trace.read_text(encoding='utf-8'))
            name=data['row']['profile']
            for log in data['result']['search_log']:
                if 'anchor_usage' in log:
                    u=log['anchor_usage']
                    terminal[(name,u['reason'],u.get('observed_closed'))]+=1
                    changed[name]+=bool(log.get('changed'))
                if 'error' in log:failures[(name,log['error'])]+=1
    (ROOT/'results/forecast-audit.json').write_text(json.dumps(dict(
        anchor_terminations=[dict(profile=k[0],reason=k[1],observed_closed=k[2],count=v)
            for k,v in sorted(terminal.items())],
        incomplete_anchor=[dict(profile=k[0],reason=k[1],count=v) for k,v in failures.items()],
        improved_known_work_forecasts=dict(changed)),indent=2),encoding='utf-8')
    lines += ['## 对假设的判断与后续方向','',
        '本轮结果不支持“仅把预测终点从返库改为待命即可降低完整场景 F”。开放流预测虽然更符合中途待命状态，但没有给未知未来任务赋予车位价值；这是一项仍需研究的有限信息估计，不能把较低的内部部分需求分数当作全局收益。也不能据此断言原返库终点在所有动态问题中更好。',
        '', '两例开发集退化的第一次派单分歧前，物理轨迹前缀完全一致，见 results/first-divergence.json。第 32 日在时刻 819 的新试排中，候选分数从其自身锚点的 0.940642 降到 0.917687，但完整场景 F 从对照的 0.939168 上升到 0.955090。当时尚有 2 单未公布；该数值是事后诊断，不提供给算法。不同终点定义的内部预测分数不能跨方案当最终 F 比较。',
        '', '下一步更应检验针对最晚完成车辆、长空驶接货和等待瓶颈的订单交换/转移，并用实际 SIPP 联合试排反馈，而不是继续盲目增加代数。该项本轮未实现，需新版本、固定预算对照和新的验证数据，不能宣称已有收益。',
        '', '耗时保留原始 wall 和 CPU：第 58 日 open_gate 种子 0 的 wall 约 177.90 秒、CPU 约 78.89 秒，未据此推断具体原因，也不据这轮小样本宣称运行速度显著变化。',
        '', '## 修改与核验边界','',
        '脱敏快照保留公开关闭标志，但不保留真实关闭时刻、未来订单数量或释放时间。开放流试排使用原执行器的等待与预约检查，直到所有已知任务完成且每辆车的相对路径在一个时间步后不变；简单处于普通格并不足以提前停止。',
        '', '代理排序用到合法待命格的无预约距离，完整试排仍执行原 SIPP 及后备返库预约。开放流剪枝不再加入返库距离下界；该距离不是部分需求问题必须发生的费用。关闭流保持原返库下界。',
        '', f"{s['independently_revalidated']} 份新完整轨迹已重新独立核验；4 个开发对照的路径、记录、派单、T/R/D 与此前冻结结果精确一致。冻结基线 {s['baseline_files_unchanged']} 个文件未改变。源码在开发阶段及验证阶段分别冻结，两个阶段仅清理协议说明字段，算法源码保持一致。",'',
        '新验证窗口按输入条件选择此前未使用的 47/48/54/58 日，完整保留入库和出库请求。此前验证过的 75/82/83/87 日未重新标为未见数据。本轮没有验证其他地图、车辆数、层数，也未改货架提前锁定规则。', '',
        '源数据是公开请求驱动的映射仿真：库存来自源请求前缀台账，货架映射、速度和装卸规则属于项目模型；不构成原仓库运行复现。', '',
        '逐次数据见 results/comparison.csv，所有原始轨迹、阶段哈希及日志见 results/development 与 results/validation；输入选择和源码冻结依据见 data/input-selection.json、results/frozen.json。累计 CPU 是完整窗口的计算时间，不是一次派单的延迟。','']
    (ROOT/'docs/结果报告.md').write_text('\n'.join(lines),encoding='utf-8')
    print(json.dumps({'recommended':s['recommended'],'report':'docs/结果报告.md','executions':s['executions']}))


if __name__=='__main__':
    main()
