"""Run the fixed recommendation while checking the experiment's code identity."""
import argparse
import json
import subprocess
import sys
from paths import ROOT, hashes, verify_baseline


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--case',required=True)
    p.add_argument('--seed',type=int,default=0)
    p.add_argument('--profile',choices=('gate','open_gate'))
    p.add_argument('--output',required=True)
    args=p.parse_args()
    summary=json.loads((ROOT/'results/summary.json').read_text(encoding='utf-8'))
    if summary['source'] != hashes():
        raise ValueError('Code or protocol differs from verified experiments')
    verify_baseline()
    profile=args.profile or summary['recommended']
    raise SystemExit(subprocess.call([sys.executable,str(ROOT/'run_trial.py'),
        '--case',args.case,'--profile',profile,'--seed',str(args.seed),'--output',args.output]))


if __name__=='__main__':
    main()
