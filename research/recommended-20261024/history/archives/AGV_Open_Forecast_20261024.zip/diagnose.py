"""Record the earliest action divergence without intervening in any execution."""
import json
from paths import ROOT


def main():
    p=json.loads((ROOT/'data/protocol.json').read_text())
    cases={c['case']:c for c in p['cases']}
    findings=[]
    for case in p['development']:
        pair=[json.loads((ROOT/f'results/development/traces/{case}-{name}-s0.json').read_text())
            for name in ('gate','open_gate')]
        a,b=[x['result'] for x in pair]
        da,db=[{d['time']:d['pairs'] for d in r['decisions']} for r in (a,b)]
        different=[t for t in sorted(da.keys()|db.keys()) if da.get(t)!=db.get(t)]
        if not different:
            findings.append(dict(case=case,actions_identical=True));continue
        t=different[0]
        if not all(x[:t+1]==y[:t+1] for x,y in zip(a['paths'],b['paths'])):
            raise ValueError('Earlier physical state differs before first dispatch divergence')
        logs=[]
        for r in (a,b):
            log=max((l for l in r['search_log'] if l['time']<=t and 'previews' in l),key=lambda l:l['time'])
            logs.append({k:log[k] for k in ('time','base_score','score','changed','anchor_usage','previews','proxy_evaluations','visible_ids')})
        findings.append(dict(case=case,first_action_difference=t,physical_prefix_exact=True,
            gate_action=da.get(t),open_gate_action=db.get(t),latest_searches=logs,
            full_window_F={name:x['row']['F'] for name,x in zip(('gate','open_gate'),pair)},
            unpublished_count_at_search=[sum(j['release']>l['time'] for j in cases[case]['tasks']) for l in logs],
            note='Unpublished counts are retrospective analyst diagnostics, never passed to policy. Across-mode prediction scores have different terminal semantics.'))
    (ROOT/'results/first-divergence.json').write_text(json.dumps(findings,indent=2),encoding='utf-8')
    print(json.dumps([{k:v for k,v in x.items() if k!='latest_searches'} for x in findings]))


if __name__=='__main__':main()
