"""Package a verified candidate and its negative cases without overwriting history."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile
from paths import ROOT, hashes, sha, verify_baseline


def main():
    outputs=ROOT.parent.parent/'outputs'
    target=outputs/'agv-open-forecast-20261024'
    archive=outputs/'AGV_Open_Forecast_20261024.zip'
    if target.exists() or archive.exists():
        raise ValueError('Refuse to overwrite an existing release')
    summary=json.loads((ROOT/'results/summary.json').read_text(encoding='utf-8'))
    if summary['source'] != hashes():
        raise ValueError('Implementation changed since result audit')
    previous=outputs/'AGV_Search_Diagnosis_20261024.zip'
    old_hash='40d33f373777ae5b3ed25c50d957713fb46c3b91e37b13839a3652c5df7bcd8d'
    if sha(previous)!=old_hash:raise ValueError('Historical package changed')
    verify_baseline()
    shutil.copytree(ROOT,target,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.ruff_cache'))
    env=dict(os.environ,PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1')
    env.pop('PYTHONPATH',None)
    testlog=outputs/'open-forecast-delivered-tests.log'
    with testlog.open('w',encoding='utf-8') as stream:
        proc=subprocess.run([sys.executable,'-m','unittest','test_boundary','test_variants','-v'],
            cwd=target,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=180)
    if proc.returncode:raise ValueError('Packaged tests failed; see '+str(testlog))
    text=testlog.read_text(encoding='utf-8')
    if 'Ran 17 tests' not in text or not text.rstrip().endswith('OK'):
        raise ValueError('Unexpected test count')
    smoke=outputs/'open-forecast-delivered-smoke.json'
    with (outputs/'open-forecast-delivered-smoke.log').open('w',encoding='utf-8') as stream:
        proc=subprocess.run([sys.executable,str(target/'run_main.py'),'--case','wepa-day45-bin4335',
            '--output',str(smoke)],cwd=outputs,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=180)
    if proc.returncode:raise ValueError('Packaged main entry failed')
    produced=json.loads(smoke.read_text(encoding='utf-8'))
    expected=json.loads((target/f"results/development/traces/wepa-day45-bin4335-{summary['recommended']}-s0.json").read_text())
    keys=('paths','labels','records','decisions','search_log','T','R','D','final_stock')
    if not all(produced['result'][k]==expected['result'][k] for k in keys) or produced['scoring']!=expected['scoring']:
        raise ValueError('Packaged main entry did not reproduce recorded run')
    with (outputs/'open-forecast-delivered-audit.log').open('w',encoding='utf-8') as stream:
        proc=subprocess.run([sys.executable,'analyze.py'],cwd=target,env=env,
            stdout=stream,stderr=subprocess.STDOUT,timeout=180)
    if proc.returncode:raise ValueError('Packaged independent trace recheck failed')
    if json.loads((target/'results/summary.json').read_text()) != summary:
        raise ValueError('Packaged audit does not reproduce result summary')
    test_record=dict(tests=17,passed=True,raw_log=testlog.read_text(encoding='utf-8'),
        entry_exact_replay=True,all_experiment_traces_revalidated=summary['independently_revalidated'])
    (target/'results/delivery-verification.json').write_text(json.dumps(test_record,indent=2),encoding='utf-8')
    manifest={p.relative_to(target).as_posix():sha(p) for p in sorted(target.rglob('*')) if p.is_file()}
    (target/'MANIFEST.sha256.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(target.rglob('*')):
            if p.is_file():z.write(p,p.relative_to(target).as_posix())
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:raise ValueError('ZIP CRC failure')
        for name,digest in manifest.items():
            if hashlib.sha256(z.read(name)).hexdigest()!=digest:raise ValueError('ZIP payload hash mismatch')
    if sha(previous)!=old_hash:raise ValueError('Previous package was modified')
    receipt=dict(archive=str(archive),directory=str(target),archive_sha256=sha(archive),
        bytes=archive.stat().st_size,files=len(manifest)+1,recommended=summary['recommended'],
        targeted_tests=17,independently_revalidated=summary['independently_revalidated'],
        baseline_files_unchanged=verify_baseline(),original_package_unchanged=True,
        zip_crc_verified=True,payload_hashes_verified=True,external_cwd_main_exact_replay=True,
        github_uploaded=False)
    (outputs/'AGV_Open_Forecast_20261024.receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    print(json.dumps(receipt),flush=True)


if __name__=='__main__':main()
