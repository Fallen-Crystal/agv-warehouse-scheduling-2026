"""Recheck every physical trace and summarize paired, fixed-protocol outcomes."""
import csv
import json
from statistics import mean
from paths import ROOT, hashes, sha, verify_baseline
from objective import LinearObjective, checked_score
from wepa.data import build


def main():
    p = json.loads((ROOT/'data/protocol.json').read_text(encoding='utf-8'))
    objective = LinearObjective(**p['objective'])
    cases = {c['case']:c for c in p['cases']}
    all_rows, groups, regression = [], {}, []
    for split in ('development', 'validation'):
        folder = ROOT/'results'/split
        if not (folder/'phase-after.json').exists():
            raise ValueError('Incomplete experiment phase: '+split)
        frozen = json.loads((folder/'phase-before.json').read_text())['source']
        rows = json.loads((folder/'runs.json').read_text())
        by_case = {}
        for row in rows:
            if not row['valid']:
                raise ValueError('Invalid run cannot receive finite fitness')
            trace = json.loads((ROOT/row['trace']).read_text(encoding='utf-8'))
            if trace['implementation_sha256'] != frozen:
                raise ValueError('Run did not use phase-frozen implementation')
            if any(value != hashes()[name] for name,value in frozen.items() if name != 'data/protocol.json'):
                raise ValueError('Algorithm code changed between phases')
            model = build(cases[row['case']], **p['configuration'])
            score = checked_score(model, trace['result'], objective)
            if score != trace['scoring'] or abs(score['F_linear_v2']-row['F'])>1e-12:
                raise ValueError('Recomputed physical score differs')
            for log in trace['result']['search_log']:
                if 'previews' in log:
                    if log['previews']>6 or log['proxy_evaluations']>192:
                        raise ValueError('Unequal candidate budget')
                    usages = [log['anchor_usage']]+[c['usage'] for c in log['candidates']]
                    if any(u['route_calls']>512 for u in usages):
                        raise ValueError('Per-preview routing budget exceeded')
            if split == 'development' and row['profile'] == 'gate':
                old = ROOT/'data/control-reference'/PathName(row)
                original = json.loads(old.read_text(encoding='utf-8'))
                keys = ('paths','labels','records','decisions','T','R','D','final_stock')
                exact = all(original['result'][k]==trace['result'][k] for k in keys)
                regression.append(dict(case=row['case'], exact_physical_replay=exact))
                if not exact:
                    raise ValueError('Control changed from selected previous algorithm')
            by_case.setdefault(row['case'], {}).setdefault(row['profile'], []).append(row)
            all_rows.append(dict(split=split, **row))
        paired = []
        for name in p[split]:
            x = by_case[name]
            gate = {r['seed']:r for r in x['gate']}
            opened = {r['seed']:r for r in x['open_gate']}
            if set(gate) != set(opened):
                raise ValueError('Unpaired seeds')
            b = mean(r['F'] for r in gate.values())
            n = mean(r['F'] for r in opened.values())
            paired.append(dict(case=name, gate=b, open_gate=n, gain_percent=100*(b-n)/b,
                seeds=[dict(seed=s, gate=gate[s]['F'], open_gate=opened[s]['F'],
                    gain_percent=100*(gate[s]['F']-opened[s]['F'])/gate[s]['F']) for s in sorted(gate)]))
        aggregates = {}
        for profile in ('gate','open_gate'):
            aggregates[profile] = {k:mean(mean(r[k] for r in by_case[c][profile]) for c in p[split])
                for k in ('F','J','T','R','D','p90','empty_distance','traffic_wait','cpu','wall')}
        groups[split] = dict(cases=paired, mean_paired_gain_percent=mean(r['gain_percent'] for r in paired),
            improved_cases=sum(r['gain_percent']>1e-10 for r in paired),
            worsened_cases=sum(r['gain_percent'] < -1e-10 for r in paired), aggregates=aggregates)
    frozen = json.loads((ROOT/'results/frozen.json').read_text())
    if frozen['source'] != hashes():
        raise ValueError('Source drift after freeze')
    selected = 'open_gate' if groups['validation']['mean_paired_gain_percent']>0 else 'gate'
    output = dict(executions=len(all_rows), independently_revalidated=len(all_rows),
        baseline_files_unchanged=verify_baseline(), regression=regression, groups=groups,
        recommended=selected, source=hashes(), validation_reselection=False,
        scope='Four independent new source days, two random seeds each; no significance or global optimality claim.')
    (ROOT/'results/summary.json').write_text(json.dumps(output,indent=2),encoding='utf-8')
    with (ROOT/'results/comparison.csv').open('w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(all_rows[0])); writer.writeheader();writer.writerows(all_rows)
    print(json.dumps({k:v for k,v in output.items() if k not in ('source','groups')},ensure_ascii=False))
    print(json.dumps(groups,ensure_ascii=False))


def PathName(row):
    return f"{row['case']}-gate-s0.json"


if __name__=='__main__':
    main()
