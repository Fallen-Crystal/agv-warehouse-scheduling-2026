"""Pair by physical scene; average optimizer repeats before seed-cluster inference."""
import json
import random
import sys
from collections import defaultdict
from pathlib import Path
from statistics import mean

path=Path(sys.argv[1])
rows=[json.loads(l) for l in (path/'rows.jsonl').read_text().splitlines()]
groups=defaultdict(lambda:defaultdict(list))
for r in rows:
    groups[r['map'],r['mode'],r['seed']][r['variant']].append(r)
variants=sorted({r['variant'] for r in rows})
summary=dict(runs=len(rows),valid=sum(r['valid'] for r in rows),comparisons={})
for base in ('v1','greedy'):
    for v in variants:
        if base==v:
            continue
        for mode in ('all','static','dynamic'):
            pairs=[]
            failures=[]
            for key,g in groups.items():
                if mode!='all' and key[1]!=mode or base not in g or v not in g:
                    continue
                if not all(r['valid'] for r in g[base]+g[v]):
                    failures.append(key)
                    continue
                metrics=('F','T','R','D','nt','nr','nd','cpu_seconds','p90')
                b={k:mean(r[k] for r in g[base]) for k in metrics}
                c={k:mean(r[k] for r in g[v]) for k in metrics}
                gain=100*(b['F']-c['F'])/b['F']
                contributions=[100*w*(b[k]-c[k])/b['F'] for w,k in zip((.5,.3,.2),('nt','nr','nd'))]
                assert abs(sum(contributions)-gain)<1e-8
                pairs.append(dict(case=key,gain=gain,contributions=contributions,b=b,c=c))
            if not pairs:
                continue
            clusters=defaultdict(list)
            for p in pairs:
                clusters[p['case'][2]].append(p['gain'])
            means=[mean(g) for g in clusters.values()]
            rng=random.Random(20261022)
            bootstrap=sorted(mean(rng.choices(means,k=len(means))) for _ in range(5000))
            gains=[p['gain'] for p in pairs]
            summary['comparisons'][f'{v}/{base}/{mode}']=dict(pairs=len(pairs),failures=failures,mean_gain_pct=mean(gains),ci95=[bootstrap[124],bootstrap[4874]],seed_clusters=len(means),wins=sum(g>1e-9 for g in gains),losses=sum(g< -1e-9 for g in gains),ties=sum(abs(g)<=1e-9 for g in gains),mean_cpu_ratio=mean(p['c']['cpu_seconds']/p['b']['cpu_seconds'] for p in pairs),signed_contributions_pct={k:mean(p['contributions'][i] for p in pairs) for i,k in enumerate('TRD')},means={side:{k:mean(p[side][k] for p in pairs) for k in metrics} for side in ('b','c')},worst_cases=sorted(pairs,key=lambda p:p['gain'])[:3])
(path/'analysis.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps({k:{f:r[f] for f in ('pairs','mean_gain_pct','ci95','wins','losses','mean_cpu_ratio')} for k,r in summary['comparisons'].items() if k.endswith('/v1/all')},indent=2))
