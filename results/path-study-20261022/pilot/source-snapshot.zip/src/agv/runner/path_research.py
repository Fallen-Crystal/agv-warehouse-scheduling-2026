"""Matched actual/shadow router injection without changing production defaults."""

from agv.planning.astar import Router
from agv.planning.hybrid_routes import HybridRouter
from agv.planning.sipp import SafeIntervalRouter
from agv.policy.bcrd import fallback
from agv.policy.f_portfolio import PortfolioSearch
from agv.policy.joint_orders import JointOrderPolicy
from agv.registry import SolverSpec
from agv.runner.environment import Environment
from agv.runner.run import run as execute

ROUTES = ("sipp", "astar", "aco_sipp", "pso_sipp", "aco_astar", "pso_astar")


class PathWorldFactory:
    def __init__(self, route, *, seed=0):
        if route not in ROUTES:
            raise ValueError("Unknown research router")
        self.route, self.seed, self.actual = route, seed, None

    def router(self, kind, scene):
        if self.route in ("sipp", "astar"):
            router = (SafeIntervalRouter if self.route == "sipp" else Router)(scene)
        else:
            method, timing = self.route.split("_")
            router = HybridRouter(scene, method=method, timing=timing, seed=self.seed)
        if self.actual is None:
            self.actual = router
        return router

    def __call__(self, scenario, **options):
        return Environment(scenario, router_factory=self.router, **options)


def run(scenario, *, route="sipp", orders="portfolio", optimizer_seed=0, candidate_budget=8):
    if not scenario.is_v9_1:
        raise ValueError("Path research requires V9.1")
    factory = PathWorldFactory(route, seed=optimizer_seed)
    if orders == "portfolio":
        policy = PortfolioSearch(world_factory=factory, optimizer_seed=optimizer_seed)
    elif orders == "greedy":
        policy = None
    else:
        policy = JointOrderPolicy(
            world_factory=factory,
            mode=orders,
            optimizer_seed=optimizer_seed,
            candidate_budget=candidate_budget,
        )
    result = execute(
        SolverSpec(router="sipp"),
        scenario,
        world_factory=factory,
        action=policy.action if policy else fallback,
        on_assignment=policy.on_assignment if isinstance(policy, JointOrderPolicy) else None,
    )
    result["path_research"] = dict(
        route=route,
        orders=orders,
        optimizer_seed=optimizer_seed,
        diagnostics=getattr(factory.actual, "diagnostics", {}),
        decisions=policy.decisions if policy else [],
        commit_feedback=policy.commit_feedback if isinstance(policy, JointOrderPolicy) else [],
    )
    return result
